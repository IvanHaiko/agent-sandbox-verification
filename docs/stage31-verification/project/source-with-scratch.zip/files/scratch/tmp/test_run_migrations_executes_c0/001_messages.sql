-- A comment; with a semicolon
CREATE TABLE messages (body TEXT);
INSERT INTO messages VALUES ('one;two');
DO $migration$
BEGIN
    INSERT INTO messages VALUES ('three;four');
END;
$migration$;
