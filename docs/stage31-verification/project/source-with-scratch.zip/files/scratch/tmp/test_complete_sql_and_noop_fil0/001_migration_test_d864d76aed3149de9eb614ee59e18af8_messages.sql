-- A line comment; must not become a separate statement.
CREATE TABLE migration_test_d864d76aed3149de9eb614ee59e18af8.messages (body TEXT NOT NULL);
/* A block comment; must also remain intact. */
INSERT INTO migration_test_d864d76aed3149de9eb614ee59e18af8.messages VALUES ('one;two');
DO $migration$
BEGIN
    INSERT INTO migration_test_d864d76aed3149de9eb614ee59e18af8.messages VALUES ('three;four');
END;
$migration$;
