-- A comment-only file;
/* Another comment; */
