"""Diagnose native Unix socket access without a model call or PostgreSQL dependency."""
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import threading

from agent_system.artifacts import owned_workspace, cleanup, save, require
from agent_system.native_codex_linux import NativeLinuxCodexRunner


directory = Path('docs/stage25-verification/retry-1').resolve()
directory.mkdir(parents=True, exist_ok=True)
server_workspace = owned_workspace({'purpose.txt': 'Stage25 socket diagnosis'})
client_workspace = owned_workspace({'TASK.json': '{}', 'role-input.md': 'Controller diagnosis'})
socket_dir = server_workspace / 'socket'
socket_dir.mkdir()
socket_path = socket_dir / 'probe.sock'
server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
server.bind(str(socket_path))
server.listen(10)
server.settimeout(.3)
stop = threading.Event()
messages = []


def serve():
    while not stop.is_set():
        try:
            connection, _ = server.accept()
        except socket.timeout:
            continue
        except OSError:
            return
        with connection:
            connection.settimeout(2)
            try:
                value = connection.recv(32)
                messages.append(value.decode(errors='replace'))
                connection.sendall(b'STAGE25_OK')
            except OSError as error:
                messages.append(type(error).__name__)


thread = threading.Thread(target=serve)
thread.start()
unlisted_path = server_workspace / 'unlisted.sock'
unlisted = socket.socket(socket.AF_UNIX)
unlisted.bind(str(unlisted_path))
unlisted.listen(2)
abstract_name = '\0stage25-' + server_workspace.name
abstract = socket.socket(socket.AF_UNIX)
abstract.bind(abstract_name)
abstract.listen(2)
tcp = socket.socket()
tcp.bind(('127.0.0.1', 0))
tcp.listen(2)
try:
    runner = NativeLinuxCodexRunner()
    networks = {
        'namespace-ipc': 'enabled=true,mode="limited",domains={},dangerously_allow_all_unix_sockets=true',
    }
    for name, network in networks.items():
        socket_access = 'read'
        profile = ('{filesystem={":minimal"="read",' + json.dumps(str(runner.runtime)) + '="read",'
                   + json.dumps(str(socket_dir)) + '=' + json.dumps(socket_access)
                   + ',":workspace_roots"={"."="read"},":tmpdir"="deny",":slash_tmp"="deny"},'
                   + 'network={' + network + '}}')
        source = ('import socket, json; s=socket.socket(socket.AF_UNIX); s.settimeout(3); '
                  + 's.connect(' + repr(str(socket_path)) + '); s.sendall(b"STAGE25_PING"); '
                  + 'print(s.recv(32)); s.close(); '
                  + 'outside=socket.socket(socket.AF_UNIX); outside.settimeout(1); '
                  + 'print("unlisted_path", outside.connect_ex(' + repr(str(unlisted_path)) + ')); '
                  + 'host_abstract=socket.socket(socket.AF_UNIX); host_abstract.settimeout(1); '
                  + 'print("host_abstract", host_abstract.connect_ex(' + repr(abstract_name) + ')); '
                  + 'host_tcp=socket.socket(); host_tcp.settimeout(1); '
                  + 'print("host_tcp", host_tcp.connect_ex(' + repr(tcp.getsockname()) + '))')
        argv = ['/usr/bin/unshare', '--user', '--map-root-user', '--net',
                runner.executable, '-c', 'features.network_proxy=true', '-c',
                'permissions.stage25_probe=' + profile, 'sandbox', '--permission-profile',
                'stage25_probe', '--cd', str(client_workspace), '/usr/bin/python3', '-I', '-B', '-c', source]
        result = runner._process(argv, client_workspace, '', 20)
        result.update(profile=profile, server_messages=list(messages))
        save(directory, 'socket-' + name, result)
        print(name, json.dumps(result), flush=True)
finally:
    stop.set()
    server.close()
    thread.join(4)
    unlisted.close()
    abstract.close()
    tcp.close()
    unlisted_path.unlink(missing_ok=True)
    socket_path.unlink(missing_ok=True)
    cleanup(client_workspace)
    cleanup(server_workspace)
