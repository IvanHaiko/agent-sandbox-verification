"""Run the frozen independent suite against the unchanged fixed source as a negative control."""
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

from agent_system.artifacts import (archive, cleanup, owned_workspace, require,
                                   require_frozen, save, snapshot)
from agent_system.native_codex_linux import NativeLinuxCodexRunner
from validation.steam_workflow import fixed_source


directory = Path('docs/stage25-verification/retry-1').resolve()
assessment = json.loads((directory / 'assessment.json').read_text())
require(assessment['workflow_completed'], 'Complete primary workflow before negative control')
freeze = json.loads((directory / 'test-freeze.json').read_text())
require_frozen(directory, freeze)
require(not (directory / 'baseline-control.json').exists(), 'Negative control already consumed')
runtime = json.loads((directory / 'runtime.json').read_text())
files = fixed_source(Path('/mnt/c/Users/4ivan/steam-etl'), assessment['source_commit'])
files['tests/test_stage25_acceptance.py'] = (directory / 'frozen-acceptance.py').read_bytes()
files['scratch/.keep'] = b''
workspace = owned_workspace(files)
try:
    before = snapshot(workspace)
    runner = NativeLinuxCodexRunner(read_paths=(Path(runtime['root']) / 'python',))
    env = {'POSTGRES_HOST': runtime['socket'], 'POSTGRES_PORT': '55425', 'POSTGRES_USER': 'stage25',
           'POSTGRES_PASSWORD': 'disposable-local-only', 'POSTGRES_DB': 'stage25_unused',
           'POSTGRES_TEST_DB': 'stage25_baseline_control', 'REQUIRE_DB_TESTS': '1',
           'PYTHONDONTWRITEBYTECODE': '1', 'TMPDIR': str(workspace / 'scratch')}
    argv = ['/usr/bin/env', *[k + '=' + v for k, v in env.items()], runtime['python'], '-B', '-m',
            'pytest', '-q', '-p', 'no:cacheprovider', '--basetemp=scratch/tmp',
            '--junitxml=scratch/results.xml', 'tests/test_stage25_acceptance.py']
    result = runner.sandbox(workspace, argv, writable_directory='scratch', timeout=180,
                            database_socket_directory=runtime['socket'])
    archive(directory, 'baseline-control-stdout.txt', result['stdout'].encode())
    archive(directory, 'baseline-control-stderr.txt', result['stderr'].encode())
    junit = (workspace / 'scratch/results.xml').read_bytes()
    archive(directory, 'baseline-control.xml', junit)
    cases = list(ET.fromstring(junit).iter('testcase'))
    failed = [t.get('name') for t in cases if t.find('failure') is not None]
    design = json.loads((directory / 'frozen-test-design.json').read_text())
    membership_tests = {c['test'] for c in design['cases'] if c['requirement'] == 'membership'}
    membership_caught = any(name.split('[')[0] in membership_tests for name in failed)
    shutil.rmtree(workspace / 'scratch')
    (workspace / 'scratch').mkdir()
    archive(workspace / 'scratch', '.keep', b'')
    require(snapshot(workspace) == before, 'Negative control mutated fixed project files')
    require_frozen(directory, freeze)
    receipt = {'returncode': result['exit_code'], 'tests': len(cases), 'failures': failed,
        'membership_defect_detected': membership_caught,
        'shutdown_confirmed': result['owned_process_group_ended'], 'timed_out': result['timed_out'],
        'workspace_unchanged': True, 'model_requests': 0,
        'purpose': 'Unchanged source, same frozen independent tests; an expected failing control, not a candidate retry'}
    save(directory, 'baseline-control', receipt)
    print(json.dumps(receipt, indent=2), flush=True)
    require(result['exit_code'] == 1 and membership_caught and result['owned_process_group_ended']
            and not result['timed_out'], 'Independent tests did not demonstrate rejection of the original membership defect')
finally:
    cleanup(workspace)
