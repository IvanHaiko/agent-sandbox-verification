"""Explicit Controller continuation after pytest environment failed before test collection.

Never reruns a model role, edits a candidate, or changes the frozen independent suite.
"""
import json
from pathlib import Path
import time

from agent_system.artifacts import archive, cleanup, digest, require, require_frozen, save
from agent_system.native_codex_linux import NativeLinuxCodexRunner
from validation.steam_workflow import acceptance_and_review, fixed_source, source_fingerprint


directory = Path('docs/stage25-verification/retry-1').resolve()
repository = Path('/mnt/c/Users/4ivan/steam-etl')
assessment = json.loads((directory / 'assessment.json').read_text())
require(assessment.get('failed_stage') == 'acceptance' and
        assessment.get('acceptance', {}).get('independent_tests') == 0,
        'Only a pre-collection environment failure can continue through this command')
require(not (directory / 'acceptance-continuation.json').exists(), 'Continuation already consumed')
require(not any(r['role'] == 'reviewer' for r in assessment['roles']), 'Reviewer already ran')
for role in ('implementer', 'independent_tester'):
    record = next(r for r in assessment['roles'] if r['role'] == role)
    require(record['execution_status'] == 'completed' and record['shutdown_confirmed']
            and record['cleanup_passed'], 'Required completed role evidence missing')
freeze = json.loads((directory / 'test-freeze.json').read_text())
require_frozen(directory, freeze)
candidate_manifest = json.loads((directory / 'candidate-manifest.json').read_text())
candidate = {p: (directory / 'candidate' / p).read_bytes() for p in candidate_manifest}
require({p: digest(b) for p, b in candidate.items()} == candidate_manifest, 'Candidate bytes changed')
patch = (directory / 'steam-etl-implementation.patch').read_bytes()
require(digest(patch) == assessment['patch_sha256'], 'Patch changed')
canonical = json.loads((directory / 'normalized-contract.json').read_text())
normalization = json.loads((directory / 'contract-normalization.json').read_text())
require(normalization['canonical_sha256'] == digest((directory / 'normalized-contract.json').read_bytes()),
        'Canonical contract changed')
original = json.loads((directory / 'original-before.json').read_text())
require(source_fingerprint(repository) == original, 'Original repository changed')
files = fixed_source(repository, assessment['source_commit'])
manifest = json.loads((directory / 'source-manifest.json').read_text())
require({p: digest(b) for p, b in files.items()} == manifest['files'], 'Pinned source changed')
runtime = json.loads((directory / 'runtime.json').read_text())
design = json.loads((directory / 'frozen-test-design.json').read_text())
for filename in ('assessment.json', 'acceptance.json', 'acceptance-stdout.txt', 'acceptance-stderr.txt',
                 'candidate-exposure.json', 'controller-decision.json'):
    if (directory / filename).exists():
        archive(directory, 'environment-failure-' + filename, (directory / filename).read_bytes())
save(directory, 'acceptance-continuation', {'started_at': time.time(), 'model_roles_retried': 0,
    'candidate_changed': False, 'frozen_tests_changed': False, 'design_sha256': freeze['design_sha256'],
    'harness_sha256': freeze['harness_sha256'], 'patch_sha256': digest(patch),
    'reason': 'First pytest process failed before collection because native temporary dirs were denied. Correct Controller TMPDIR and localize pinned dependencies; continue same frozen artifacts with the single outstanding Reviewer.'})
for key in ('failed_stage', 'failure_type', 'failure_reason', '_active_stage'):
    assessment.pop(key, None)
assessment['failure_category'] = None
assessment['environment_startup_failure_preserved'] = True
owned = []
try:
    runner = NativeLinuxCodexRunner(read_paths=(Path(runtime['root']) / 'python',))
    env = {'POSTGRES_HOST': runtime['socket'], 'POSTGRES_PORT': '55425', 'POSTGRES_USER': 'stage25',
           'POSTGRES_PASSWORD': 'disposable-local-only', 'POSTGRES_DB': 'stage25_unused',
           'POSTGRES_TEST_DB': 'stage25_acceptance', 'REQUIRE_DB_TESTS': '1',
           'PYTHONDONTWRITEBYTECODE': '1'}
    acceptance_and_review(runner, directory, files, candidate, patch, canonical, freeze,
                          design, runtime, assessment, owned, env)
except Exception as error:
    assessment.update(accepted=False, failed_stage=assessment.get('_active_stage', 'acceptance'),
        failure_category='continued_frozen_acceptance_failed', failure_type=type(error).__name__,
        failure_reason=str(error)[:1000])
finally:
    failures = []
    for workspace in owned:
        if workspace.exists():
            try:
                cleanup(workspace)
            except Exception as error:
                failures.append(str(error))
    assessment['owned_workspaces'].extend(str(p) for p in owned)
    assessment['cleanup_failures'] = failures
    assessment['cleanup_passed'] = not failures and all(not Path(p).exists()
                                                     for p in assessment['owned_workspaces'])
    after = source_fingerprint(repository)
    save(directory, 'original-after', after)
    assessment['original_unchanged'] = after == original
    assessment['accepted'] = assessment['accepted'] and assessment['cleanup_passed'] and after == original
    assessment['outcome'] = 'PASS' if assessment['accepted'] else 'FAIL'
    assessment['elapsed_seconds'] = round(time.time() - assessment['started_at'], 3)
    assessment.pop('_active_stage', None)
    save(directory, 'assessment', assessment)
    save(directory, 'controller-decision', {k: assessment[k] for k in
        ('outcome', 'accepted', 'workflow_completed', 'cleanup_passed', 'original_unchanged', 'failure_category')})
print(json.dumps({k: v for k, v in assessment.items() if k not in ('roles', 'review')}, indent=2))
raise SystemExit(0 if assessment['accepted'] else 1)
