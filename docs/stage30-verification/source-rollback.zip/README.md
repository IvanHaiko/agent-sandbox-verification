# Native WSL Codex artifact workflows

The preferred backend is native Codex inside Linux/WSL. The Controller owns the task,
canonical contract, artifacts, handoff, test freeze, acceptance and final decision.
Each role runs in a fresh private Git repository and a fresh ephemeral native Codex
context. Roles share artifacts selected by the Controller; they inherit no conversation
history. Native failure is explicit and never selects another backend.

For a small bounded task:

```text
Implementer → Controller artifact validation and handoff
            → blind Independent Tester → frozen design and harness
            → Controller deterministic acceptance → decision → cleanup
```

The Implementer workspace is removed before Tester execution. The Tester receives
only the canonical task, public interface, criteria, constraints and design schema.
It receives no candidate, source stub, diff, handoff or previous role history.
Only after Tester shutdown and the design/harness freeze does the Controller expose
its candidate to a separate read-only acceptance workspace. The Controller generates
the harness from frozen Tester data and executes it without a model call. Artifact
hashes, interface checks, exact mutation scope and frozen task/design/harness hashes
must agree. Cleanup must pass before the final decision accepts the result.

Architect and Reviewer are optional. Architect helps clarify ambiguous or complex
requirements; its read-only output is a proposal which the Controller normalizes,
preserving every original task field. Reviewer provides read-only static review of
the contract, candidate diff, handoff and frozen acceptance evidence. Its rejection
blocks acceptance. Small tasks need neither role. A Data Auditor is not implemented
in the current native workflow; add one only when an actual task justifies it.

## Active source

| File | Responsibility |
|---|---|
| `agent_system/controller.py` | One implementation/Tester/acceptance sequence and final cleanup-bound decision |
| `agent_system/native_codex_linux.py` | Native discovery/login prerequisite, permission profile, preflight, ephemeral execution, owned process shutdown and sanitized execution receipts |
| `agent_system/test_environment.py` | Optional Controller-owned predefined pytest/Ruff checks for a network-disabled Implementer, using the existing native contained execution path |
| `agent_system/artifacts.py` | Hashes, complete repository snapshots/diffs, owned workspace creation/removal and test freeze verification |
| `agent_system/roles.py` | Optional semantic role schemas/instructions, read-only execution through the same runner and Controller normalization validation |
| `validation/labels_contract.py` | Bounded label-normalization integration fixture, schemas, interface validation and deterministic harness |
| `validation/native_workflow.py` | The single small integration driver |

There is no custom inference transport, OAuth session logic, relay, Docker backend,
Windows native runner, model routing experiment or backend plugin framework in the
active package. The former `agentctl` CLI, task formats and configuration belong to
the archived framework; this package exposes `run_workflow` as its current Python API.
The integration driver runs from the source checkout.

## Run and verify

Use Python 3.11+, Git, an installed native Linux Codex CLI, and its native login.
The supported execution route is **gpt-6.1-sol / medium**. Run these commands in the
WSL source checkout:

```bash
python3 -m pip install -e '.[dev]'
python3 -m pytest -q -p no:cacheprovider
python3 -m validation.native_workflow minimal --evidence docs/local-verification/minimal
```

The integration command consumes real model quota. The tests consume none. Use a
fresh evidence directory; a completed workflow is never silently replayed or retried.
Linux workspace and process lifecycle tests are verified in WSL and explicitly
skipped on Windows.

The optional full chain uses the same driver:

```bash
python3 -m validation.native_workflow prepare-full --evidence docs/local-verification/full
# Controller reviews architect-result.json and records normalization as described below.
python3 -m validation.native_workflow full --evidence docs/local-verification/full
```

Between preparation and execution the Controller writes `normalized-contract.json`
with all original task fields unchanged, optionally adding reviewed `clarifications`
and `risks`. It writes `contract-normalization.json` containing `authority: "Controller"`,
`original_criteria_preserved: true` and `canonical_sha256`, the SHA-256 of the exact
normalized file bytes. `load_canonical` verifies the original fields, allowed keys,
authority and digest before implementation. The driver also verifies the prepared
Architect proposal digest. Architect/Reviewer use native `--output-schema` and
`--output-last-message`; array constraints use scalar enums and fixed lengths,
followed by complete ordered-list validation by the Controller.

## Isolation, receipts and cleanup

Native execution uses `--no-daemon`, `--ephemeral`, `--ignore-user-config`, the exact
model/effort and disabled subagents/web search. Inherited API credentials, chat IDs
and the app pipe are removed. Authentication remains owned by native Codex; the
Controller never copies login material into role inputs.

The permission profile grants minimal runtime reads and workspace reads, a bounded
artifact subtree for Implementer/Tester, and no role workspace writes for semantic
roles. Project network and temporary-directory access are denied. Preflights verify
read-only inputs and forbidden candidate reads. Complete snapshots include Git
metadata and reject linked entries. Every role output must pass scope/artifact checks,
an exact resolved-model check, a native session identity and confirmed owned process
shutdown. Receipts retain hashes, routing, timing and sanitized native diagnostics;
they discard narration, reasoning and raw tool output.

Each owned repository is a distinct `codex-role-*` directory under the Linux user's
home. Roles are cleaned immediately after artifact collection, and a final cleanup
pass handles failures. Evidence stays in Controller directories. Cleanup failure
blocks acceptance.

This is the bounded architecture validated with the label-normalization fixture.
The evidence does not establish arbitrary project support, dependency-heavy tasks,
host-wide write containment or general abnormal-runtime recovery. Such behavior is
not added by this cleanup.

Stage 25 completed a fixed-commit Steam ETL coding challenge through Architect,
Implementer, blind Independent Tester, Controller acceptance and read-only Reviewer.
The [final assessment is PASS](STAGE25_REAL_WORLD_CODING_ASSESSMENT.md): 234 candidate
tests passed with real PostgreSQL, including 29 independent acceptance tests, and
40 framework regression tests passed. The same frozen independent suite found
22 failures on the unchanged source. The original repository stayed unchanged;
a clean patch, test evidence and Reviewer result are retained.

`validation.steam_workflow` is a task-specific real-repository driver with `prepare`
and `run` modes, accepting `--repository`, `--commit`, `--contract` and `--evidence`.
Preparation produces the Architect proposal for Controller normalization. Running
requires that normalization and a provisioned runtime receipt; the documented
experiment used `validation.steam_runtime` for disposable pinned dependencies and
native PostgreSQL. This is a bounded repository integration, not a generic task DSL.

The first failed attempt remains archived. The user-authorized retry required manual
IPC, Python dependency and temporary-directory setup, followed by one explicit
acceptance startup continuation with unchanged candidate and frozen tests. Model
commands retain network disabled. Controller database commands use a fresh user/network
namespace and native filesystem sandbox exposing the owned Unix socket directory;
the explicit Unix-syscall capability and its limits are described in the assessment.
No automatic model retries or alternate execution backend were introduced.

Stage 26 delivered a Steam Store preparation/persistence refactoring and working
Implementer functional checks, but its [final assessment is PARTIAL](STAGE26_AUTONOMOUS_REFACTORING_ASSESSMENT.md).
The exact candidate passed 210 project tests with PostgreSQL and Ruff. Independent
Tester artifact validation failed, and the driver cleaned rejected outputs before
archiving them; no frozen independent acceptance or mutation-control result exists.
The Reviewer confirmed useful engineering value but rejected experiment acceptance
for that missing evidence. The original native FAIL remains preserved. There was
one Controller failure closeout, no role retry and no original checkout modification.

The optional Implementer check facility keeps model network permissions disabled.
The role requests only Controller-defined check names through its workspace; the
Controller invokes the existing native sandbox in a private user/network namespace
with the owned disposable database socket. Final candidate hashes must match the
successful check receipts. Private runtime provisioning explicitly installs pinned
dependencies rather than relying on global packages outside sandbox visibility.
`validation.steam_refactoring` records this bounded experiment. Its post-experiment
collection-order correction preserves unvalidated Tester bytes before future cleanup;
it was not used to rerun or change the recorded failed trial.

## History and rollback

[Historical assessments](docs/history/README.md) are separate from the current system.
The complete former source, tests, configurations and evidence are preserved in
`docs/history/pre-cleanup.zip` with original relative paths and verified entry hashes.
Final assessments and evidence for Stages 20–23 also remain readable under
`docs/history/`. The old backend is an inert manual rollback snapshot, outside Python
imports and package discovery. Restoring it requires an explicit separate checkout;
native failures never invoke it automatically. This workspace has no Git metadata.

The cleanup inventory, exact dispositions, size changes and verification results are
in [STAGE24_ARCHITECTURE_CLEANUP.md](STAGE24_ARCHITECTURE_CLEANUP.md).
