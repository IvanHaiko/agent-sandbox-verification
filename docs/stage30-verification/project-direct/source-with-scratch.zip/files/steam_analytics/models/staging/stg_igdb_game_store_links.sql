SELECT
    igdb_game_id,
    store,
    store_game_id
FROM igdb_game_store_links