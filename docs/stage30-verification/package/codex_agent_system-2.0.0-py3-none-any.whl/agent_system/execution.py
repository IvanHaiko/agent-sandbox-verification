"""Narrow Linux CLI permissions and owned process lifetime; no role scheduling."""
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess


def environment():
    blocked = {'OPENAI_API_KEY', 'OPENAI_BASE_URL', 'OPENAI_ORG_ID', 'OPENAI_PROJECT_ID',
               'CODEX_API_KEY', 'CODEX_ACCESS_TOKEN', 'CODEX_THREAD_ID', 'CODEX_SESSION_ID',
               'CODEX_APP_TOOLS_PIPE_PATH', 'CODEX_PERMISSION_PROFILE',
               'CODEX_INTERNAL_ORIGINATOR_OVERRIDE', 'PYTHONPATH', 'PYTHONHOME'}
    return {k: v for k, v in os.environ.items() if k.upper() not in blocked}


def process(argv, workspace, *, prompt='', timeout=180):
    """Capture actual exit/timeout and kill descendants in this owned process group."""
    if os.name != 'posix':
        raise RuntimeError('Restricted execution requires Linux/WSL')
    child = subprocess.Popen([str(a) for a in argv], cwd=workspace, env=environment(),
                             stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             text=True, encoding='utf-8', errors='replace', start_new_session=True)
    timed_out = False
    forced = False
    try:
        try:
            stdout, stderr = child.communicate(prompt, timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(child.pid, signal.SIGTERM)
            try:
                stdout, stderr = child.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                stdout, stderr = child.communicate(timeout=5)
        try:
            os.killpg(child.pid, 0)
        except ProcessLookupError:
            ended = True
        else:
            os.killpg(child.pid, signal.SIGKILL)
            forced, ended = True, False
        return {'exit_code': child.returncode, 'timed_out': timed_out,
                'owned_process_group_ended': ended, 'descendants_killed': forced,
                'stdout': stdout, 'stderr': stderr}
    finally:
        if child.poll() is None:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait(timeout=5)


def permissions(*, writable=(), read_paths=(), database_socket=None):
    """Installed native named profile. Probe it before launching strict roles."""
    executable = shutil.which('codex')
    if not executable or os.name != 'posix':
        raise RuntimeError('Installed Linux Codex required; no fallback')
    runtime = Path(executable).resolve().parent.parent
    access = {'.': 'read'}
    for name in writable:
        p = Path(name)
        if p.is_absolute() or '..' in p.parts or name in ('', '.'):
            raise ValueError('Writable access must name a bounded subtree')
        access[p.as_posix()] = 'write'
    reads = {':minimal': 'read', str(runtime): 'read'}
    for path in read_paths:
        reads[str(Path(path).resolve(strict=True))] = 'read'
    network = 'enabled=false'
    if database_socket is not None:
        socket = Path(database_socket).resolve(strict=True)
        if (not socket.is_dir() or socket.name != 'socket' or
                socket.parent.parent != Path.home().resolve() or
                not (socket.parent / '.codex-owned').is_file()):
            raise ValueError('Database socket must be in an owned private workspace')
        reads[str(socket)] = 'read'
        # CLI 0.160.1 needs AF_UNIX creation enabled. A separate network namespace
        # prevents TCP access; filesystem policy exposes only this socket path.
        network = 'enabled=true,mode="limited",domains={},dangerously_allow_all_unix_sockets=true'
    entries = ','.join(json.dumps(k) + '=' + json.dumps(v) for k, v in reads.items())
    scoped = ','.join(json.dumps(k) + '=' + json.dumps(v) for k, v in access.items())
    profile = ('{filesystem={' + entries + ',":workspace_roots"={' + scoped +
               '},":tmpdir"="deny",":slash_tmp"="deny"},network={' + network + '}}')
    args = ['-c', 'default_permissions="bounded"', '-c', 'permissions.bounded=' + profile]
    if database_socket is not None:
        args += ['-c', 'features.network_proxy=true']
    return args


def sandbox(workspace, argv, *, writable=(), read_paths=(), database_socket=None, timeout=180):
    namespace = ['/usr/bin/unshare', '--user', '--map-root-user', '--net'] if database_socket else []
    return process([*namespace, shutil.which('codex'),
                    *permissions(writable=writable, read_paths=read_paths, database_socket=database_socket),
                    'sandbox', '--permission-profile', 'bounded', '--cd', str(workspace), *argv],
                   workspace, timeout=timeout)


def command(workspace, *, writable=(), read_paths=(), output=None):
    """Native exec owns auth/model/settings and structured events, never a wrapper role."""
    argv = [shutil.which('codex'), '--no-daemon', '-a', 'never', 'exec', '--ignore-user-config',
            '--ephemeral', '--json', '--color', 'never', '--skip-git-repo-check', '--cd', str(workspace),
            '-c', 'shell_environment_policy.inherit="core"', '-c', 'features.multi_agent=false',
            '-c', 'web_search="disabled"', *permissions(writable=writable, read_paths=read_paths)]
    if output is not None:
        output = Path(output).absolute()
        if output.exists() or output.is_relative_to(Path(workspace).resolve()):
            raise ValueError('Last-message output must be fresh and outside worker inputs')
        argv += ['--output-last-message', str(output)]
    return [*argv, '-']
