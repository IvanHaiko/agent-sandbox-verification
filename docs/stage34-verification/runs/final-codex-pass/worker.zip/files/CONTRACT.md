Protected role input; read-only for workers. Control CANARY-80417ebe4229026ede98120221133834
