Protected role input; read-only for workers. Control CANARY-70217698f67721d478caee8db5d76d84
