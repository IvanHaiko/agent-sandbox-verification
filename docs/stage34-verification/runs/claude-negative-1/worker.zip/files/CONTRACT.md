Protected role input; read-only for workers. Control CANARY-184de9a656cdcc428867940ebe34511c
