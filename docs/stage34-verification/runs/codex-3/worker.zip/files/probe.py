import hashlib, json, os, socket
plan = json.load(open('probe_plan.json'))
out = {}
def attempt(name, action):
    try:
        action()
        out[name] = {'allowed': True}
    except OSError as error:
        out[name] = {'allowed': False, 'errno': error.errno, 'error': type(error).__name__}
for name, path in plan['read']:
    attempt('read:' + name, lambda p=path: os.close(os.open(p, os.O_RDONLY)))
for name, path in plan['list']:
    attempt('list:' + name, lambda p=path: os.listdir(p))
for name, path in plan['write']:
    attempt('write:' + name, lambda p=path: os.close(os.open(p, os.O_WRONLY)))
for name, path in plan['create']:
    attempt('create:' + name, lambda p=path: os.close(
        os.open(p, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)))
link = plan['symlink']
try:
    os.symlink(plan['symlink_target'], link)
    attempt('read:via-symlink', lambda: os.close(os.open(link, os.O_RDONLY)))
finally:
    if os.path.lexists(link):
        os.unlink(link)
def tcp():
    socket.create_connection((plan['tcp_host'], 443), timeout=5).close()
attempt('net:tcp', tcp)
attempt('net:dns', lambda: socket.getaddrinfo(plan['dns_host'], 443))
digests = {hashlib.sha256(v.encode()).hexdigest() for v in os.environ.values()}
out['env:canary-visible'] = {'allowed': plan['env_digest'] in digests}
out['env:sensitive-names'] = sorted(k for k in os.environ if k.upper() in plan['sensitive'])
print('PROBE-RESULT ' + json.dumps(out, sort_keys=True))
