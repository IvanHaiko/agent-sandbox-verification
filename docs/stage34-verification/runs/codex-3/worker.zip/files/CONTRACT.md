Protected role input. Workers may read but never modify it.
