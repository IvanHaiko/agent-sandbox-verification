Protected role input; read-only for workers. Control CANARY-36d6f3afb1be1888f3b4909cae651eb7
