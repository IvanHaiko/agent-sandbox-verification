Protected role input; read-only for workers. Control CANARY-caf070b1b8e745c42103b3f7404ce632
