Protected role input; read-only for workers. Control CANARY-354cabb7f58ebc98cb1875f214b48257
