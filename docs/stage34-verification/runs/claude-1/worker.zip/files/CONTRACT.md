Protected role input; read-only for workers. Control CANARY-754a24578bff86283b87ce41415666b0
