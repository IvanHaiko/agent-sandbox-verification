Protected role input; read-only for workers. Control CANARY-ab5abb095fc879efbe633de7bf5bdc85
