Protected role input; read-only for workers. Control CANARY-b827ca554abb0c16ea599afbe5047e50
