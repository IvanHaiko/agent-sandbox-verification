Protected role input; read-only for workers. Control CANARY-d210f971c8621ec5c3632f99a240ea5b
