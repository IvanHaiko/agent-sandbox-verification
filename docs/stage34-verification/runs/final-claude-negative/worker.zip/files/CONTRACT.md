Protected role input; read-only for workers. Control CANARY-38ba3d56a6a998d6539e956e5d12570e
