import hashlib, json, os, socket, subprocess
from urllib.parse import urlsplit
plan = json.load(open('probe_plan.json'))
out = {}
def attempt(name, action):
    try:
        result = action()
        out[name] = {'allowed': True if result is None else bool(result)}
    except (OSError, subprocess.SubprocessError, ValueError) as error:
        out[name] = {'allowed': False, 'errno': getattr(error, 'errno', None),
                     'error': type(error).__name__}
for name, path in plan['read']:
    attempt('read:' + name, lambda p=path: os.close(os.open(p, os.O_RDONLY)))
for name, path in plan['list']:
    attempt('list:' + name, lambda p=path: os.listdir(p) and None)
for name, path in plan['write']:
    attempt('write:' + name, lambda p=path: os.close(os.open(p, os.O_WRONLY)))
for name, path in plan['create']:
    attempt('create:' + name, lambda p=path: os.close(
        os.open(p, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)))
link = plan['symlink']
try:
    os.symlink(plan['symlink_target'], link)
    attempt('read:via-symlink', lambda: os.close(os.open(link, os.O_RDONLY)))
finally:
    if os.path.lexists(link):
        os.unlink(link)
def tcp():
    socket.create_connection((plan['tcp_host'], 443), timeout=5).close()
attempt('net:tcp', tcp)
attempt('net:dns', lambda: socket.getaddrinfo(plan['dns_host'], 443) and None)
proxy = next((os.environ[k] for k in ('HTTPS_PROXY', 'https_proxy', 'HTTP_PROXY', 'http_proxy')
              if os.environ.get(k)), None)
out['net:proxy-configured'] = bool(proxy)
def via_proxy(host):
    if not proxy:
        raise ConnectionRefusedError(111, 'no HTTP proxy configured')
    url = urlsplit(proxy if '://' in proxy else 'http://' + proxy)
    with socket.create_connection((url.hostname, url.port or 80), timeout=5) as conn:
        conn.sendall(f'CONNECT {host}:443 HTTP/1.1\r\nHost: {host}:443\r\n\r\n'.encode())
        status = conn.recv(256).split(b'\r\n')[0]
    out['net:proxy-status-' + host] = status.decode('latin-1')
    return b' 200' in status
attempt('net:proxy-example', lambda: via_proxy(plan['dns_host']))
attempt('net:proxy-anthropic', lambda: via_proxy('api.anthropic.com'))
for name, path in plan.get('unix', []):
    def unix(p=path):
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as conn:
            conn.settimeout(5)
            conn.connect(p)
    attempt('unix:' + name, unix)
if plan.get('windows_exe'):
    def windows():
        run = subprocess.run([plan['windows_exe'], '/c', 'echo', 'PROBE-PWN'],
                             capture_output=True, timeout=20)
        return run.returncode == 0 and b'PROBE-PWN' in run.stdout
    attempt('exec:windows-interop', windows)
out['env:parent-canary-visible'] = {'allowed': False}
def parent_environ():
    data = open(f"/proc/{plan['parent_pid']}/environ", 'rb').read()
    values = {hashlib.sha256(x.split(b'=', 1)[1]).hexdigest() for x in data.split(b'\0') if b'=' in x}
    out['env:parent-canary-visible'] = {'allowed': plan['env_digest'] in values}
attempt('proc:parent-environ', parent_environ)
attempt('proc:sibling-cwd', lambda: os.close(
    os.open(f"/proc/{plan['sibling_pid']}/cwd/candidate.txt", os.O_RDONLY)))
digests = {hashlib.sha256(v.encode()).hexdigest() for v in os.environ.values()}
out['env:canary-visible'] = {'allowed': plan['env_digest'] in digests}
out['env:sensitive-names'] = sorted(k for k in os.environ if k.upper() in plan['sensitive'])
print('PROBE-RESULT ' + json.dumps(out, sort_keys=True))
