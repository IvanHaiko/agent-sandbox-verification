Protected role input; read-only for workers. Control CANARY-f256db0bbf54a7055e19261084143a4d
