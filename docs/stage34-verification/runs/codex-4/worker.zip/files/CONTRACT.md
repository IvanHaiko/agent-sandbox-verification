Protected role input; read-only for workers. Control CANARY-8400c7d903eb92806dc1ae4dd6f48541
