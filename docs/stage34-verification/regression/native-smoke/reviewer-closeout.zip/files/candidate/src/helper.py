def clamp(x, lo, hi):
    if lo > hi:
        raise ValueError("lo must be less than or equal to hi")
    if x < lo:
        return lo
    if x > hi:
        return hi
    return x
