"""Append all-Sol continuation results without erasing Stage22 history."""
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'validation')]
import stage21_workflow as s
OUT=ROOT/'docs/stage22-sol56-evidence'


def main():
    qualification=s.load(OUT/'qualification.json')
    campaign=s.load(OUT/'campaign.json') if (OUT/'campaign.json').exists() else {'trials':[],'completed':False}
    cleanup=s.load(OUT/'final-cleanup.json')
    attempts=qualification['attempts']; trials=campaign['trials']
    roles=[r for a in attempts+trials for r in a['roles']]
    models={m:sum(r['requests'] for r in roles if r['model']==m) for m in
        ('gpt-5.6-sol','gpt-6.1-sol','gpt-6-sol','gpt-5.6-luna','gpt-5.6-terra','gpt-6-astra')}
    s.require(all(r['model']=='gpt-5.6-sol' and r['reasoning']=='medium' for r in roles),'Unexpected role route')
    s.require(models['gpt-6-astra']==0,'Astra prohibition violated')
    rows=[]
    for a in attempts:
        artifact=(OUT/('qualification-'+str(a['attempt']))/'qualification-design-result.json').exists()
        row={**a,'artifact_received':artifact,
            'schema_valid':a.get('validation',{}).get('schema_domain_valid') if artifact else None,
            'contract_valid':a['valid'] if artifact else None,
            'requests':sum(r['requests'] for r in a['roles'])}
        rows.append(row)
    accepted=sum(t['accepted'] for t in trials)
    completed=sum(t['workflow_completed'] for t in trials)
    longest=streak=0
    for a in attempts:
        streak=streak+1 if a['valid'] else 0
        longest=max(longest,streak)
    verdict=('STAGE22_ALL_SOL56_PROGRESSIVE_COMPLETED' if campaign['completed'] else
        'STAGE22_ALL_SOL56_STOP_QUALIFICATION_FAILED' if not qualification['qualified'] else
        'STAGE22_ALL_SOL56_STOP_WORKFLOW_FAILED')
    result={'verdict':verdict,'route':'gpt-5.6-sol','reasoning':'medium',
        'all_roles_requested':True,'qualification_attempts':rows,
        'consecutive_valid_designs':qualification['consecutive_valid_designs'],
        'maximum_consecutive_valid_designs':longest,
        'qualified':qualification['qualified'],'workflow_trials':trials,
        'trustworthy_workflows_completed':accepted,'operational_workflows_completed':completed,
        'inference_requests_by_model':models,'total_requests':sum(models.values()),
        'role_executions':len(roles),'tool_calls':sum(r['tool_calls'] for r in roles),
        'reviewer_runs':sum(r['role']=='reviewer' for r in roles),
        'architect_runs':sum(r['phase']=='architecture' for r in roles),'data_auditor_runs':0,
        'candidate_exposures':sum(t['acceptance_reached'] for t in trials),
        'catalog_sha256':s.sha(OUT/'catalog.json'),'cleanup':cleanup,
        'semantic_quality_evaluable':any(a['artifact_received'] for a in rows),
        'oracle_used':False,'frozen_expectations_rewritten':False}
    s.atomic_json(OUT/'assessment.json',result)
    root_json=ROOT/'STAGE22_SIMPLIFIED_EXECUTION_ASSESSMENT.json'
    history=s.load(root_json); history['all_sol56_continuation']=result; s.atomic_json(root_json,history)
    table='\n'.join('| {attempt} | {requests} | {cases} | {schema} | {contract} | {freeze} | {reason} | {clean} |'.format(
        **a,schema='not assessed' if a['schema_valid'] is None else str(a['schema_valid']),
        contract='not assessed' if a['contract_valid'] is None else str(a['contract_valid']),
        freeze=a['freezeable'],reason=a['failure_category'] or '; '.join(a.get('validation',{}).get('violations',[])) or 'none',
        clean=a['cleanup_passed']) for a in rows)
    workflow_table='\n'.join(f"| {t['trial_id']} | {t['candidate_sha256']} | {t['frozen_tester_sha256']} | {sum(r['requests'] for r in t['roles'])} | {t['acceptance_reached']} | {t['accepted']} | {t['cleanup_result']} |" for t in trials)
    if not trials: workflow_table='No revised workflow started: the independent Tester qualification prerequisite did not pass.'
    elif trials: workflow_table='| Trial | Candidate SHA256 | Frozen design SHA256 | Requests | Acceptance executed | Accepted | Cleanup |\n|---|---|---|---:|---|---|---|\n'+workflow_table
    txt=f'''\n\n---

# Stage22 continuation — all roles on Sol 5.6 medium

**{verdict}**. The user's latest instruction explicitly overrides the earlier asymmetric route: Implementer, Independent Tester, Reviewer and Architect are configured to use **`gpt-5.6-sol / medium`**. Phase prerequisites remain in place; configured roles are counted as executed only when actually invoked. Astra inference requests: **0**.

The connected account exposes this exact route and effort. [Catalog](docs/stage22-sol56-evidence/catalog.json), [structured assessment](docs/stage22-sol56-evidence/assessment.json). The existing artifact executor and frozen contract were preserved. Historical trials and assessments remain separate and do not count toward this continuation.

## N. Sol 5.6 medium Tester qualification

Fresh independent attempts: **{len(attempts)}**. Longest valid/freezable streak: **{longest}**, required: **3**; final streak: **{qualification['consecutive_valid_designs']}**. Qualified: **{qualification['qualified']}**. Every context receives only the frozen task/interface/criteria/domain/constraints. No candidate, diff, Implementer output, previous design/error or corrected expectation is supplied. Each attempt uses a new role home and baseline checkout.

| Attempt | Model requests | Cases in complete artifact | Schema valid | Contract valid | Freezeable | Rejection/failure | Cleanup passed |
|---:|---:|---:|---|---|---|---|---|
{table}

Incomplete transport artifacts are qualification failures, but are **not evidence of incorrect expected values**. Schema and semantics are marked not assessed when no complete design exists. Qualification attempts are bounded by five; no silent route substitution or transport hardening was made. The first failure remains in the record; all remaining authorized attempts used fresh contexts. The final stream failure hit the existing body deadline before validated completion (body_deadline).

The pre-freeze gate checks schema, ASCII domain, unique IDs, nonempty/lowercase/deduplicated expected labels and the empty-input rule. When a complete design arrives, explicit Controller contract reasoning examines every case before freeze. It never executes a candidate as an oracle and does not use the previous Controller task interpreter. Complex disagreements remain frozen evidence for independent execution/review; expectations are never silently rewritten.

## O. Revised minimal workflows

Trustworthy accepted workflows: **{accepted}**; operational completions: **{completed}**. Prior Stage22 workflows contribute zero to the new three-run prerequisite. No second Tester narration is introduced. The preserved Implementer path ends at one successful permitted write and receives a Controller artifact handoff; it was not invoked in this continuation.

{workflow_table}

## P. Preserved Tester comparison

| Route | Observed result | Supported conclusion |
|---|---|---|
| Previous Luna low | Unicode and quoted-uppercase contradiction | Rejected before freeze. |
| Previous Luna medium | One accepted workflow; one frozen expectation dropped literal `b` | Semantic quality was inconsistent in that sample. |
| Previous Terra medium | Timeout before valid design | Semantic quality not evaluated. |
| Current Sol 5.6 medium | {len(attempts)} qualification attempts, {sum(a['artifact_received'] for a in rows)} complete designs | {'Contract validity observations are recorded above; this is a small sample.' if any(a['artifact_received'] for a in rows) else 'Semantic quality cannot be compared; no complete acceptance artifact was obtained.'} |

This is same-task validation, not a general model benchmark. Transport failure is distinguished from test defect and implementation defect.

## Q. Progressive role restoration

Reviewer executions: **{result['reviewer_runs']}**. Architect executions: **{result['architect_runs']}**. Data Auditor executions: **0**. Full-chain completion: **{campaign['completed']}**. Roles expand only after the required simpler phases pass; no role is invoked merely to increase agent count.

## R. Recommendation and exact usage

{'All requested phases completed; retain this as small-sample evidence, not a broad reliability guarantee.' if campaign['completed'] else 'Stop at the failed prerequisite. This run does not establish a reliable all-Sol workflow or justify production routing changes. Keep the accepted artifact boundary; no new stage or unrelated hardening is started.'}

| Model | New inference requests | Cumulative Stage22 requests |
|---|---:|---:|
| `gpt-5.6-sol` | {models['gpt-5.6-sol']} | {models['gpt-5.6-sol']} |
| `gpt-6.1-sol` | 0 | 0 |
| `gpt-6-sol` | 0 | 0 |
| Luna | 0 | 8 |
| Terra | 0 | 1 |
| Astra | **0** | **0** |

Actual new role executions: **{len(roles)}**. Model-selected tool actions: **{result['tool_calls']}**. Catalog discovery and synthetic admission are not inference. Primary assistant work is outside validation-role counts; no monetary estimate is fabricated.

Source-bound synthetic Docker/Codex admission: **1 passed** (zero live inference). Structural-gate smoke checks passed for a preserved valid design and four invalid variants; no full regression-suite rerun is claimed. Production source/configuration unchanged: **{cleanup['production_source_unchanged']}**. Credentials unchanged during this continuation: **{cleanup['credential_store_unchanged']}**. Stale owned containers: **{cleanup['stale_owned_containers']}**. Disposable admission/role storage removed: **{cleanup['disposable_storage_removed']}**. [Final cleanup](docs/stage22-sol56-evidence/final-cleanup.json).
'''
    document=ROOT/'STAGE22_SIMPLIFIED_EXECUTION_ASSESSMENT.md'
    s.require('# Stage22 continuation — all roles on Sol 5.6 medium' not in document.read_text(encoding='utf-8'),
        'All-Sol assessment already appended')
    with document.open('a',encoding='utf-8') as f: f.write(txt)
    print(json.dumps({k:result[k] for k in ('verdict','total_requests','qualified','reviewer_runs','architect_runs')}))


if __name__=='__main__': main()
