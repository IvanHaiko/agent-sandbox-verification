"""Controller-only full-body inspection. Never returns body to model transport."""
import hashlib
import http.client
import json
import socket
import threading
import time

from jsonschema import Draft202012Validator
from agent_system.agent_transport import strict_json
from agent_system.errors import AgentSystemError
from agent_system.model_tool_boundary import ResponsesGate, tool_spec

MAX_BYTES = 1048576
MAX_SECONDS = 60.0
MAX_READS = 4096
CHUNK_BYTES = 8192
IDLE_SECONDS = 5.0
JOIN_SECONDS = 5.5


def inspect_full(response, policy, secrets):
    """Bound decoded body in memory; validate only at EOF, then discard."""
    if not isinstance(response, http.client.HTTPResponse):
        raise AgentSystemError('Unsupported full diagnostic response')
    sock = response.fp.raw._sock
    if not isinstance(sock, socket.socket): raise AgentSystemError('Owned full diagnostic socket required')
    chunks, state = [], {'stop_reason': 'read_limit', 'bytes_read': 0, 'reads': 0}
    deadline = min(policy.deadline, time.monotonic() + MAX_SECONDS)
    def reader():
        try:
            for _ in range(MAX_READS):
                remaining = deadline - time.monotonic()
                if remaining <= 0: state['stop_reason'] = 'timeout'; return
                sock.settimeout(min(IDLE_SECONDS, remaining))
                chunk = response.read1(min(CHUNK_BYTES, MAX_BYTES - state['bytes_read']))
                state['reads'] += 1
                if not chunk: state['stop_reason'] = 'eof'; return
                chunks.append(chunk)
                state['bytes_read'] += len(chunk)
                if state['bytes_read'] >= MAX_BYTES:
                    state['stop_reason'] = 'byte_limit'; return
        except TimeoutError: state['stop_reason'] = 'idle_or_deadline_timeout'
        except (OSError, ValueError, http.client.HTTPException): state['stop_reason'] = 'read_error'
    worker = threading.Thread(target=reader, daemon=True, name='controller-full-response-reader')
    worker.start()
    while worker.is_alive() and time.monotonic() < deadline:
        worker.join(min(0.05, max(0, deadline - time.monotonic())))
    if worker.is_alive():
        try: sock.shutdown(socket.SHUT_RDWR)
        except OSError: pass
        sock.close()
        worker.join(JOIN_SECONDS)
        state['stop_reason'] = 'deadline'
    result = {**state, 'reader_shutdown_confirmed': not worker.is_alive(),
        'body_complete': state['stop_reason'] == 'eof', 'strict_response_gate_passed': False,
        'passed_to_codex': False, 'tool_execution_allowed': False, 'accepted_as_inference': False,
        'raw_body_persisted': False, 'body_sha256': None}
    if worker.is_alive(): return result
    response.close()
    raw = b''.join(chunks)
    chunks.clear()
    try:
        text = raw.decode('utf-8')
        secrets.reject(text)
        # Canonical secret checks run even if the strict event gate later fails.
        events = []
        for frame in text.replace('\r\n', '\n').split('\n\n'):
            if not frame: continue
            data = [line[6:] for line in frame.split('\n') if line.startswith('data: ')]
            try: value = strict_json('\n'.join(data))
            except AgentSystemError: continue
            secrets.reject(json.dumps(value))
            if isinstance(value, dict): events.append(value)
        result['body_sha256'] = hashlib.sha256(raw).hexdigest()
        result['utf8_valid'] = True
        counts = {}
        safe_types = ResponsesGate.EVENTS | {'response.failed', 'response.incomplete', 'error'}
        for value in events:
            kind = value.get('type')
            kind = kind if isinstance(kind, str) and kind in safe_types else 'other'
            counts[kind] = counts.get(kind, 0) + 1
        result['event_counts'] = counts
        result['frame_suffix_complete'] = text.replace('\r\n', '\n').endswith('\n\n')
        if not result['body_complete']: return result
        gate = ResponsesGate(policy, secrets)
        try:
            gate.response(raw)
            result['strict_response_gate_passed'] = True
            result['validated_completed_response'] = True
            schema = Draft202012Validator(tool_spec(policy)['inputSchema'])
            result['function_call_count'] = len(gate.authorized_arguments)
            result['function_arguments_schema_valid'] = all(schema.is_valid(strict_json(value))
                for value in gate.authorized_arguments.values())
        except AgentSystemError as error:
            # Only static literals from the reviewed gate, never arbitrary text.
            import ast
            from pathlib import Path
            import agent_system.model_tool_boundary as boundary
            literals = {n.value for n in ast.walk(ast.parse(Path(boundary.__file__).read_text()))
                        if isinstance(n, ast.Constant) and isinstance(n.value, str)}
            result['gate_failure'] = str(error) if str(error) in literals else 'strict_gate_denied'
        finally:
            gate.authorized_arguments.clear()
            gate.close()
        return result
    except UnicodeDecodeError:
        result['utf8_valid'] = False
        return result
    except AgentSystemError:
        return {**state, 'reader_shutdown_confirmed': True,
            'body_complete': result['body_complete'], 'secret_rejected': True,
            'strict_response_gate_passed': False, 'body_sha256': None,
            'passed_to_codex': False, 'tool_execution_allowed': False,
            'accepted_as_inference': False, 'raw_body_persisted': False}
    finally:
        del raw
