"""Aggregate deterministic evidence; no model calls, secrets or report rewrites."""
import contextlib
import hashlib
import io
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import pytest

from validation.regression_shards import Collector


def main():
    root = Path(__file__).resolve().parents[1]
    evidence = root / 'docs/stage18-evidence'
    summary = json.loads((evidence / 'regression/summary.json').read_text())
    if summary['failures'] or summary['errors'] or summary['skipped'] or any(summary['exit_codes']):
        raise RuntimeError('Full offline regression not green')
    junit = [evidence / 'regression/full.xml', evidence / 'focused-final.xml']
    identities = set()
    for path in junit:
        tree = ET.parse(path)
        if any(list(tree.iter(name)) for name in ('failure', 'error', 'skipped')):
            raise RuntimeError('Focused/current regression not green')
        identities.update(case.get('classname').replace('.', '/') + '.py::' + case.get('name')
                          for case in tree.iter('testcase'))
    collector = Collector()
    with contextlib.redirect_stdout(io.StringIO()):
        code = pytest.main(['tests', '--collect-only', '-q', '-p', 'no:cacheprovider'], plugins=[collector])
    if code or identities != set(collector.nodes):
        raise RuntimeError('Current collection and regression/focused union differ')
    previous = json.loads((root / 'docs/STAGE16_17_ASSESSMENT.json').read_text())
    preserved = dict(previous['preserved_artifact_hashes'])
    # Stage 16-17 records are only read, never regenerated.
    for name in ('docs/STAGE16_17_ASSESSMENT.md', 'docs/STAGE16_17_ASSESSMENT.json'):
        preserved[name] = hashlib.sha256((root / name).read_bytes()).hexdigest()
    if any(hashlib.sha256((root / name).read_bytes()).hexdigest() != value for name, value in preserved.items()):
        raise RuntimeError('Historical assessment integrity mismatch')
    paths = ['runners/docker_isolated.py', 'isolation_probes.py', 'isolation.py',
             'contexts.py', 'gates.py', 'mechanical_gates.py']
    boundary_hash = hashlib.sha256(b''.join((root / 'agent_system' / name).read_bytes() for name in paths)).hexdigest()
    probe = json.loads(next((root / 'docs/stage16-17-evidence/real-probes').rglob('validation.json')).read_text())
    if boundary_hash != probe['record']['binding']['implementation']:
        raise RuntimeError('Offline measured boundary changed')
    preflight = json.loads((evidence / 'preflight.json').read_text())
    focused_count = len(list(ET.parse(junit[1]).iter('testcase')))
    report = {
        'version': 1, 'date': '2026-10-05', 'highest_completed_stage': 17,
        'current_authoritative_status': 'OS_ISOLATION_OFFLINE_VERIFIED_WITH_LIMITATIONS',
        'stage18_status': 'PARTIAL_BLOCKED', 'next_stage_admitted': False,
        'live_roles_actually_tested': [], 'framework_real_model_invocation_count': 0,
        'usage': {'input_tokens': None, 'output_tokens': None, 'monetary_cost': None,
                  'reason': 'No live framework invocations'},
        'implementation_changes': ['agent_system/agent_transport.py',
                                   'agent_system/schemas/transport_result.schema.json',
                                   'tests/test_agent_transport.py', 'validation/stage18_assessment.py'],
        'focused_tests': {'passed': focused_count, 'failures': 0, 'errors': 0, 'skipped': 0,
                          'junit': 'docs/stage18-evidence/focused-final.xml'},
        'regression': {'full_run': summary, 'final_current_unique_passed': len(identities),
                       'coverage': 'full regression union final focused transport suite equals current collected node IDs',
                       'historical_real_docker_passed': 13, 'real_docker_suite_rerun': False},
        'isolation': {'offline_boundary_implementation_unchanged': True,
                      'boundary_sha256': boundary_hash,
                      'historically_verified_capabilities': previous['verified_capabilities'],
                      'live_isolation_verified': False},
        'transport_auth_guarantees': {
            'strict_offline_protocol_tests': True, 'live_admission_fails_closed': True,
            'host_home_mounted': False, 'real_credentials_injected': False,
            'synthetic_literal_secret_redaction_tested': True,
            'same_uid_secret_protection_verified': False, 'live_cli_protocol_verified': False,
            'restricted_live_model_egress_verified': False, 'process_launcher_integrated': False},
        'completed_live_pilots': [], 'routing_evidence': 'insufficient evidence',
        'role_value_evidence': 'insufficient evidence', 'workflow_tiers_changed': False,
        'environment_evidence': preflight,
        'limitations': ['Offline decoding/command preparation only; no secure live injector or launcher',
                        'Literal redaction does not stop deliberate secret encoding/exfiltration',
                        'Historical Docker evidence is configuration-specific, not fresh live admission',
                        'Configured aliases and actual backend identity/entitlement unverified'],
        'unresolved_blockers': ['Reviewed credential boundary/security decision required',
                                'Verified image has no Linux Codex CLI',
                                'Measured network-none policy cannot reach remote model transport',
                                'New image/transport requires fresh capability measurements'],
        'stages': [{'stage': 18, 'status': 'PARTIAL_BLOCKED', 'checkpoint': 'docs/STAGE18_CREDENTIAL_TRANSPORT.md',
                    'new_live_evidence': [], 'model_invocations_consumed': 0}]
                  + [{'stage': stage, 'status': 'NOT_ADMITTED', 'reason': 'Live prerequisite stages incomplete',
                      'model_invocations_consumed': 0} for stage in range(19, 25)],
        'preserved_artifact_hashes': preserved,
        'exact_next_step': 'Operator review of narrow credential/egress design, then reviewed pinned Linux CLI image, '
                           'approved runner integration and fresh admission probes; Stage 19 only after all preflight guarantees pass.'}
    (root / 'MASTER_PROGRESS_ASSESSMENT.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    markdown = f'''# Master progress assessment — 2026-10-05

Highest completed stage: **17**. Stage 18: **PARTIAL_BLOCKED**.
Authoritative status: `OS_ISOLATION_OFFLINE_VERIFIED_WITH_LIMITATIONS`.

The offline transport adapter, versioned result schema and AgentResult bridge
are implemented. Strict JSON/protocol validation, byte limits, synthetic credential
redaction and terminal failure behavior have **{focused_count} passing focused tests**.
The new adapter's live admission method always rejects. No real credential injector,
restricted model egress or isolated CLI process integration is claimed complete.

**Live roles tested: none. Real framework model invocations: 0.** Live tokens,
latency, money, role value and routing comparisons are unavailable. No live pilot
has completed. Stages 19–24 are not admitted; workflow tiers remain unchanged.

Current offline regression coverage: **{len(identities)} unique passing cases**,
zero failures/errors/skips. The full {summary['executed_unique']}-case run plus the
final {focused_count}-case focused suite covers exactly every current collected
case. New cases added during the full run are included in the final focused suite.
Thirteen real Docker cases remain historical passing Stage 17 evidence, not new
live-agent validation. See [regression evidence](docs/stage18-evidence/regression/summary.json)
and [final focused JUnit](docs/stage18-evidence/focused-final.xml).

The measured offline Docker implementation hash and preserved historical report
hashes still match. Its private selected-commit staging, readonly protected inputs,
excluded Controller/HOME/siblings/holdouts, non-root UID, readonly root, dropped
capabilities, no-new-privileges, network none, tmpfs and resource/output limits
remain intact. Those measurements are specific to the Stage 17 configuration.

Host CLI: 0.159.2. Current environment has no explicit API key/access token.
Local auth metadata indicates reusable ChatGPT OAuth, including a refresh-token
field; no credential values were exported. The measured Linux image has no Codex
executable. Direct secret injection into a same-UID agent/process environment
does not establish protection from generated code. The current network-none
policy prevents remote model transport. No HOME mounts, auth cache copying,
network relaxation, image pull/build or unrelated container changes occurred.

The next step is operator review of a narrow credential/egress boundary, followed
by a reviewed pinned Linux CLI image, approved runner integration and fresh
capability probes. A changed image or transport cannot reuse old admission.
Only then may Stage 19 run its bounded authenticated smokes. Configured model
aliases remain unverified. See the [Stage 18 checkpoint](docs/STAGE18_CREDENTIAL_TRANSPORT.md)
for the threat model, implementation limits and official documentation.

The [machine-readable assessment](MASTER_PROGRESS_ASSESSMENT.json) contains stage
statuses, evidence, usage availability, unresolved blockers and preserved hashes.
'''
    (root / 'MASTER_PROGRESS_ASSESSMENT.md').write_text(markdown, encoding='utf-8')
    print(json.dumps({'current_unique_passed': len(identities), 'focused_passed': focused_count,
                      'highest_completed_stage': 17, 'live_invocations': 0}))


if __name__ == '__main__':
    main()
