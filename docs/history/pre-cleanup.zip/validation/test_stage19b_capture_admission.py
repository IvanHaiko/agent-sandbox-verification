"""Fresh synthetic Docker/native admission; no account traffic or workflow."""
import ast
import hashlib
from pathlib import Path

import test_stage18c_real as measured
from agent_system.git import git
from agent_system.storage import atomic_json


def test_fresh_diagnostic_admission(project, hardened, tmp_path, monkeypatch):
    hardened[0]['task_id'] = 'STAGE19-SMOKE'
    tree = ast.parse(Path(measured.__file__).read_text(encoding='utf-8'))
    function = next(n for n in tree.body if isinstance(n, ast.FunctionDef)
                    and n.name == 'test_fresh_stage18c_transport_and_adversarial_boundary')
    stop = next(i for i, n in enumerate(function.body)
                if isinstance(n, ast.Expr) and isinstance(n.value, ast.Call)
                and isinstance(n.value.func, ast.Name) and n.value.func.id == 'git')
    function.body = function.body[:stop] + [ast.Return(ast.Call(ast.Name('locals', ast.Load()), [], []))]
    function.decorator_list = []
    namespace = dict(measured.__dict__)
    module = ast.fix_missing_locations(ast.Module(body=[function], type_ignores=[]))
    exec(compile(module, measured.__file__, 'exec'), namespace)
    result = namespace[function.name](project, hardened, tmp_path, monkeypatch)
    runner, workspace = result['runner'], result['workspace']
    result['bridge2'].close()
    git(workspace, 'checkout', '--', 'src/example.py')
    assert (workspace / 'src/example.py').read_text() == 'value = 1\n'
    assert not runner.stale_executions()
    root = Path(__file__).resolve().parents[1]
    observer = root / 'agent_system/transport_diagnostics.py'
    atomic_json(root / 'docs/stage19b-capture-evidence/fresh-admission.json', {
        **result['proof'], 'signed_admission': True,
        'attestation_directory': str(result['store'].directory), 'project': str(project),
        'runtime': str(tmp_path / 'runtime'), 'workspace': str(workspace), 'task': result['task'],
        'full_workflow_executed': False, 'workspace_reset_to_baseline': True,
        'observer_sha256': hashlib.sha256(observer.read_bytes()).hexdigest(), 'account_requests': 0})
