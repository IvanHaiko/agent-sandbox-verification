"""One native Linux CLI smoke, run inside Ubuntu; no transport or agent wrapper."""
import argparse
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'docs/stage23b-evidence'
MODEL = 'gpt-6.1-sol'
TARGET = 'src/add_one.py'
BASELINE = 'def add_one(value: int) -> int:\n    raise NotImplementedError\n'
EXPECTED = 'def add_one(value: int) -> int:\n    return value + 1\n'
INPUT = '''Role: Implementer. This is one fresh, bounded native Codex smoke.
Read role-input.md and inspect src/add_one.py in this repository.
Implement def add_one(value: int) -> int with the single statement return value + 1.
Supported domain: Python integer inputs. Preserve the type annotations.
Only src/add_one.py may change. Do not change role-input.md or Git metadata.
No imports, I/O, dependencies, extra files, commits, other workspaces, auth files,
agent histories, subagents or network. Use a native file edit and end immediately.
Controller determines correctness from the artifact. No final summary is required.
'''


def tree_bytes(root):
    result = {}
    for p in root.rglob('*'):
        if p.is_symlink():
            raise RuntimeError('Unexpected linked workspace entry')
        if p.is_file():
            if p.stat().st_nlink != 1:
                raise RuntimeError('Unexpected hard-linked workspace file')
            result[p.relative_to(root).as_posix()] = p.read_bytes()
    return result


def main(*, evidence_root=None, trial_id=None):
    global OUT
    if evidence_root is not None:
        OUT = Path(evidence_root)
        corrected_attempt = False
    else:
        parser = argparse.ArgumentParser()
        parser.add_argument('--authorized-rerun', action='store_true',
                            help='Explicit user-authorized corrected sandbox attempt')
        parser.add_argument('--evidence-name', default='corrected-src-profile')
        options = parser.parse_args()
        corrected_attempt = options.authorized_rerun
        if corrected_attempt:
            if not re.fullmatch(r'[a-z0-9-]+', options.evidence_name):
                raise RuntimeError('Invalid evidence directory name')
            OUT = OUT / options.evidence_name
    if os.name == 'nt':
        raise RuntimeError('Run this validation inside Ubuntu WSL2')
    executable = shutil.which('codex')
    if not executable:
        raise RuntimeError('Native Linux Codex CLI unavailable')
    version = subprocess.run([executable, '--version'], capture_output=True,
        text=True, timeout=15, check=True).stdout.strip()
    login = subprocess.run([executable, 'login', 'status'], capture_output=True,
        text=True, timeout=15)
    if login.returncode != 0:
        raise RuntimeError('STOP: native Linux login required')
    OUT.mkdir(parents=True, exist_ok=True)
    receipt_path = OUT / 'smoke.json'
    if receipt_path.exists():
        raise RuntimeError('Refuse an unrequested repeat of the single smoke')
    # Supported native catalog command refreshes through Codex, not custom auth.
    catalog = subprocess.run([executable, 'debug', 'models'], capture_output=True,
        text=True, timeout=45)
    if catalog.returncode != 0:
        raise RuntimeError('STOP: native Linux model discovery failed')
    raw = json.loads(catalog.stdout)
    entries = raw.get('models', raw.get('data', [])) if isinstance(raw, dict) else raw
    models = [{key: entry.get(key) for key in ('slug', 'id', 'model', 'display_name')}
              for entry in entries]
    listed = any(MODEL in (m['slug'], m['id'], m['model']) for m in models)
    (OUT / 'native-models.json').write_text(json.dumps({'version': version,
        'supported_command': 'codex debug models', 'models': models,
        'requested_model': MODEL, 'listed': listed}, indent=2), encoding='utf-8')
    if not listed:
        raise RuntimeError('STOP: requested model absent from native Linux catalog')
    # Keep the disposable workspace outside /tmp, which this profile denies.
    cleanup_parent = Path.home().resolve()
    workspace = Path(tempfile.mkdtemp(prefix='stage23b-native-', dir=cleanup_parent)).resolve()
    (workspace / 'src').mkdir()
    (workspace / TARGET).write_text(BASELINE, encoding='utf-8')
    (workspace / 'role-input.md').write_text(INPUT, encoding='utf-8')
    for args in (['init', '--initial-branch=main'], ['add', '.'],
                 ['-c', 'user.name=Stage23B Controller', '-c',
                  'user.email=stage23b@example.invalid', 'commit', '-m', 'Frozen WSL smoke input']):
        subprocess.run(['git', '-C', str(workspace), *args],
                       capture_output=True, timeout=15, check=True)
    before = tree_bytes(workspace)  # Includes Git metadata, not just source files.
    runtime_directory = Path(executable).resolve().parent.parent
    profile = ('{filesystem={":minimal"="read",' + json.dumps(str(runtime_directory))
               + '="read",":workspace_roots"={"."="read",'
               '"src"="write"},":tmpdir"="deny",":slash_tmp"="deny"},'
               'network={enabled=false}}')
    overrides = ['-c', 'default_permissions="stage23b"',
                 '-c', 'permissions.stage23b=' + profile]
    receipt = {'version': version, 'executable': executable,
        'trial_id': trial_id, 'role': 'implementer', 'reasoning_effort': 'low',
        'invocation_mode': 'native CLI exec', 'fresh_context': True,
        'conversation_history_inherited': False, 'ephemeral': True,
        'prompt_sha256': hashlib.sha256(INPUT.encode()).hexdigest(),
        'baseline_hashes': {p: hashlib.sha256(b).hexdigest() for p, b in before.items()},
        'workspace_identity': hashlib.sha256(str(workspace).encode()).hexdigest(),
        'authentication': 'native Linux ChatGPT sign-in; login status exit 0',
        'requested_model': MODEL, 'catalog_listed': listed,
        'workspace': str(workspace), 'initial_project_files': ['role-input.md', TARGET],
        'permission_write_scope': 'isolated src directory; exact changed-file scope validated afterward',
        'authorized_corrected_attempt': corrected_attempt,
        'native_runtime_read_directory': str(runtime_directory),
        'windows_credentials_copied': False, 'inference_started': False,
        'resolved_model': None, 'thread_id': None, 'passed': False}
    stdout = stderr = ''
    process = None
    try:
        # Preflight native Linux sandbox before requesting model inference.
        boundary_probe = '''import os
from pathlib import Path
assert Path('role-input.md').is_file()
assert Path('src/add_one.py').is_file()
os.close(os.open('src/add_one.py', os.O_WRONLY))
for p in ('role-input.md', '.git/config'):
    try:
        fd = os.open(p, os.O_WRONLY)
    except OSError:
        continue
    os.close(fd)
    raise RuntimeError('Unexpected writable path: ' + p)
print(Path.cwd())
'''
        preflight = subprocess.run([executable, *overrides, 'sandbox',
            '--cd', str(workspace), '--permission-profile', 'stage23b',
            '/usr/bin/python3', '-c', boundary_probe],
            cwd=workspace, capture_output=True, text=True, timeout=30)
        receipt['sandbox_preflight_exit'] = preflight.returncode
        receipt['sandbox_preflight_workspace_verified'] = preflight.stdout.strip() == str(workspace)
        receipt['sandbox_preflight_no_mutation'] = tree_bytes(workspace) == before
        if (preflight.returncode != 0 or not receipt['sandbox_preflight_workspace_verified']
                or not receipt['sandbox_preflight_no_mutation']):
            receipt['blocker'] = 'native Linux sandbox startup'
            # Only bounded native startup error; no model/credential output.
            receipt['sandbox_error'] = preflight.stderr[:2000]
            return
        argv = [executable, '--no-daemon', '-a', 'never', 'exec',
            '--ignore-user-config', '--ephemeral', '--color', 'never',
            '--cd', str(workspace), '--model', MODEL,
            '-c', 'model_reasoning_effort="low"',
            '-c', 'shell_environment_policy.inherit="core"',
            '-c', 'features.multi_agent=false', '-c', 'web_search="disabled"',
            *overrides, '-']
        receipt['command'] = argv
        env = {k: v for k, v in os.environ.items() if k not in {
            'OPENAI_API_KEY', 'OPENAI_BASE_URL', 'CODEX_API_KEY', 'CODEX_ACCESS_TOKEN',
            'CODEX_THREAD_ID', 'CODEX_SESSION_ID', 'CODEX_APP_TOOLS_PIPE_PATH',
            'CODEX_PERMISSION_PROFILE', 'CODEX_INTERNAL_ORIGINATOR_OVERRIDE'}}
        started = time.monotonic()
        print('Starting one native Linux gpt-6.1-sol/low execution', flush=True)
        process = subprocess.Popen(argv, cwd=workspace, stdin=subprocess.PIPE,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            encoding='utf-8', env=env, start_new_session=True)
        try:
            stdout, stderr = process.communicate(INPUT, timeout=120)
        except subprocess.TimeoutExpired:
            receipt['blocker'] = 'native execution timeout'
            os.killpg(process.pid, signal.SIGTERM)
            try:
                stdout, stderr = process.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                stdout, stderr = process.communicate(timeout=5)
        receipt['elapsed_seconds'] = round(time.monotonic() - started, 3)
        receipt['process_exit_code'] = process.returncode
        if process.returncode != 0:
            receipt['native_errors'] = [line[:1000] for line in stderr.splitlines()
                if line.startswith(('Error:', 'ERROR:', 'error:', 'bwrap:'))][:8]
        # Native CLI banner only. Never retain narration, reasoning or raw tools.
        for name, key in (('model', 'resolved_model'), ('session id', 'thread_id'),
                          ('provider', 'provider'), ('sandbox', 'sandbox_banner')):
            match = re.search(r'^' + re.escape(name) + r':\s*(.+)$', stderr, re.MULTILINE)
            if match:
                receipt[key] = match.group(1).strip()
        after = tree_bytes(workspace)
        changed = sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))
        receipt['changed_files_including_git_metadata'] = changed
        receipt['mutation_scope_valid'] = changed == [TARGET]
        candidate = after.get(TARGET, b'')
        receipt['candidate_sha256'] = hashlib.sha256(candidate).hexdigest()
        receipt['candidate_changed'] = candidate != before[TARGET]
        receipt['candidate_valid'] = candidate == EXPECTED.encode('utf-8')
        receipt['inference_started'] = bool(receipt['thread_id'] and receipt['candidate_changed'])
        receipt['passed'] = bool(process.returncode == 0 and receipt['inference_started']
            and receipt['resolved_model'] == MODEL and receipt['mutation_scope_valid']
            and receipt['candidate_valid'])
        if receipt['candidate_changed'] and receipt['mutation_scope_valid'] and receipt['candidate_valid']:
            archived = OUT / 'candidate.py'
            archived.write_bytes(candidate)
            receipt['artifact_recoverable'] = hashlib.sha256(archived.read_bytes()).hexdigest() == receipt['candidate_sha256']
            receipt['diff'] = ''.join(difflib.unified_diff(BASELINE.splitlines(True),
                candidate.decode().splitlines(True), fromfile='a/' + TARGET, tofile='b/' + TARGET))
        else:
            receipt['artifact_recoverable'] = False
        if not receipt['passed'] and 'blocker' not in receipt:
            receipt['blocker'] = 'native inference/artifact validation failed'
    finally:
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=5)
        safe_parent = cleanup_parent
        if workspace.parent != safe_parent or not workspace.name.startswith('stage23b-native-'):
            raise RuntimeError('Unsafe WSL smoke cleanup root')
        tree_bytes(workspace)  # Refuse linked workspace entries before deletion.
        shutil.rmtree(workspace)
        receipt['cleanup_passed'] = not workspace.exists()
        receipt['passed'] = (receipt['passed'] and receipt['cleanup_passed']
                             and receipt.get('artifact_recoverable', False))
        receipt['execution_status'] = 'completed' if receipt['passed'] else 'unrecoverable'
        receipt['candidate_status'] = 'unaccepted' if receipt['passed'] else 'unusable'
        receipt_path.write_text(json.dumps(receipt, indent=2), encoding='utf-8')
        print(json.dumps(receipt, indent=2), flush=True)


if __name__ == '__main__':
    main()
