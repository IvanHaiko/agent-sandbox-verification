"""Offline Controller audit of the completed continuation; never invokes inference."""
import difflib
import json
from pathlib import Path

import stage23_wsl_continuation as continuation
import stage23_wsl_workflow as flow
from agent_system.native_codex_linux import digest


OUT = continuation.OUT


def load(path):
    return flow.contract.strict_json(path.read_text(encoding='utf-8'))


def check_role(record, directory):
    flow.require(record['model'] == record['resolved_model'] == 'gpt-6.1-sol', 'Model mismatch')
    flow.require(record['reasoning'] == 'medium', 'Effort mismatch')
    flow.require(record['fresh_context'] and record['ephemeral'] and
                 not record['conversation_history_inherited'], 'Context contamination')
    flow.require(record['sandbox_preflight_passed'] and record['shutdown_confirmed'] and
                 not record['timed_out'] and record['mutation_scope_valid'], 'Execution boundary failed')
    flow.require(record['process_exit_code'] == 0 and record['execution_status'] == 'completed',
                 'Role did not complete')
    name = 'tester' if record['role'] == 'independent_tester' else record['role']
    flow.require(digest((directory / (name + '-input.md')).read_bytes()) == record['prompt_sha256'],
                 'Role input archive mismatch')
    flow.require(record['cleanup_passed'] and not Path(record['workspace']).exists(), 'Role still present')
    argv = record['command']
    flow.require('--ephemeral' in argv and '--ignore-user-config' in argv and
                 'resume' not in argv and 'fork' not in argv, 'Invocation context mismatch')
    profile = argv[argv.index('-c', argv.index('default_permissions="stage23"')) + 1]
    flow.require('network={enabled=false}' in profile and '":tmpdir"="deny"' in profile and
                 '":slash_tmp"="deny"' in profile and '":root"' not in profile,
                 'Sandbox profile drift')


def main():
    if not Path('/home/ivan').is_dir():
        raise RuntimeError('Run the filesystem-absence audit inside the existing Ubuntu WSL environment')
    prior = load(OUT.parent / 'smoke-summary.json')
    old_sessions = {r['thread_id'] for r in prior['trials']}
    old_sessions.add(load(flow.ROOT / 'docs/stage23b-evidence/isolated-home-workspace/smoke.json')['thread_id'])
    for trial in load(OUT.parent / 'minimal/summary.json')['trials']:
        old_sessions.update(r['thread_id'] for r in trial['roles'])
    sessions, workspaces, audits, consistency = [], [], [], []
    source_hashes = {}
    for phase in ['reviewer', 'architect']:
        source_hashes[phase] = {}
        for name, source in [('executed-driver.py', Path(continuation.__file__)),
                             ('workflow-driver.py', Path(flow.__file__)),
                             ('native-runner.py', flow.ROOT / 'agent_system/native_codex_linux.py'),
                             ('contract-harness.py', Path(flow.contract.__file__))]:
            data = (OUT / phase / name).read_bytes()
            flow.require(data == source.read_bytes(), 'Executed source mismatch')
            source_hashes[phase][name] = digest(data)
    for number in [1, 2]:
        directory = OUT / 'reviewer' / ('reviewer-' + str(number))
        trial = load(directory / 'assessment.json')
        flow.require(trial['accepted'] and trial['workflow_completed'], 'Reviewer workflow failed')
        flow.require([r['role'] for r in trial['roles']] ==
                     ['implementer', 'independent_tester', 'reviewer'], 'Unexpected roles')
        for role in trial['roles']:
            check_role(role, directory)
            sessions.append(role['thread_id'])
        workspaces.extend(trial['owned_workspaces'])
        candidate = (directory / 'candidate.py').read_bytes()
        candidate_hash = digest(candidate)
        flow.contract.validate_candidate(candidate)
        flow.require(candidate_hash == trial['candidate_sha256'], 'Candidate archive mismatch')
        freeze = load(directory / 'test-freeze.json')
        flow.require_frozen(directory, freeze)
        flow.require(load(directory / 'frozen-task.json') == flow.contract.TASK, 'Contract changed')
        design = load(directory / 'frozen-test-design.json')
        flow.contract.validate_design((directory / 'frozen-test-design.json').read_bytes())
        flow.require((directory / 'frozen-acceptance.py').read_bytes() ==
                     flow.contract.acceptance_source(design).encode(), 'Frozen harness mismatch')
        exposure = load(directory / 'candidate-exposure.json')
        flow.require(freeze['sequence'] == 1 and exposure['sequence'] == 2 and
                     freeze['frozen_at'] <= exposure['exposed_at'] and
                     not freeze['candidate_visible_during_design'] and freeze['tester_execution_ended'] and
                     freeze['tester_sessions'] == 1 and not exposure['tester_session_running'],
                     'Blindness/freeze ordering failed')
        flow.require(exposure['freeze_receipt_sha256'] == digest((directory / 'test-freeze.json').read_bytes())
                     and exposure['candidate_sha256'] == candidate_hash, 'Exposure hash mismatch')
        acceptance = load(directory / 'acceptance.json')
        flow.require(acceptance == trial['acceptance'] and acceptance['result']['passed'] and
                     acceptance['returncode'] == 0 and acceptance['model_requests'] == 0 and
                     acceptance['tester_sessions'] == 0 and acceptance['mutation_scope_valid'],
                     'Acceptance receipt failed')
        for key in ['candidate_sha256_before', 'candidate_sha256_after']:
            flow.require(acceptance[key] == candidate_hash, 'Acceptance candidate hash mismatch')
        flow.require(acceptance['design_sha256'] == freeze['design_sha256'] and
                     acceptance['harness_sha256'] == freeze['harness_sha256'], 'Acceptance freeze mismatch')
        flow.require(len(acceptance['result']['cases']) == len(design['cases']) == trial['case_count'] and
                     all(c['passed'] for c in acceptance['result']['cases']) and
                     all(p['passed'] for p in acceptance['result']['properties']), 'Frozen cases failed')
        handoff = load(directory / 'implementer-handoff.json')
        diff = ''.join(difflib.unified_diff(flow.BASELINE.splitlines(True), candidate.decode().splitlines(True),
                                          fromfile='a/' + flow.TARGET, tofile='b/' + flow.TARGET))
        flow.require(handoff['diff'] == diff and handoff['candidate_hashes'][flow.TARGET] == candidate_hash
                     and handoff['authority'] == 'controller_observed_artifacts', 'Handoff mismatch')
        reviewer = trial['roles'][-1]
        result_bytes = (directory / 'reviewer-result.json').read_bytes()
        continuation.validate_semantic(result_bytes, continuation.REVIEW_SCHEMA)
        result = load(directory / 'reviewer-result.json')
        flow.require(reviewer['read_only'] and reviewer['changed_files'] == [] and
                     reviewer['artifact_sha256'] == digest(result_bytes) and
                     result['recommendation'] == 'accept' and not result['blockers'] and not result['findings'],
                     'Readonly review evidence mismatch')
        decision = load(directory / 'controller-decision.json')
        flow.require(decision['accepted'] and decision['cleanup_passed'] and
                     decision['reviewer_recommendation'] == 'accept' and
                     decision['candidate_sha256'] == candidate_hash, 'Controller decision mismatch')
        mismatches = []
        for case in design['cases']:
            try:
                expected = flow.contract.contract_interpret(case['input'])
            except ValueError:
                expected = None
            if expected != case['expected']:
                mismatches.append(case['id'])
        flow.require(not mismatches, 'Frozen expectation disagrees with original contract')
        consistency.append({'trial_id': trial['trial_id'], 'case_count': len(design['cases']),
                            'contract_consistency_passed': True, 'mismatches': []})
        audits.append({'trial_id': trial['trial_id'], 'case_count': len(design['cases']),
                       'archive_hashes_verified': True, 'freeze_preceded_exposure': True,
                       'readonly_review_verified': True, 'controller_decision_verified': True,
                       'cleanup_independently_verified': True})
        marginal = load(directory / 'reviewer-marginal-value.json')
        marginal.update(controller_evaluation_pending=False, controller_novel_material_findings=0,
                        controller_decision_changed=False, static_contract_corroboration=True,
                        conclusion='No novel finding or changed decision; limited static corroboration in this sample.')
        flow.save(directory, 'reviewer-marginal-value', marginal)
    failed_dir = OUT / 'architect/architect-1'
    failed = load(failed_dir / 'architect-execution.json')
    flow.require(failed['process_exit_code'] == 1 and failed['sandbox_preflight_passed'] and
                 failed['changed_files'] == [] and failed['mutation_scope_valid'] and
                 failed['shutdown_confirmed'] and not failed['timed_out'] and
                 failed['cleanup_passed'] and not Path(failed['workspace']).exists() and
                 not (failed_dir / 'architect-result.json').exists(), 'Architect failure receipt mismatch')
    sessions.append(failed['thread_id'])
    workspaces.append(failed['workspace'])
    flow.require(len(sessions) == len(set(sessions)) and not set(sessions) & old_sessions,
                 'Prior session reused')
    flow.require(len(workspaces) == len(set(workspaces)) == 9 and
                 all(not Path(p).exists() for p in workspaces), 'Temporary repository survives')
    flow.save(OUT, 'integrity-audit', {'passed': True, 'trials': audits,
        'successful_native_role_contexts': 6, 'failed_architect_launch_contexts': 1,
        'distinct_from_all_prior_sessions': True, 'total_frozen_cases': 46,
        'all_nine_current_continuation_repositories_removed': True,
        'executed_source_hashes': source_hashes, 'architect_output_absent_verified': True})
    flow.save(OUT, 'contract-consistency', {'passed': True, 'trials': consistency,
        'basis': 'Preexisting frozen Controller interpreter; independent Tester expectations unchanged'})
    print('PASS: 46 frozen cases, 6 completed native roles, 1 failed Architect launch, 9 repositories absent')


if __name__ == '__main__':
    main()
