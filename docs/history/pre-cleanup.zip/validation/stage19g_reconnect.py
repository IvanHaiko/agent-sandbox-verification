"""Human-requested browser login; no inference, no credential output."""
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT/'.test-tmp/stage18-oauth-deps'))
from agent_system.storage import atomic_json
from agent_system.chatgpt_oauth import CredentialStore, ChatGPTPlanOAuth
from validation.stage19_reconnect import bounded_time_decoder
from validation.stage19_authorized_smoke import connect

def main():
    import jwt
    out = ROOT/'docs/stage19g-live-smoke-evidence'
    record = {'started_at':time.time(), 'success':False, 'responses_posts':0,
              'raw_credentials_exported':False, 'production_verifier_changed':False}
    original = jwt.decode
    diagnostics = {}
    jwt.decode = bounded_time_decoder(original, jwt.exceptions.ImmatureSignatureError, diagnostics)
    try:
        directory = Path('C:/Users/4ivan/.agentctl/stage19-oauth')
        result = connect(directory)
        status = ChatGPTPlanOAuth(CredentialStore(directory, [ROOT])).status()
        record.update(success=bool(result['oauth_connection_success'] and status['plan_permission']
                                   and not status['access_token_expired']),
                      protected_store_verified=True, plan_permission=status['plan_permission'],
                      access_token_expired=status['access_token_expired'])
    except Exception:
        record['failure_category'] = 'browser_or_strict_identity_verification_failed'
    finally:
        jwt.decode = original
        record['time_diagnostics'] = diagnostics
        atomic_json(out/'reconnection.json', record)
        print(json.dumps(record), flush=True)
    return 0 if record['success'] else 1

if __name__ == '__main__': raise SystemExit(main())
