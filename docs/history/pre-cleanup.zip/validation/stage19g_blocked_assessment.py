"""Finalize the failed live preflight; no refresh, catalog, inference or retry."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from agent_system.chatgpt_oauth import CredentialStore
from agent_system.config import Configuration
from agent_system.runners.tool_docker import ToolDockerRunner
from agent_system.runners.docker_isolated import regular_tree
from agent_system.storage import atomic_json

OUT=ROOT/'docs/stage19g-live-smoke-evidence'
def load(path): return json.loads(path.read_text(encoding='utf-8'))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    proposal=load(ROOT/'docs/stage19g-evidence/prepared-smoke.json')
    admission=load(OUT/'fresh-admission.json')
    current={p.relative_to(ROOT).as_posix():sha(p) for p in sorted((ROOT/'agent_system').rglob('*.py'))}
    assert current==proposal['source_sha256']==admission['source_sha256']
    runner=ToolDockerRunner(Configuration.load(Path(admission['project'])))
    assert runner.preflight()==admission['binding']
    runner.require_transport_admission()
    workspace,project=Path(admission['workspace']),Path(admission['project'])
    runner._workspace(workspace,admission['task'])
    assert not runner.stale_executions()
    assert (workspace/'src/example.py').read_text()=='value = 1\n'
    assert (project/'src/example.py').read_text()=='value = 1\n'
    records=list(runner.root.glob('executions/*/ownership.json'))
    assert records and all(load(p).get('cleanup')=='confirmed' and load(p).get('storage_cleanup')=='confirmed' for p in records)
    assert all(not (p.parent/'checkout').exists() and not (p.parent/'transfer').exists() for p in records)
    fixture=project.parent.resolve()
    assert fixture.is_relative_to((ROOT/'.test-tmp/stage19g-live-admission-1').resolve())
    for name in ('codex-home','attack-codex-home'):
        home=fixture/name
        assert home.resolve().parent==fixture
        if home.exists():
            regular_tree(home)
            shutil.rmtree(home.resolve())
        assert not home.exists()
    store=CredentialStore(Path('C:/Users/4ivan/.agentctl/stage19-oauth'),[ROOT])
    before={p.name:sha(p) for p in store.directory.iterdir() if p.is_file()}
    credentials=store.read('credentials.json')
    assert credentials and time.time()>=credentials['expires_at']
    assert before=={p.name:sha(p) for p in store.directory.iterdir() if p.is_file()}
    catalog=load(OUT/'catalog.json')
    assert catalog['catalog_requests']==catalog['responses_posts']==catalog['refresh_attempts']==0
    assert catalog['credentials_expired'] and not catalog['credentials_valid']
    receipt=load(OUT/'authorization.json')
    assert receipt['proposal_sha256']==sha(ROOT/'docs/stage19g-evidence/prepared-smoke.json')
    result={'execution_id':'stage19g-smoke-1','task_id':'STAGE19-SMOKE','role':'implementer','phase':'implementation',
        'model':'gpt-6-astra','reasoning':'low','verdict':'BLOCKED_BEFORE_INFERENCE',
        'blocker':'Expired current ChatGPT-plan OAuth credentials',
        'human_authorization_received':True,'human_billing_confirmation_received':True,
        'current_source_admission_verified':True,'current_codex_docker_engine_image_config_project_binding_verified':True,
        'signed_transport_proof_verified':True,'credentials_valid':False,'credentials_expired':True,
        'current_catalog_eligibility_verified':False,'catalog_requests':0,'responses_requests':0,'agent_turns':0,
        'live_tool_calls':0,'successful_live_tool_calls':0,'refresh_attempts':0,'automatic_retries':0,
        'live_latch_created':False,'signed_live_authorization_issued':False,'signed_no_credit_authorization_issued':False,
        'signed_authorizations_not_issued_reason':'Credential and catalog prerequisites did not pass',
        'disposable_workspace_unchanged':True,'disposable_primary_unchanged':True,
        'accepted_production_source_unchanged':True,'credential_store_unchanged_by_verification':True,
        'unauthorized_capability_observed':False,'credential_exposure_observed':False,
        'stale_owned_containers':0,'owned_role_storage_cleanup_confirmed':True,'synthetic_codex_homes_removed':True,
        'live_resources_created':False,'live_anomalies':[],
        'stage19_passed':False,'stage20_technically_admissible':False,'stage20_started':False,
        'source_bundle_sha256':admission['source_bundle_sha256'],
        'evidence':['fresh-admission.json','admission.xml','catalog.json','authorization.json']}
    atomic_json(OUT/'execution.json',result)
    atomic_json(ROOT/'STAGE19G_LIVE_SMOKE.json',result)
    (ROOT/'STAGE19G_LIVE_SMOKE.md').write_text('''# Stage19g live smoke — blocked before inference

**BLOCKED_BEFORE_INFERENCE:** the existing ChatGPT-plan OAuth credentials are expired. The explicitly authorized `stage19g-smoke-1` did not start a live agent turn. No refresh, catalog request, Responses request, live tool call, retry or Stage20 execution occurred.

Fresh current-source Docker/Codex admission passed (one existing synthetic admission test). An independent check verified the signed transport proof and current Codex executable, Docker image/engine/config/project binding against that admission. Accepted Stage19g production source still matches the prepared proposal; simplified anomaly handling was retained.

The credential storage access check passed, but credential validity failed. Account catalog eligibility therefore remains unverified. The live latch and execution/client-bound live/no-credit signatures were not created because those prerequisites did not pass. The actual human authorization and fresh billing confirmation are recorded; no confirmation was fabricated.

The disposable source and primary fixture remain at `value = 1`. No live mutation was accepted. There are zero stale owned containers; synthetic admission role storage cleanup is confirmed, and its disposable Codex homes were removed. The credential verification did not change the credential files. No unauthorized capability or credential exposure was observed.

- Stage19 passed: **false** (live path unproven).
- Stage20 technically admissible: **false**.
- Stage20 started: **false**.

Credentials must be renewed through the authorized OAuth flow before a separately authorized live attempt. This assessment ends the current attempt; no renewal or follow-up smoke is scheduled.

Evidence: `docs/stage19g-live-smoke-evidence/execution.json`, `fresh-admission.json`, `admission.xml`, `catalog.json`, and `authorization.json`.
''',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('verdict','responses_requests','live_tool_calls','stage19_passed','stage20_technically_admissible','stale_owned_containers')}))

if __name__=='__main__': main()
