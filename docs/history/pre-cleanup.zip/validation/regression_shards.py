"""Run every current offline test once, with independent temporary repositories.

This is validation tooling, not framework scheduling or agent delegation.
Historical JUnit durations balance local pytest processes; no Docker/model calls
are introduced. The selected tests remain the default offline test suite.
"""
import argparse
import contextlib
import io
from collections import defaultdict
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

import pytest


class Collector:
    def pytest_collection_finish(self, session):
        self.nodes = [item.nodeid for item in session.items]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--historical', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--temporary-root', type=Path, required=True)
    parser.add_argument('--workers', type=int, default=4, choices=(1, 2, 3, 4))
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    if args.temporary_root.exists():
        raise RuntimeError('Refusing to reuse an existing pytest temporary root')
    collector = Collector()
    with contextlib.redirect_stdout(io.StringIO()):
        code = pytest.main(['tests', '--collect-only', '-q', '-p', 'no:cacheprovider'], plugins=[collector])
    if code != 0:
        return int(code)
    nodes = collector.nodes
    if len(nodes) != len(set(nodes)):
        raise RuntimeError('Duplicate current test identities')
    weights = defaultdict(lambda: 1.0)
    for case in ET.parse(args.historical).getroot().iter('testcase'):
        node = case.get('classname').replace('.', '/') + '.py::' + case.get('name')
        weights[node] = float(case.get('time', '1'))
    groups, durations = [[] for _ in range(args.workers)], [0.0] * args.workers
    for node in sorted(nodes, key=lambda item: weights[item], reverse=True):
        lane = min(range(args.workers), key=lambda i: durations[i])
        groups[lane].append(node)
        durations[lane] += weights[node]
    plan = {'version': 1, 'current_collected': len(nodes), 'workers': args.workers,
            'groups': [{'index': i, 'nodes': group, 'historical_weight_seconds': durations[i]} for i, group in enumerate(groups)]}
    (args.output / 'plan.json').write_text(json.dumps(plan, indent=2), encoding='utf-8')
    processes = []
    args.temporary_root.mkdir(parents=True)
    start = time.monotonic()
    try:
        for index, group in enumerate(groups):
            log = (args.output / f'shard-{index}.log').open('w', encoding='utf-8')
            command = [sys.executable, '-u', '-m', 'pytest', '-q', '-p', 'no:cacheprovider',
                       '--basetemp=' + str(args.temporary_root / str(index)),
                       '--junitxml=' + str(args.output / f'shard-{index}.xml'), *group]
            process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                                       creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
            processes.append((index, process, log))
            print(f'Started shard {index}: {len(group)} tests', flush=True)
        pending = {index for index, _, _ in processes}
        while pending:
            for index, process, log in processes:
                if index in pending and process.poll() is not None:
                    log.close()
                    pending.remove(index)
                    print(f'Shard {index} completed with exit code {process.returncode}', flush=True)
            time.sleep(0.5)
    finally:
        for _, process, log in processes:
            if process.poll() is None:
                process.kill()
                process.wait(timeout=20)
            log.close()
    merged = ET.Element('testsuites')
    actual = []
    for index, _, _ in processes:
        root = ET.parse(args.output / f'shard-{index}.xml').getroot()
        for suite in root:
            merged.append(suite)
        for case in root.iter('testcase'):
            actual.append(case.get('classname').replace('.', '/') + '.py::' + case.get('name'))
    if set(actual) != set(nodes) or len(actual) != len(nodes):
        raise RuntimeError('Full regression coverage mismatch, duplicate or omitted case')
    ET.ElementTree(merged).write(args.output / 'full.xml', encoding='utf-8', xml_declaration=True)
    report = {'version': 1, 'collected': len(nodes), 'executed_unique': len(set(actual)),
              'failures': len(list(merged.iter('failure'))), 'errors': len(list(merged.iter('error'))),
              'skipped': len(list(merged.iter('skipped'))), 'duration_seconds': time.monotonic() - start,
              'source': 'all current default offline node IDs, each executed exactly once',
              'exit_codes': [process.returncode for _, process, _ in processes]}
    (args.output / 'summary.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report), flush=True)
    return 1 if report['failures'] or report['errors'] or report['skipped'] or any(report['exit_codes']) else 0


if __name__ == '__main__':
    raise SystemExit(main())
