"""Honest interim report requested while the operator considers authentication."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET


def main():
    root = Path(__file__).resolve().parents[1]
    evidence = root / 'docs/stage18-evidence'
    previous = json.loads((root / 'docs/STAGE16_17_ASSESSMENT.json').read_text())
    focused = ET.parse(evidence / 'focused-final.xml')
    checks = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() == value
              for name, value in previous['preserved_artifact_hashes'].items()}
    if not all(checks.values()):
        raise RuntimeError('Historical artifact mismatch')
    count = len(list(focused.iter('testcase')))
    if any(list(focused.iter(name)) for name in ('failure', 'error', 'skipped')):
        raise RuntimeError('Focused tests not green')
    report = {
        'version': 1, 'date': '2026-10-05', 'report_kind': 'interim_operator_checkpoint',
        'highest_completed_stage': 17,
        'current_authoritative_status': 'OS_ISOLATION_OFFLINE_VERIFIED_WITH_LIMITATIONS',
        'stage18_status': 'PARTIAL_BLOCKED', 'next_stage_admitted': False,
        'live_roles_actually_tested': [], 'framework_real_model_invocation_count': 0,
        'implementation_changes': ['agent_system/agent_transport.py', 'agent_system/schemas/transport_result.schema.json',
                                   'tests/test_agent_transport.py', 'docs/STAGE18_CREDENTIAL_TRANSPORT.md',
                                   'validation/stage18_assessment.py', 'validation/stage18_checkpoint.py', 'README.md'],
        'focused_tests': {'passed': count, 'failures': 0, 'errors': 0, 'skipped': 0,
                          'evidence': 'docs/stage18-evidence/focused-final.xml'},
        'regression': {'current_full_run_status': 'in_progress_at_checkpoint',
                       'session_id': 97977, 'evidence_directory': 'docs/stage18-evidence/regression',
                       'historical_offline_unique_passed': 226, 'historical_real_docker_unique_passed': 13,
                       'historical_evidence_is_current_live_acceptance': False},
        'new_live_evidence': [],
        'usage': {'input_tokens': None, 'output_tokens': None, 'monetary_cost': None,
                  'reason': 'No live framework role invocations'},
        'isolation_guarantees': {'offline_boundary_changed': False,
                                'historically_verified_capabilities': previous['verified_capabilities'],
                                'live_isolation_verified': False},
        'transport_auth_guarantees': {'strict_offline_protocol_tested': True,
                                      'synthetic_secret_redaction_tested': True,
                                      'new_adapter_live_admission_always_rejects': True,
                                      'host_home_mounted': False, 'real_credentials_injected': False,
                                      'live_process_launcher_integrated': False,
                                      'restricted_model_egress_verified': False},
        'completed_live_pilots': [], 'routing_evidence': 'insufficient evidence',
        'role_value_evidence': 'insufficient evidence', 'workflow_tiers_changed': False,
        'environment_evidence': json.loads((evidence / 'preflight.json').read_text()),
        'historical_hash_checks': checks,
        'unresolved_blockers': ['Operator authentication route undecided',
                                'Credential isolation and restricted model egress require reviewed implementation',
                                'Verified Linux image contains no Codex executable',
                                'New image/transport requires new measured admission',
                                'Current full regression has not completed at this checkpoint'],
        'limitations': ['Adapter is offline command preparation/decoding and a result bridge, not a live transport',
                        'Redaction cannot prove protection against arbitrary secret encoding or same-UID reads',
                        'No authenticated model identity, role value, costs or live workflow verified'],
        'stages': [{'stage': 18, 'status': 'PARTIAL_BLOCKED', 'model_invocations_consumed': 0}]
                  + [{'stage': number, 'status': 'NOT_ADMITTED', 'model_invocations_consumed': 0}
                     for number in range(19, 25)],
        'exact_next_step': 'Read the running regression summary when it completes; after the operator selects '
                           'authentication, review the narrow credential/egress design, provision a pinned Linux CLI '
                           'image and implement/revalidate isolated transport before Stage 19.'}
    (root / 'MASTER_PROGRESS_ASSESSMENT.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    markdown = f'''# Master progress assessment — промежуточный отчет, 2026-10-05

Последний завершенный этап: **17**. Stage 18: **PARTIAL_BLOCKED**.
Авторитетный статус: `OS_ISOLATION_OFFLINE_VERIFIED_WITH_LIMITATIONS`.

По просьбе пользователя отчет зафиксирован до завершения полной регрессии и
выбора аутентификации. Положительная оценка live-исполнения не присваивается.

Сделано:

- Добавлен CodexCliAdapter: подготовка команды, строгий разбор JSONL и конечного
  результата, проверка схемы, идентичности задачи/исполнения и единичного завершения.
- Добавлена версия 1 схемы transport_result и мост к существующему AgentResult.
- Разделены и ограничены протокол, stderr и журналы инструментов; ошибки,
  переполнение, таймаут, отмена и авария отклоняются без восстановления из прозы.
- Добавлена привязанная к роли/исполнению редакция синтетических секретов,
  включая разрывы между блоками и JSON Unicode escapes.
- Подготовлены модель угроз, ограничения и требования к следующему шагу.

Проверки: **{count} целевых тестов проходят**, ошибок и пропусков нет.
Полная офлайн-регрессия запущена в четырех процессах и **еще выполняется на
момент отчета**; ее успех пока не заявлен. Предыдущие 226 офлайн-тестов и 13
Docker-тестов остаются историческими свидетельствами Stage 17. Финальный результат
текущего запуска появится в docs/stage18-evidence/regression/summary.json.

**Реальные вызовы моделей внутри framework: 0. Live-роли и live-пилоты: отсутствуют.**
Токены, стоимость, задержка live-ролей, польза независимых ролей и сравнительные
данные маршрутизации недоступны. Stages 19–24 не допущены; workflow tiers не менялись.

Исторические оценки сохранены; их контрольные суммы совпадают. Реализация
измеренной Docker-границы не менялась: private staging, защищенные readonly inputs,
исключенные HOME/Controller/соседи/holdouts, non-root UID, readonly root, dropped
capabilities, no-new-privileges, network none, tmpfs и ресурсные лимиты сохранены.
Это исторически измеренные гарантии конкретной конфигурации, не live-аттестация.

Проверка окружения: Windows Codex CLI 0.159.2; явных API key/access token в
окружении нет. Метаданные локального login cache указывают на ChatGPT OAuth с
полем refresh token; значения не выводились и не копировались. В проверенном
Linux image Codex отсутствует. HOME и `.codex` не монтировались, реальные секреты
не инжектировались; сеть не ослаблялась, image не собирался и не скачивался.

Stage 18 не завершен: безопасная credential injection, ограниченный model egress
и live launcher внутри Docker еще не реализованы. Новый adapter всегда отклоняет
live admission. Прямая передача reusable secret процессам одной роли не доказывает
защиту от generated code; редакция журналов этого не исправляет.

Следующий шаг: получить итог запущенной регрессии. После выбора пользователем
API либо ChatGPT-аутентификации — согласовать узкую credential/egress границу,
подготовить проверенный pinned Linux CLI image, интегрировать транспорт и заново
измерить admission. Только после этого допустим Stage 19.

Подробности: [Stage 18 checkpoint](docs/STAGE18_CREDENTIAL_TRANSPORT.md),
[JSON отчет](MASTER_PROGRESS_ASSESSMENT.json),
[целевые тесты](docs/stage18-evidence/focused-final.xml).
'''
    (root / 'MASTER_PROGRESS_ASSESSMENT.md').write_text(markdown, encoding='utf-8')
    print(json.dumps({'focused_passed': count, 'stage18': 'PARTIAL_BLOCKED', 'full_regression': 'in_progress'}))


if __name__ == '__main__':
    main()
