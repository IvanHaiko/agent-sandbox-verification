"""Bounded whole stream tests, synthetic sockets only."""
import time
import subprocess
import pytest
from agent_system.agent_transport import InvocationBinding
from agent_system.model_tool_boundary import ExecutionPolicy, SecretFilter
from test_transport_diagnostics import response
from test_model_tool_boundary import message, sse, function
import full_response_observer as full


@pytest.fixture(autouse=True)
def no_execution(monkeypatch):
    def deny(*a, **kw): pytest.fail('Full inspection executed a tool or process')
    monkeypatch.setattr(subprocess, 'Popen', deny)
    monkeypatch.setattr(subprocess, 'run', deny)
    monkeypatch.setattr('agent_system.codex_tool_session.CodexToolSession.run', deny)
    monkeypatch.setattr('agent_system.model_tool_boundary.IsolatedExecutionBridge.execute', deny)


def policy():
    return ExecutionPolicy(InvocationBinding('full-1', 'implementer', 'TASK', 1, 'offline', 'low'),
                           'implementation', 'owned', time.monotonic() + 10)


def test_complete_valid_stream_is_inspected_without_acceptance():
    with response(sse([message('synthetic output')]), None) as value:
        record = full.inspect_full(value, policy(), SecretFilter())
    assert record['body_complete'] and record['strict_response_gate_passed']
    assert record['event_counts']['response.completed'] == 1
    assert not record['accepted_as_inference'] and not record['passed_to_codex']


@pytest.mark.parametrize('raw', [b'ordinary private prose', b'event: response.created\ndata: broken\n\n',
    b'event: unknown\ndata: {"type":"unknown"}\n\n', b'\xff'],
    ids=['plain', 'bad-json', 'unknown-event', 'invalid-utf8'])
def test_complete_invalid_response_never_passes_gate(raw):
    with response(raw, None) as value:
        record = full.inspect_full(value, policy(), SecretFilter())
    assert record['body_complete'] and not record['strict_response_gate_passed']
    assert not record['tool_execution_allowed']


def test_secret_suppresses_hash_and_structure():
    with response(sse([message('synthetic-sensitive')]), None) as value:
        record = full.inspect_full(value, policy(), SecretFilter(['synthetic-sensitive']))
    assert record['secret_rejected'] and record['body_sha256'] is None
    assert 'event_counts' not in record


def test_size_limit_is_not_completion(monkeypatch):
    monkeypatch.setattr(full, 'MAX_BYTES', 64)
    with response(b'x' * 1024, None) as value:
        record = full.inspect_full(value, policy(), SecretFilter())
    assert record['bytes_read'] == 64 and not record['body_complete']
    assert not record['strict_response_gate_passed']


def test_timeout_closes_reader(monkeypatch):
    monkeypatch.setattr(full, 'IDLE_SECONDS', 0.05)
    with response(stuck=True, content_type=None) as value:
        record = full.inspect_full(value, policy(), SecretFilter())
    assert not record['body_complete'] and record['reader_shutdown_confirmed']


def test_full_stream_larger_than_old_prefix_ceiling():
    with response(sse([message('x' * 20000)]), None) as value:
        record = full.inspect_full(value, policy(), SecretFilter())
    assert record['bytes_read'] > 8192 and record['strict_response_gate_passed']


def test_allowed_function_inspected_but_never_executed():
    p = policy()
    with response(sse([function(p)]), None) as value:
        record = full.inspect_full(value, p, SecretFilter())
    assert record['strict_response_gate_passed'] and record['function_call_count'] == 1
    assert record['function_arguments_schema_valid'] and not record['tool_execution_allowed']


def test_hosted_function_denied():
    call = function(policy())
    call['name'] = 'shell'
    with response(sse([call]), None) as value:
        record = full.inspect_full(value, policy(), SecretFilter())
    assert not record['strict_response_gate_passed']
