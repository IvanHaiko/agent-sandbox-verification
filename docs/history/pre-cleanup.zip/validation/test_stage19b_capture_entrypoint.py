"""Offline enforcement of frozen payload, one dispatch and no SSE forwarding."""
import hashlib
from types import SimpleNamespace
from email.message import Message
from urllib.request import Request

import pytest

from agent_system.errors import AgentSystemError
from agent_system.model_tool_boundary import UPSTREAM, SecretFilter
from stage19b_capture import SingleRequestDelegate, StopExpectedTransport, original_prompt


def setup_delegate(content_type='text/plain'):
    calls = []
    response = SimpleNamespace(status=200, headers=Message(), close=lambda: calls.append('closed'))
    response.headers['Content-Type'] = content_type
    class Opener:
        def open(self, *args, **kwargs):
            calls.append('http')
            return response
    payload = b'{"model":"synthetic"}'
    evidence = {}
    delegate = SingleRequestDelegate(Opener(), hashlib.sha256(payload).hexdigest(),
        lambda: calls.append('approval'), lambda: calls.append('dispatch-latch'), SecretFilter(), evidence)
    return delegate, payload, calls, response, evidence


@pytest.mark.parametrize('change', ['body', 'route', 'method'])
def test_frozen_scope_rejected_before_any_http(change):
    delegate, payload, calls, _, _ = setup_delegate()
    request = Request(UPSTREAM if change != 'route' else 'https://example.invalid',
                      data=payload if change != 'body' else b'{}',
                      method='POST' if change != 'method' else 'GET')
    with pytest.raises(AgentSystemError): delegate.open(request)
    assert calls == []


def test_exact_unknown_response_returned_only_to_quarantine_once():
    delegate, payload, calls, response, evidence = setup_delegate()
    request = Request(UPSTREAM, data=payload, method='POST')
    assert delegate.open(request) is response
    assert calls == ['approval', 'dispatch-latch', 'http'] and evidence['http_status'] == 200
    with pytest.raises(AgentSystemError): delegate.open(request)
    assert calls.count('http') == 1


def test_expected_mime_closed_without_read_or_forwarding():
    delegate, payload, calls, _, evidence = setup_delegate('text/event-stream')
    with pytest.raises(StopExpectedTransport):
        delegate.open(Request(UPSTREAM, data=payload, method='POST'))
    assert calls == ['approval', 'dispatch-latch', 'http', 'closed']
    assert evidence['http_status'] == 200


def test_original_stage19_prompt_semantics_preserved():
    prompt = original_prompt({'task_id': 'STAGE19-SMOKE'})
    assert 'Change the public variable value from 1 to 2' in prompt
    assert 'agentctl_execute' in prompt and 'STAGE19-SMOKE' in prompt
