"""Bind passing local evidence and a reviewed one-shot driver, without inference."""
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]


def main():
    number = int(sys.argv[1])
    assert 7 <= number <= 11
    out = ROOT/'docs'/f'stage19g-smoke-{number}-evidence'
    assert not (out/'one-shot-latch').exists()
    cases = set()
    for name in ('guards.xml', 'roundtrip.xml'):
        suites = ET.parse(out/name).getroot().iter('testsuite')
        for suite in suites:
            assert int(suite.get('failures', '0')) == int(suite.get('errors', '0')) == int(suite.get('skipped', '0')) == 0
            for case in suite.findall('testcase'):
                cases.add((case.get('classname'), case.get('name')))
    entrypoint = ROOT/'validation'/f'stage19g_live_smoke_{number}.py'
    record = {'entrypoint_sha256': hashlib.sha256(entrypoint.read_bytes()).hexdigest(),
        'proposal_sha256': hashlib.sha256((out/'prepared-smoke.json').read_bytes()).hexdigest(),
        'execution_id': f'stage19g-smoke-{number}', 'offline_tests_passed': True,
        'offline_test_count': len(cases), 'real_codex_docker_roundtrip_passed': True,
        'source_bound': True, 'strict_nonexecutable_bijection_restored': False,
        'live_authorization_received': True, 'automatic_retries': 0}
    (out/'driver-admission.json').write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(record))


if __name__ == '__main__': main()
