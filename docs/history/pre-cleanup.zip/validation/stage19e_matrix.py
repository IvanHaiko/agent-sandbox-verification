"""Exclusive, serialized, maximum-five diagnostic POSTs. No automatic retry."""
import ast
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'docs/stage19e-live-evidence'
EXECUTION = 'stage19e-matrix-1'
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT/'tests'))
from agent_system.agent_transport import InvocationBinding, strict_json
from agent_system.approvals import ApprovalStore
from agent_system.chatgpt_oauth import CredentialStore, PLAN_SCOPE
from agent_system.codex_tool_session import CodexToolSession
from agent_system.config import Configuration
from agent_system.errors import AgentSystemError
from agent_system.git import git
from agent_system.model_tool_boundary import (ExecutionPolicy, ResponsesGate, LocalModelRelay,
    PlanUpstream, SecretFilter, UPSTREAM)
import agent_system.model_tool_boundary as boundary
from agent_system.runners.tool_docker import ToolDockerRunner
from agent_system.runners.docker_isolated import CLEANUP
from agent_system.storage import atomic_json
from validation.stage19_final_smoke_retry import (ExactBridge, expected_arguments,
    fixed_result_schema, safe_remove_tree, consume_latch)
from test_model_tool_boundary import message, sse

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path): return strict_json(path.read_text())
def require(value, reason):
    if not value: raise AgentSystemError(reason)

VARIANTS = {'A_BASELINE', 'B_TYPED_CONST', 'C_NO_MESSAGE_IDS',
            'D_NON_STRICT_CONTROL', 'E_CATALOG_MODEL_CONTROL'}

def variant_body(baseline, variant, model=None):
    require(variant in VARIANTS, 'Unknown diagnostic variant')
    body = copy.deepcopy(baseline)
    if variant == 'B_TYPED_CONST':
        props = body['tools'][0]['tools'][0]['parameters']['properties']
        for prop in props.values():
            if set(prop) == {'const'}:
                value = prop['const']
                require(type(value) in (str, int), 'Unsupported const diagnostic type')
                prop['type'] = 'integer' if type(value) is int else 'string'
    elif variant == 'C_NO_MESSAGE_IDS':
        for item in body['input']:
            if isinstance(item, dict) and item.get('role') in ('user', 'developer', 'assistant'):
                item.pop('id', None)
    elif variant == 'D_NON_STRICT_CONTROL':
        body['tools'][0]['tools'][0]['strict'] = False
    elif variant == 'E_CATALOG_MODEL_CONTROL':
        require(isinstance(model, str) and model != baseline['model'], 'Catalog model control requires change')
        body['model'] = model
    return body

def fingerprint(body):
    # Values that could contain identifiers/prose are replaced before hashing.
    fixed = {'model', 'effort', 'type', 'strict', 'store', 'stream', 'parallel_tool_calls',
             'tool_choice', 'context', 'verbosity', 'include', 'required', 'additionalProperties',
             'minItems', 'maxItems', 'minLength', 'maxLength', 'minimum', 'maximum'}
    def shape(v, key=None):
        if isinstance(v, dict): return {k:shape(x, k) for k,x in sorted(v.items())}
        if isinstance(v, list): return [shape(x, key) for x in v]
        if isinstance(v, str): return v if key in fixed else '<string>'
        return v
    return hashlib.sha256(json.dumps(shape(body), sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def consume_variant(directory, variant, ledger):
    require(variant in VARIANTS and len(ledger) < 5 and variant not in ledger, 'Diagnostic budget/replay denied')
    directory.mkdir(parents=True, exist_ok=True)
    with (directory/(variant+'.consumed')).open('x', encoding='utf-8') as stream:
        stream.write('Dispatch allowance consumed before network; never retry.\n')
        stream.flush(); os.fsync(stream.fileno())
    ledger.append(variant)
    atomic_json(directory/'consumed-attempts.json', {'ceiling':5, 'consumed':ledger,
        'count':len(ledger), 'automatic_retry':False})

def next_variant(record, attempted):
    error = record.get('http_error', {})
    if record.get('http_status') != 400: return None
    # Machine routing does not consume every allowance indiscriminately.
    param, category = error.get('param') or '', error.get('message_category')
    if param.startswith('input') and 'C_NO_MESSAGE_IDS' not in attempted:
        return 'C_NO_MESSAGE_IDS'
    if (category == 'invalid_schema' or param.startswith('tools')):
        if 'B_TYPED_CONST' not in attempted: return 'B_TYPED_CONST'
        if 'D_NON_STRICT_CONTROL' not in attempted: return 'D_NON_STRICT_CONTROL'
        return None
    if category in ('model_unavailable', 'unsupported_capability', 'authentication', 'permission',
                    'usage_limit', 'plan_availability', 'plan_eligibility', 'unsupported_route'):
        return None
    for candidate in ('B_TYPED_CONST', 'C_NO_MESSAGE_IDS', 'D_NON_STRICT_CONTROL'):
        if candidate not in attempted: return candidate
    return None

def main():
    require(sys.argv[1:] == ['--execute-authorized-matrix'], 'Explicit diagnostic entry required')
    consume_latch(OUT/'matrix-latch')
    result = {'execution_id':EXECUTION, 'verdict':'DIAGNOSTIC_MATRIX_INCONCLUSIVE',
              'records':[], 'responses_posts':0, 'tools_executed':0,
              'stage19_passed':False, 'stage20_started':False, 'production_modified':False,
              'safe_failure_category':None, 'baseline_model':'gpt-6-sol', 'reasoning':'low'}
    session = bridge = runner = invocation = None
    original_popen, original_opener = subprocess.Popen, boundary.build_opener
    secrets = SecretFilter()
    ledger = []
    try:
        admission = load(OUT/'fresh-admission.json')
        catalog = load(OUT/'catalog.json')
        require(catalog['catalog_success'] and catalog['credentials_valid'], 'Fresh credential/catalog admission required')
        available = {m['model']:m['reasoning'] for m in catalog['models']}
        require('low' in available.get('gpt-6-astra', []), 'Confirmed catalog replacement required')
        model = 'gpt-6-sol' if 'low' in available.get('gpt-6-sol', []) else 'gpt-6-astra'
        result.update(catalog_model=model, catalog=catalog, model_control_required=model != 'gpt-6-sol')
        sources = admission['source_sha256']
        driver_hash, catalog_hash = sha(Path(__file__)), sha(OUT/'catalog.json')
        driver_admission = load(OUT/'driver-admission.json')
        require(driver_admission['entrypoint_sha256'] == driver_hash and driver_admission['offline_tests_passed'], 'Driver offline admission mismatch')
        config = Configuration.load(Path(admission['project']))
        runner = ToolDockerRunner(config)
        workspace = Path(admission['workspace'])
        require(workspace.resolve().is_relative_to((ROOT/'.test-tmp/stage19e-live-admission').resolve()), 'Disposable workspace binding required')
        def admission_check():
            require(sha(Path(__file__)) == driver_hash and sha(OUT/'catalog.json') == catalog_hash,
                    'Driver/catalog source changed')
            require(all(sha(ROOT/p) == h for p,h in sources.items()), 'Production source admission stale')
            require(runner.preflight() == admission['binding'], 'Current transport binding changed')
            runner.require_transport_admission()
        admission_check()
        require(not runner.stale_executions(), 'Stale owned containers')
        require((workspace/'src/example.py').read_text() == 'value = 1\n'
                and not git(workspace, 'status', '--porcelain', '--untracked-files=all'), 'Pristine smoke fixture required')
        result.update(fresh_admission_verified=True, signed_transport_proof_verified=True,
                      source_bundle_sha256=admission['source_bundle_sha256'])
        store = CredentialStore(Path('C:/Users/4ivan/.agentctl/stage19-oauth'), [ROOT, Path(admission['project']), config.worktrees_dir])
        value, registration = store.read('credentials.json'), store.read('registration.json')
        require(value and PLAN_SCOPE in value['scopes'] and value['expires_at']-time.time()>240
                and value['client_id'] == registration['client_id'], 'Fresh current credentials required')
        secrets = SecretFilter([value[k] for k in ('access_token','refresh_token','id_token')])
        credential_hashes = {p.name:sha(p) for p in store.directory.iterdir() if p.is_file()}
        authorization = load(OUT/'human-authorization.json')
        confirmed_at = authorization['received_and_recorded_at']
        require(authorization['credits_fallback_disabled'] and 0 <= time.time()-confirmed_at <= 86400,
                'Actual current human no-credit confirmation required')
        # Baseline generation stays bound to the requested model. Only E changes
        # the upstream model; execution identity and prompt stay exactly equal.
        base_policy = ExecutionPolicy(InvocationBinding(EXECUTION, 'implementer', 'STAGE19-SMOKE', 1, 'gpt-6-sol', 'low'),
            'implementation', hashlib.sha256(str(workspace.resolve()).encode()).hexdigest(), time.monotonic()+180,
            max_requests=1, max_tool_calls=2, max_tool_seconds=20)
        policy = ExecutionPolicy(InvocationBinding(EXECUTION, 'implementer', 'STAGE19-SMOKE', 1, model, 'low'),
            'implementation', base_policy.workspace_id, time.monotonic()+240,
            max_requests=5, max_tool_calls=2, max_tool_seconds=20)
        approvals = ApprovalStore(config.runtime_root/'stage19e-approvals',
            {'transport':admission['binding'], 'source_bundle':admission['source_bundle_sha256'],
             'driver':driver_hash, 'catalog':catalog_hash, 'human_confirmation':sha(OUT/'human-authorization.json'),
             'execution':policy.identity(), 'model':model, 'reasoning':'low'})
        approvals.issue('no-credits/'+EXECUTION, {'execution_id':EXECUTION, 'client_id':value['client_id'],
            'credits_fallback_disabled':True, 'operator':'Human confirmed OFF throughout diagnostic matrix', 'attested_at':confirmed_at})
        approvals.issue('live-smoke/'+EXECUTION, {'authorized':True, **policy.identity(), 'model':model, 'reasoning':'low', 'route':UPSTREAM})
        result.update(signed_live_authorization=True, signed_no_credit_attestation=True,
                      original_confirmation_timestamp_used=True)
        proposal = load(ROOT/'docs/stage19-final-conformance-2-evidence/prepared-scope.json')['smoke']
        invocation = OUT/'capture-home'
        bridge = ExactBridge(runner, workspace, admission['task'], base_policy, secrets, proposal=proposal, observed={})
        captured = []
        class CaptureGate(ResponsesGate):
            def request(self, raw):
                body = super().request(raw)
                body['parallel_tool_calls'] = False
                return body
        def synthetic(body):
            require(not captured, 'Only one localhost capture allowed')
            captured.append(copy.deepcopy(body))
            return sse([message(json.dumps(proposal['structured_result']))])
        prompt = (proposal['prompt_contract']+' Use exactly these complete argument objects, in order: '
            +json.dumps([expected_arguments(base_policy, proposal, i) for i in (0,1)])
            +'. Do not combine the calls; wait for each successful tool result. After both succeed return ONLY '
            +json.dumps(proposal['structured_result']))
        executable = Path(admission['binding']['stage18c']['codex']['path'])
        acl_tree = ast.parse((ROOT/'agent_system/chatgpt_oauth.py').read_text())
        acl_scripts = {n.value for n in ast.walk(acl_tree) if isinstance(n, ast.Constant)
                       and isinstance(n.value, str) and n.value.startswith('$a=Get-Acl')}
        def trap(argv, *args, **kwargs):
            name = Path(argv[0]).name.lower() if isinstance(argv,(tuple,list)) and argv else ''
            allowed = name in ('git','git.exe') or (name in ('docker','docker.exe') and list(argv[1:3]) == ['--context','desktop-linux'])
            if name == 'codex.exe': allowed = Path(argv[0]).resolve() == executable.resolve() and list(argv[1:]) == ['app-server','--listen','stdio://']
            if name.startswith('python'): allowed = len(argv)==6 and list(argv[1:4])==['-I','-c',CLEANUP]
            if name in ('powershell','powershell.exe'): allowed = len(argv)==5 and list(argv[1:4])==['-NoProfile','-NonInteractive','-Command'] and argv[4] in acl_scripts
            require(allowed, 'Unapproved host process denied')
            return original_popen(argv,*args,**kwargs)
        subprocess.Popen = trap
        with LocalModelRelay(CaptureGate(base_policy,secrets), synthetic) as relay:
            with CodexToolSession(executable, admission['codex_sha256'], invocation, relay, bridge, base_policy) as session:
                session.run(prompt, fixed_result_schema(proposal))
            require(bridge.calls == 0 and len(captured) == 1, 'Local capture must never execute tools')
            channel_filter = SecretFilter([value[k] for k in ('access_token','refresh_token','id_token')]+[relay.child_channel()])
            for p in invocation.rglob('*'):
                if p.is_file(): channel_filter.reject(p.read_bytes().decode(errors='replace'))
        safe_remove_tree(invocation, OUT)
        result['local_capture_complete'] = True
        baseline = captured[0]
        control = variant_body(baseline, 'E_CATALOG_MODEL_CONTROL', model) if model != 'gpt-6-sol' else baseline
        result['baseline_request_shape_fingerprint'] = fingerprint(baseline)
        current = {'record':None}
        def tracked(*args):
            opener = original_opener(*args)
            class Tracked:
                def open(self, request, **kwargs):
                    record = current['record']
                    require(record and not record.get('dispatched') and request.full_url == UPSTREAM
                            and request.get_method() == 'POST' and request.data == current['body'], 'Unexpected/repeated HTTP dispatch denied')
                    record['dispatched'] = True
                    result['responses_posts'] += 1
                    atomic_json(OUT/'execution.json',result)
                    try:
                        response = opener.open(request,**kwargs)
                        record['http_status'] = response.status
                        return response
                    except boundary.HTTPError as error:
                        record['http_status'] = error.code
                        raise  # centralized bounded capture owns and closes error
            return Tracked()
        boundary.build_opener = tracked
        variant = 'E_CATALOG_MODEL_CONTROL' if model != 'gpt-6-sol' else 'A_BASELINE'
        upstream = PlanUpstream(store, policy, approvals, admission_check, runner.cancel_event)
        while variant:
            body = control if variant in ('A_BASELINE','E_CATALOG_MODEL_CONTROL') else variant_body(control, variant)
            require(body['model']==model and body['reasoning']['effort']=='low' and body['parallel_tool_calls'] is False, 'Diagnostic binding mismatch')
            record = {'variant':variant, 'comparison_base':'A_BASELINE' if variant=='E_CATALOG_MODEL_CONTROL' else
                      'E_CATALOG_MODEL_CONTROL' if model != 'gpt-6-sol' else 'A_BASELINE',
                      'catalog_model':model, 'http_status':None, 'http_error':None,
                      'request_shape_fingerprint':fingerprint(body), 'sse_reached':False,
                      'tool_call_reached':False, 'tool_execution':False, 'dispatched':False}
            result['records'].append(record)
            admission_check()
            consume_variant(OUT/'attempts',variant,ledger)
            current.update(record=record,body=json.dumps(body).encode())
            try:
                raw = upstream(body)
                record['sse_reached'] = True
                validator = ResponsesGate(policy,secrets)
                calls,_,_,metadata = validator.inspect_response(raw)
                record['tool_call_reached'] = bool(calls)
                record['gate_structure'] = metadata
                result['admission_success_variant'] = variant
                # Admission diagnosis never releases weakened schemas or
                # diagnostic responses to a model dispatcher.
            except AgentSystemError:
                pass
            record['transport_structure'] = copy.deepcopy(upstream.last_response_metadata)
            record['http_error'] = record['transport_structure'].get('http_error')
            record['sse_reached'] = bool(record['transport_structure'].get('event_counts'))
            record['tool_call_reached'] = bool(record['transport_structure'].get('function_call_count'))
            if record['http_status'] == 200:
                result['provider_admission_observed'] = True
                if variant == 'B_TYPED_CONST':
                    result['verdict'] = 'ROOT_CAUSE_IDENTIFIED'
                    result['root_cause'] = 'Strict const-only function schema incompatibility; adding types alone admitted the request'
                elif variant == 'C_NO_MESSAGE_IDS':
                    result['verdict'] = 'ROOT_CAUSE_IDENTIFIED'
                    result['root_cause'] = 'Input message ID incompatibility; removal alone admitted the request'
                elif variant == 'D_NON_STRICT_CONTROL':
                    result['verdict'] = 'ROOT_CAUSE_IDENTIFIED'
                    result['root_cause'] = 'Explicit strict function schema rejected; non-strict is diagnostic only, no security correction yet'
                elif variant == 'E_CATALOG_MODEL_CONTROL':
                    result['verdict'] = 'ROOT_CAUSE_IDENTIFIED'
                    result['root_cause'] = 'Current requested model absent from account catalog; catalog model admitted unchanged baseline'
                break
            if record['http_status'] != 400:
                break
            variant = next_variant(record, ledger)
            atomic_json(OUT/'execution.json',result)
        require(credential_hashes == {p.name:sha(p) for p in store.directory.iterdir() if p.is_file()}, 'Credentials changed during matrix')
        result['credential_store_unchanged_during_matrix'] = True
    except Exception as error:
        result['safe_failure_category'] = 'admission_or_security_blocker' if isinstance(error,AgentSystemError) else 'local_failure'
    finally:
        subprocess.Popen, boundary.build_opener = original_popen, original_opener
        if bridge: bridge.close()
        try:
            if session: session.close()
            if invocation and invocation.exists(): safe_remove_tree(invocation,OUT)
            result['disposable_codex_home_removed'] = not invocation or not invocation.exists()
            if runner: require(not runner.stale_executions(), 'Stale owned containers after diagnosis')
            result['cleanup_confirmed'] = True
            result['tools_executed'] = bridge.calls if bridge else 0
            for p in OUT.rglob('*'):
                if p.is_file(): secrets.reject(p.read_bytes().decode(errors='replace'))
            result['safe_metadata_secret_checked'] = True
        except Exception:
            result['cleanup_confirmed'] = False
            result['verdict'] = 'FAIL_SECURITY_BOUNDARY'
        result['consumed_variants'] = ledger
        atomic_json(OUT/'execution.json',result)
        print(json.dumps({'verdict':result['verdict'], 'responses_posts':result['responses_posts'],
                          'records':[{'variant':r['variant'],'status':r['http_status'],'error':r['http_error']} for r in result['records']]}))
    return 0

if __name__ == '__main__': raise SystemExit(main())
