"""Stage 17: all role programs and relevant probes use real Linux containers."""
import json
from pathlib import Path
import subprocess
from uuid import uuid4

import pytest

from agent_system.approvals import ApprovalStore
from agent_system.errors import AgentSystemError
from agent_system.git import git
from agent_system.isolation import verify_imports
from agent_system.isolation_probes import host_candidates
from agent_system.storage import atomic_json, read_json


def executions(runner):
    return sorted((runner.root / 'executions').glob('*/ownership.json'))


def test_01_implementer_canary_leakage(real_runner):
    store = real_runner._store()
    report = store.verify('validation')
    assert report['capabilities']['isolated_checkout']['passed']
    assert report['capabilities']['filesystem_read']['passed']
    root = Path(report['probe_input_root'])
    canary = (root / 'implementer/private.txt').read_text()
    assert all(canary not in p.read_text(errors='replace') for p in store.directory.glob('probe-*-stdout.txt'))


def test_02_curious_tester_and_direct_capabilities(real_runner):
    report = real_runner._store().verify('validation')
    assert all(item['passed'] for item in report['capabilities'].values())
    assert report['private_files_unchanged'] and report['cleanup_confirmed']
    assert not real_runner.stale_executions()
    # New backend instances independently load evidence; configuration drift fails.
    from agent_system.runners import create_runner
    create_runner(real_runner.config).isolation_capabilities().require()
    real_runner.options['memory_mb'] = 768
    with pytest.raises(AgentSystemError, match='unverified'):
        real_runner.isolation_capabilities().require()


def test_03_import_provenance(real_case):
    task, make = real_case
    _, controller, runner = make()
    assert controller.resume(task['task_id'])['state'] == 'ACCEPTED'
    workspace = controller.workflow(task['task_id']).git.path('tester')
    observed = verify_imports(workspace, ['src.example'], runner, task)
    assert observed['origins']['src.example'] == ['/workspace/src/example.py']
    with pytest.raises(AgentSystemError, match='escaped'):
        verify_imports(workspace, ['json'], runner, task)


def test_04_forged_approval_and_key_access(real_runner):
    report = real_runner._store().verify('validation')
    checkout = Path(report['probe_input_root']) / 'role source with spaces'
    store = real_runner._store()
    original_key = (store.directory / 'key').read_bytes()
    paths = host_candidates(store.directory / 'key') + host_candidates(store.directory / 'validation.json')
    script = 'import pathlib,json,sys; result=[]\nfor p in json.loads(sys.argv[1]):\n try: result.append(pathlib.Path(p).read_text())\n except OSError: result.append("inaccessible")\nprint(json.dumps(result))'
    cp, _, _ = real_runner._execute(['python', '-c', script, json.dumps(paths)], checkout, 15, {})
    assert cp.returncode == 0 and all(v == 'inaccessible' for v in json.loads(cp.stdout))
    assert (store.directory / 'key').read_bytes() == original_key
    forge = 'import pathlib; pathlib.Path("decision.json").write_text(\'{"approved_by":"forged-role"}\')'
    fake_task = {'_role': 'implementer', '_phase': 'implementation',
                 'scope': {'allowed_paths': ['decision.json'], 'forbidden_paths': []},
                 'workflow': {'test_paths': ['tests/acceptance/**']}}
    real_runner._execute(['python', '-c', forge], checkout, 15, fake_task, False)
    with pytest.raises(AgentSystemError, match='Missing controller'):
        ApprovalStore(store.directory, store.binding).verify('forged-role-decision')
    store.verify('validation')


def test_05_frozen_test_mutation(real_case):
    task, make = real_case
    _, controller, runner = make()
    assert controller.resume(task['task_id'])['state'] == 'ACCEPTED'
    workflow = controller.workflow(task['task_id'])
    workspace = workflow.git.path('integration')
    hidden = workspace / 'tests/acceptance/test_holdout.py'
    original = hidden.read_bytes()
    code = 'from pathlib import Path; Path("tests/acceptance/test_holdout.py").write_text("assert True")'
    result = runner.run_command(['python', '-c', code], workspace, {}, 15, task)
    assert result.returncode != 0 and hidden.read_bytes() == original
    workflow.control.verify('tests/1')


def test_06_gitignored_protected_data(real_runner):
    report = real_runner._store().verify('validation')
    assert report['capabilities']['filesystem_write']['passed']
    root = Path(report['probe_input_root'])
    assert (root / 'role source with spaces/raw/history.csv').read_text() == 'protected history\n'
    observations = [json.loads(p.read_text()) for p in real_runner._store().directory.glob('probe-*-stdout.txt')]
    assert any(o.get('raw/history.csv') is True for o in observations)


def test_07_hidden_architecture_drift(real_case):
    task, make = real_case
    task['scope']['allowed_paths'].append('pyproject.toml')
    _, controller, runner = make('drift')
    state = controller.resume(task['task_id'])
    assert state['state'] == 'ARCHITECTURE_DECISION_REQUIRED', state['detail']
    package = controller.architecture(task['task_id'])
    assert 'pyproject.toml' in package['problem']
    controller.approve_architecture(task['task_id'], package['decision_id'], 'approve', 'human')
    state = controller.resume(task['task_id'])
    assert state['state'] == 'ACCEPTED', state['detail']
    assert any('pyproject.toml' in read_json(p).get('changed_paths', []) for p in executions(runner))


def test_08_incorrect_independent_test(real_case):
    task, make = real_case
    _, controller, runner = make('dispute')
    state = controller.resume(task['task_id'])
    assert state['state'] == 'TEST_DISPUTE', state['detail']
    assert state['fix_cycle'] == 0 and state['dispute_count'] == 1
    controller.resolve_dispute(task['task_id'], 'human')
    state = controller.resume(task['task_id'])
    assert state['state'] == 'ACCEPTED', state['detail']
    assert state['fix_cycle'] == 0 and state['test_version'] == 2


def test_09_actual_diff_data_escalation_and_auditor(real_case):
    task, make = real_case
    task['hardening']['audit_commands'] = [['python', '-c', 'import json; from src.example import value; print(json.dumps({"value":value}))']]
    task['hardening']['data_expectations'] = [{'metric': 'value', 'availability': 'registered', 'minimum': 2, 'maximum': 2}]
    task['scope']['allowed_paths'] = ['src/**', 'tests/**']
    _, controller, runner = make(project_changes={'data_critical_patterns': ['src/example.py']})
    state = controller.resume(task['task_id'])
    assert state['state'] == 'ACCEPTED', state['detail']
    assert state['data_critical']
    workflow = controller.workflow(task['task_id'])
    observed = workflow.evidence.read('cycles/0/auditor/regenerated')
    assert observed['metrics'] == {'value': 2}
    assert observed['imports']['origins']['src.example'] == ['/workspace/src/example.py']
    assert observed['expectations']['passed']
    assert any(read_json(p)['workspace'] == str(workflow.git.path('auditor')) for p in executions(runner))


def test_10_sanitized_feedback_and_holdout_secrecy(real_case):
    task, make = real_case
    _, controller, runner = make('feedback')
    state = controller.resume(task['task_id'])
    assert state['state'] == 'ACCEPTED', state['detail']
    assert state['fix_cycle'] == 1
    workflow = controller.workflow(task['task_id'])
    inputs = workflow.evidence.read(workflow.role_key('fix') + '/intent')['context']['inputs']
    assert 'test_holdout' not in str(inputs) and 'assert value' not in str(inputs)
    implementer = workflow.git.path('implementer')
    holdout = workflow.git.path('tester') / 'tests/acceptance/test_holdout.py'
    probes = host_candidates(holdout)
    script = 'import pathlib,sys,json; result=[]\nfor p in json.loads(sys.argv[1]):\n try: result.append(pathlib.Path(p).read_text())\n except OSError: result.append("inaccessible")\nprint(json.dumps(result))'
    result = runner.run_command(['python', '-c', script, json.dumps(probes)], implementer, {}, 15, task)
    assert result.returncode == 0 and all(v == 'inaccessible' for v in json.loads(result.stdout))
    result = runner.run_command(['git', 'log', '--all', '--name-only'], implementer, {}, 15, task)
    assert result.returncode == 0 and 'test_holdout.py' not in result.stdout
    frozen = workflow.control.verify('tests/1')
    result = runner.run_command(['git', 'show', frozen['commit'] + ':tests/acceptance/test_holdout.py'], implementer, {}, 15, task)
    assert result.returncode != 0
    for path in (runner.root / 'executions').glob('*/command.json'):
        ownership = read_json(path.with_name('ownership.json'))
        if ownership['workspace'] == str(implementer):
            argv = read_json(path)['argv']
            assert 'def test_holdout' not in str(argv) and 'assert value ==' not in str(argv)


def test_11_timeout_and_failure_cleanup(real_runner):
    checkout = Path(real_runner._store().verify('validation')['probe_input_root']) / 'role source with spaces'
    with pytest.raises(subprocess.TimeoutExpired):
        real_runner._execute(['python', '-c', 'import time; time.sleep(30)'], checkout, 0.5, {})
    assert not real_runner.stale_executions()
    cp, directory, _ = real_runner._execute(['python', '-c', 'raise RuntimeError("failure probe")'], checkout, 15, {})
    assert cp.returncode != 0 and read_json(directory / 'ownership.json')['cleanup'] == 'confirmed'
    assert not real_runner.stale_executions()


def test_12_output_overflow_cleanup(real_runner):
    checkout = Path(real_runner._store().verify('validation')['probe_input_root']) / 'role source with spaces'
    with pytest.raises(AgentSystemError, match='output limit'):
        real_runner._execute(['python', '-c', 'import sys; sys.stdout.write("x" * 2000000)'], checkout, 15, {})
    assert not real_runner.stale_executions()


def test_13_real_stale_detection_and_owned_cleanup(real_runner):
    checkout = Path(real_runner._store().verify('validation')['probe_input_root']) / 'role source with spaces'
    execution_id = uuid4().hex
    directory = real_runner.root / 'executions' / execution_id
    directory.mkdir()
    snapshot = real_runner._snapshot(checkout, directory)
    name = 'agentctl-' + real_runner.owner[:12] + '-' + execution_id
    container_id = real_runner._docker(real_runner._create_args(name, snapshot, True)).stdout.strip()
    atomic_json(directory / 'ownership.json', {'owner': real_runner.owner, 'execution_id': execution_id,
                'name': name, 'container_id': container_id, 'status': 'created'})
    assert any(v['Id'] == container_id for v in real_runner.stale_executions())
    real_runner.cleanup_stale(execution_id)
    assert not real_runner.stale_executions()
    assert read_json(directory / 'ownership.json')['cleanup'] == 'confirmed'
