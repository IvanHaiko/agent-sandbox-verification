"""Explicit browser reconnection, strict verification after bounded time wait.

No production verifier changes, clock changes, claim bypass, or inference.
"""
import base64
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / '.test-tmp/stage18-oauth-deps'))
from agent_system.errors import AgentSystemError
from agent_system.storage import atomic_json

MAX_WAIT_SECONDS = 5.0


def bounded_time_decoder(decode, immature_error, diagnostics, now=time.time, sleep=time.sleep):
    def verify(token, *args, **kwargs):
        try:
            return decode(token, *args, **kwargs)
        except immature_error:
            # Untrusted payload is only a bounded delay hint, NEVER an identity.
            try:
                segment = token.split('.')[1]
                if len(segment) > 16384: raise ValueError()
                hint = json.loads(base64.urlsafe_b64decode(segment + '=' * (-len(segment) % 4)))
                stamps = [hint[k] for k in ('iat', 'nbf') if k in hint]
                if not stamps or any(type(v) is not int for v in stamps): raise ValueError()
                wait = max(stamps) - now() + 0.05
            except (ValueError, TypeError, KeyError, IndexError):
                diagnostics['time_hint'] = 'unusable'
                raise immature_error('ID token time hint unavailable') from None
            diagnostics['time_hint'] = 'within_5_seconds' if 0 < wait <= MAX_WAIT_SECONDS else 'outside_5_seconds'
            if not 0 < wait <= MAX_WAIT_SECONDS:
                raise
            diagnostics['bounded_wait_performed'] = True
            sleep(wait)
            # Full original signature/algorithm/issuer/audience/expiry/iat/nbf
            # validation runs again, with exactly unchanged options and no leeway.
            return decode(token, *args, **kwargs)
    return verify


def main():
    if sys.argv[1:] != ['--restore-authorized-session']:
        raise AgentSystemError('Explicit reconnection required')
    import jwt
    from stage19_authorized_smoke import connect
    from agent_system.chatgpt_oauth import CredentialStore, ChatGPTPlanOAuth, AuthError
    diagnostics = {}
    original_decode = jwt.decode
    jwt.decode = bounded_time_decoder(original_decode, jwt.exceptions.ImmatureSignatureError, diagnostics)
    report = {'browser_sign_in': True, 'responses_requests': 0, 'production_verifier_changed': False,
        'clock_changed': False, 'time_validation_disabled': False, 'max_wait_seconds': MAX_WAIT_SECONDS,
        'earlier_attempt': {'success': False, 'signed_decode_error_type': 'ImmatureSignatureError'},
        'official_reference': 'https://developers.openai.com/siwc/website'}
    try:
        result = connect(Path('C:/Users/4ivan/.agentctl/stage19-oauth'))
        store = CredentialStore(Path('C:/Users/4ivan/.agentctl/stage19-oauth'), [ROOT])
        status = ChatGPTPlanOAuth(store).status()
        record = store.read('credentials.json')
        previous = json.loads((ROOT / 'STAGE19_AUTHORIZED_LIVE_SMOKE.json').read_text())
        client_hash = hashlib.sha256(result['client_id'].encode()).hexdigest()
        if client_hash != previous['issued_client_sha256'] or result['account_subject_sha256'] != previous['account_subject_sha256']:
            raise AgentSystemError('Reconnected account binding changed')
        if not status['plan_permission'] or status['access_token_expired']:
            raise AgentSystemError('Reconnected plan session invalid')
        report.update(success=True, connected=True, plan_permission=True, access_token_expired=False,
            existing_client_and_account_match=True, protected_store_verified=True,
            access_valid_for_seconds=int(record['expires_at'] - time.time()))
    except AuthError as error:
        report.update(success=False, safe_error=error.code)
    except AgentSystemError as error:
        safe_codes = {'ChatGPT sign-in timed out': 'browser_callback_timeout',
            'System browser could not open OAuth consent': 'browser_open_failed',
            'ChatGPT ID token verification failed': 'strict_id_token_verification_failed'}
        report.update(success=False, safe_error=safe_codes.get(str(error),
                      'strict_identity_or_storage_verification_failed'))
    finally:
        jwt.decode = original_decode
        report['time_diagnostics'] = diagnostics
        atomic_json(ROOT / 'docs/stage19b-capture-evidence/reconnection.json', report)
    print(json.dumps(report))
    return 0 if report.get('success') else 1


if __name__ == '__main__':
    raise SystemExit(main())
