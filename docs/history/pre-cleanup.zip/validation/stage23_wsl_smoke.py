"""Stage23 three-smoke gate, reusing the proven Stage23B native Linux invocation.

No Tester or later roles are started. Each trial owns a fresh Linux repository
and ephemeral native Codex execution. Stop at the first unusable result.
"""
import hashlib
import json
import os
from pathlib import Path

import stage23b_wsl_smoke as native_smoke

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'docs/stage23-wsl-evidence'


def save_summary(summary):
    (OUT / 'smoke-summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')


def main():
    if os.name == 'nt':
        raise RuntimeError('Run the smoke gate inside Ubuntu WSL2')
    prerequisite = json.loads((ROOT / 'docs/stage23b-evidence/isolated-home-workspace/smoke.json')
                             .read_text(encoding='utf-8'))
    if not prerequisite['passed'] or prerequisite['resolved_model'] != native_smoke.MODEL:
        raise RuntimeError('Stage23B prerequisite not passed')
    OUT.mkdir(parents=True, exist_ok=False)
    (OUT / 'smoke-input.md').write_text(native_smoke.INPUT, encoding='utf-8')
    (OUT / 'smoke-baseline.py').write_text(native_smoke.BASELINE, encoding='utf-8')
    summary = {'required': 3, 'usable': 0, 'gate': 'running', 'backend': 'native WSL Codex CLI',
               'model': native_smoke.MODEL, 'trials': [], 'tester_started': False,
               'prerequisite_counted_as_gate_trial': False}
    identities = set()
    workspaces = set()
    save_summary(summary)
    for number in range(1, 4):
        trial = 'smoke-' + str(number)
        evidence = OUT / trial
        print(trial + ': fresh native WSL execution', flush=True)
        try:
            native_smoke.main(evidence_root=evidence, trial_id=trial)
            record = json.loads((evidence / 'smoke.json').read_text(encoding='utf-8'))
            if record['passed']:
                data = (evidence / 'candidate.py').read_bytes()
                record['controller_archive_verified'] = (
                    data == native_smoke.EXPECTED.encode() and
                    hashlib.sha256(data).hexdigest() == record['candidate_sha256'])
                record['distinct_context_verified'] = (bool(record['thread_id']) and
                    record['thread_id'] not in identities and record['workspace'] not in workspaces)
                record['usable'] = record['controller_archive_verified'] and record['distinct_context_verified']
                identities.add(record['thread_id'])
                workspaces.add(record['workspace'])
                if record['usable']:
                    handoff = {'role': 'implementer', 'trial_id': trial,
                        'execution_status': record['execution_status'],
                        'model': record['resolved_model'], 'changed_files': [native_smoke.TARGET],
                        'candidate_hashes': {native_smoke.TARGET: record['candidate_sha256']},
                        'mutation_scope_valid': True, 'interface_check_passed': True,
                        'deterministic_check': 'exact bytes match frozen add_one contract',
                        'candidate_status': 'unaccepted', 'accepted': False,
                        'authority': 'controller_observed_artifacts', 'diff': record['diff']}
                    (evidence / 'implementer-handoff.json').write_text(
                        json.dumps(handoff, indent=2), encoding='utf-8')
                    summary['usable'] += 1
            else:
                record['usable'] = False
            summary['trials'].append(record)
            print(trial + ': ' + record['execution_status'], flush=True)
            if not record['usable']:
                summary['stop_reason'] = record.get('blocker', 'Controller verification failed')
                break
        except Exception as error:
            summary['stop_reason'] = type(error).__name__ + ': ' + str(error)
            break
        finally:
            save_summary(summary)
    summary['gate'] = 'passed' if summary['usable'] == 3 else 'failed'
    summary['distinct_thread_count'] = len(identities)
    summary['distinct_workspace_count'] = len(workspaces)
    summary['all_trial_workspaces_removed'] = all(
        record.get('cleanup_passed') and not Path(record['workspace']).exists()
        for record in summary['trials']) and len(summary['trials']) == 3
    if not summary['all_trial_workspaces_removed']:
        summary['gate'] = 'failed'
    save_summary(summary)
    print(json.dumps({k: v for k, v in summary.items() if k != 'trials'}, indent=2), flush=True)


if __name__ == '__main__':
    main()
