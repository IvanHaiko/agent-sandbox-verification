"""Final controlled-comparison report. Never sends inference."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'docs/stage19e-live-evidence'
FINAL = ROOT/'docs/stage19e-final-admission-evidence'
def load(path): return json.loads(path.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def tests(path):
    suites = ET.parse(path).getroot().findall('testsuite')
    return {k:sum(int(s.attrib[k]) for s in suites) for k in ('tests','failures','errors','skipped')}

def main():
    execution = load(OUT/'execution.json')
    admission = load(FINAL/'fresh-admission.json')
    prior = load(OUT/'fresh-admission.json')
    sources = {p.relative_to(ROOT).as_posix():sha(p) for p in sorted((ROOT/'agent_system').rglob('*.py'))}
    assert sources == admission['source_sha256']
    changed = [p for p in sources if sources[p] != prior['source_sha256'][p]]
    assert changed == ['agent_system/model_tool_boundary.py']
    e,b = execution['records']
    assert e['variant']=='E_CATALOG_MODEL_CONTROL' and e['http_status']==400
    assert b['variant']=='B_TYPED_CONST' and b['http_status']==200
    assert execution['responses_posts']==2 and execution['tools_executed']==0
    regression = tests(OUT/'after-repair-focused.xml')
    assert regression['failures']==regression['errors']==0
    admission_tests = tests(FINAL/'admission-2.xml')
    assert admission_tests['failures']==admission_tests['errors']==0
    not_run = {'A_BASELINE':'Not dispatched: requested model absent from account-specific catalog',
               'C_NO_MESSAGE_IDS':'Not needed after E/B single-factor comparison',
               'D_NON_STRICT_CONTROL':'Not needed after E/B single-factor comparison'}
    factors = {'E_CATALOG_MODEL_CONTROL':'Only model: gpt-6-sol to catalog-confirmed gpt-6-astra; low retained',
               'B_TYPED_CONST':'Only seven explicit function property types; compared against necessary E control'}
    table = []
    for variant in ('A_BASELINE','E_CATALOG_MODEL_CONTROL','B_TYPED_CONST','C_NO_MESSAGE_IDS','D_NON_STRICT_CONTROL'):
        record = next((r for r in execution['records'] if r['variant']==variant),None)
        error = record['http_error'] or {} if record else {}
        table.append({'variant':variant, 'executed':record is not None,
            'single_changed_factor':factors.get(variant, {'A_BASELINE':'None',
               'C_NO_MESSAGE_IDS':'Input message IDs only', 'D_NON_STRICT_CONTROL':'Function strict flag only'}[variant] if variant not in factors else ''),
            'catalog_model':record['catalog_model'] if record else None,
            'http_status':record['http_status'] if record else None,
            'error_type':error.get('type'), 'code':error.get('code'), 'param':error.get('param'),
            'category':error.get('message_category'), 'sse_reached':bool(record and record['sse_reached']),
            'tool_call_reached':bool(record and record['tool_call_reached']),
            'request_shape_fingerprint':record['request_shape_fingerprint'] if record else None,
            'interpretation':not_run.get(variant, '400 with const-only strict schema' if variant=='E_CATALOG_MODEL_CONTROL'
                else '200 after adding types only; subsequent lifecycle reconciliation rejected final output')})
    report = {'stage':'19e','verdict':'ROOT_CAUSE_IDENTIFIED_AND_REPAIRED',
        'catalog':execution['catalog'], 'catalog_requested_pair_available':False,
        'catalog_control_pair':{'model':'gpt-6-astra','reasoning':'low'},
        'model_control_reason':'Requested gpt-6-sol absent; gpt-6-astra is the available same-generation reasoning model with documented Responses, streaming and function support',
        'capability_reference':'https://developers.openai.com/api/docs/models/gpt-6-astra',
        'capability_evidence_limit':'Catalog directly proves entitlement and reasoning levels; official model documentation proves general Responses/tool capability',
        'exact_executed_variants':execution['consumed_variants'], 'comparison_table':table,
        'variants_not_needed':['C_NO_MESSAGE_IDS','D_NON_STRICT_CONTROL'],
        'variants_not_admitted':['A_BASELINE'], 'responses_posts':2,'responses_posts_max':5,
        'automatic_retries':0,'parallel_requests':0,'tools_executed':0,
        'structured_provider_diagnostics':[{'variant':e['variant'],**e['http_error']}],
        'request_fingerprints':{r['variant']:r['request_shape_fingerprint'] for r in execution['records']},
        'fingerprint_method':'SHA256 over recursively sanitized shape: prose and opaque string values replaced before hashing; no raw body/hash, provider IDs or credentials persisted',
        'controlled_comparisons':[{'base':'E_CATALOG_MODEL_CONTROL','test':'B_TYPED_CONST',
            'single_factor':'Explicit string/integer types on seven const-bound function properties',
            'before_status':400,'after_status':200,'same_in_memory_baseline':True,
            'unchanged':['model/reasoning','namespace','strict:true','const values','required','additionalProperties:false','bounds','input/content/message IDs','text','include','parallel_tool_calls:false','tool_choice'],
            'model_control_held_fixed':'gpt-6-astra/low',
            'combination_justification':'E is independently necessary because the account catalog excludes gpt-6-sol; B tests one additional independent schema variable'}],
        'observed_facts':['Fresh browser OAuth sign-in succeeded under strict identity verification',
            'Current catalog excludes gpt-6-sol and includes gpt-6-astra/low',
            'E returned HTTP400; B changed only property types and returned HTTP200',
            'B body EOF and reader shutdown confirmed; lifecycle final bijection failed',
            'Zero diagnostic tools executed'],
        'root_cause_conclusion':'Controlled admission incompatibility of strict const-only function properties: explicit property types alone changed HTTP400 to HTTP200 on the same catalog model',
        'inference':'The provider strict-schema handling is implicated; its compiler implementation and exact rejection prose are not known',
        'confirmed_root_cause_scope':'Current request admission comparison only; no live A on unavailable model and no claim of exact historical gpt-6-sol server rejection mechanism',
        'error_capture_limit':'400 metadata was suppressed_or_malformed: type/code/param unavailable; no precise provider error cause claimed',
        'production_correction':{'file':'agent_system/model_tool_boundary.py','function':'tool_spec',
            'change':'Add string type to six string const properties and integer type to contract_version; retain exact const and strict boundary',
            'strict_disabled':False,'message_ids_removed':False,'permanent_model_switch':False},
        'production_source_before':prior['source_bundle_sha256'],
        'production_source_after':admission['source_bundle_sha256'], 'changed_production_files':changed,
        'previous_admission_stale':True, 'final_fresh_admission_passed':True,
        'final_admission_binding':admission['binding'],
        'final_signed_transport_proof_verified':True,'offline_regression_after_correction':regression,
        'final_admission_tests':admission_tests, 'signed_no_credit_attestation_issued':True,
        'validation_limit':'Full default suite stopped during unrelated workflow tests; 421 relevant post-repair tests passed. First final admission failed on case-sensitive cancellation assertion; new test corrected and second admission passed. Both admission results retained.',
        'signed_diagnostic_live_authorization_issued':True,
        'human_confirmation_timestamp_basis':load(OUT/'human-authorization.json')['timestamp_basis'],
        'attestation_uses_original_confirmation_timestamp':True,
        'another_final_smoke_required':True,
        'final_smoke_requirements':['Use fresh final-admission bundle and revalidate runtime/source binding',
            'Refresh catalog/credential freshness if elapsed time requires it',
            'Bind final smoke approval/no-credit attestation to a new execution and confirmed catalog model',
            'Retain strict schema, exact two-tool smoke constraints and lifecycle reconciliation'],
        'stage19_status':'FAIL_LIVE_TRANSPORT','stage19_passed':False,
        'stage19_failure_limit':'Diagnostic HTTP200 failed lifecycle reconciliation; full end-to-end smoke not executed',
        'stage20_technically_admissible':False,'stage20_started':False,
        'remaining_allowance_not_consumed':3,'stop_reason':'Controlled root-cause comparison complete; no further diagnostic variants',
        'safe_execution_evidence':execution,
        'initial_precondition_stop_preserved':'docs/stage19e-evidence/precondition-stop-STAGE19E_HTTP400_DIAGNOSTIC_MATRIX.json'}
    (ROOT/'STAGE19E_HTTP400_DIAGNOSTIC_MATRIX.json').write_text(json.dumps(report,indent=2)+'\n')
    lines=['# Stage19e — Controlled HTTP 400 diagnostic matrix','',
        '**ROOT_CAUSE_IDENTIFIED_AND_REPAIRED**. Two sequential live POSTs: catalog model control returned 400; adding explicit types to seven strict const-bound function properties returned 200. No diagnostic tool executed. Strict mode remains enabled.','',
        '## Credentials, catalog and admission','',
        'Fresh browser login succeeded with signature, issuer/audience/time/nonce checks intact. Credentials stayed in the protected store. The previous expired-credential stop is preserved separately; it was followed by the requested new sign-in and complete re-admission. No credentials, callbacks, account IDs or provider IDs were exported.','',
        '`gpt-6-sol / low` is **not available** in the fresh account catalog. Available relevant pairs:', '']
    for model in execution['catalog']['models']:
        lines.append(f"- `{model['model']}`: {', '.join(model['reasoning'])}.")
    lines += ['', 'E used `gpt-6-astra / low`, the available same-generation reasoning model. Catalog entitlement/reasoning and [official Responses/function/streaming support](https://developers.openai.com/api/docs/models/gpt-6-astra) justify this explicit control. No A POST was sent on an unavailable model and no permanent model substitution was applied.','',
        'Real Docker/Codex admission was rebuilt after login, then rebuilt again after the correction. Both verified signed transport proof, current executable, pinned image, engine/config/project binding and isolation/cleanup. Role network remained denied; model tools were not executed by the matrix. Fresh execution/client-bound no-credit and live signatures used the actual original human-confirmation handling timestamp, without refreshing or fabricating it.','',
        '## Comparison','',
        '| Variant | Single changed factor | Catalog model | HTTP status | Error type | Code | Param | Category | SSE reached | Tool call reached | Interpretation |',
        '|---|---|---|---:|---|---|---|---|---|---|---|']
    for row in table:
        vals=[row['variant'],row['single_changed_factor'],row['catalog_model'] or '—',
              str(row['http_status'] or '—'),row['error_type'] or '—',row['code'] or '—',row['param'] or '—',
              row['category'] or '—','Yes' if row['sse_reached'] else 'No','Yes' if row['tool_call_reached'] else 'No',row['interpretation']]
        lines.append('| '+' | '.join(vals)+' |')
    lines += ['', 'B was compared against E, holding the catalog-required model correction fixed. Both requests came from the **same in-memory baseline**: identical messages and IDs, prompt, reasoning, text/include, namespace, strict flag, constants, bounds and tool choice. B added only seven property types. This is the permitted one-additional-variable experiment after independently establishing E as necessary from the catalog.','',
        'The 400 error went through centralized bounded capture. It produced status=400 and category=`suppressed_or_malformed`; type/code/param are unavailable. No raw error body or prose was persisted. The root-cause conclusion rests on the controlled 400→200 comparison, not an invented provider error.','',
        'Request shape fingerprints:', '']
    for variant,fp in report['request_fingerprints'].items(): lines.append(f'- `{variant}`: `{fp}`.')
    lines += ['', 'Fingerprints hash sanitized shape, with opaque IDs, prose and private string values replaced first. No raw request body is persisted. Exclusive consumed-variant files and the matrix latch prevent repeating E or B; the remaining three allowances were not consumed. C and D were not needed.','',
        '## Facts, inference and root-cause scope','',
        '**Observed:** E=400; B=200 after types only. **Controlled conclusion:** the current strict const-only function declaration has an admission incompatibility corrected by explicit types. **Inference:** strict schema compilation/handling is implicated. The exact provider compiler failure and historical `gpt-6-sol` rejection cannot be reconstructed from this comparison. Model absence is a separate current catalog fact.','',
        'B reached a bounded 26,667-byte SSE body with EOF and reader shutdown confirmed; MIME was absent. Lifecycle reconciliation ran and rejected `stream_final_bijection=false`, with zero function calls. Missing-MIME compatibility was not accepted because full validation failed. No response was released to a tool dispatcher. This **does not pass Stage19** and does not justify weakening lifecycle enforcement.','',
        '## Repair and validation','',
        'Only `agent_system/model_tool_boundary.py:tool_spec` changed in production: string/integer types were added to seven const-bound properties. All const values, strict mode, required fields, additionalProperties=false and bounds remain. The production schema is regression-checked against the admitted B candidate; wrong identity/type and extra-authority arguments remain rejected. Message IDs, non-strict controls and default model configuration were not adopted.','',
        f"Post-repair relevant offline suite: **{regression['tests']-regression['skipped']} passed**, {regression['skipped']} skipped, zero failures/errors. Before dispatch, 283 focused tests passed. Final real admission: **{admission_tests['tests']} passed**. A broader default suite was stopped during unrelated workflow tests; no full-suite pass is claimed.",'',
        'First final admission failed because its cancellation assertion expected lowercase cancel while the fixed error began Cancelled. The new admission test matches cancellation case-insensitively; production enforcement is unchanged. The second admission passed; both results are retained.','',
        f"Previous source bundle: `{prior['source_bundle_sha256']}` (stale after repair). Final source bundle: `{admission['source_bundle_sha256']}`. Final signed admission and the unchanged-source check are in `docs/stage19e-final-admission-evidence/fresh-admission.json`.",'',
        'A separate final Stage19 smoke remains required under the fresh repaired admission, a catalog-confirmed model, fresh execution-bound approvals, exact smoke commands and unchanged strict lifecycle checks. No additional live POST was sent after identifying the correction. Stage19 remains `FAIL_LIVE_TRANSPORT`; Stage20 is not admissible and was not started.','',
        'Evidence: [live observations](docs/stage19e-live-evidence/execution.json), [catalog](docs/stage19e-live-evidence/catalog.json), [consumed attempts](docs/stage19e-live-evidence/attempts/consumed-attempts.json), [post-repair tests](docs/stage19e-live-evidence/after-repair-focused.xml), [final admission](docs/stage19e-final-admission-evidence/fresh-admission.json), [reconnection](docs/stage19e-evidence/reconnection.json).']
    (ROOT/'STAGE19E_HTTP400_DIAGNOSTIC_MATRIX.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({'verdict':report['verdict'],'posts':2,'regression':regression,'final_source_bundle':admission['source_bundle_sha256']}))

if __name__=='__main__': main()
