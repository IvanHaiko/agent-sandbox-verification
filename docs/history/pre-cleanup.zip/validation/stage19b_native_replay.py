"""Pinned native provider reconstruction with synthetic localhost only."""
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tests'))
from agent_system.agent_transport import InvocationBinding, strict_json
from agent_system.codex_tool_session import CodexToolSession
from agent_system.model_tool_boundary import ExecutionPolicy, ResponsesGate, LocalModelRelay, IsolatedExecutionBridge
from test_model_tool_boundary import Runner, message, sse


def describe(body):
    return {'fields': sorted(body), 'model': body.get('model'), 'reasoning': body.get('reasoning'),
        'stream': body.get('stream'), 'store': body.get('store'), 'input_type': type(body.get('input')).__name__,
        'input_items': [{'type': v.get('type') if v.get('type') in ('message', 'reasoning', 'function_call', 'function_call_output') else 'other',
                         'role': v.get('role') if v.get('role') in ('user', 'assistant', 'developer', 'system') else None}
                        for v in body.get('input', []) if isinstance(v, dict)],
        'tool_types': [v.get('type') for v in body.get('tools', [])],
        'tool_choice': body.get('tool_choice'), 'input_text_exported': False}


def main():
    old = strict_json((ROOT / 'STAGE18C_MODEL_TOOL_BOUNDARY.json').read_text())['runtime']['binding']['stage18c']['codex']
    new = strict_json((ROOT / 'docs/stage19-evidence/second-live-observations.json').read_text())['binding']['stage18c']['codex']
    records = []
    for version, runtime in [('0.159.2', old), ('0.160.0', new)]:
        executable = Path(runtime['path'])
        record = {'version': version, 'historical_exact_payload': 'UNKNOWN', 'openai_requests': 0}
        if not executable.is_file():
            record['replay'] = 'pinned binary unavailable'
            records.append(record); continue
        assert hashlib.sha256(executable.read_bytes()).hexdigest() == runtime['sha256']
        home = ROOT / '.test-tmp/stage19b-native-replay' / version
        policy = ExecutionPolicy(InvocationBinding('offline-native-replay', 'implementer', 'REPLAY', 1, 'gpt-6-astra', 'low'),
            'implementation', 'offline-owned', time.monotonic() + 30)
        class ObservedGate(ResponsesGate):
            def request(self, raw):
                record['native_request'] = describe(strict_json(raw.decode()))
                return super().request(raw)
        def synthetic(body):
            record['gated_request'] = describe(body)
            return sse([message(json.dumps({'task_id': 'REPLAY', 'contract_version': 1, 'outcome': 'completed',
                'summary': 'Synthetic offline completion', 'architecture_decision': None}))])
        runner = Runner()
        bridge = IsolatedExecutionBridge(runner, 'offline-selection', {}, policy)
        with LocalModelRelay(ObservedGate(policy), synthetic) as relay:
            with CodexToolSession(executable, runtime['sha256'], home, relay, bridge, policy) as session:
                session.run('Offline provider reconstruction only. Return the supplied synthetic completion. Do not call tools.')
            assert session.process.poll() == 0 and not runner.calls
        record['replay'] = 'synthetic native session completed; no tools'
        records.append(record)
    out = ROOT / 'docs/stage19b-evidence/native-replay.json'
    out.write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(records))


if __name__ == '__main__':
    main()
