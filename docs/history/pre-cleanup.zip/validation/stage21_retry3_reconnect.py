"""Explicit user-requested OAuth browser reconnection. No inference or tokens exported."""
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / '.test-tmp/stage18-oauth-deps')]
from agent_system.chatgpt_oauth import CredentialStore, ChatGPTPlanOAuth
from agent_system.storage import atomic_json
from validation.stage19_authorized_smoke import connect
from validation.stage19_reconnect import bounded_time_decoder


def main():
    import jwt
    record = {'human_requested_browser_sign_in': True, 'started_at': time.time(),
              'success': False, 'responses_posts': 0, 'raw_credentials_exported': False,
              'production_verifier_changed': False}
    diagnostics, original = {}, jwt.decode
    jwt.decode = bounded_time_decoder(original, jwt.exceptions.ImmatureSignatureError, diagnostics)
    try:
        store = CredentialStore(Path('C:/Users/4ivan/.agentctl/stage19-oauth'), [ROOT])
        before = store.read('credentials.json')
        result = connect(store.directory)
        after = store.read('credentials.json')
        assert before['client_id'] == after['client_id'] and before['subject'] == after['subject']
        status = ChatGPTPlanOAuth(store).status()
        record.update(same_client_and_account=True,
            success=bool(result['oauth_connection_success'] and status['plan_permission'] and not status['access_token_expired']),
            valid_for_seconds=int(after['expires_at'] - time.time()), protected_store_verified=True,
            plan_permission=status['plan_permission'], access_token_expired=status['access_token_expired'])
    except Exception:
        record['failure_category'] = 'browser_or_strict_identity_verification_failed'
    finally:
        jwt.decode = original
        record['time_diagnostics'] = diagnostics
        atomic_json(ROOT / 'docs/stage21-retry3-evidence/reconnection.json', record)
        print(json.dumps(record), flush=True)
    return 0 if record['success'] else 1


if __name__ == '__main__':
    assert sys.argv[1:] == ['--user-authorized-browser-sign-in']
    raise SystemExit(main())
