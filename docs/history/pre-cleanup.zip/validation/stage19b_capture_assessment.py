"""Finalize separate diagnostic attempt, with no account or inference calls."""
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from agent_system.config import Configuration
from agent_system.runners.tool_docker import ToolDockerRunner
from agent_system.storage import atomic_json


def main():
    out = ROOT / 'docs/stage19b-capture-evidence'
    capture = json.loads((out / 'capture.json').read_text())
    admission = json.loads((out / 'fresh-admission.json').read_text())
    historical = json.loads((ROOT / 'docs/stage19b-evidence/historical-hashes.json').read_text())
    assert all(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected
               for name, expected in historical.items())
    assert capture['http_dispatch_attempts'] == 0 and capture['refresh_attempts'] == 1
    assert capture['safe_failure_reason'] == 'ChatGPT ID token verification failed'
    passed = 0
    for name in ('observer.xml', 'entrypoint.xml', 'admission-final.xml'):
        tree = ET.parse(out / name).getroot()
        assert not any(list(tree.iter(kind)) for kind in ('error', 'failure', 'skipped'))
        passed += len(list(tree.iter('testcase')))
    assert passed == 47
    runner = ToolDockerRunner(Configuration.load(Path(admission['project'])))
    assert runner.preflight() == admission['binding']
    runner.require_transport_admission()
    assert not runner.stale_executions()
    assert (Path(admission['workspace']) / 'src/example.py').read_text() == 'value = 1\n'
    assert not (ROOT / '.test-tmp/stage19b-capture-native/home').exists()
    report = {'date': '2026-10-06', 'stage': '19b-authorized-capture',
        'verdict': 'BLOCKED_AUTH_BEFORE_INFERENCE', 'capture': capture,
        'operator_authorized': 'one diagnostic request; fresh explicit credits-fallback off/remains-off confirmation',
        'observed': {'responses_posts_dispatched': 0, 'responses_received': 0, 'oauth_refresh_attempts': 1,
            'validated_refresh': False, 'new_sign_in_attempts': 0, 'catalog_requests': 0,
            'model_selected_tool_calls': 0, 'live_codex_session': False,
            'fresh_passed_tests': passed, 'fresh_diagnostic_tests': 40, 'fresh_entrypoint_tests': 6,
            'fresh_real_docker_native_admission': True, 'admission_model_provider': 'synthetic-localhost-only',
            'raw_unknown_body_captured': False, 'raw_body_persisted': False,
            'historical_22_files_unchanged': True, 'stale_owned_containers': 0,
            'native_home_removed': True, 'owned_workspace_at_baseline': True,
            'production_acceptance_changed': False},
        'inferred': {'failure_stage': 'OAuth refresh _record -> strict verify_identity; no Responses dispatch reached',
            'credentials_replacement_on_this_failure': 'refresh writes credentials only after successful verification; no replacement from this rejected result',
            'server_side_refresh_rotation': 'UNKNOWN; do not assume old refresh token remains reusable',
            'one_execution_latch': 'preserved; no automatic retry or reset',
            'next_step': 'separate authorized reconnection/authentication diagnosis before any further inference attempt',
            'stage19_verdict': 'FAIL_LIVE_TRANSPORT', 'stage19_passed': False, 'stage20_admissible': False},
        'unknown': ['exact ID-token verification failure reason; raw auth data not retained/exported',
            'whether server rotated refresh credentials before verification failed',
            'historical HTTP200 response body format/cause, unchanged from Stage19b'],
        'source_sha256': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in (
            'validation/stage19b_capture.py', 'validation/test_stage19b_capture_entrypoint.py',
            'validation/test_stage19b_capture_admission.py', 'validation/stage19b_capture_assessment.py',
            'agent_system/transport_diagnostics.py')}}
    atomic_json(ROOT / 'STAGE19B_AUTHORIZED_CAPTURE.json', report)
    print(json.dumps({'verdict': report['verdict'], 'responses_posts': 0,
                      'fresh_passed_tests': passed, 'stale_containers': 0, 'history_unchanged': True}))


if __name__ == '__main__':
    main()
