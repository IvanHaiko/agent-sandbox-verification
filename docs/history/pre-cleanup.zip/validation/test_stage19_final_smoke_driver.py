"""Offline guards for the human-authorized driver; never invokes its live entry point."""
import copy
from datetime import datetime, timezone
import json
from pathlib import Path
from types import SimpleNamespace

import pytest
from jsonschema import Draft202012Validator

from agent_system.errors import AgentSystemError
from agent_system.model_tool_boundary import IsolatedExecutionBridge
from stage19_final_smoke import (ExactBridge, ExactGate, expected_arguments,
    fixed_result_schema, consume_latch, CONFIRMATION_TIME, ROOT)
from test_model_tool_boundary import function, sse, body, message
from test_stage19c_reconciliation import policy


@pytest.fixture
def proposal():
    return json.loads((ROOT/'docs/stage19d-evidence/final-smoke-proposal.json').read_text())


def test_original_billing_confirmation_clock_and_strict_result(proposal):
    assert datetime.fromtimestamp(CONFIRMATION_TIME, timezone.utc).strftime('%Y-%m-%d %H:%M:%S') == '2026-10-06 08:29:30'
    schema = fixed_result_schema(proposal)
    validator = Draft202012Validator(schema)
    assert validator.is_valid(proposal['structured_result'])
    assert not validator.is_valid({**proposal['structured_result'], 'extra': 'provider prose'})
    assert not validator.is_valid({**proposal['structured_result'], 'summary': 'something else'})


def test_exclusive_latch_cannot_be_reused(tmp_path):
    path = tmp_path/'latch'
    consume_latch(path)
    before = path.read_bytes()
    with pytest.raises(FileExistsError): consume_latch(path)
    assert path.read_bytes() == before


@pytest.mark.parametrize('step', [0, 1, 2])
def test_valid_response_exact_order_and_no_final_tools(proposal, step):
    p = policy(); gate = ExactGate(p, proposal=proposal, bridge=SimpleNamespace(successful=step), observed={})
    gate.requests = step+1
    if step < 2:
        item = function(p); item['arguments'] = json.dumps(expected_arguments(p, proposal, step))
    else: item = message(json.dumps(proposal['structured_result']))
    assert gate.response(sse([item]))
    assert gate.last_response_metadata['smoke_scope_passed']
    assert len(gate.authorized_arguments) == (1 if step < 2 else 0)


@pytest.mark.parametrize('attack', ['unexpected_argv', 'wrong_step', 'multiple_calls', 'missing_tool', 'tool_in_final', 'previous_tool_not_successful'])
def test_scope_rejection_is_atomic_and_cannot_dispatch(proposal, attack):
    p = policy(); observed = {}; bridge = SimpleNamespace(successful=0)
    gate = ExactGate(p, proposal=proposal, bridge=bridge, observed=observed); gate.requests = 1
    item = function(p); item['arguments'] = json.dumps(expected_arguments(p, proposal, 0))
    items = [item]
    if attack == 'unexpected_argv':
        args = expected_arguments(p, proposal, 0); args['argv'] = ['python', '-c', 'print("unexpected")']; item['arguments'] = json.dumps(args)
    elif attack == 'wrong_step': item['arguments'] = json.dumps(expected_arguments(p, proposal, 1))
    elif attack == 'multiple_calls':
        second = copy.deepcopy(item); second.update(id='fc-second', call_id='call-second'); items.append(second)
    elif attack == 'missing_tool': items = [message()]
    elif attack == 'tool_in_final': gate.requests = 3; bridge.successful = 2
    elif attack == 'previous_tool_not_successful': gate.requests = 2
    original = gate.authorized_arguments
    with pytest.raises(AgentSystemError): gate.response(sse(items))
    assert gate.authorized_arguments is original and not gate.seen_calls and not gate.seen_items and not gate.seen_responses
    assert observed['tool_boundary_failure'] and gate.last_response_metadata['smoke_scope_passed'] is False


def test_parallel_calls_are_disabled_in_actual_provider_request(proposal):
    p = policy(); gate = ExactGate(p, proposal=proposal, bridge=SimpleNamespace(successful=0), observed={})
    request = body(p); request['parallel_tool_calls'] = True
    assert gate.request(json.dumps(request).encode())['parallel_tool_calls'] is False


@pytest.mark.parametrize('attack', ['argv', 'read_only', 'timeout', 'output', 'identity', 'third_call', 'previous_failure'])
def test_bridge_denies_deviation_before_underlying_execute(proposal, attack, monkeypatch):
    p = policy(); reached = []
    monkeypatch.setattr(IsolatedExecutionBridge, 'execute', lambda *args: reached.append(True))
    runner = SimpleNamespace(backend='docker_isolated', run_tool=lambda: None)
    bridge = ExactBridge(runner, 'fixture', {}, p, proposal=proposal, observed={})
    args = expected_arguments(p, proposal, 0)
    if attack == 'argv': args['argv'] = ['python', '-c', 'print("unexpected")']
    elif attack == 'read_only': args['read_only'] = True
    elif attack == 'timeout': args['timeout_seconds'] = 19
    elif attack == 'output': args['output_bytes'] = 1024
    elif attack == 'identity': args['execution_id'] = 'other'
    elif attack == 'third_call': bridge.calls = bridge.successful = 2
    elif attack == 'previous_failure': bridge.calls = 1
    with pytest.raises(AgentSystemError): bridge.execute(args)
    assert not reached and bridge.observed['tool_boundary_failure']


def test_bridge_exact_outputs_and_sequential_success(proposal, monkeypatch):
    p = policy()
    def fake_execute(self, args):
        step = self.calls; self.calls += 1
        return {'returncode': 0, 'stdout': ['stage19-mutated\n', 'stage19-verified\n'][step], 'stderr': ''}
    monkeypatch.setattr(IsolatedExecutionBridge, 'execute', fake_execute)
    bridge = ExactBridge(SimpleNamespace(backend='docker_isolated', run_tool=lambda: None), 'fixture', {}, p,
                         proposal=proposal, observed={})
    for step in (0, 1): bridge.execute(expected_arguments(p, proposal, step))
    assert bridge.successful == bridge.calls == 2 and all(c['stdout_exact'] for c in bridge.checks)


@pytest.mark.parametrize('result', [{'returncode': 1, 'stdout': '', 'stderr': ''},
                                  {'returncode': 0, 'stdout': 'unexpected', 'stderr': ''},
                                  {'returncode': 0, 'stdout': 'stage19-mutated\n', 'stderr': 'unexpected'}])
def test_output_deviation_stops_and_is_not_success(proposal, result, monkeypatch):
    p = policy()
    def fake_execute(self, args): self.calls += 1; return result
    monkeypatch.setattr(IsolatedExecutionBridge, 'execute', fake_execute)
    bridge = ExactBridge(SimpleNamespace(backend='docker_isolated', run_tool=lambda: None), 'fixture', {}, p,
                         proposal=proposal, observed={})
    with pytest.raises(AgentSystemError): bridge.execute(expected_arguments(p, proposal, 0))
    assert bridge.successful == 0
    with pytest.raises(AgentSystemError): bridge.execute(expected_arguments(p, proposal, 1))
    assert bridge.calls == 1
