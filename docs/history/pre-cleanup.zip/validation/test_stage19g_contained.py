"""Real Codex/Docker roundtrip with synthetic provider responses and acceptance checks."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

import pytest
import yaml

from agent_system.agent_transport import InvocationBinding
from agent_system.codex_tool_session import CodexToolSession
from agent_system.config import Configuration
from agent_system.errors import AgentSystemError
from agent_system.git import WorktreeManager, git
from agent_system.model_tool_boundary import ExecutionPolicy, IsolatedExecutionBridge, ResponsesGate, LocalModelRelay, SecretFilter
from agent_system.runners.tool_docker import ToolDockerRunner
from agent_system.runners.docker_isolated import regular_tree
from agent_system.storage import atomic_json
from conftest import settings
from test_model_tool_boundary import function, message, sse, tool_request


def test_contained_two_calls_anomaly_verification_and_export(project, hardened, tmp_path, monkeypatch):
    config_path = project / '.agent_system/project.yaml'
    config_data = yaml.safe_load(config_path.read_text())
    config_data['runtime'] = {'version': 2, 'root': str(tmp_path / 'runtime')}
    config_data['runner'] = settings('stage19g')
    config_path.write_text(yaml.safe_dump(config_data))
    runner = ToolDockerRunner(Configuration.load(project))
    isolation = runner.validate_isolation()
    assert isolation['admitted'] and isolation['model_calls'] == 0
    task = json.loads(json.dumps(hardened[0]))
    task['scope']['allowed_paths'] = ['src/example.py']
    manifest = WorktreeManager(runner.config).prepare(task['task_id'], git(project, 'rev-parse', 'HEAD'), False, isolated_tester=True)
    workspace = Path(manifest['worktrees']['implementer']['path'])
    secret = 'synthetic-controller-canary-123456'
    policy = ExecutionPolicy(InvocationBinding('stage19g-synthetic', 'implementer', task['task_id'], 1, 'gpt-6-astra', 'low'),
                             'implementation', 'controller-workspace', time.monotonic()+180)
    bridge = IsolatedExecutionBridge(runner, workspace, task, policy, SecretFilter([secret]))
    gate = ResponsesGate(policy, bridge.secrets)
    calls = []
    role_result = {'task_id': task['task_id'], 'contract_version': 1, 'outcome': 'completed',
                   'summary': 'Changed and verified value.', 'architecture_decision': None}
    mutation = "from pathlib import Path; p=Path('src/example.py'); assert p.read_text() == 'value = 1\\n'; p.write_text('value = 2\\n'); print('mutated')"
    verification = "import os,socket,runpy; assert runpy.run_path('src/example.py')['value'] == 2; assert 'AGENTCTL_MODEL_CHANNEL' not in os.environ; s=socket.socket(); s.settimeout(.2)\ntry: s.connect(('1.1.1.1',443)); raise AssertionError('network accessible')\nexcept OSError: pass\nprint('verified')"
    def upstream(body):
        step = len(calls)
        calls.append(body)
        if step == 2: return sse([message(json.dumps(role_result))], response_id='r-final')
        item = function(policy, call_id='call-'+str(step))
        item['id'] = 'function-'+str(step)
        args = tool_request(policy)
        args.update(argv=['python', '-c', (mutation, verification)[step]], read_only=step == 1, timeout_seconds=20)
        item['arguments'] = json.dumps(args)
        reasoning = {'type': 'reasoning', 'id': 'reasoning-'+str(step), 'summary': []}
        raw = sse([reasoning, item], response_id='r-'+str(step))
        events = [json.loads(frame.split('data: ',1)[1]) for frame in raw.decode().strip().split('\n\n')]
        events[-1]['response']['output'].pop(0)  # Harmless inventory mismatch must reach real Codex.
        return ''.join('event: '+e['type']+'\ndata: '+json.dumps(e)+'\n\n' for e in events).encode()
    original_popen = subprocess.Popen
    def guarded_popen(argv, *args, **kwargs):
        first = Path(argv[0]).name.lower()
        if first.startswith('python'):
            from agent_system.runners.docker_isolated import CLEANUP
            assert len(argv) == 6 and argv[1:4] == ['-I', '-c', CLEANUP], 'Generated host Python'
        else: assert first in ('docker', 'docker.exe', 'git', 'git.exe', 'codex.exe'), 'Generated host process'
        return original_popen(argv, *args, **kwargs)
    monkeypatch.setattr(subprocess, 'Popen', guarded_popen)
    executable = Path(shutil.which('codex'))
    with LocalModelRelay(gate, upstream) as relay:
        with CodexToolSession(executable, hashlib.sha256(executable.read_bytes()).hexdigest(), tmp_path/'model-home', relay, bridge, policy) as session:
            assert session.run('Perform the two synthetic tool calls and return the final result.') == role_result
    assert session.process.poll() == 0
    model_home = (tmp_path/'model-home').resolve()
    assert model_home.parent == tmp_path.resolve() and model_home.name == 'model-home'
    regular_tree(model_home)
    shutil.rmtree(model_home)
    assert not (tmp_path/'model-home').exists()
    assert len(calls) == 3 and bridge.calls == 2 and bridge.changed_paths == {'src/example.py'}
    assert (workspace/'src/example.py').read_text() == 'value = 2\n'
    assert (project/'src/example.py').read_text() == 'value = 1\n'
    assert all(r['validation_passed'] for r in gate.response_metadata_history)
    assert any(r['anomalies'] for r in gate.response_metadata_history)
    # Controller snapshot/export rejects an unexpected artifact before copying it back.
    bad = tool_request(policy)
    bad.update(argv=['python','-c',"from pathlib import Path; Path('unexpected.txt').write_text('unsafe artifact')"], read_only=False)
    fresh_bridge = IsolatedExecutionBridge(runner, workspace, task, policy)
    with pytest.raises(AgentSystemError): fresh_bridge.execute(bad)
    assert not (workspace/'unexpected.txt').exists()
    bad.update(argv=['python','-c',"import runpy; assert runpy.run_path('src/example.py')['value'] == 99"], read_only=True)
    verification_failed = fresh_bridge.execute(bad)['returncode'] != 0
    assert verification_failed
    assert not runner.stale_executions()
    records = list(runner.root.glob('executions/*/ownership.json'))
    assert all(json.loads(p.read_text())['cleanup'] == 'confirmed' for p in records)
    assert all(json.loads(p.read_text())['storage_cleanup'] == 'confirmed' for p in records)
    atomic_json(Path(__file__).resolve().parents[1]/'docs/stage19g-evidence/contained-summary.json', {
        'real_codex': True, 'real_docker': True, 'model_calls': 0, 'sequential_tool_calls': 2,
        'nonexecutable_anomaly_continued': True, 'network_denied': True, 'host_execution_trap': True,
        'unexpected_export_rejected': True, 'verification_failure_measured': verification_failed,
        'cleanup_confirmed': True, 'codex_home_removed': True,
        'capabilities': {k:v['passed'] for k,v in isolation['capabilities'].items()},
        'response_metadata': gate.response_metadata_history})
