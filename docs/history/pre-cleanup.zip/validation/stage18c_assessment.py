"""Reproducible Stage18c assessment; preserves all earlier checkpoints."""
import contextlib
import hashlib
import io
import json
from pathlib import Path
import shutil
import sys

import pytest

from stage18_chatgpt_assessment import Collector, passed_nodes

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
OUT = ROOT / 'docs/stage18c-evidence'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    collector = Collector()
    with contextlib.redirect_stdout(io.StringIO()):
        result = pytest.main(['tests', '--collect-only', '-q', '-p', 'no:cacheprovider'], plugins=[collector])
    assert result == 0
    sources = ['docs/stage18-evidence/regression/full.xml',
               'docs/stage18-chatgpt-evidence/focused-final-pass.xml',
               'docs/stage18c-evidence/focused-complete.xml']
    suites = [passed_nodes(ROOT / p) for p in sources]
    covered = set.union(*suites)
    assert not collector.nodes - covered, sorted(collector.nodes - covered)
    local = covered - collector.nodes
    real = passed_nodes(OUT / 'real-final-2.xml')
    crypto = passed_nodes(ROOT / 'docs/stage18-chatgpt-evidence/signatures-complete.xml')
    assert len(local) == 1 and len(real) == 1 and len(crypto) == 10
    previous = json.loads((ROOT / 'STAGE18_CHATGPT_PLAN_TRANSPORT.json').read_text(encoding='utf-8'))
    immutable = previous['historical_sha256'].copy()
    for name, expected in immutable.items():
        assert sha(ROOT / name) == expected, name
    for name in ('STAGE18_CHATGPT_PLAN_TRANSPORT.md', 'STAGE18_CHATGPT_PLAN_TRANSPORT.json'):
        immutable[name] = sha(ROOT / name)
    measured = json.loads((OUT / 'real-summary.json').read_text(encoding='utf-8'))
    base = ['runners/docker_isolated.py', 'isolation_probes.py', 'isolation.py',
            'contexts.py', 'gates.py', 'mechanical_gates.py']
    base_hash = hashlib.sha256(b''.join((ROOT / 'agent_system' / p).read_bytes() for p in base)).hexdigest()
    assert base_hash == measured['binding']['implementation']
    new = ['runners/tool_docker.py', 'model_tool_boundary.py', 'codex_tool_session.py',
           'runners/chatgpt_plan.py', 'chatgpt_oauth.py', 'agent_transport.py']
    current_hash = hashlib.sha256(b''.join((ROOT / 'agent_system' / p).read_bytes() for p in new)).hexdigest()
    assert current_hash == measured['binding']['stage18c']['implementation']
    assert sha(Path(measured['binding']['stage18c']['codex']['path'])) == measured['codex_sha256']
    facts = ['codex_dynamic_roundtrip', 'docker_mutation', 'host_execution_trap', 'token_visibility',
             'builtin_response_denied', 'timeout_cleanup', 'cancel_cleanup', 'overflow_cleanup',
             'secret_output_rejected_before_export']
    assert all(measured[p] is True for p in facts)
    assert len(measured['isolation_capabilities']) == 13 and all(measured['isolation_capabilities'].values())
    assert measured['agent_runner_factory_integration'] is True and measured['signed_admission'] is True
    assert type(measured['real_model_calls']) is int and measured['real_model_calls'] == 0
    attestation = Path(measured['attestation_directory'])
    exported = OUT / 'fresh-admission'
    exported.mkdir(exist_ok=True)
    for name in ('validation.json', 'stage18c-transport.json', 'stage18c-proof.json'):
        shutil.copyfile(attestation / name, exported / name)
    proof = json.loads((exported / 'stage18c-proof.json').read_text(encoding='utf-8'))
    assert proof['real_model_calls'] == 0
    evidence = {str(p.relative_to(ROOT)).replace('\\', '/'): sha(p) for p in
                [*(ROOT / p for p in sources), OUT / 'real-final-2.xml', OUT / 'real-summary.json',
                 ROOT / 'docs/stage18-chatgpt-evidence/signatures-complete.xml', *exported.glob('*.json')]}
    report = {
        'version': 1, 'date': '2026-10-05', 'report_kind': 'separate_stage18c_engineering_checkpoint',
        'status': 'READY_FOR_AUTHORIZED_LIVE_SMOKE', 'stage18_complete': True,
        'highest_completed_stage': 18, 'stage19_technically_admitted': False,
        'stage19_authorized': False, 'stage19_executed': False,
        'real_model_calls': 0, 'real_oauth_login_performed': False, 'real_tokens_acquired': False,
        'real_model_catalog_requested': False,
        'topology': 'A: trusted Codex app-server, gated model-only relay, dynamic Docker tools',
        'auth_route': 'official ChatGPT-plan OAuth; no ordinary API key or paid fallback',
        'credentials': {'owner': 'Controller', 'role_bearer': False, 'role_refresh_token': False,
                        'app_server_openai_bearer': False, 'app_server_channel': 'ephemeral local-only token',
                        'host_home_mounted': False, 'host_codex_mounted': False},
        'network': {'roles': 'none', 'trusted_codex': 'authenticated loopback Responses relay',
                    'upstream': 'https://api.openai.com/v1/responses', 'generic_proxy': False},
        'credits': {'mode': 'required operator setting and signed per-execution attestation',
                    'software_controls_account_setting': False, 'account_setting_verified': False,
                    'attestation_present_for_real_execution': False, 'max_attestation_age_seconds': 86400,
                    'missing_attestation_denies_inference': True, 'api_key_fallback': False},
        'runtime': {'codex_version': '0.159.2', 'dynamic_tools_experimental': True,
                    'new_linux_image_required': False, 'binding': measured['binding']},
        'fresh_admission': {'capabilities': measured['isolation_capabilities'],
                            'transport_facts': {p: measured[p] for p in facts},
                            'signed': True, 'factory_controller_workflow': 'ACCEPTED with synthetic provider',
                            'original_evidence_directory': measured['attestation_directory'],
                            'historical_binding_reused_as_new_proof': False},
        'regression': {'method': 'exact current default node-ID coverage from baseline plus focused reruns',
                       'current_default_collected': len(collector.nodes), 'covered_default': len(collector.nodes),
                       'baseline_passed': len(suites[0]), 'previous_focused_passed': len(suites[1]),
                       'current_focused_passed': len(suites[2]), 'local_codex_opt_in_passed': len(local),
                       'fresh_docker_codex_opt_in_passed': len(real), 'crypto_opt_in_passed': len(crypto),
                       'covered_all_unique': len(covered | real | crypto), 'missing_default_nodes': [],
                       'failures': 0, 'errors': 0, 'skipped': 0, 'single_fresh_full_run': False},
        'usage': {'entitlement': 'unverified', 'input_tokens': None, 'output_tokens': None,
                  'remaining_plan_usage': None, 'monetary_cost': None},
        'stage19_prerequisites': ['separately authorized real OAuth setup and connection',
            'exact operator-selected model slug and reasoning; configured aliases are not entitlement',
            'fresh admission for the actual target project/config/runtime binding',
            'operator disables credit fallback and signs current client/execution-bound attestation',
            'separate explicit signed live-smoke authorization for exact identity/model/route'],
        'limitations': ['experimental dynamic-tool ABI measured only against pinned Codex 0.159.2',
            'trusted Controller/Codex and same-user host administrator remain trusted',
            'bounded buffered SSE; future or unsupported events fail closed',
            'known-secret rejection is defense in depth, not arbitrary encoded-secret DLP',
            'process ownership/shutdown measured; no complete native descendant-process census',
            'real OAuth, model entitlement, real reasoning and plan billing were not exercised',
            'token refresh requires a new execution/session; no in-session automatic refresh',
            'live usage telemetry is unknown; no inferred quota or cost'],
        'historical_sha256': immutable, 'evidence_sha256': evidence,
        'source_sha256': {str((ROOT / 'agent_system' / p).relative_to(ROOT)).replace('\\', '/'): sha(ROOT / 'agent_system' / p) for p in new},
    }
    (ROOT / 'STAGE18C_MODEL_TOOL_BOUNDARY.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    (OUT / 'coverage.json').write_text(json.dumps({'current_default_nodes': sorted(collector.nodes),
        'covered_nodes': sorted(covered), 'crypto_nodes': sorted(crypto), 'real_nodes': sorted(real),
        'missing': []}, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': report['status'], 'default_tests': len(collector.nodes),
                      'all_unique': report['regression']['covered_all_unique'], 'real_model_calls': 0}))


if __name__ == '__main__':
    main()
