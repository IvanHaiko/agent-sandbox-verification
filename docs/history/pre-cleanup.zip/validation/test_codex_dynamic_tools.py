"""Actual pinned Codex, synthetic localhost Responses backend. No OpenAI calls."""
import hashlib
import json
import shutil
import time

import pytest

from agent_system.agent_transport import InvocationBinding
from agent_system.codex_tool_session import CodexToolSession
from agent_system.model_tool_boundary import ExecutionPolicy, ResponsesGate, LocalModelRelay, IsolatedExecutionBridge

from test_model_tool_boundary import Runner, function, message, sse


def test_actual_codex_dynamic_tool_roundtrip(tmp_path):
    executable = shutil.which('codex')
    assert executable
    policy = ExecutionPolicy(InvocationBinding('exec-1', 'implementer', 'TASK', 1, 'gpt-5.4', 'low'),
                             'implementation', 'owned-workspace', time.monotonic() + 30)
    requests = []
    def upstream(body):
        requests.append({'fields': sorted(body), 'tools': [t['name'] for t in body['tools']]})
        return sse([function(policy)]) if len(requests) == 1 else sse([message() ], response_id='response-2')
    runner = Runner()
    bridge = IsolatedExecutionBridge(runner, 'owned-selection', {}, policy)
    with LocalModelRelay(ResponsesGate(policy), upstream) as relay:
        with CodexToolSession(executable, hashlib.sha256(__import__('pathlib').Path(executable).read_bytes()).hexdigest(),
                              tmp_path / 'codex-home', relay, bridge, policy) as session:
            try:
                schema = {'type': 'object', 'properties': {'answer': {'type': 'string'}},
                          'required': ['answer'], 'additionalProperties': False}
                assert session.run('Offline synthetic tool delegation test.', schema) == {'answer': 'ok'}
            except Exception:
                print('Safe relay diagnostic:', relay.failures, relay.gate.request_fields)
                raise
        assert session.process.poll() == 0
    assert len(runner.calls) == 1 and len(requests) == 2
