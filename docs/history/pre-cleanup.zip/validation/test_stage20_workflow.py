"""Small focused action-boundary checks plus one actual offline Codex/Docker roundtrip."""
import json
from pathlib import Path
import sys
import time
import pytest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'validation'))
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tests'))
import stage20_workflow as s
from test_model_tool_boundary import function,message,sse

def policy(role='implementer',phase='implementation'):
    return s.ExecutionPolicy(s.InvocationBinding('offline-stage20',role,s.TASK_ID,1,'gpt-5.6-sol','high'),
        phase,'workspace',time.monotonic()+180,max_requests=3,max_tool_calls=2,output_bytes=65536)

def request(p,argv,stdin='',read_only=True):
    return {**p.identity(),'tool_type':'argv','argv':argv,'stdin':stdin,'read_only':read_only,'timeout_seconds':20,'output_bytes':65536}

def test_selector_resolves_only_owned_file():
    p=policy(); a=s.Actions(p,['write','inspect','check'])
    r=request(p,['write','src/slugify.py'],'def slugify(value: str) -> str: return value\n',False)
    assert a.resolve(r)['argv']==['python','-c',s.WRITE]
    for argv in (['write','../secret.py'],['inspect','../TASK.json'],['python','-c','print(1)']):
        with pytest.raises(s.AgentSystemError): a.resolve({**r,'argv':argv})

def test_readonly_and_identity_denied():
    p=policy(); a=s.Actions(p,['write','check']); r=request(p,['write','src/slugify.py'],'x',False)
    for change in ({'read_only':True},{'execution_id':'sibling'},{'workspace_id':'sibling'},{'role':'reviewer'}):
        with pytest.raises(s.AgentSystemError): a.resolve({**r,**change})
    reviewer=policy('reviewer','review')
    with pytest.raises(s.AgentSystemError): s.Actions(reviewer,[]).resolve(request(reviewer,['write','src/slugify.py'],'x',False))

def test_read_actions_cannot_smuggle_source():
    p=policy(); a=s.Actions(p,['inspect','check'])
    with pytest.raises(s.AgentSystemError): a.resolve(request(p,['inspect','TASK.json'],'evil'))
    with pytest.raises(s.AgentSystemError): a.resolve(request(p,['check'],'{"command":"evil"}'))

def test_unknown_action_blocked_before_relay_release():
    p=policy(); a=s.Actions(p,['inspect']); gate=s.ActionGate(p,actions=a)
    call=function(p); call['arguments']=json.dumps(request(p,['python','-c','print(1)']))
    with pytest.raises(s.AgentSystemError): gate.response(sse([call]))
    assert not gate.authorized_arguments

def test_test_harness_embeds_only_frozen_design():
    design={'cases':[{'id':'a','intent':'punctuation','input':'a_b','expected':'ab'}], 'properties':['idempotence']}
    source=s.acceptance_source(design)
    assert 'a_b' in source and 'self.assertEqual' in source
    assert 'implementation_result' not in source

def test_host_python_rejected():
    import subprocess
    observed={}
    with s.host_trap(observed,'codex.exe'):
        with pytest.raises(s.AgentSystemError,match='host process'):
            subprocess.Popen(['python','-c','print(1)'])
    assert observed['host_execution_attempt']

def test_readonly_storage_cleanup_preserves_parent(tmp_path):
    import stat
    target=tmp_path/'owned'; target.mkdir(); obj=target/'git-object'
    obj.write_text('copied object'); obj.chmod(stat.S_IREAD)
    s.remove_owned(target,tmp_path)
    assert tmp_path.exists() and not target.exists()
    with pytest.raises(s.AgentSystemError,match='Unsafe'):
        s.remove_owned(tmp_path,tmp_path)

def test_real_offline_roundtrip():
    prepared=s.load(s.OUT/'prepared.json'); config=s.Configuration.load(Path(prepared['project']))
    if not config.runtime_root.exists(): pytest.skip('One-shot disposable role runtime has been cleaned up')
    runner=s.ToolDockerRunner(config); runner.require_transport_admission()
    workspace=Path(prepared['manifest']['worktrees']['implementer']['path']); baseline=(workspace/'src/slugify.py').read_bytes()
    p=policy(); a=s.Actions(p,['write','check']); secret=s.SecretFilter(['synthetic-stage20-private-canary'])
    task={**s.TASK,'scope':{'allowed_paths':['src/slugify.py'],'forbidden_paths':[]},'workflow':{'test_paths':['tests/test_acceptance.py']}}
    bridge=s.ActionBridge(runner,workspace,task,p,secret,actions=a); gate=s.ActionGate(p,secret,actions=a)
    calls=[]
    def upstream(body):
        calls.append(body)
        index=len(calls)
        if index<=2:
            call=function(p,call_id='call-'+str(index)); call['id']='fc-'+str(index)
            args=request(p,['write','src/slugify.py'],'def slugify(value: str) -> str:\n    return value\n',False) if index==1 else request(p,['check'],'[["hello","hello"]]')
            call['arguments']=json.dumps(args)
            return sse([call],response_id='response-'+str(index))
        return sse([message('{"ok":true}')],response_id='response-3')
    exe=prepared['binding']['stage18c']['codex']; home=config.runtime_root/'offline-model-home'
    observed={}
    try:
        with s.host_trap(observed,exe['path']):
            with s.LocalModelRelay(gate,upstream) as relay:
                with s.CodexToolSession(Path(exe['path']),exe['sha256'],home,relay,bridge,p) as session:
                    assert session.run('Synthetic Stage20 driver check.',{'type':'object','properties':{'ok':{'const':True}},'required':['ok'],'additionalProperties':False})=={'ok':True}
        assert len(calls)==3 and bridge.calls==2 and all(t['returncode']==0 for t in bridge.evidence)
        assert not runner.stale_executions()
        s.save('offline-roundtrip',{'real_codex':True,'real_docker':True,'provider':'synthetic-local-only',
            'real_model_requests':0,'synthetic_requests':3,'tools':bridge.evidence,'host_trap_passed':True,
            'cleanup_confirmed':not runner.stale_executions(),'driver_sha256':s.sha(Path(s.__file__))})
    finally:
        bridge.close(); (workspace/'src/slugify.py').write_bytes(baseline)
        s.remove_owned(home,config.runtime_root)
