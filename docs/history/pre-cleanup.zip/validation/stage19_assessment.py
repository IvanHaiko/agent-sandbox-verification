"""Record the stopped Stage19 attempt without modifying prior assessments."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'docs/stage19-evidence'


def main():
    if (OUT / 'second-live-observations.json').exists():
        from stage19_finalize import main as finalize
        return finalize()
    inspection = json.loads((OUT / 'auth-inspection.json').read_text(encoding='utf-8'))
    reconnection = json.loads((OUT / 'oauth-reconnection.json').read_text(encoding='utf-8'))
    assert inspection['connected'] is True and inspection['plan_permission'] is True
    assert inspection['persisted_record_names'] == ['credentials.json', 'host.json', 'registration.json']
    accepted = json.loads((ROOT / 'STAGE18C_MODEL_TOOL_BOUNDARY.json').read_text(encoding='utf-8'))
    for name, expected in {**accepted['historical_sha256'], **accepted['source_sha256']}.items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
    cases = ET.parse(OUT / 'offline-focused.xml').getroot()
    assert not any(list(cases.iter(tag)) for tag in ('failure', 'error', 'skipped'))
    count = len(list(cases.iter('testcase')))
    assert count == 150
    preserved = accepted['historical_sha256'].copy()
    for name in ('STAGE18C_MODEL_TOOL_BOUNDARY.md', 'STAGE18C_MODEL_TOOL_BOUNDARY.json'):
        preserved[name] = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
    report = {
        'version': 1, 'date': '2026-10-05', 'stage': 19,
        'verdict': 'BLOCKED_BEFORE_INFERENCE',
        'operator_authorized_scope': 'one minimal live execution after all existing preflight gates',
        'oauth_connection_attempts': 3, 'oauth_connection_actually_performed': True,
        'oauth_connection_success': True, 'issued_registration_present': True,
        'account_binding_verified': True, 'issued_client_sha256': inspection['issued_client_sha256'],
        'account_subject_sha256': reconnection['account_subject_sha256'],
        'token_exchange_reached': True, 'token_acquisition_success': True,
        'credentials_persisted': True, 'token_refresh_occurred': False,
        'real_inference_occurred': False, 'real_model_executions': 0, 'real_responses_requests': 0,
        'exact_model_used': None, 'exact_reasoning_used': None,
        'model_catalog_requests': 0, 'entitlement_proven': False,
        'dynamic_docker_tool_execution': 'NOT_RUN', 'host_model_selected_execution': False,
        'credential_escape_observed': False,
        'credential_escape_verification': 'credentials protected in Controller store; live token-visibility probe not reached',
        'disposable_task': 'NOT_STARTED: reconnection complete; remaining smoke preflight not performed',
        'live_target_admission': 'NOT_GENERATED',
        'completion_status': 'NOT_STARTED', 'observed_live_response_events': [],
        'provider_warnings': [], 'provider_error_details': 'prior retry: ChatGPT ID token verification failed; last retry successful',
        'auth_failure_observation': 'prior root cause unestablished; strict verification passed later without changing verifier',
        'reconnection': reconnection,
        'cleanup': {'oauth_controller_process_exited': True, 'loopback_listener_closed_by_context_manager': True,
                    'controller_lock_file_absent': True, 'live_codex_session_started': False,
                    'live_tool_containers_started': False, 'temporary_token_records_present': False,
                    'protected_persistent_credentials_present': True,
                    'host_and_registration_metadata_retained_in_protected_store': True,
                    'disposable_live_workspace_changes': False, 'live_cleanup_probe': 'NOT_APPLICABLE'},
        'usage': {'input_tokens': None, 'output_tokens': None, 'total_tokens': None,
                  'remaining_plan_usage': None, 'monetary_cost': None},
        'credits': {'operator_reported_balance': 0, 'operator_reported_auto_top_up_enabled': False,
                    'required_app_credit_fallback_setting_confirmed_disabled': True,
                    'setting_confirmation_source': 'explicit operator reply in this chat: отключено',
                    'actual_required_setting_state': 'operator-attested disabled; not programmatically verified',
                    'signed_no_credits_attestation_created': False,
                    'signed_live_smoke_authorization_created': False, 'paid_fallback_used': False,
                    'billing_behavior_observed': False},
        'regression': {'offline_focused_passed': count, 'failures': 0, 'errors': 0, 'skipped': 0,
                       'normal_tests_remain_offline': True, 'evidence': 'docs/stage19-evidence/offline-focused.xml',
                       'fresh_role_network_cleanup_probes_run_for_stage19': False},
        'deviations': ['two initial OAuth failures before successful strict verification; root cause unestablished'],
        'changes': ['explicit opt-in OAuth operator wrapper only',
                    'boolean-only ID verification diagnostics; retries explicitly authorized by operator',
                    'read-only protected-store inspection and separate reports'],
        'stage18_production_sources_unchanged': True, 'preserved_checkpoint_sha256': preserved,
        'evidence_sha256': {str(p.relative_to(ROOT)).replace('\\', '/'): hashlib.sha256(p.read_bytes()).hexdigest()
                           for p in (OUT / 'auth-inspection.json', OUT / 'offline-focused.xml', OUT / 'oauth-reconnection.json')},
        'blockers': ['model entitlement/selection and exact live-target admission not reached',
                     'signed execution-bound no-credit attestation and live authorization not created'],
        'stage20_technically_admissible': False, 'stage20_authorized': False, 'stage20_started': False,
        'next_step': 'prepare remaining minimal-smoke preflight; no inference until every gate passes',
    }
    (ROOT / 'STAGE19_AUTHORIZED_LIVE_SMOKE.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'verdict': report['verdict'], 'real_model_executions': 0, 'offline_tests_passed': count}))


if __name__ == '__main__':
    main()
