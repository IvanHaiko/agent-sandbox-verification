"""One human-authorized conformance smoke. No refresh, discovery, retry or workflow."""
import ast
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from urllib.error import HTTPError

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'docs/stage19-final-conformance-evidence'
EXECUTION = 'stage19-final-conformance-1'
MODEL = 'gpt-6-sol'
CONFIRMATION_TIME = 1791275370.0  # 2026-10-06 08:29:30 UTC, first handling of human authorization
sys.path.insert(0, str(ROOT))
from agent_system.agent_transport import InvocationBinding, strict_json
from agent_system.approvals import ApprovalStore
from agent_system.chatgpt_oauth import CredentialStore, PLAN_SCOPE
from agent_system.codex_tool_session import CodexToolSession
from agent_system.config import Configuration
from agent_system.errors import AgentSystemError
from agent_system.git import git
from agent_system.model_tool_boundary import (ExecutionPolicy, IsolatedExecutionBridge,
    ResponsesGate, LocalModelRelay, PlanUpstream, SecretFilter, UPSTREAM, tool_spec)
import agent_system.model_tool_boundary as boundary
from agent_system.runners.tool_docker import ToolDockerRunner
from agent_system.runners.docker_isolated import CLEANUP, regular_tree
from agent_system.runners.base import AgentResult
from agent_system.storage import atomic_json


def load(path):
    return strict_json(path.read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, reason):
    if not condition: raise AgentSystemError(reason)


def expected_arguments(policy, proposal, step):
    require(step in (0, 1), 'Unexpected smoke tool call')
    return {**policy.identity(), 'tool_type': 'argv',
            **proposal['mutation' if step == 0 else 'verification']}


def fixed_result_schema(proposal):
    return {'type': 'object', 'properties': {k: {'const': v} for k, v in proposal['structured_result'].items()},
            'required': list(proposal['structured_result']), 'additionalProperties': False}


def consume_latch(path):
    with path.open('x', encoding='utf-8') as stream:
        stream.write('One authorized execution consumed, including preflight failure. No retry.\n')
        stream.flush()
        os.fsync(stream.fileno())


def file_manifest(root):
    result = {}
    excluded = {'.git', '.test-tmp', '__pycache__', '.pytest_cache', 'stage19-final-conformance-evidence'}
    for directory, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = [name for name in dirs if name not in excluded]
        for name in files:
            path = Path(directory)/name
            if path.is_file() and not path.is_symlink(): result[path.relative_to(root).as_posix()] = sha(path)
    return result


class ExactBridge(IsolatedExecutionBridge):
    def __init__(self, *args, proposal, observed, **kwargs):
        super().__init__(*args, **kwargs)
        self.proposal, self.observed, self.successful = proposal, observed, 0
        self.checks = []

    def execute(self, request):
        self.observed['tool_boundary_entered'] = True
        try:
            require(self.calls == self.successful, 'Previous smoke tool failed; no further dispatch')
            require(request == expected_arguments(self.policy, self.proposal, self.calls), 'Exact smoke tool template mismatch')
            step = self.calls
            result = super().execute(request)
            expected = ('stage19-mutated\n', 'stage19-verified\n')[step]
            check = {'step': step + 1, 'returncode_zero': result['returncode'] == 0,
                     'stdout_exact': result['stdout'] == expected, 'stderr_empty': result['stderr'] == ''}
            self.checks.append(check)
            require(all(check[k] for k in ('returncode_zero', 'stdout_exact', 'stderr_empty')), 'Deterministic smoke tool output mismatch')
            self.successful += 1
            return result
        except BaseException:
            self.observed['tool_boundary_failure'] = True
            raise


class ExactGate(ResponsesGate):
    def __init__(self, *args, proposal, bridge, observed, **kwargs):
        super().__init__(*args, **kwargs)
        self.proposal, self.bridge, self.observed = proposal, bridge, observed

    def request(self, raw):
        value = super().request(raw)
        value['parallel_tool_calls'] = False
        return value

    def inspect_response(self, raw):
        result = super().inspect_response(raw)
        candidates = result[0]
        try:
            step = self.requests - 1
            require(0 <= step <= 2 and self.bridge.successful == step, 'Smoke response/tool order mismatch')
            require(len(candidates) == (1 if step < 2 else 0), 'Smoke response has unexpected tool inventory')
            if step < 2:
                require(list(candidates.values()) == [json.dumps(expected_arguments(self.policy, self.proposal, step), sort_keys=True)],
                        'Smoke response differs from exact tool template')
            self.last_response_metadata['smoke_scope_passed'] = True
        except BaseException:
            self.observed['tool_boundary_failure'] = True
            self.last_response_metadata.update(smoke_scope_passed=False, validation_passed=False)
            raise
        return result


def safe_remove_tree(path, parent):
    resolved, base = path.resolve(), parent.resolve()
    require(resolved.is_relative_to(base) and resolved != base, 'Unsafe smoke cleanup target')
    if not path.exists(): return
    regular_tree(path)
    shutil.rmtree(resolved)
    require(not path.exists(), 'Smoke storage cleanup unconfirmed')


def main():
    require(sys.argv[1:] == ['--execute-authorized-once'], 'Explicit one-shot smoke entry required')
    OUT.mkdir(parents=True, exist_ok=True)
    consume_latch(OUT/'one-shot-latch')  # consumes failures before inference as well
    observed = {'execution_id': EXECUTION, 'task_id': 'STAGE19-SMOKE', 'model': MODEL, 'reasoning': 'low',
        'verdict': 'BLOCKED_BEFORE_INFERENCE', 'execution_allowance_consumed': True,
        'authorization_time_utc': '2026-10-06 08:29:30 UTC', 'authorization_time_basis': 'First handling of original human message; never refreshed',
        'model_amendment_explicitly_confirmed': True, 'responses_dispatch_attempts': 0,
        'responses_http_statuses': [], 'successful_tools': 0, 'tool_attempts': 0,
        'refresh_attempts': 0, 'reconnect_attempts': 0, 'discovery_requests': 0, 'automatic_retries': 0,
        'stage19_passed': False, 'stage20_technically_admissible': False, 'stage20_started': False,
        'raw_response_persisted': False, 'raw_provider_ids_persisted': False, 'raw_model_arguments_persisted': False,
        'model_prose_persisted': False, 'tool_boundary_failure': False, 'host_model_execution': False,
        'credential_escape_observed': False, 'signed_live_authorization': False, 'signed_no_credits': False}
    result_path = OUT/'execution.json'
    atomic_json(result_path, observed)
    framework_before = file_manifest(ROOT)
    atomic_json(OUT/'primary-and-historical-baseline.json', framework_before)
    session = bridge = runner = invocation = gate = upstream = None
    relay = None
    new_execution_dirs = []
    real_popen, real_opener = subprocess.Popen, boundary.build_opener
    secrets = SecretFilter()
    stage = 'preflight'
    try:
        proposal_path = ROOT/'docs/stage19d-evidence/final-smoke-proposal.json'
        proposal = load(proposal_path)
        require(proposal['execution_id'] == EXECUTION and proposal['task_id'] == observed['task_id']
                and proposal['reasoning'] == 'low' and proposal['requests_max'] == 3
                and proposal['tool_calls_max'] == 2 and proposal['tool_calls_required'] == 2
                and proposal['automatic_retries'] == 0, 'Accepted smoke proposal scope mismatch')
        authorization_path = OUT/'authorization.json'
        authorization = load(authorization_path)
        require(authorization == {'execution_id': EXECUTION, 'task_id': 'STAGE19-SMOKE', 'model': MODEL,
            'reasoning': 'low', 'human_billing_confirmation_at': CONFIRMATION_TIME,
            'credits_fallback_disabled': True, 'one_execution': True, 'no_retry': True,
            'model_amendment': 'User explicitly confirmed Use gpt-6-sol only', 'proposal_sha256': sha(proposal_path)},
            'Human smoke authorization receipt mismatch')
        driver_admission = load(OUT/'driver-admission.json')
        driver_hash = sha(Path(__file__))
        require(driver_admission['entrypoint_sha256'] == driver_hash and driver_admission['offline_tests_passed'] is True,
                'Fresh smoke driver source admission mismatch')
        admission = load(ROOT/'docs/stage19d-evidence/fresh-admission.json')
        sources = {p.relative_to(ROOT).as_posix(): sha(p) for p in sorted((ROOT/'agent_system').rglob('*.py'))}
        require(sources == admission['source_sha256'], 'Stage19d source manifest mismatch')
        bundle = hashlib.sha256(json.dumps(sources, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        require(bundle == admission['source_bundle_sha256'], 'Stage19d source bundle mismatch')
        config = Configuration.load(Path(admission['project']))
        runner = ToolDockerRunner(config)
        workspace, project = Path(admission['workspace']), Path(admission['project'])
        require(project.resolve().is_relative_to((ROOT/'.test-tmp/stage19d-admission-2').resolve()), 'Fresh admission project ownership mismatch')
        runner._workspace(workspace, admission['task'])
        def require_admission():
            require(sha(Path(__file__)) == driver_hash and sha(authorization_path) == authorization_hash
                    and sha(proposal_path) == authorization['proposal_sha256'], 'Smoke entrypoint authorization changed')
            require(all(sha(ROOT/name) == expected for name, expected in sources.items()), 'Admitted production source changed')
            require(runner.preflight() == admission['binding'], 'Fresh Docker/Codex/config/project binding mismatch')
            runner.require_transport_admission()
        authorization_hash = sha(authorization_path)
        require_admission()
        observed.update(source_bundle_verified=True, source_bundle_sha256=bundle,
                        current_runtime_binding_verified=True, signed_transport_proof_verified=True,
                        driver_source_sha256=driver_hash)
        require(not runner.stale_executions(), 'Stale owned containers block smoke')
        require((workspace/'src/example.py').read_bytes() == b'value = 1\n'
                and not git(workspace, 'status', '--porcelain', '--untracked-files=all'), 'Owned smoke workspace is not pristine baseline')
        workspace_before = {p.relative_to(workspace).as_posix(): sha(p) for p in workspace.rglob('*')
                            if p.is_file() and '.git' not in p.relative_to(workspace).parts}
        project_before = {p.relative_to(project).as_posix(): sha(p) for p in project.rglob('*')
                          if p.is_file() and '.git' not in p.relative_to(project).parts}
        execution_dirs_before = {p for p in (runner.root/'executions').iterdir() if p.is_dir()}
        observed['preflight_step'] = 'existing_plan_credentials'
        atomic_json(result_path, observed)
        credential_directory = Path('C:/Users/4ivan/.agentctl/stage19-oauth')
        require(credential_directory.is_dir(), 'Existing protected OAuth storage required; no reconnect')
        credential_store = CredentialStore(credential_directory, [ROOT, project, config.worktrees_dir])
        credentials = credential_store.read('credentials.json')
        registration = credential_store.read('registration.json')
        require(isinstance(credentials, dict) and isinstance(registration, dict), 'Existing OAuth credentials and registration required')
        secrets = SecretFilter([credentials.get(k) for k in ('access_token', 'refresh_token', 'id_token')])
        observed['credential_storage_permissions_verified'] = True
        valid = (PLAN_SCOPE in credentials.get('scopes', []) and isinstance(credentials.get('expires_at'), (int, float))
                 and credentials['expires_at'] - time.time() > 180
                 and credentials.get('client_id') == registration.get('client_id')
                 and all(isinstance(credentials.get(k), str) and bool(credentials[k]) for k in ('access_token', 'refresh_token', 'id_token')))
        observed['existing_plan_credentials_valid_for_smoke'] = bool(valid)
        require(valid, 'Existing ChatGPT-plan OAuth credentials expired or invalid; refresh/reconnect prohibited')
        credential_hashes = {p.name: sha(p) for p in credential_directory.iterdir() if p.is_file()}
        policy = ExecutionPolicy(InvocationBinding(EXECUTION, 'implementer', observed['task_id'], 1, MODEL, 'low'),
            'implementation', hashlib.sha256(str(workspace.resolve()).encode()).hexdigest(), time.monotonic()+180,
            max_requests=3, max_response_bytes=1048576, max_tool_calls=2, max_tool_seconds=20, output_bytes=1048576)
        approvals = ApprovalStore(config.runtime_root/'stage19-final-conformance-approvals',
            {'transport': admission['binding'], 'source_bundle': bundle, 'driver': driver_hash,
             'proposal': sha(proposal_path), 'human_authorization': authorization_hash,
             'execution': policy.identity(), 'model': MODEL, 'reasoning': 'low'})
        approvals.issue('no-credits/'+EXECUTION, {'execution_id': EXECUTION, 'client_id': credentials['client_id'],
            'credits_fallback_disabled': True, 'operator': 'Human explicitly confirmed OFF and remains OFF for this smoke',
            'attested_at': CONFIRMATION_TIME})
        approvals.issue('live-smoke/'+EXECUTION, {'authorized': True, **policy.identity(), 'model': MODEL, 'reasoning': 'low', 'route': UPSTREAM})
        boundary.require_credit_attestation(approvals, policy.binding, credentials['client_id'])
        observed.update(signed_live_authorization=True, signed_no_credits=True, attestation_uses_original_confirmation_time=True)
        invocation = config.runs_dir/'STAGE19-SMOKE'/'invocations'/EXECUTION
        invocation.mkdir(parents=True, exist_ok=False)
        bridge = ExactBridge(runner, workspace, admission['task'], policy, secrets, proposal=proposal, observed=observed)
        gate = ExactGate(policy, secrets, proposal=proposal, bridge=bridge, observed=observed)
        upstream = PlanUpstream(credential_store, policy, approvals, require_admission, runner.cancel_event)
        prompt = (proposal['prompt_contract']+' Use exactly these complete argument objects, in order: '
                  +json.dumps([expected_arguments(policy, proposal, i) for i in (0, 1)])
                  +'. Do not combine the calls; wait for each successful tool result. After both succeed return ONLY '
                  +json.dumps(proposal['structured_result']))
        secrets.reject(prompt)
        acl_tree = ast.parse((ROOT/'agent_system/chatgpt_oauth.py').read_text())
        acl_scripts = {node.value for node in ast.walk(acl_tree) if isinstance(node, ast.Constant)
                       and isinstance(node.value, str) and node.value.startswith('$a=Get-Acl')}
        executable = Path(admission['binding']['stage18c']['codex']['path'])
        def trapped_popen(argv, *args, **kwargs):
            name = Path(argv[0]).name.lower() if isinstance(argv, (list, tuple)) and argv else ''
            allowed = name in ('git', 'git.exe') or (name in ('docker', 'docker.exe') and list(argv[1:3]) == ['--context', 'desktop-linux'])
            if name == 'codex.exe': allowed = Path(argv[0]).resolve() == executable.resolve() and list(argv[1:]) == ['app-server', '--listen', 'stdio://']
            if name.startswith('python'): allowed = len(argv) == 6 and list(argv[1:4]) == ['-I', '-c', CLEANUP]
            if name in ('powershell', 'powershell.exe'):
                allowed = len(argv) == 5 and list(argv[1:4]) == ['-NoProfile', '-NonInteractive', '-Command'] and argv[4] in acl_scripts
            if not allowed:
                observed['host_model_execution'] = True
                raise AgentSystemError('Unexpected host process denied')
            return real_popen(argv, *args, **kwargs)
        subprocess.Popen = trapped_popen
        def tracked_opener(*args):
            opener = real_opener(*args)
            class Tracked:
                def open(self, request, **kwargs):
                    index = observed['responses_dispatch_attempts']
                    require(request.full_url == UPSTREAM and request.get_method() == 'POST' and index < 3,
                            'Unexpected or excess smoke HTTP request')
                    require(gate.requests == index+1 and bridge.successful == index, 'Smoke request/tool sequence mismatch')
                    body = strict_json(request.data.decode('utf-8'))
                    require(body['model'] == MODEL and body['reasoning']['effort'] == 'low'
                            and body['parallel_tool_calls'] is False, 'Smoke HTTP model/reasoning/parallel binding mismatch')
                    observed['responses_dispatch_attempts'] += 1
                    atomic_json(result_path, observed)  # record attempted dispatch before failed send
                    try:
                        response = opener.open(request, **kwargs)
                        observed['responses_http_statuses'].append(response.status)
                        return response  # retain actual owned HTTPResponse for bounded reader
                    except HTTPError as error:
                        observed['responses_http_statuses'].append(error.code)
                        error.close()  # never retain error body/prose
                        raise
            return Tracked()
        boundary.build_opener = tracked_opener
        stage = 'transport'
        with LocalModelRelay(gate, upstream) as relay:
            session = CodexToolSession(executable, admission['codex_sha256'], invocation/'model-home', relay, bridge, policy)
            with session:
                role_result = session.run(prompt, fixed_result_schema(proposal))
            channel_filter = SecretFilter([credentials[k] for k in ('access_token', 'refresh_token', 'id_token')]+[relay.child_channel()])
            for path in (invocation/'model-home').rglob('*'):
                if path.is_file(): channel_filter.reject(path.read_bytes().decode('utf-8', errors='replace'))
        stage = 'task'
        require(bridge.successful == bridge.calls == len(session.call_ids) == 2 and gate.requests == 3
                and observed['responses_dispatch_attempts'] == 3, 'Complete two-tool three-response smoke required')
        require(role_result == proposal['structured_result'], 'Exact structured role result required')
        require((workspace/'src/example.py').read_bytes() == b'value = 2\n', 'Exact smoke file content mismatch')
        parsed = ast.parse((workspace/'src/example.py').read_text())
        require(len(parsed.body) == 1 and isinstance(parsed.body[0], ast.Assign)
                and ast.literal_eval(parsed.body[0].value) == 2, 'Independent public value check failed')
        workspace_after = {p.relative_to(workspace).as_posix(): sha(p) for p in workspace.rglob('*')
                           if p.is_file() and '.git' not in p.relative_to(workspace).parts}
        paths = {name for name in workspace_before.keys() | workspace_after.keys() if workspace_before.get(name) != workspace_after.get(name)}
        require(paths == bridge.changed_paths == {'src/example.py'}, 'Unexpected disposable workspace mutation')
        project_after = {p.relative_to(project).as_posix(): sha(p) for p in project.rglob('*')
                         if p.is_file() and '.git' not in p.relative_to(project).parts}
        require(project_before == project_after, 'Disposable primary project changed')
        require(credential_hashes == {p.name: sha(p) for p in credential_directory.iterdir() if p.is_file()}, 'OAuth storage changed')
        agent_result = AgentResult(EXECUTION, 'STAGE19-SMOKE', 'implementer', 'success', MODEL, 'low', 0, 0,
                                   json.dumps(proposal['structured_result']), ['src/example.py']).to_dict()
        observed.update(exact_file_content_verified=True, public_python_value_verified=True,
                        disposable_changed_paths=['src/example.py'], disposable_primary_unchanged=True,
                        credential_store_unchanged=True, strict_agent_result_verified=True,
                        agent_result=agent_result, complete_end_to_end_path=True)
        observed['verdict'] = 'PASS_STAGE19_LIVE_SMOKE'
    except BaseException as error:
        observed['verdict'] = ('BLOCKED_BEFORE_INFERENCE' if not observed['responses_dispatch_attempts'] else
            'FAIL_TOOL_BOUNDARY' if observed['tool_boundary_failure'] or observed['host_model_execution'] else
            'FAIL_TASK_EXECUTION' if stage == 'task' else 'FAIL_LIVE_TRANSPORT')
        literals = {node.value for file in [Path(__file__), *(ROOT/'agent_system'/name for name in
            ('model_tool_boundary.py', 'responses_lifecycle.py', 'responses_http.py', 'codex_tool_session.py', 'chatgpt_oauth.py'))]
            for node in ast.walk(ast.parse(file.read_text())) if isinstance(node, ast.Constant) and isinstance(node.value, str)}
        if isinstance(error, AgentSystemError) and str(error) in literals: observed['safe_failure_reason'] = str(error)
        observed['failure_category'] = type(error).__name__ if isinstance(error, (AgentSystemError, OSError)) else 'local_failure'
        if str(error) == 'Credential-bearing output rejected': observed['credential_escape_observed'] = False; observed['credential_output_rejected'] = True
    finally:
        subprocess.Popen, boundary.build_opener = real_popen, real_opener
        if upstream: observed['transport_structure'] = upstream.response_metadata_history
        if gate:
            observed['gate_structure'] = gate.response_metadata_history
            observed['validated_function_count'] = len(gate.authorized_arguments)
        if bridge:
            bridge.close()
            observed.update(tool_attempts=bridge.calls, successful_tools=bridge.successful, tool_output_checks=bridge.checks)
        if session:
            try:
                session.close()
                observed['codex_process_exited'] = session.process is not None and session.process.poll() is not None
            except BaseException: observed['verdict'] = 'FAIL_CLEANUP'; observed['codex_shutdown_failed'] = True
        try:
            if invocation:
                safe_remove_tree(invocation/'model-home', invocation)
                observed['disposable_codex_home_removed'] = not (invocation/'model-home').exists()
            else: observed['disposable_codex_home_removed'] = True
            if runner:
                observed['stale_owned_containers'] = len(runner.stale_executions())
                require(observed['stale_owned_containers'] == 0, 'Stale owned smoke container after execution')
                if 'execution_dirs_before' in locals():
                    new_execution_dirs = [p for p in (runner.root/'executions').iterdir() if p.is_dir() and p not in execution_dirs_before]
                for directory in new_execution_dirs:
                    record = load(directory/'ownership.json')
                    require(record['owner'] == runner.owner and record.get('cleanup') == 'confirmed'
                            and record.get('storage_cleanup') == 'confirmed', 'Owned smoke role cleanup not confirmed')
                    require(not (directory/'checkout').exists() and not (directory/'transfer').exists(), 'Role storage remains after smoke')
                    safe_remove_tree(directory, runner.root/'executions')  # purge transient raw command/inspection records
            observed['disposable_role_storage_removed'] = True
            after = file_manifest(ROOT)
            require(framework_before == after, 'Primary framework or historical evidence changed')
            observed['primary_framework_and_historical_evidence_unchanged'] = True
            for path in OUT.rglob('*'):
                if path.is_file(): secrets.reject(path.read_bytes().decode('utf-8', errors='replace'))
            observed['safe_metadata_secret_checked'] = True
        except BaseException:
            observed['verdict'] = 'FAIL_CLEANUP'
            observed['cleanup_failed'] = True
        observed['stage19_passed'] = observed['verdict'] == 'PASS_STAGE19_LIVE_SMOKE'
        observed['stage20_technically_admissible'] = observed['stage19_passed']
        observed['stage19_status'] = 'PASS_STAGE19_LIVE_SMOKE' if observed['stage19_passed'] else 'FAIL_LIVE_TRANSPORT'
        atomic_json(result_path, observed)
    print(json.dumps({k: observed[k] for k in ('verdict', 'responses_dispatch_attempts', 'tool_attempts',
        'successful_tools', 'stage19_passed', 'stage20_technically_admissible')}, indent=2))
    return 0 if observed['stage19_passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
