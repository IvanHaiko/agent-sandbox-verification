"""Assess completed diagnostic using metadata only; no account/network calls."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from agent_system.approvals import ApprovalStore
from agent_system.config import Configuration
from agent_system.runners.tool_docker import ToolDockerRunner
from agent_system.storage import atomic_json


def main():
    folder = ROOT / 'docs/stage19b-capture-evidence'
    capture = json.loads((folder / 'attempt-2/capture.json').read_text())
    admission = json.loads((folder / 'fresh-admission.json').read_text())
    assert capture['http_dispatch_attempts'] == capture['responses_received'] == 1
    assert capture['http_status'] == 200 and capture['refresh_attempts'] == 0
    q = capture['quarantine']
    assert q['content_type_count'] == 0 and q['library_media_type'] == 'text/plain'
    assert q['bytes_observed'] == 5537 and q['chunks_observed'] == 8
    assert q['sse_like'] and q['malformed_or_partial_data'] and not q['complete_frame_suffix']
    assert q['reader_shutdown_confirmed'] and not q['passed_to_codex']
    assert not q['accepted_as_inference'] and not q['tool_execution_allowed']
    assert capture['tool_calls'] == 0 and not capture['live_codex_session']
    assert not capture['raw_body_persisted']
    runner = ToolDockerRunner(Configuration.load(Path(admission['project'])))
    assert runner.preflight() == admission['binding']
    runner.require_transport_admission()
    assert not runner.stale_executions()
    assert (Path(admission['workspace']) / 'src/example.py').read_text() == 'value = 1\n'
    assert not (ROOT / '.test-tmp/stage19b-capture-native/home').exists()
    approvals = ApprovalStore(Path(capture['approval_directory']), capture['binding'])
    grants = {name: approvals.verify(name + '/' + capture['execution_id']) for name in
              ('no-credits', 'live-smoke', 'diagnostic', 'frozen-request')}
    assert grants['frozen-request']['request_sha256'] == capture['request_sha256']
    assert grants['no-credits']['credits_fallback_disabled'] is True
    assert grants['diagnostic']['observer_sha256'] == capture['binding']['observer']
    assert hashlib.sha256((ROOT / 'validation/stage19b_capture.py').read_bytes()).hexdigest() == capture['binding']['entrypoint']
    historical = json.loads((ROOT / 'docs/stage19b-evidence/historical-hashes.json').read_text())
    assert all(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected
               for name, expected in historical.items())
    report = {
        'date': '2026-10-06', 'verdict': 'CAPTURE_COMPLETED_TRANSPORT_REJECTED',
        'execution_id': capture['execution_id'], 'observed': capture,
        'confirmed': {'parsed_header_collection_has_no_content_type': True,
            'library_default_explains_this_requests_text_plain_label': True,
            'body_prefix_has_sse_event_and_data_framing': True,
            'entire_stream_validated': False, 'model_completion_validated': False,
            'signed_grants_reverified': True, 'stale_owned_containers': 0,
            'native_home_removed': True, 'workspace_at_baseline': True,
            'historical_22_files_unchanged': True, 'automatic_retry_occurred': False},
        'inferred': {
            'rejection_chain': 'No recognized Content-Type header -> CPython get_content_type default text/plain -> strict MIME rejection',
            'historical_relation': 'Consistent with prior Stage19 parsed text/plain; historical raw header/body remain unknown and are not retroactively rewritten',
            'body_interpretation': 'SSE-like bounded prefix; data object/frame incomplete at chunk limit. Incomplete classification is not proof of intrinsically malformed upstream SSE.',
            'next_engineering_step': 'Separate proposal to establish provider header contract or narrowly admit missing MIME only after complete existing SSE/event/completion validation and adversarial admission. No acceptance change in this execution.',
            'flat_tool_format_gap_causality': 'UNKNOWN',
            'stage19_verdict': 'FAIL_LIVE_TRANSPORT', 'stage19_passed': False, 'stage20_admissible': False},
        'unknown': ['whether malformed or ignored wire header lines existed; raw wire header bytes not retained',
            'full response body validity/event sequence/completion',
            'whether inference was accepted/completed server-side, token usage or cost',
            'why upstream header was absent from parsed collection',
            'whether the two historical responses had identical header/body behavior'],
        'request_totals': {'stage19_historical': 2, 'first_diagnostic_blocked_before_post': 0,
                          'this_diagnostic': 1, 'cumulative_responses_dispatches': 3},
        'production_acceptance_changed': False, 'raw_body_retained': False}
    atomic_json(ROOT / 'STAGE19B_CAPTURE_RESULT.json', report)
    print(json.dumps({'verdict': report['verdict'], 'requests': 1, 'http_status': 200,
        'content_type_present': False, 'prefix_bytes': 5537, 'sse_like': True,
        'complete_validated': False, 'tool_calls': 0, 'cleanup_confirmed': True}))


if __name__ == '__main__':
    main()
