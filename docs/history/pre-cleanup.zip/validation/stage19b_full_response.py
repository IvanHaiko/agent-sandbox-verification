"""One newly authorized full-response observation; no MIME override in production."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import time
from urllib.error import HTTPError

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / '.test-tmp/stage18-oauth-deps'))
from stage19b_capture import prepare, sha, load
import full_response_observer as full
from agent_system.agent_transport import InvocationBinding, strict_json
from agent_system.approvals import ApprovalStore
from agent_system.chatgpt_oauth import CredentialStore, PLAN_SCOPE
from agent_system.config import Configuration
from agent_system.errors import AgentSystemError
from agent_system.model_tool_boundary import (ExecutionPolicy, PlanUpstream, SecretFilter, UPSTREAM,
                                             require_credit_attestation)
import agent_system.model_tool_boundary as boundary
from agent_system.runners.tool_docker import ToolDockerRunner
from agent_system.storage import atomic_json
from agent_system.transport_diagnostics import safe_headers

OUT = ROOT / 'docs/stage19b-full-response-evidence'
EXECUTION = 'stage19b-full-response-1'


class ObservationFinished(AgentSystemError): pass


def main():
    if sys.argv[1:] != ['--one-authorized-full-response']:
        raise AgentSystemError('Explicit full-response observation required')
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / 'execution-latch').open('x') as latch:
        latch.write('One authorized full-response observation; never reset\n')
    observed = {'execution_id': EXECUTION, 'http_dispatch_attempts': 0, 'responses_received': 0,
        'model': 'gpt-6-astra', 'reasoning': 'low', 'tool_calls': 0,
        'live_codex_session': False, 'accepted_as_inference': False,
        'production_mime_policy_changed': False, 'verdict': 'BLOCKED_BEFORE_INFERENCE',
        'limits': {'body_bytes': full.MAX_BYTES, 'body_seconds': full.MAX_SECONDS,
            'reads': full.MAX_READS, 'socket_idle_seconds': full.IDLE_SECONDS,
            'shutdown_join_seconds': full.JOIN_SECONDS}}
    original_opener = boundary.build_opener
    secrets = None
    try:
        history = load(ROOT / 'docs/stage19b-evidence/historical-hashes.json')
        for name, expected in history.items():
            if sha(ROOT / name) != expected: raise AgentSystemError('Historical evidence changed')
        for name, expected in load(ROOT / 'STAGE18C_MODEL_TOOL_BOUNDARY.json')['source_sha256'].items():
            if sha(ROOT / name) != expected: raise AgentSystemError('Production boundary changed')
        admission = load(ROOT / 'docs/stage19b-capture-evidence/fresh-admission.json')
        runtime = admission['binding']['stage18c']['codex']
        if sha(Path(runtime['path'])) != runtime['sha256']: raise AgentSystemError('Pinned executable changed')
        runner = ToolDockerRunner(Configuration.load(Path(admission['project'])))
        source_hashes = {str(p.relative_to(ROOT)).replace('\\', '/'): sha(p) for p in
            (Path(__file__), ROOT / 'validation/full_response_observer.py', ROOT / 'validation/stage19b_capture.py')}
        def admission_check():
            if runner.preflight() != admission['binding']: raise AgentSystemError('Fresh runtime mismatch')
            runner.require_transport_admission()
            for name, expected in source_hashes.items():
                if sha(ROOT / name) != expected: raise AgentSystemError('Full observer source changed')
        admission_check()
        if runner.stale_executions(): raise AgentSystemError('Stale owned execution')
        workspace = Path(admission['workspace'])
        policy = ExecutionPolicy(InvocationBinding(EXECUTION, 'implementer', admission['task']['task_id'],
            1, 'gpt-6-astra', 'low'), 'implementation', hashlib.sha256(str(workspace.resolve()).encode()).hexdigest(),
            time.monotonic() + 300, max_requests=1)
        frozen = prepare(policy, runtime, admission['task'], ROOT / '.test-tmp/stage19b-capture-native/full-home')
        request_hash = hashlib.sha256(frozen).hexdigest()
        store = CredentialStore(Path('C:/Users/4ivan/.agentctl/stage19-oauth'), [ROOT, Path(admission['project'])])
        values = store.read('credentials.json')
        if not values or PLAN_SCOPE not in values['scopes'] or values['expires_at'] - time.time() < 180:
            raise AgentSystemError('Restored credentials expired; no automatic refresh')
        previous = load(ROOT / 'docs/stage19b-capture-evidence/attempt-2/capture.json')
        old_approvals = ApprovalStore(Path(previous['approval_directory']), previous['binding'])
        attested = old_approvals.verify('no-credits/' + previous['execution_id'])
        if attested['client_id'] != values['client_id']: raise AgentSystemError('Issued client changed')
        secrets = SecretFilter([values[k] for k in ('access_token', 'refresh_token', 'id_token')])
        secrets.reject(frozen.decode())
        signed_binding = {'transport': admission['binding'], 'sources': source_hashes,
                          'request_sha256': request_hash, 'execution': policy.identity()}
        approvals = ApprovalStore(runner.config.runtime_root / 'full-response-approvals', signed_binding)
        approvals.issue('no-credits/' + EXECUTION, {**attested, 'execution_id': EXECUTION})
        approvals.issue('live-smoke/' + EXECUTION, {'authorized': True, **policy.identity(),
            'model': policy.binding.model, 'reasoning': policy.binding.reasoning, 'route': UPSTREAM})
        full_grant = {'authorized': True, 'observe_only': True, 'http_requests_max': 1,
            'request_sha256': request_hash, 'limits': observed['limits'], 'sources': source_hashes,
            'no_live_codex_or_tools': True}
        approvals.issue('full-response/' + EXECUTION, full_grant)
        observed.update(binding=signed_binding, request_sha256=request_hash,
            approval_directory=str(approvals.directory), signed_full_response_scope=True,
            no_credit_attestation_reused_timestamp=True, offline_native_preparation_complete=True)
        atomic_json(OUT / 'result.json', observed)
        used = False
        def opener_factory(*args):
            delegate = original_opener(*args)
            class FullOpener:
                def open(self, request, **kwargs):
                    nonlocal used
                    if (used or request.full_url != UPSTREAM or request.get_method() != 'POST'
                            or hashlib.sha256(request.data).hexdigest() != request_hash):
                        raise AgentSystemError('One frozen full-response request required')
                    admission_check()
                    require_credit_attestation(approvals, policy.binding, values['client_id'])
                    approvals.verify('full-response/' + EXECUTION, full_grant)
                    used = True
                    observed['http_dispatch_attempts'] = 1
                    atomic_json(OUT / 'result.json', observed)
                    try: response = delegate.open(request, **kwargs)
                    except HTTPError as error:
                        observed['http_status'] = error.code
                        observed['responses_received'] = 1
                        error.close()
                        raise
                    try:
                        observed['http_status'] = response.status
                        observed['responses_received'] = 1
                        observed['headers'] = safe_headers(response.headers, secrets)
                        observed['full_response'] = full.inspect_full(response, policy, secrets)
                    finally: response.close()
                    raise ObservationFinished('Full response observed; no transport acceptance')
            return FullOpener()
        boundary.build_opener = opener_factory
        PlanUpstream(store, policy, approvals, admission_check)(strict_json(frozen.decode()))
        raise AgentSystemError('Unexpected full observer return')
    except ObservationFinished:
        observed['verdict'] = 'FULL_RESPONSE_OBSERVED_WITHOUT_EXECUTION'
    except Exception as error:
        observed['verdict'] = 'FULL_OBSERVATION_FAILED' if observed['http_dispatch_attempts'] else 'BLOCKED_BEFORE_INFERENCE'
        literals = {n.value for file in (Path(__file__), ROOT / 'agent_system/model_tool_boundary.py')
            for n in ast.walk(ast.parse(file.read_text())) if isinstance(n, ast.Constant) and isinstance(n.value, str)}
        observed['safe_error'] = str(error) if isinstance(error, AgentSystemError) and str(error) in literals else 'details_suppressed'
    finally:
        boundary.build_opener = original_opener
        if 'runner' in locals():
            observed['stale_owned_containers'] = len(runner.stale_executions())
            observed['workspace_at_baseline'] = ('workspace' in locals()
                and (workspace / 'src/example.py').read_text() == 'value = 1\n')
        observed['native_home_removed'] = not (ROOT / '.test-tmp/stage19b-capture-native/full-home').exists()
        observed['historical_hashes_unchanged'] = all(sha(ROOT / name) == expected for name, expected in
            load(ROOT / 'docs/stage19b-evidence/historical-hashes.json').items())
        if secrets: secrets.reject(json.dumps(observed))
        atomic_json(OUT / 'result.json', observed)
    print(json.dumps(observed))
    return 0 if 'full_response' in observed else 1


if __name__ == '__main__':
    raise SystemExit(main())
