"""Explicit Stage19 operator entry point. Never collected by default tests.

Connection does not perform inference. No token or callback URI is printed.
"""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import sys
import webbrowser

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / '.test-tmp/stage18-oauth-deps'))

from agent_system.chatgpt_oauth import CredentialStore, ChatGPTPlanOAuth, AuthError
import agent_system.chatgpt_oauth as oauth_module
from agent_system.errors import AgentSystemError


def connect(directory):
    import jwt
    import cryptography
    store = CredentialStore(directory, [ROOT])
    oauth = ChatGPTPlanOAuth(store)
    diagnostics = {}
    original_verify = oauth_module.verify_identity
    def observed_verify(token, client_id, nonce, http):
        # Diagnostic booleans only. Unverified metadata never authorizes login.
        try:
            header = jwt.get_unverified_header(token)
            diagnostics['id_algorithm_rs256'] = header.get('alg') == 'RS256'
            diagnostics['id_key_id_present'] = isinstance(header.get('kid'), str)
        except Exception:
            diagnostics['id_header_parse_ok'] = False
        original_decode = jwt.decode
        def observed_decode(*args, **kwargs):
            try:
                claims = original_decode(*args, **kwargs)
            except Exception as error:
                permitted = {name for name in dir(jwt.exceptions) if name.endswith('Error')}
                diagnostics['signed_decode_error_type'] = type(error).__name__ if type(error).__name__ in permitted else 'verification_error'
                raise
            diagnostics['signature_and_standard_claims_verified'] = True
            diagnostics['subject_valid'] = isinstance(claims.get('sub'), str) and bool(claims['sub'])
            diagnostics['nonce_present'] = isinstance(claims.get('nonce'), str)
            diagnostics['nonce_matches'] = nonce is None or claims.get('nonce') == nonce
            diagnostics['authorized_party_matches'] = not (isinstance(claims.get('aud'), list) and len(claims['aud']) > 1) or claims.get('azp') == client_id
            return claims
        jwt.decode = observed_decode
        try:
            return original_verify(token, client_id, nonce, http)
        finally:
            jwt.decode = original_decode
            print(json.dumps({'id_verification_diagnostics': diagnostics}), flush=True)
    oauth_module.verify_identity = observed_verify
    print('Opening official ChatGPT OAuth consent in the system browser. No inference.', flush=True)
    def launch(url):
        if not webbrowser.open(url):
            raise AgentSystemError('System browser could not open OAuth consent')
    try:
        status = oauth.sign_in(launch)
    finally:
        oauth_module.verify_identity = original_verify
    value = store.read('credentials.json')
    return {'oauth_connection_performed': True, 'oauth_connection_success': status['connected'],
            'plan_permission': status['plan_permission'], 'client_id': value['client_id'],
            'account_subject_sha256': hashlib.sha256(value['subject'].encode()).hexdigest(),
            'real_model_executions': 0, 'real_responses_requests': 0,
            'crypto_runtime': {'PyJWT': jwt.__version__, 'cryptography': cryptography.__version__}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['connect', 'inspect'])
    parser.add_argument('--credential-directory', required=True, type=Path)
    args = parser.parse_args()
    try:
        if args.command == 'inspect':
            store = CredentialStore(args.credential_directory, [ROOT])
            status = ChatGPTPlanOAuth(store).status()
            registration = store.read('registration.json')
            result = {'inspection_only': True, 'connected': status['connected'],
                'plan_permission': status['plan_permission'],
                'registration_present': registration is not None,
                'issued_client_sha256': hashlib.sha256(registration['client_id'].encode()).hexdigest() if registration else None,
                'controller_store_permissions_verified': True,
                'persisted_record_names': sorted(p.name for p in store.directory.iterdir() if p.is_file()),
                'real_model_executions': 0, 'real_responses_requests': 0}
            (ROOT / 'docs/stage19-evidence/auth-inspection.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
        else:
            result = connect(args.credential_directory)
    except AuthError as error:
        result = {'oauth_connection_success': False, 'error_type': 'AuthError',
                  'error_code': error.code, 'http_status': error.status, 'real_model_executions': 0}
    except AgentSystemError as error:
        # Only exact static error literals from the reviewed implementation may
        # be exported; never arbitrary upstream prose, token or callback data.
        tree = ast.parse((ROOT / 'agent_system/chatgpt_oauth.py').read_text(encoding='utf-8'))
        allowed = {node.args[0].value for node in ast.walk(tree)
                   if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
                   and node.func.id == 'AgentSystemError' and node.args
                   and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str)}
        result = {'oauth_connection_success': False, 'error_type': 'preflight_or_auth_denied',
                  'safe_reason': str(error) if str(error) in allowed else 'auth_failed_details_suppressed',
                  'real_model_executions': 0}
    except ImportError:
        result = {'oauth_connection_success': False, 'error_type': 'preflight_or_auth_denied',
                  'real_model_executions': 0}
    print(json.dumps(result), flush=True)
    return 0 if result.get('oauth_connection_success') or result.get('inspection_only') else 1


if __name__ == '__main__':
    raise SystemExit(main())
