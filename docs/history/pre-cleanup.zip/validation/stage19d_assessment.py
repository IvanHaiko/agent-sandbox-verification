"""Build the offline assessment from final measured evidence; never grant live scope."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from agent_system.approvals import ApprovalStore


ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / 'docs/stage19d-evidence'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def main():
    admission = json.loads((EVIDENCE / 'fresh-admission.json').read_text())
    sources = {p.relative_to(ROOT).as_posix(): sha(p) for p in sorted((ROOT / 'agent_system').rglob('*.py'))}
    bundle = hashlib.sha256(json.dumps(sources, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    assert sources == admission['source_sha256'] and bundle == admission['source_bundle_sha256']
    assert sha(Path(admission['binding']['stage18c']['codex']['path'])) == admission['codex_sha256']
    store = ApprovalStore(Path(admission['attestation_directory']), admission['binding'])
    proof = store.verify('stage18c-transport')
    required = ('codex_dynamic_roundtrip', 'docker_mutation', 'host_execution_trap', 'token_visibility',
                'builtin_response_denied', 'timeout_cleanup', 'cancel_cleanup', 'overflow_cleanup',
                'secret_output_rejected_before_export')
    assert all(proof.get(k) is True for k in required) and proof['real_model_calls'] == 0
    assert sha(store.directory / 'stage18c-proof.json') == proof['evidence_sha256']
    assert not admission['real_oauth_used'] and not admission['live_authorization_issued']

    baseline = json.loads((EVIDENCE / 'baseline-hashes.json').read_text())
    changed = {name: {'before': value, 'after': sha(ROOT/name)} for name, value in baseline.items()
               if sha(ROOT/name) != value}
    assert set(changed) == {'agent_system/model_tool_boundary.py', 'agent_system/codex_tool_session.py',
                            'agent_system/runners/chatgpt_plan.py', 'agent_system/runners/tool_docker.py'}
    new_modules = ['agent_system/responses_lifecycle.py', 'agent_system/responses_http.py']
    runs, covered = [], set()
    for filename in ('focused-final.xml', 'selected-regression.xml', 'admission-final.xml'):
        tree = ET.parse(EVIDENCE/filename)
        cases = list(tree.iter('testcase'))
        assert not list(tree.iter('failure')) and not list(tree.iter('error')) and not list(tree.iter('skipped'))
        nodes = sorted(c.attrib['classname'].replace('.', '/')+'.py::'+c.attrib['name'] for c in cases)
        assert len(nodes) == len(set(nodes))
        covered.update(nodes)
        runs.append({'artifact': 'docs/stage19d-evidence/'+filename, 'sha256': sha(EVIDENCE/filename),
                     'passed': len(nodes), 'failures': 0, 'errors': 0,
                     'by_module': dict(sorted(Counter(c.attrib['classname'] for c in cases).items())),
                     'node_ids': nodes})
    default = {line.strip() for line in (EVIDENCE/'default-nodeids.txt').read_text(encoding='utf-8-sig').splitlines()
               if line.startswith('tests/') and '::' in line}
    coverage = {'default_collected': len(default), 'default_fresh_passed': len(default & covered),
                'default_not_completed': len(default-covered), 'fresh_unique_passed': len(covered),
                'outside_default_fresh_passed': len(covered-default), 'fresh_full_default_pass': False,
                'completed_node_ids': sorted(covered), 'default_uncompleted_node_ids': sorted(default-covered),
                'runs': runs,
                'full_attempt': 'Stopped after slow unrelated deterministic workflow fixtures; no final XML, no partial passes counted.'}
    write(EVIDENCE/'coverage.json', coverage)
    old = json.loads((ROOT/'STAGE19C_TOOL_CALL_RECONCILIATION.json').read_text())
    matrix = [{'case': row['case'], 'expected_acceptance': row['proposal_accepts'],
               'historical_legacy_acceptance': row['unchanged_gate_accepts'], 'production_result': 'PASS',
               'rejection_downstream_traps_zero': not row['proposal_accepts']}
              for row in old['derived']['matrix']]
    # Stage19g archived this historical protocol matrix instead of retaining it
    # as the production acceptance contract.
    tree = ast.parse((ROOT/'docs/stage19g-evidence/test_stage19d_conformance.before.py').read_text())
    assignments = {n.targets[0].id: ast.literal_eval(n.value) for n in tree.body
                   if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)
                   and n.targets[0].id in ('MORE', 'TRANSPORT')}
    telemetry_tests = [n.name for n in tree.body if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
    test_sources = sorted({node.split('::', 1)[0] for node in covered})
    assessment = {
        'date': '2026-10-06', 'verdict': 'READY_FOR_FINAL_STAGE19_SMOKE',
        'verdict_scope': 'Offline repairs and source-bound admission; one separately authorized future smoke only',
        'production_changes': {
            'agent_system/responses_lifecycle.py': 'Private lifecycle candidates; stable distinct item/call/index/response identities; ordered argument events; exact terminal bijection; canonical arguments; safe telemetry',
            'agent_system/model_tool_boundary.py': 'Namespaced strict Controller tool; overwritten/stripped injected inventories; independent schema/policy checks; locked atomic publication; full SSE validation before upstream release',
            'agent_system/responses_http.py': 'Actual raw MIME classification; bounded owned-socket HTTP reader, EOF/cancellation/shutdown enforcement; explicit incompatible MIME rejection',
            'agent_system/codex_tool_session.py': 'Codex namespace dynamicTools wrapper and namespace-bound dispatch',
            'agent_system/runners/chatgpt_plan.py': 'Pass cancellation to upstream and retain bounded secret-checked structural metadata in invocation finally',
            'agent_system/runners/tool_docker.py': 'Include both new modules in transport source admission binding; isolation architecture unchanged'},
        'old_invariant': 'Earlier call_id inventory was a subset of final keys after terminal inventory merge; duplicate IDs collapsed; argument events ignored; authorization could publish before rejection',
        'new_invariant': 'Each position has one registered item ID; each function has a separate unique call ID, fixed name/namespace, arguments.done then item.done; final output is bijective by position, identity, canonical arguments and completed state; supplied sequences strictly increase',
        'atomic_authorization': 'Private candidates only until all validation and replay checks pass under response lock; then replace authorization map once. Failure preserves previous map object and replay sets. Upstream inspect publishes nothing.',
        'tool_format': {'namespace': 'agentctl', 'function': 'agentctl_execute', 'strict': True,
                        'top_level_tools': 1, 'functions': 1, 'schema_unchanged': True,
                        'additionalProperties': False, 'input_additional_tools': 'removed entirely',
                        'tool_search_items': 'rejected', 'hosted_native_tools': 'never exposed'},
        'mime_policy': {'event_stream': 'Eligible only after full semantic validation',
                        'absent': 'Tolerated only after full semantic validation',
                        'malformed_empty_media_token': 'Tolerated only after full semantic validation',
                        'unrecognized_without_valid_media_type': 'Tolerated only after full semantic validation',
                        'explicit_text_plain': 'REJECT', 'explicit_application_json': 'REJECT',
                        'other_valid_media_type': 'REJECT', 'damaged_leading_explicit_media_type': 'REJECT',
                        'duplicate_unsafe_header_or_non_utf8_charset': 'REJECT',
                        'partial_unknown_invalid_utf8_secret_or_invalid_lifecycle_body': 'REJECT regardless of MIME',
                        'prefix_sniffing': False, 'dispatch_before_complete_validation': False},
        'adversarial': {'stage19d_tests_passed': 84, 'stage19c_matrix': matrix,
                        'stage19c_matrix_valid': 5, 'stage19c_matrix_rejected': 33,
                        'previously_accepted_attacks_now_rejected': 16,
                        'additional_rejection_cases': assignments['MORE'],
                        'transport_cases': [{'case': n, 'mime': m, 'body_kind': k, 'accepted': v, 'result': 'PASS'}
                                            for n, m, k, v in assignments['TRANSPORT']],
                        'test_functions': telemetry_tests,
                        'empty_object': 'Valid JSON canonicalization; rejected executable authorization because exact agentctl schema requires bound fields',
                        'traps': ['Codex downstream callback', 'CodexToolSession.handle', 'IsolatedExecutionBridge.execute',
                                  'ToolDockerRunner.run_tool', 'Docker command', 'host subprocess', 'host file mutation'],
                        'rejected_cases_trap_hits': 0},
        'regression': {k: coverage[k] for k in ('default_collected', 'default_fresh_passed', 'default_not_completed',
                                               'fresh_unique_passed', 'outside_default_fresh_passed', 'fresh_full_default_pass')},
        'coverage_artifact': 'docs/stage19d-evidence/coverage.json',
        'source_bundle_sha256': bundle, 'source_sha256': sources, 'changed_baseline_hashes': changed,
        'new_production_modules': {name: sources[name] for name in new_modules},
        'historical_evidence_baseline_unchanged': True,
        'test_source_sha256': {name: sha(ROOT/name) for name in test_sources},
        'admission': {'fresh': True, 'signed_proof_reverified': True, 'evidence_sha256_reverified': True,
                      'production_sources_match_measured_run': True,
                      'codex_sha256': admission['codex_sha256'], 'binding': admission['binding'],
                      'probe_results': {key: proof[key] for key in required},
                      'real_docker_codex': True, 'model_provider': 'synthetic-localhost-only',
                      'real_model_calls': 0, 'real_oauth_used': False, 'live_scope_issued': False,
                      'full_workflow_executed': False,
                      'evidence': 'docs/stage19d-evidence/fresh-admission.json',
                      'fresh_requirements': 'Before any live request reverify exact source/Codex/image/engine/settings/project signed binding; any binding change requires new admission. Require fresh separate user live authorization and valid execution/client-bound human no-credit attestation.'},
        'known_uncertainties': [
            'Repaired path has not succeeded against real SIWC traffic; synthetic conformance and offline admission do not establish live success.',
            'Historical destroyed response and Partial tool completion root cause remain unknown; no reconstruction attempted.',
            'Stable cross-event identity and terminal bijection are local fail-closed authorization policy derived from documented identities; unseen provider variations may reject safely.',
            'Optional sequence numbers do not identify identical repeated fragments without supplied ordering; append and full argument/final reconciliation still apply.',
            'No fresh full default regression; exact uncovered node IDs retained. No real Controller multi-agent workflow was executed.',
            'Missing-MIME handling is the explicit narrow compatibility policy requested here, not a documented general allowance for text/plain.',
            'Existing real OAuth validity was not inspected or refreshed; future expired credentials stop the smoke before inference.',
            'Disposable admission fixture and local integrity key must remain protected/available; later cleanup or environment changes can require readmission.'],
        'earlier_attempts': {'focused.xml': '139 tests, one obsolete replay-message expectation failure; corrected test expectation',
                            'adversarial.xml': '82 tests, five failures caused by too-short synthetic credential fixture; fixed synthetic fixture',
                            'admission.xml': 'Failed stale source binding because source changed during run; discarded as admission and rerun after source freeze',
                            'adversarial-final.xml': 'Earlier passing 210-test run; superseded by final 235-test focused run, not added to fresh unique total'},
        'smoke': json.loads((EVIDENCE/'final-smoke-proposal.json').read_text()),
        'official_sources': {
            'function_namespaces': 'https://developers.openai.com/api/docs/guides/function-calling',
            'event_fields': 'https://developers.openai.com/api/reference/resources/responses/streaming-events',
            'siwc_preview': 'https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations',
            'siwc_codex': 'https://developers.openai.com/siwc/token-sharing-open-source/codex-app-server'},
        'stage19': 'FAIL_LIVE_TRANSPORT', 'stage19_passed': False, 'stage20_admissible': False,
        'live_inference_executed': False, 'oauth_refresh_performed': False,
        'oml_executed': False, 'benchmark_executed': False, 'multi_agent_workflow_executed': False}
    assert coverage['fresh_unique_passed'] == 438
    write(ROOT/'STAGE19D_SIWC_CONFORMANCE_REPAIR.json', assessment)
    table = '\n'.join(f'| `{name}` | {values["before"]} | {values["after"]} |' for name, values in changed.items())
    modules = '\n'.join(f'| `{name}` | {value} |' for name, value in assessment['new_production_modules'].items())
    regression = '\n'.join(f'| `{module}` | {count} |' for run in runs for module, count in run['by_module'].items())
    md = f'''# Stage 19d — SIWC Conformance Repair

`READY_FOR_FINAL_STAGE19_SMOKE` — the three production repairs, offline adversarial regression and fresh source-bound admission passed. Exactly one future smoke is proposed, awaiting separate user authorization after this assessment is reviewed. No live inference, OAuth refresh, OML, benchmark or real multi-agent workflow occurred.

**Stage19 remains `FAIL_LIVE_TRANSPORT`; Stage19 passed: false; Stage20 admissible: false.** Stage18c remains historical evidence for the architectural boundary, not admission of changed production bytes.

## Production changes and authorization invariant

The old gate merged accepted item/snapshot calls by `call_id`, then checked that earlier keys were a subset of final keys. Duplicate IDs collapsed, argument deltas/done were ignored, and canonical authorization could become visible before a later inventory/replay rejection. It did not confuse `item_id` with `call_id`.

The new production validator in `agent_system/responses_lifecycle.py` privately tracks response ID, supplied sequence ordering, output position, output item ID, separate logical call ID, function name, namespace, streamed arguments, arguments-done and item-done. Each final array position must match its registered completed item; functions must match all identities and canonical JSON. Missing/extra/duplicate/mutated/unfinished calls fail closed. Interleaved calls are accepted; supplied sequences must increase but need not be contiguous. Argument events use documented `item_id`, `output_index`, `delta`/`arguments`; they cannot invent alternate call/name/namespace authority. See the [Responses streaming event reference](https://developers.openai.com/api/reference/resources/responses/streaming-events).

`ResponsesGate.response` serializes full validation and replay checks under its existing lock. It builds private candidates, then replaces a copied authorization map exactly once on success. Rejection preserves the previous map object and seen-call/item/response sets; safe diagnostic metadata may change. `inspect_response` never publishes authority. `PlanUpstream` validates the complete body before returning it; the actual relay gate revalidates against session replay state before Codex receives it. Existing Controller and bridge checks independently validate exact identity, canonical arguments, schema, role/workspace/read-only bounds and Docker confinement.

`model_tool_boundary.py` declares one Controller-owned `agentctl` namespace containing one strict `agentctl_execute` function with the unchanged execution-bound schema, `additionalProperties: false`, argv-only execution and existing timeout/output limits. Top-level provider inventories are overwritten; Codex input `additional_tools` inventories are removed entirely; tool-search items are rejected. `codex_tool_session.py` emits the matching namespace `dynamicTools` wrapper and requires that namespace at dispatch. This follows the [function namespace format](https://developers.openai.com/api/docs/guides/function-calling) and [SIWC preview tool restrictions](https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations). The installed Codex's generated `DynamicToolSpec` schema was checked independently, and the real local app-server synthetic roundtrip passed; see [SIWC Codex app-server guidance](https://developers.openai.com/siwc/token-sharing-open-source/codex-app-server).

`responses_http.py` inspects actual Content-Type fields before library defaults. It buffers only an HTTP200 response from the fixed route on an owned socket, within byte/time/read/idle limits, with validated framing, EOF and confirmed reader shutdown. Cancellation, timeout, overflow and truncation discard bytes. Only after UTF-8, complete SSE framing, supported events/items, identity/lifecycle/final reconciliation, schema, secret and session replay validation pass can absent/unrecognized MIME be tolerated. No prefix sniffing or partial dispatch is used.

| MIME/body case | Decision |
|---|---|
| `text/event-stream`, optional UTF-8 charset | Eligible after full validation |
| Header absent | Tolerated after full validation |
| Empty malformed media token or unrecognized token with no valid media type | Tolerated after full validation |
| Explicit `text/plain`, `application/json`, or another valid incompatible media type | Reject |
| Damaged leading explicit media type, duplicate/unsafe header, non-UTF-8 charset | Reject |
| Invalid UTF-8, malformed/partial SSE, unknown event/tool, secret, replay, incomplete lifecycle | Reject for every MIME |

`runners/chatgpt_plan.py` passes cancellation and saves bounded structural metadata in invocation cleanup: known event counts, function/transition counts, stability/equality/bijection flags, byte count, MIME category/tolerance, EOF/shutdown, terminal status and recognized numeric usage. It retains no raw IDs, arguments, prose, account data or arbitrary provider fields. Known secret rejection suppresses metadata to fixed validation/secret flags. `runners/tool_docker.py` adds both new validators to admission source binding; Docker execution architecture, OAuth ownership, bearer storage, route/proxy/redirect policy and signed live/no-credit requirements remain unchanged.

## Measured offline results

**438 unique final-source tests passed:** 235 focused protocol/history/transport tests, 202 selected security/adapter/runner regressions and one fresh real Docker/Codex admission test. Zero final failures/errors/skips. The 84 Stage19d tests include all 38 Stage19c matrix cases: five valid accepted, 33 invalid rejected, including all 16 previously accepted attacks. Twenty extra lifecycle/security cases and twenty actual synthetic HTTP reader cases passed. Other tests cover interleaving, reasoning/message output, optional sequences, canonical whitespace, independent namespace/schema checks, atomic publication and bounded safe telemetry. Every rejected Stage19d case uses downstream/execution/host-write traps and must leave authorization/replay state unchanged; trap hits were zero.

`{{}}` is valid JSON and canonicalizes successfully; it cannot authorize `agentctl_execute` because the exact schema requires execution-bound fields. This explicitly preserves JSON validity without weakening the executable schema. Historical Stage19c characterization now uses a frozen legacy algorithm only in validation; production never imports it. Historical reports/evidence are byte-preserved.

| Final test module | Passed |
|---|---:|
{regression}

The default collection contains **{coverage['default_collected']}** node IDs. **{coverage['default_fresh_passed']}** passed freshly; **{coverage['default_not_completed']}** remain uncompleted in this stage, with **{coverage['outside_default_fresh_passed']}** additional validation nodes outside default collection. The full default attempt was stopped after slow unrelated deterministic workflow fixtures and produced no final XML; partial progress is excluded. This is selected fresh regression, not a fresh full-suite pass. The [coverage ledger](docs/stage19d-evidence/coverage.json) lists every completed and uncompleted node ID and each XML SHA256. Earlier failed attempts and fixes are recorded in the JSON assessment; superseded passing runs are not double-counted.

## Exact source and fresh admission

Current production bundle SHA256: **`{bundle}`**. The bundle is SHA256 of the sorted compact JSON mapping all `agent_system/**/*.py` paths to their byte SHA256. The complete mapping is in the JSON assessment and measured admission evidence.

| Changed baseline file | Before SHA256 | After SHA256 |
|---|---|---|
{table}

| New production file | SHA256 |
|---|---|
{modules}

The final admission test reused the existing Stage18c deterministic admission prefix, stopping before Controller workflow. It measured the installed Codex app-server with synthetic localhost Responses, real Docker mutation, host execution traps, token/environment visibility, network/storage isolation, native tool rejection, timeout/cancel/overflow cleanup and secret-output rejection. It signed new transport admission for the changed source. Nine deterministic tool executions occurred, zero real model calls; the disposable workspace was reset to `value = 1`, bridges closed and stale owned containers checked absent.

The assessment independently reverified the HMAC-bound transport proof and evidence SHA256, current production byte hashes and Codex executable SHA256. Pinned image: `{admission['binding']['image']}`; Docker `{admission['binding']['engine']['ServerVersion']}`, context `desktop-linux`; Codex SHA256 `{admission['codex_sha256']}`. Full engine/settings/project binding is retained in [fresh admission evidence](docs/stage19d-evidence/fresh-admission.json). No live-smoke grant was issued. Source, executable, image, engine, settings or project changes require fresh matching admission before live use. The signed local proof relies on protected Controller storage, not protection from the machine's administrator.

## One final smoke proposal

The exact [proposal JSON](docs/stage19d-evidence/final-smoke-proposal.json) is reviewable and contains the exact argv templates and structured result. It proposes the existing disposable Stage19 fixture under one fresh execution identity `stage19-final-conformance-1`, task `STAGE19-SMOKE`, one implementer/implementation role, `gpt-6-astra`, reasoning `low`, one turn/execution, no retries, at most three fixed-route Responses requests and exactly two sequential `agentctl.agentctl_execute` calls. Parallel calls are disabled.

The first command checks `src/example.py` equals `value = 1\\n`, changes only that file to `value = 2\\n`, and prints `stage19-mutated`. The second reads the same file, loads its public value, checks both equal 2 and prints `stage19-verified`. Each tool is bounded to 20 seconds/1MiB output; the mutation uses `read_only=false`, verification `true`, stdin empty. Controller supplies all six exact identity constants and independently restricts the bridge to those two templates. Total deadline 180 seconds; response ceiling 1MiB; body ceiling 60 seconds/4096 reads/5-second idle. The final role result must exactly match the task/version/completed outcome and fixed summary in the proposal.

A future driver must be created and independently source-bound after separate review/authorization. Historical live entrypoints/grants cannot authorize this scope. It must reverify matching admission, valid existing OAuth and a genuine fresh execution/client-bound human no-credit-fallback attestation (at most 24 hours old), obtain the separately authorized signed live grant, persist an exclusive one-shot latch before inference, and consume the allowance on failure. Expired credentials stop before inference; no automatic refresh. Capture safe structural metadata for every request, independently verify the exact file diff/public value/tool outputs/strict result, and confirm owned container, Codex home and role-storage cleanup plus unchanged primary workspace and historical evidence. No driver, live grant, scheduling or execution was performed here.

## Remaining uncertainty and stop state

Offline fixtures cannot prove success on real SIWC traffic. Cross-event stability and terminal bijection are conservative local authorization rules based on documented event identities; unseen provider variation may safely reject. Missing-MIME tolerance is the explicit narrow policy requested for observed SIWC behavior, not a general documented `text/plain` allowance. Without supplied sequence numbers, identical legitimate fragments are appended and checked by full argument reconciliation rather than inferred duplicate detection. Message/reasoning remain nonexecutable under the accepted policy; no new general text transcript completeness guarantee is claimed.

The destroyed historical response and its `Partial tool completion` cause remain unknown. Current account credentials were neither inspected nor refreshed. Exact default regression omissions are retained. Admission fixture/storage must remain available and protected, and all environment bindings must be checked again for any future smoke. Production is ready to propose exactly one separately authorized smoke; Stage19 has no live success and Stage20 remains inadmissible. Work stops here.
'''
    (ROOT/'STAGE19D_SIWC_CONFORMANCE_REPAIR.md').write_text(md, encoding='utf-8')
    print(json.dumps({'verdict': assessment['verdict'], 'coverage': assessment['regression'],
                      'source_bundle_sha256': bundle, 'signed_admission_reverified': True}, indent=2))


if __name__ == '__main__':
    main()
