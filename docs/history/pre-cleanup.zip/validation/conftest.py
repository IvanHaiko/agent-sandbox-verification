"""Opt-in real Docker validation; deliberately outside default offline tests."""
from pathlib import Path
import ast
import hashlib
import os
import shutil
import sys

import pytest
import yaml

SOURCE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SOURCE / 'tests'))
from test_hardened_workflow import hardened
from agent_system.config import Configuration
from agent_system.git import git
from agent_system.orchestrator import Orchestrator
from agent_system.runners import create_runner
from agent_system.runners.docker_isolated import DockerIsolatedRunner


def phase_program(phase):
    """Only this phase's program crosses the boundary, never the Tester body."""
    module = ast.parse((SOURCE / 'validation/role_driver.py').read_text())
    first = next(index for index, node in enumerate(module.body) if isinstance(node, ast.If))
    branch = module.body[first]
    while isinstance(branch, ast.If):
        test = branch.test
        right = test.comparators[0]
        names = [right.value] if isinstance(right, ast.Constant) else [node.value for node in right.elts]
        if phase in names:
            selected = ast.Module(body=[*module.body[:first], *branch.body, *module.body[first + 1:]], type_ignores=[])
            return ast.unparse(ast.fix_missing_locations(selected))
        branch = branch.orelse[0]
    raise AssertionError('Unsupported validation phase: ' + phase)


class OfflineRoleRunner(DockerIsolatedRunner):
    """Real OS adapter with separate deterministic programs, no model calls."""
    def _role_argv(self, role, phase):
        program = phase_program(phase)
        if str(role) == 'implementer':
            assert 'def test_holdout' not in program and 'assert value ==' not in program
        return ['python', '-c', program, self.options['role_args'][-1]]


@pytest.fixture
def project(tmp_path):
    root = tmp_path / 'project'
    root.mkdir()
    shutil.copytree(SOURCE / '.agent_system', root / '.agent_system')
    shutil.copy(SOURCE / '.gitignore', root / '.gitignore')
    (root / 'src').mkdir()
    (root / 'src/example.py').write_text('value = 1\n')
    (root / 'tests').mkdir()
    (root / 'tests/test_example.py').write_text('assert True\n')
    git(root, 'init', '--initial-branch=main')
    git(root, 'config', 'user.name', 'Real Container Validation')
    git(root, 'config', 'user.email', 'validation@example.invalid')
    git(root, 'add', '.')
    git(root, 'commit', '-m', 'Public baseline')
    return root


def settings(scenario='normal'):
    image = os.environ.get('AGENTCTL_ISOLATION_IMAGE')
    if not image:
        pytest.fail('Explicit AGENTCTL_ISOLATION_IMAGE is required; this suite starts real containers')
    return {'backend': 'docker_isolated', 'executable': 'python', 'timeout_seconds': 60,
            'max_infrastructure_retries': 0,
            'container': {'image': image, 'context': 'desktop-linux', 'memory_mb': 512, 'cpus': 1,
                          'role_args': ['validation-driver-sha256',
                                        hashlib.sha256((SOURCE / 'validation/role_driver.py').read_bytes()).hexdigest(), scenario]}}


@pytest.fixture
def real_runner(project, tmp_path):
    path = project / '.agent_system/project.yaml'
    value = yaml.safe_load(path.read_text())
    value['runtime'] = {'version': 2, 'root': str(tmp_path / 'runtime')}
    value['runner'] = settings()
    path.write_text(yaml.safe_dump(value))
    runner = create_runner(Configuration.load(project))
    report = runner.validate_isolation()
    assert report['admitted'], report
    runner.isolation_capabilities().require()
    return runner


@pytest.fixture
def real_case(project, hardened):
    task, _ = hardened
    def make(scenario='normal', project_changes=None):
        path = project / '.agent_system/project.yaml'
        value = yaml.safe_load(path.read_text())
        value['runner'] = settings(scenario)
        if project_changes:
            value.update(project_changes)
        path.write_text(yaml.safe_dump(value))
        runner = OfflineRoleRunner(Configuration.load(project))
        report = runner.validate_isolation()
        assert report['admitted'], report
        task_path = project / 'real-task.yaml'
        task_path.write_text(yaml.safe_dump(task))
        controller = Orchestrator(project, lambda config: runner)
        controller.plan(task_path)
        return task, controller, runner
    return task, make
