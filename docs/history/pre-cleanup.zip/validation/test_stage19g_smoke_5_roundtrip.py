"""Actual Codex/Docker with a synthetic provider; verifies the repaired request contract."""
import hashlib
import json
from pathlib import Path
import shutil
import time

import yaml

from agent_system.agent_transport import InvocationBinding
from agent_system.codex_tool_session import CodexToolSession
from agent_system.config import Configuration
from agent_system.git import WorktreeManager, git
from agent_system.model_tool_boundary import ExecutionPolicy, LocalModelRelay
from agent_system.runners.tool_docker import ToolDockerRunner
from agent_system.runners.docker_isolated import regular_tree
from agent_system.storage import atomic_json
from conftest import settings
from stage19g_live_smoke_5 import ExactBridge, ExactGate, expected_arguments, fixed_result_schema, OUT
from test_model_tool_boundary import function, message, sse


def test_repaired_contract_reaches_real_codex_and_docker(project, hardened, tmp_path):
    proposal = json.loads((OUT/'prepared-smoke.json').read_text(encoding='utf-8'))['smoke']
    config_path = project/'.agent_system/project.yaml'
    value = yaml.safe_load(config_path.read_text())
    value['runtime'] = {'version': 2, 'root': str(tmp_path/'runtime')}
    value['runner'] = settings('stage19g')
    config_path.write_text(yaml.safe_dump(value))
    runner = ToolDockerRunner(Configuration.load(project))
    assert runner.validate_isolation()['admitted']
    task = json.loads(json.dumps(hardened[0]))
    task['scope']['allowed_paths'] = ['src/example.py']
    manifest = WorktreeManager(runner.config).prepare(task['task_id'], git(project,'rev-parse','HEAD'), False, isolated_tester=True)
    workspace = Path(manifest['worktrees']['implementer']['path'])
    policy = ExecutionPolicy(InvocationBinding('stage19g-smoke-5-offline', 'implementer', task['task_id'], 1, 'gpt-6-astra', 'low'),
        'implementation', 'owned-workspace', time.monotonic()+180, max_requests=3, max_tool_calls=2, max_tool_seconds=20)
    observed = {}
    bridge = ExactBridge(runner, workspace, task, policy, proposal=proposal, observed=observed)
    gate = ExactGate(policy, proposal=proposal, bridge=bridge, observed=observed)
    choices = []
    def provider(body):
        step = len(choices)
        choices.append(body['tool_choice'])
        assert body['tool_choice'] == ('required','required','none')[step]
        assert body['parallel_tool_calls'] is False and bridge.successful == step
        if step < 2:
            properties = body['tools'][0]['tools'][0]['parameters']['properties']
            expected = expected_arguments(policy, proposal, step)
            assert properties['argv']['items']['enum'] == expected['argv']
            assert properties['read_only']['enum'] == [step == 1]
            assert properties['timeout_seconds']['enum'] == [20]
            item = function(policy, call_id='synthetic-call-'+str(step))
            item['id'] = 'synthetic-function-'+str(step)
            item['arguments'] = json.dumps(expected_arguments(policy, proposal, step))
        else:
            result = {**proposal['structured_result'], 'task_id': task['task_id']}
            item = message(json.dumps(result))
        raw = sse([item], response_id='synthetic-response-'+str(step))
        if step < 2:
            events = [json.loads(frame.split('data: ',1)[1]) for frame in raw.decode().strip().split('\n\n')]
            events[-1]['response']['output'] = []
            for event in events:
                if isinstance(event.get('item'),dict): event['item'].pop('status',None)
            raw = ''.join('event: '+e['type']+'\ndata: '+json.dumps(e)+'\n\n' for e in events).encode()
        return raw
    executable = Path(shutil.which('codex'))
    home = tmp_path/'model-home'
    result_proposal = {**proposal, 'structured_result': {**proposal['structured_result'], 'task_id': task['task_id']}}
    try:
        with LocalModelRelay(gate, provider) as relay:
            with CodexToolSession(executable, hashlib.sha256(executable.read_bytes()).hexdigest(), home, relay, bridge, policy) as session:
                assert session.run('Perform both calls and return the result.', fixed_result_schema(result_proposal)) == result_proposal['structured_result']
        assert choices == ['required','required','none'] and bridge.successful == bridge.calls == 2
        assert all(m.get('completed_calls_omitted_from_final') == 1 for m in gate.response_metadata_history[:2])
        assert bridge.changed_paths == {'src/example.py'}
        assert (workspace/'src/example.py').read_bytes() == b'value = 2\n'
        assert (project/'src/example.py').read_text() == 'value = 1\n'
        assert session.process.poll() is not None and not runner.stale_executions()
        assert all(all(c[k] for k in ('returncode_zero','stdout_exact','stderr_empty')) for c in bridge.checks)
        atomic_json(OUT/'offline-roundtrip.json', {'real_codex': True, 'real_docker': True, 'live_model_calls': 0,
            'request_tool_choices': choices, 'successful_tools': bridge.successful, 'exact_outputs': True,
            'only_expected_file_changed': True, 'primary_unchanged': True, 'owned_containers_cleaned': True})
    finally:
        bridge.close()
        if home.exists():
            assert home.resolve().parent == tmp_path.resolve()
            regular_tree(home)
            shutil.rmtree(home)
