"""Assess the completed variants from bounded evidence; performs no execution."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')


def main():
    out7 = ROOT/'docs/stage19g-smoke-7-evidence'
    out8 = ROOT/'docs/stage19g-smoke-8-evidence'
    earlier, current = read(out7/'execution.json'), read(out8/'execution.json')
    proposal = read(out8/'prepared-smoke.json')['smoke']
    required = ('stage19_passed', 'stage20_technically_admissible', 'complete_end_to_end_path',
        'source_bundle_verified', 'current_runtime_binding_verified', 'signed_transport_proof_verified',
        'signed_live_authorization', 'signed_no_credits', 'exact_file_content_verified',
        'public_python_value_verified', 'disposable_primary_unchanged', 'credential_store_unchanged',
        'strict_agent_result_verified', 'codex_process_exited', 'disposable_codex_home_removed',
        'disposable_role_storage_removed', 'primary_framework_and_historical_evidence_unchanged',
        'safe_metadata_secret_checked')
    assert all(current.get(k) is True for k in required)
    assert current['responses_dispatch_attempts'] == 3 and current['responses_http_statuses'] == [200, 200, 200]
    assert current['successful_tools'] == current['tool_attempts'] == current['validated_function_count'] == 2
    assert current['disposable_changed_paths'] == ['src/example.py']
    assert json.loads(current['agent_result']['message']) == proposal['structured_result']
    assert current['automatic_retries'] == current['stale_owned_containers'] == 0
    assert not any(current[k] for k in ('host_model_execution', 'credential_escape_observed', 'stage20_started'))
    assert len(current['tool_output_checks']) == 2
    assert all(c[k] is True for c in current['tool_output_checks'] for k in ('returncode_zero', 'stdout_exact', 'stderr_empty'))
    assert current['approved_command_resolutions'] == [
        {'step': 1, 'exact_prepared_argv': True}, {'step': 2, 'exact_prepared_argv': True}]
    anomalies = sorted({a['anomaly_type'] for m in current['transport_structure']+current['gate_structure']
        for a in m.get('anomalies', [])})
    diag = earlier['gate_structure'][-1]['argv_diagnostic']
    assessment7 = {'execution_id': earlier['execution_id'], 'verdict': 'FAIL_EXACT_PYTHON_SCRIPT',
        'responses': earlier['responses_dispatch_attempts'], 'successful_tools': 0,
        'argument_mismatch_fields': earlier['gate_structure'][-1]['argument_mismatch_fields'],
        'argv_diagnostic': diag, 'exact_difference_retained': False,
        'root_cause': 'python and -c match; Python script differs, is 31 characters shorter, and fails AST parsing.',
        'primary_unchanged': earlier['primary_framework_and_historical_evidence_unchanged'],
        'credentials_unchanged': earlier['credential_store_unchanged'],
        'owned_resources_cleaned': earlier['codex_process_exited'] and earlier['disposable_role_storage_removed']
            and earlier['disposable_codex_home_removed'] and earlier['stale_owned_containers'] == 0}
    write(out7/'assessment.json', assessment7)
    assessment = {'execution_id': current['execution_id'], 'task_id': current['task_id'],
        'model': current['model'], 'reasoning': current['reasoning'], 'verdict': current['verdict'],
        'stage19_passed': True, 'stage20_technically_admissible': True, 'stage20_started': False,
        'responses': 3, 'http_statuses': [200, 200, 200], 'successful_tools': 2, 'tool_attempts': 2,
        'automatic_retries': 0, 'complete_end_to_end_path': True,
        'wire_variant': 'Two fixed command selectors, independently matched and resolved to the unchanged frozen Python argv.',
        'raw_argv_reproduction_variant_passed': False,
        'resolution_scope': 'Smoke driver only; no general execution policy or production runner capability expanded.',
        'source_bundle_sha256': current['source_bundle_sha256'],
        'source_and_runtime_bindings_verified': True, 'fresh_signed_authorizations_verified': True,
        'changed_paths': ['src/example.py'], 'expected_content': 'value = 2\n', 'public_python_value': 2,
        'mutation_returncode': 0, 'mutation_stdout': 'stage19-mutated\n',
        'verification_returncode': 0, 'verification_stdout': 'stage19-verified\n',
        'final_structured_result': proposal['structured_result'],
        'primary_unchanged': True, 'credentials_unchanged': True,
        'credential_escape_observed': False, 'unauthorized_capability_exercised': False,
        'owned_resources_cleaned': True, 'stale_owned_containers': 0,
        'harmless_anomalies_observed_and_tolerated': anomalies,
        'offline_checks_passed': read(out8/'driver-admission.json')['offline_test_count'],
        'additional_live_tests_authorized': 5, 'additional_live_tests_used': 2,
        'unused_authorized_tests': 3, 'stopped_after_success': True,
        'further_live_attempt_scheduled': False,
        'evidence': 'docs/stage19g-smoke-8-evidence/execution.json'}
    write(out8/'assessment.json', assessment)
    historical = ROOT/'docs/stage19g-additional-tests-evidence'
    for suffix in ('md', 'json'):
        prior = ROOT/f'STAGE19G_FINAL_ASSESSMENT.{suffix}'
        archive = historical/f'prior-final-assessment.{suffix}'
        if not archive.exists(): archive.write_bytes(prior.read_bytes())
    write(ROOT/'STAGE19G_FINAL_ASSESSMENT.json', assessment)
    report = '''# Stage19g — Final smoke assessment

**Stage19 passed: true. Stage20 technically admissible: true. Stage20 started: false.**

`stage19g-smoke-8` completed the authorized live path using `gpt-6-astra / low`: three sequential Responses requests (all HTTP 200), one Codex turn and exactly two successful `agentctl.agentctl_execute` calls. No automatic retries or alternate model/reasoning were used.

The working variant gives the model two fixed selectors, `stage19-mutate` and `stage19-verify`. The Controller validates their complete execution-bound arguments and maps each to its unchanged prepared Python command. It runs neither extra arguments nor arbitrary replacement commands. This resolver is confined to the smoke driver; production runner capabilities were not expanded.

Only disposable `src/example.py` changed. Its bytes are exactly `value = 2\\n`, and the verification confirmed the public Python value is 2. Mutation and verification each returned 0, with stdout exactly `stage19-mutated\\n` and `stage19-verified\\n`. The final structured result exactly matched the prepared contract. Project acceptance, unchanged primary workspace/credentials and cleanup all passed; zero owned containers remained.

The preceding `stage19g-smoke-7` tested direct argv copying with stronger instructions. Its `python` and `-c` matched, but the script was 31 characters shorter and did not parse as Python. It was blocked before Docker. The selector variant removes that reproduction problem. Direct raw-argv copying and the earlier HTTP 400 cause remain unresolved; they do not establish a capability failure in the successful fixed-action path.

Current source, Codex executable, Docker image/engine/config/project bindings and signed admission were verified before inference. Expired OAuth credentials were reconnected through official browser login before either live attempt; credentials stayed protected. Fresh execution/client-bound authorizations and exclusive latches were used, retaining the original human confirmation that credit fallback is OFF.

Harmless stream/final message variation, completed tool omission from the final summary, and absent MIME were recorded and tolerated. Exact executable authority, identity, replay, output and project checks remained enforced. The variants passed 43 and 49 distinct local checks respectively, including real Codex/Docker roundtrips with a synthetic provider.

Two of the five newly authorized live tests were used. Work stopped after success; three remain unused and none is scheduled. Stage20 was not started.

Evidence: [successful execution](docs/stage19g-smoke-8-evidence/execution.json), [assessment](docs/stage19g-smoke-8-evidence/assessment.json), [local checks](docs/stage19g-smoke-8-evidence/roundtrip.xml), [failed direct-copy variant](docs/stage19g-smoke-7-evidence/assessment.json). Previous assessments are preserved in `docs/stage19g-additional-tests-evidence`.
'''
    (ROOT/'STAGE19G_FINAL_ASSESSMENT.md').write_text(report, encoding='utf-8')
    print(json.dumps({k: assessment[k] for k in ('stage19_passed', 'stage20_technically_admissible',
        'stage20_started', 'additional_live_tests_used', 'unused_authorized_tests')}))


if __name__ == '__main__': main()
