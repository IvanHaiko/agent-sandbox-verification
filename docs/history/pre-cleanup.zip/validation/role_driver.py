"""Deterministic JSON-stdin role driver for real-container Pilot 0. No LLM."""
import json
from pathlib import Path
import sys

request = json.load(sys.stdin)
scenario = sys.argv[1] if len(sys.argv) > 1 else 'normal'
phase = request['phase']
common = {'task_id': request['task_id'], 'contract_version': request['contract_version']}
if phase == 'test_design':
    report = {**common, 'cases': [
        {'id': name, 'category': 'acceptance', 'priority': 'critical', 'criterion': 0,
         'preconditions': [], 'action': 'Read public value', 'expected_result': '2', 'fixtures': []}
        for name in ('ACCEPT-0', 'ACCEPT-H')]}
elif phase in ('test_implementation', 'test_correction'):
    folder = Path('tests/acceptance')
    folder.mkdir(parents=True, exist_ok=True)
    value = 3 if scenario == 'dispute' and phase != 'test_correction' else 2
    for name in ('visible', 'holdout'):
        (folder / f'test_{name}.py').write_text(f'from src.example import value\ndef test_{name}():\n    assert value == {value}\n')
    report = {**common, 'summary': 'Independent executable tests', 'independent': [
        {'case_id': 'ACCEPT-0', 'path': 'tests/acceptance/test_visible.py', 'test_id': 'tests/acceptance/test_visible.py::test_visible'},
        {'case_id': 'ACCEPT-H', 'path': 'tests/acceptance/test_holdout.py', 'test_id': 'tests/acceptance/test_holdout.py::test_holdout'}], 'additional': []}
elif phase in ('implementation', 'fix'):
    if phase == 'fix':
        assert 'assert value' not in json.dumps(request['inputs'])
        assert 'test_holdout' not in json.dumps(request['inputs'])
    assert not Path('tests/acceptance/test_holdout.py').exists()
    Path('src/example.py').write_text(f'value = {0 if scenario == "feedback" and phase == "implementation" else 2}\n')
    if scenario == 'drift':
        Path('pyproject.toml').write_text('[project]\ndependencies=["new"]\n')
    report = {**common, 'outcome': 'completed', 'summary': 'Public behavior implemented', 'architecture_decision': None}
elif phase in ('review', 'review_blind', 'test_correction_review'):
    report = {**common, 'summary': 'Reviewed', 'findings': [], 'architecture_decision': None}
elif phase == 'audit':
    report = {**common, 'verdict': 'PASS', 'summary': 'Audited', 'checks': [
        {'name': 'data', 'evidence': 'Independent regeneration', 'passed': True}], 'findings': [], 'architecture_decision': None}
else:
    raise AssertionError(phase)
print(json.dumps(report))
