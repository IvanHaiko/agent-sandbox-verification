"""Explicit account-specific model discovery, never inference."""
import hashlib
import json
from pathlib import Path
import sys
import time
from urllib.request import Request, build_opener, ProxyHandler

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / '.test-tmp/stage18-oauth-deps'))
from agent_system.chatgpt_oauth import CredentialStore, ChatGPTPlanOAuth, PLAN_SCOPE, NoRedirect
from agent_system.agent_transport import strict_json
from agent_system.model_tool_boundary import SecretFilter


def main():
    store = CredentialStore(Path('C:/Users/4ivan/.agentctl/stage19-oauth'), [ROOT])
    values = store.read('credentials.json')
    refreshed = False
    if values and time.time() >= values['expires_at']:
        ChatGPTPlanOAuth(store).refresh()
        values, refreshed = store.read('credentials.json'), True
    assert values and PLAN_SCOPE in values['scopes'] and time.time() < values['expires_at']
    filter_ = SecretFilter([values[k] for k in ('access_token', 'refresh_token', 'id_token')])
    request = Request('https://api.openai.com/v1/models', headers={'Authorization': 'Bearer ' + values['access_token']})
    with build_opener(ProxyHandler({}), NoRedirect()).open(request, timeout=15) as response:
        raw = response.read(1048577)
        assert len(raw) <= 1048576
    filter_.reject(raw.decode('utf-8'))
    catalog = strict_json(raw.decode('utf-8'))
    models = [{k: m.get(k) for k in ('slug', 'display_name', 'visibility', 'supported_reasoning_levels', 'default_reasoning_level')}
              for m in catalog['models'] if m.get('visibility') == 'list']
    result = {'catalog_success': True, 'catalog_requests': 1, 'real_responses_requests': 0,
              'client_sha256': hashlib.sha256(values['client_id'].encode()).hexdigest(),
              'refresh_occurred': refreshed, 'models': models}
    (ROOT / 'docs/stage19-evidence/account-catalog.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result))


if __name__ == '__main__':
    try:
        main()
    except Exception:
        print('Account model discovery denied or failed; no inference.')
        raise SystemExit(1)
