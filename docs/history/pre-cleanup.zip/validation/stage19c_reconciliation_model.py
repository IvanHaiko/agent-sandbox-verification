"""Offline executable proposal only. Never imported by production transport.

This deliberately narrow function-call model is not SIWC acceptance authority.
It retains the existing gate and adds lifecycle checks before calling it.
"""
import json

from jsonschema import Draft202012Validator

from agent_system.agent_transport import strict_json
from agent_system.errors import AgentSystemError
from agent_system.model_tool_boundary import tool_spec
from validation.stage19c_legacy_gate import ResponsesGate


class OfflineReconciliationModel:
    def __init__(self, policy, secrets=None):
        self.gate = ResponsesGate(policy, secrets)
        self.authorized_arguments = {}
        self.seen_items = set()
        self.seen_responses = set()

    def response(self, raw):
        self.authorized_arguments = {}
        self.gate.authorized_arguments.clear()
        self.gate.alive()
        if len(raw) > self.gate.policy.max_response_bytes:
            raise AgentSystemError('Model output overflow')
        try:
            text = raw.decode('utf-8').replace('\r\n', '\n')
        except UnicodeDecodeError:
            raise AgentSystemError('Invalid model output encoding') from None
        self.gate.secrets.reject(text)
        if not text.endswith('\n\n'):
            raise AgentSystemError('Partial model SSE frame')
        items, ids, logical = {}, set(), set()
        response_id, completed, previous_sequence = None, False, -1
        for frame in text.split('\n\n')[:-1]:
            if not frame:
                continue
            data, event = [], None
            for line in frame.split('\n'):
                if line.startswith('data: '): data.append(line[6:])
                elif line.startswith('event: ') and event is None: event = line[7:]
                else: raise AgentSystemError('Unsupported SSE framing')
            value = strict_json('\n'.join(data))
            self.gate.secrets.reject(json.dumps(value))
            if not isinstance(value, dict): raise AgentSystemError('Invalid event')
            kind, seq = value.get('type'), value.get('sequence_number')
            if (completed or kind not in ResponsesGate.EVENTS or event not in (None, kind)
                    or type(seq) is not int or seq <= previous_sequence):
                raise AgentSystemError('Unknown, replayed or out-of-order event')
            previous_sequence = seq
            if 'item' in value and kind not in ('response.output_item.added', 'response.output_item.done'):
                raise AgentSystemError('Unexpected item on non-item event')
            if kind in ('response.created', 'response.in_progress', 'response.completed'):
                response = value.get('response')
                if not isinstance(response, dict) or not isinstance(response.get('id'), str) or not response['id']:
                    raise AgentSystemError('Missing response identity')
                if response_id is None:
                    if kind != 'response.created' or response['id'] in self.seen_responses:
                        raise AgentSystemError('Missing creation or replayed response')
                    response_id = response['id']
                elif response['id'] != response_id or kind == 'response.created':
                    raise AgentSystemError('Response identity mutation or duplicate creation')
                if not isinstance(response.get('output'), list):
                    raise AgentSystemError('Malformed output')
                if kind != 'response.completed':
                    # Proposal deliberately supports empty progress inventories only.
                    if response['output']: raise AgentSystemError('Unsupported progress snapshot')
                    continue
                if response.get('status') != 'completed' or len(response['output']) != len(items):
                    raise AgentSystemError('Incomplete or conflicting final inventory')
                for index, item in enumerate(response['output']):
                    record = items.get(index)
                    if record is None or not record['done'] or item != record['snapshot']:
                        raise AgentSystemError('Conflicting final snapshot')
                completed = True
                continue
            if response_id is None: raise AgentSystemError('Event before creation')
            index = value.get('output_index')
            if type(index) is not int or index < 0: raise AgentSystemError('Invalid output index')
            if kind == 'response.output_item.added':
                item = value.get('item')
                self.gate._item(item, {})
                iid = item.get('id')
                if not isinstance(iid, str) or not iid or iid in ids or iid in self.seen_items or index in items:
                    raise AgentSystemError('Duplicate item or output index')
                ids.add(iid)
                record = {'item': item, 'arguments': item.get('arguments', ''),
                          'deltas': 0, 'arguments_done': False, 'done': False}
                if item['type'] == 'function_call':
                    cid = item['call_id']
                    if cid in logical or cid in self.gate.seen_calls or not isinstance(record['arguments'], str):
                        raise AgentSystemError('Duplicate or replayed call')
                    logical.add(cid)
                    if len(logical) > self.gate.policy.max_tool_calls: raise AgentSystemError('Too many calls')
                items[index] = record
                continue
            record = items.get(index)
            if record is None or record['done']: raise AgentSystemError('Orphan or completed item event')
            original = record['item']
            if kind == 'response.output_item.done':
                item = value.get('item')
                self.gate._item(item, {})
                fields = ('id', 'type')
                if original['type'] == 'function_call':
                    fields += ('call_id', 'name', 'namespace')
                    if not record['arguments_done'] or item.get('arguments') != record['arguments']:
                        raise AgentSystemError('Missing or conflicting completed arguments')
                    if item.get('status') != 'completed': raise AgentSystemError('Incomplete call')
                if any(item.get(k) != original.get(k) for k in fields):
                    raise AgentSystemError('Item identity or function mutation')
                record.update(done=True, snapshot=item)
                continue
            if value.get('item_id') != original['id']:
                raise AgentSystemError('Orphan or mutated item identity')
            if kind.startswith('response.function_call_arguments.'):
                if original['type'] != 'function_call' or record['arguments_done']:
                    raise AgentSystemError('Orphan or duplicate arguments event')
                if kind.endswith('.delta'):
                    if not isinstance(value.get('delta'), str): raise AgentSystemError('Malformed delta')
                    record['arguments'] += value['delta']
                    record['deltas'] += 1
                else:
                    arguments = value.get('arguments')
                    if not isinstance(arguments, str): raise AgentSystemError('Malformed arguments')
                    if (record['deltas'] or original.get('arguments')) and arguments != record['arguments']:
                        raise AgentSystemError('Arguments differ from stream')
                    parsed = strict_json(arguments)
                    self.gate.secrets.reject(json.dumps(parsed))
                    if not Draft202012Validator(tool_spec(self.gate.policy)['inputSchema']).is_valid(parsed):
                        raise AgentSystemError('Invalid executable arguments')
                    record.update(arguments=arguments, arguments_done=True)
            elif original['type'] == 'function_call':
                raise AgentSystemError('Unsupported event for function item')
        if not completed: raise AgentSystemError('Missing model completion')
        # Only publish after the entire stream and the unchanged gate validate.
        result = self.gate.response(raw)
        self.authorized_arguments = dict(self.gate.authorized_arguments)
        self.seen_items.update(ids)
        self.seen_responses.add(response_id)
        return result
