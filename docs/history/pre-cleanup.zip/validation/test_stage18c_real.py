"""Fresh real Docker admission + actual Codex dynamic tools, synthetic model only."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import threading
import time

import pytest
import yaml

from agent_system.agent_transport import InvocationBinding
from agent_system.codex_tool_session import CodexToolSession
from agent_system.config import Configuration
from agent_system.errors import AgentSystemError
from agent_system.git import WorktreeManager, git
from agent_system.isolation_probes import host_candidates
from agent_system.model_tool_boundary import (ExecutionPolicy, IsolatedExecutionBridge, ResponsesGate,
                                            LocalModelRelay, SecretFilter)
from agent_system.runners.tool_docker import ToolDockerRunner
from agent_system.storage import atomic_json
from agent_system.approvals import ApprovalStore
from agent_system.orchestrator import Orchestrator
from agent_system.roles import Role
from agent_system.runners.chatgpt_plan import ChatGPTPlanRunner
from agent_system.chatgpt_oauth import PLAN_SCOPE
from conftest import settings, phase_program
from agent_system.runners.docker_isolated import DockerIsolatedRunner
from test_model_tool_boundary import function, message, sse, tool_request


def test_fresh_stage18c_transport_and_adversarial_boundary(project, hardened, tmp_path, monkeypatch):
    task, _ = hardened
    config_path = project / '.agent_system/project.yaml'
    value = yaml.safe_load(config_path.read_text())
    value['runner'] = settings('stage18c')
    config_path.write_text(yaml.safe_dump(value))
    config = Configuration.load(project)
    runner = ToolDockerRunner(config)
    report = runner.validate_isolation()
    assert report['admitted'] and report['model_calls'] == 0
    runner.isolation_capabilities().require()
    manifest = WorktreeManager(config).prepare(task['task_id'], git(project, 'rev-parse', 'HEAD'), False,
                                               isolated_tester=True)
    workspace = Path(manifest['worktrees']['implementer']['path'])
    policy = ExecutionPolicy(InvocationBinding('exec-1', 'implementer', task['task_id'], 1, 'gpt-5.4', 'low'),
                             'implementation', 'owned-workspace', time.monotonic() + 180)
    secret = 'synthetic-controller-oauth-canary-123456'
    private = tmp_path / 'controller-oauth-canary'
    private.write_text(secret)
    filter_ = SecretFilter([secret])
    bridge = IsolatedExecutionBridge(runner, workspace, task, policy, filter_)
    executable = Path(shutil.which('codex'))
    exe_hash = hashlib.sha256(executable.read_bytes()).hexdigest()
    # Fail immediately if a generated argv runs as a host process. Only exact
    # deterministic Controller utilities and Docker/Codex executables are allowed.
    real_popen = subprocess.Popen
    host_calls = []
    def host_trap(argv, *args, **kwargs):
        first = Path(argv[0]).name.lower()
        if first.startswith('python'):
            from agent_system.runners.docker_isolated import CLEANUP
            assert len(argv) == 6 and argv[1:4] == ['-I', '-c', CLEANUP], 'Untrusted Python on host'
        else:
            assert first in ('git', 'git.exe', 'docker', 'docker.exe', 'codex.exe'), 'Untrusted host executable'
        host_calls.append(first)
        return real_popen(argv, *args, **kwargs)
    monkeypatch.setattr(subprocess, 'Popen', host_trap)
    request = tool_request(policy)
    request.update(argv=['python', '-c', 'from pathlib import Path; Path("src/example.py").write_text("value = 2\\n"); print("isolated-edit")'],
                   read_only=False, timeout_seconds=20)
    requests = []
    def upstream(body):
        requests.append([t['name'] for t in body['tools']])
        call = function(policy)
        call['arguments'] = json.dumps(request)
        result = {'task_id': task['task_id'], 'contract_version': 1, 'outcome': 'completed',
                  'summary': 'Synthetic Docker edit', 'architecture_decision': None}
        return sse([call]) if len(requests) == 1 else sse([message(json.dumps(result))], response_id='response-2')
    with LocalModelRelay(ResponsesGate(policy, filter_), upstream) as relay:
        with CodexToolSession(executable, exe_hash, tmp_path / 'codex-home', relay, bridge, policy) as session:
            assert session.run('Synthetic offline model tool test.')['outcome'] == 'completed'
        assert session.process.poll() == 0
    assert (workspace / 'src/example.py').read_text() == 'value = 2\n'
    assert bridge.changed_paths == {'src/example.py'} and len(requests) == 2
    # New helper for each ephemeral role execution; identity is never reused.
    policy2 = ExecutionPolicy(InvocationBinding('exec-2', 'implementer', task['task_id'], 1, 'gpt-5.4', 'low'),
                             'implementation', 'owned-workspace', time.monotonic() + 180)
    bridge2 = IsolatedExecutionBridge(runner, workspace, task, policy2, filter_)
    request2 = tool_request(policy2)
    script = '''import json,os,pathlib,sys,socket
paths=json.loads(sys.argv[1]); result={'env':dict(os.environ),'reads':[], 'proc':[]}
for p in paths:
 try: result['reads'].append(pathlib.Path(p).read_text())
 except OSError: result['reads'].append('inaccessible')
for p in pathlib.Path('/proc').glob('[0-9]*/environ'):
 try: result['proc'].append(p.read_bytes().decode(errors='replace'))
 except OSError: pass
s=socket.socket(); s.settimeout(.2)
try: s.connect(('1.1.1.1',443)); result['egress']='connected'
except OSError: result['egress']='denied'
print(json.dumps(result))'''
    request2['argv'] = ['python', '-c', script, json.dumps(host_candidates(private))]
    observed = json.loads(bridge2.execute(request2)['stdout'])
    assert all(x == 'inaccessible' for x in observed['reads']) and secret not in json.dumps(observed)
    assert 'AGENTCTL_MODEL_CHANNEL' not in observed['env'] and observed['egress'] == 'denied'
    assert observed['env']['HOME'] == '/role/home'
    # Built-ins are rejected by the real relay before any byte reaches Codex.
    attack_policy = ExecutionPolicy(InvocationBinding('exec-attack', 'implementer', task['task_id'], 1, 'gpt-5.4', 'low'),
                                   'implementation', 'owned-workspace', time.monotonic() + 30)
    attack_bridge = IsolatedExecutionBridge(runner, workspace, task, attack_policy, filter_)
    sentinel = tmp_path / 'host-execution-sentinel'
    attack = function(attack_policy, name='exec_command')
    attack['arguments'] = json.dumps({'cmd': 'echo UNSAFE > ' + str(sentinel)})
    with LocalModelRelay(ResponsesGate(attack_policy, filter_), lambda body: sse([attack])) as relay:
        with CodexToolSession(executable, exe_hash, tmp_path / 'attack-codex-home', relay, attack_bridge, attack_policy) as session:
            with pytest.raises(AgentSystemError): session.run('Synthetic adversarial builtin call.')
        assert relay.failures
    assert not sentinel.exists()
    # Timeout, overflow, cancellation and output-secret rejection must dispose
    # the actual container and stage before any raw output is exported.
    request2['argv'] = ['python', '-c', 'import time; time.sleep(15)']
    request2['timeout_seconds'] = 1
    with pytest.raises(subprocess.TimeoutExpired): bridge2.execute(request2)
    request2['timeout_seconds'] = 10
    request2['argv'] = ['python', '-c', 'print("X"*1100000)']
    with pytest.raises(AgentSystemError, match='output limit'): bridge2.execute(request2)
    request2['argv'] = ['python', '-c', 'print(bytes.fromhex("' + secret.encode().hex() + '").decode())']
    with pytest.raises(AgentSystemError, match='Credential'): bridge2.execute(request2)
    timer = threading.Timer(1.5, runner.cancel_event.set)
    request2['argv'] = ['python', '-c', 'import time; time.sleep(15)']
    timer.start()
    try:
        with pytest.raises(AgentSystemError, match='cancel'): bridge2.execute(request2)
    finally:
        timer.cancel()
    assert not runner.stale_executions()
    records = [json.loads(p.read_text()) for p in runner.root.glob('executions/*/ownership.json')]
    assert all(r['cleanup'] == 'confirmed' and r['storage_cleanup'] == 'confirmed' for r in records)
    assert all(not (p.parent / 'checkout').exists() and not (p.parent / 'transfer').exists()
               for p in runner.root.glob('executions/*/ownership.json'))
    assert all(secret not in p.read_text(errors='replace') for p in runner.root.glob('executions/*/*.txt'))
    proof = {'codex_dynamic_roundtrip': True, 'docker_mutation': True, 'host_execution_trap': True,
        'token_visibility': True, 'builtin_response_denied': True, 'timeout_cleanup': True,
        'cancel_cleanup': True, 'overflow_cleanup': True, 'secret_output_rejected_before_export': True,
        'real_model_calls': 0, 'host_executable_names': sorted(set(host_calls)),
        'isolation_capabilities': {k: v['passed'] for k, v in report['capabilities'].items()},
        'codex_sha256': exe_hash, 'binding': runner.preflight(), 'execution_count': len(records),
        'workspace_mutations': ['src/example.py'], 'provider': 'synthetic-localhost-only'}
    store = runner._store()
    atomic_json(store.directory / 'stage18c-proof.json', proof)
    signed = {k: v for k, v in proof.items() if type(v) is bool or k == 'real_model_calls'}
    signed['evidence_sha256'] = hashlib.sha256((store.directory / 'stage18c-proof.json').read_bytes()).hexdigest()
    store.issue('stage18c-transport', signed)
    runner.require_transport_admission()
    # Exercise the existing AgentRunner/telemetry integration too. This fixture
    # uses synthetic Controller approvals and replaces only the OpenAI caller;
    # no real credentials, operator attestation or live authorization are issued.
    git(workspace, 'checkout', '--', 'src/example.py')
    factory_task = json.loads(json.dumps(task))
    factory_task['task_id'] = 'STAGE18C-FACTORY'
    task_path = project / 'stage18c-task.yaml'
    task_path.write_text(yaml.safe_dump(factory_task))
    factory_workspace = config.worktrees_dir / factory_task['task_id'] / 'implementer'
    operation = 'c0-implementation-r0-t1'
    class SyntheticStore:
        directory = tmp_path / 'synthetic-controller-storage'
        def read(self, name):
            return {'access_token': 'synthetic-access-token-123456', 'refresh_token': 'synthetic-refresh-token-123456',
                    'id_token': 'synthetic-id-token-123456', 'client_id': 'oaiapp_synthetic',
                    'scopes': [PLAN_SCOPE], 'expires_at': time.time() + 300}
    approvals = ApprovalStore(tmp_path / 'synthetic-controller-approvals', {'synthetic': True})
    model_config = config.model_for(Role.IMPLEMENTER)
    factory_policy = ExecutionPolicy(InvocationBinding(operation, 'implementer', factory_task['task_id'], 1,
        model_config.model, model_config.reasoning), 'implementation', hashlib.sha256(str(factory_workspace.resolve()).encode()).hexdigest(),
        time.monotonic() + 60)
    approvals.issue('no-credits/' + operation, {'execution_id': operation, 'client_id': 'oaiapp_synthetic',
        'credits_fallback_disabled': True, 'operator': 'offline-fixture-only', 'attested_at': time.time()})
    from agent_system.model_tool_boundary import UPSTREAM
    approvals.issue('live-smoke/' + operation, {'authorized': True, **factory_policy.identity(),
        'model': model_config.model, 'reasoning': model_config.reasoning, 'route': UPSTREAM})
    class SyntheticUpstream:
        def __init__(self, credentials, bound_policy, approvals, admission):
            self.policy, self.count = bound_policy, 0
        def __call__(self, body):
            self.count += 1
            if self.count == 1:
                call = function(self.policy)
                args = tool_request(self.policy)
                args.update(argv=['python', '-c', 'from pathlib import Path; Path("src/example.py").write_text("value = 2\\n")'], read_only=False)
                call['arguments'] = json.dumps(args)
                return sse([call])
            result = {'task_id': factory_task['task_id'], 'contract_version': 1, 'outcome': 'completed',
                      'summary': 'Synthetic factory integration', 'architecture_decision': None}
            return sse([message(json.dumps(result))], response_id='response-2')
    monkeypatch.setattr('agent_system.runners.chatgpt_plan.PlanUpstream', SyntheticUpstream)
    class HybridFixture(ChatGPTPlanRunner):
        def _role_argv(self, role, phase):
            return ['python', '-c', phase_program(phase), 'normal']
        def run(self, role, model_config, context, workspace, task):
            if context['phase'] == 'implementation':
                return super().run(role, model_config, context, workspace, task)
            return DockerIsolatedRunner.run(self, role, model_config, context, workspace, task)
    factory = HybridFixture(config, SyntheticStore(), approvals)
    controller = Orchestrator(project, lambda config: factory)
    controller.plan(task_path)
    final_state = controller.resume(factory_task['task_id'])
    assert final_state['state'] == 'ACCEPTED', final_state['detail']
    invocation = config.runs_dir / factory_task['task_id'] / 'invocations' / operation
    assert json.loads((invocation / 'result.json').read_text())['status'] == 'success'
    assert (invocation / 'telemetry.json').exists()
    assert not factory.stale_executions()
    proof['agent_runner_factory_integration'] = True
    out = Path(__file__).resolve().parents[1] / 'docs/stage18c-evidence'
    out.mkdir(parents=True, exist_ok=True)
    atomic_json(out / 'real-summary.json', {**proof, 'signed_admission': True,
                'attestation_directory': str(store.directory)})
