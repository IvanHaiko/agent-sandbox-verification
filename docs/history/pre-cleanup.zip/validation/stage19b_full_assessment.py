"""Separate full-response assessment; reads safe evidence, never sends requests."""
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from agent_system.approvals import ApprovalStore
from agent_system.storage import atomic_json


def main():
    evidence = json.loads((ROOT / 'docs/stage19b-full-response-evidence/result.json').read_text())
    full = evidence['full_response']
    assert evidence['http_dispatch_attempts'] == evidence['responses_received'] == 1
    assert evidence['http_status'] == 200 and evidence['tool_calls'] == 0
    assert full['body_complete'] and full['stop_reason'] == 'eof'
    assert full['bytes_read'] == 105349 and full['event_counts']['response.completed'] == 1
    assert not full['strict_response_gate_passed'] and full['gate_failure'] == 'Partial tool completion'
    assert not evidence['headers']['content_type_present']
    assert not full['accepted_as_inference'] and not full['passed_to_codex']
    assert evidence['stale_owned_containers'] == 0 and evidence['workspace_at_baseline']
    assert evidence['native_home_removed'] and evidence['historical_hashes_unchanged']
    store = ApprovalStore(Path(evidence['approval_directory']), evidence['binding'])
    for name in ('live-smoke', 'no-credits', 'full-response'):
        store.verify(name + '/' + evidence['execution_id'])
    for name, digest in evidence['binding']['sources'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
    history = json.loads((ROOT / 'docs/stage19b-evidence/historical-hashes.json').read_text())
    assert all(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest for name, digest in history.items())
    tree = ET.parse(ROOT / 'docs/stage19b-full-response-evidence/adversarial.xml').getroot()
    assert not list(tree.iter('failure')) and not list(tree.iter('error'))
    assert len(list(tree.iter('testcase'))) == 11
    report = {'date': '2026-10-06', 'verdict': 'FULL_RESPONSE_CAPTURED_STRICT_GATE_REJECTED',
        'observed': evidence,
        'inferred': {'mime_rejection_cause_for_this_request': 'No recognized Content-Type -> stdlib default text/plain',
            'second_independent_barrier': 'Strict gate detected at least one streamed function-call ID absent from completed output function-call set',
            'basis': 'ResponsesGate.response set(calls) - set(final_calls) raises Partial tool completion',
            'response_completed_event_is_insufficient': True,
            'next_step': 'Offline investigation of SIWC stream/snapshot semantics and existing call reconciliation before any production MIME-policy change',
            'no_fix_or_extra_request_performed': True},
        'unknown': ['which specific call/item IDs differed; identifiers and arguments were not exported',
            'whether provider snapshot omission, identity drift, tool format, or local validation assumption caused disagreement',
            'final response text, backend usage/cost and reason for missing MIME header'],
        'checks': {'new_synthetic_tests_passed': 11, 'signed_authority_reverified': True,
            'historical_22_files_preserved': True, 'raw_body_retained': False,
            'production_sources_or_acceptance_changed': False},
        'historical_status': {'stage19': 'FAIL_LIVE_TRANSPORT', 'stage19_passed': False,
            'stage20_admissible': False, 'cumulative_responses_requests': 4}}
    atomic_json(ROOT / 'STAGE19B_FULL_RESPONSE.json', report)
    print(json.dumps({'verdict': report['verdict'], 'bytes': 105349, 'complete_body': True,
        'response_completed_events': 1, 'strict_gate_passed': False, 'tool_calls_executed': 0}))


if __name__ == '__main__':
    main()
