"""First-request reconstruction: localhost only; never reads OAuth or calls SIWC.

Artifacts are REPLAY observations, not recovered historical wire bodies.
"""
import ast
import hashlib
import json
from pathlib import Path
import shutil
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'docs/stage19-request-audit-evidence'
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tests'))
from agent_system.agent_transport import InvocationBinding, strict_json
from agent_system.codex_tool_session import CodexToolSession
from agent_system.model_tool_boundary import ExecutionPolicy, ResponsesGate, LocalModelRelay, IsolatedExecutionBridge
from test_model_tool_boundary import Runner, message, sse
from validation.stage19_final_smoke_retry import expected_arguments, ExactGate
from validation.stage19b_capture import original_prompt


def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2) + '\n', encoding='utf-8')


def replay(label, runtime, policy, prompt, legacy=False):
    executable = Path(runtime['path'])
    assert hashlib.sha256(executable.read_bytes()).hexdigest() == runtime['sha256']
    home_root = ROOT / 'offline-stage19-request-audit'
    home = home_root / label
    assert not home.exists()
    captured = {}
    class CaptureGate(ExactGate):
        def __init__(self, policy):
            ResponsesGate.__init__(self, policy)
        def inspect_response(self, raw):
            return ResponsesGate.inspect_response(self, raw)
        def request(self, raw):
            assert not captured, 'Only one synthetic request allowed'
            native = strict_json(raw.decode())
            captured['native'] = native
            if legacy:
                # Source-derived historical gate behavior: flat function,
                # no strict flag; additional_tools input was not stripped.
                value = ResponsesGate.request(self, raw)
                value['input'] = native['input']
                function = value['tools'][0]['tools'][0]
                function.pop('strict')
                value['tools'] = [function]
            else:
                # Execute the exact consumed driver's request transform only.
                value = ExactGate.request(self, raw)
            captured['postgate'] = value
            return value
    def synthetic(body):
        assert body is captured['postgate']
        result = {'task_id': policy.binding.task_id, 'contract_version': 1,
                  'outcome': 'completed', 'summary': 'Synthetic offline reconstruction',
                  'architecture_decision': None}
        return sse([message(json.dumps(result))])
    session_class = CodexToolSession
    if legacy:
        # Old Codex dynamicTools were flat. The rest is current hardened session
        # configuration; this is explicitly an approximation of the old source.
        import agent_system.codex_tool_session as mod
        source = (ROOT / 'agent_system/codex_tool_session.py').read_text()
        old = "[{'type': 'namespace', 'name': NAMESPACE, 'description': 'Controller-owned isolated execution',\n                    'tools': [tool_spec(self.policy)]}]"
        assert source.count(old) == 1
        namespace = dict(vars(mod))
        exec(compile(source.replace(old, '[tool_spec(self.policy)]'), '<offline-flat-session>', 'exec'), namespace)
        session_class = namespace['CodexToolSession']
    runner = Runner()
    bridge = IsolatedExecutionBridge(runner, 'offline-only', {}, policy)
    try:
        with LocalModelRelay(CaptureGate(policy), synthetic) as relay:
            with session_class(executable, runtime['sha256'], home, relay, bridge, policy) as session:
                session.run(prompt)
        assert session.process.poll() == 0 and not runner.calls and len(captured) == 2
        # No auth headers/response prose are captured. Client-generated opaque
        # IDs and local home paths are replaced explicitly, recursively in text.
        native = captured['native']
        replacements = {str(home): '<DISPOSABLE_CODEX_HOME>', str(home).replace('\\', '/'): '<DISPOSABLE_CODEX_HOME>'}
        if isinstance(native.get('prompt_cache_key'), str):
            replacements[native['prompt_cache_key']] = '<CLIENT_PROMPT_CACHE_KEY>'
        if 'client_metadata' in native:
            # Preserve keys and value types; only export known static settings.
            native['client_metadata'] = {k: '<CLIENT_LOCAL_VALUE>' for k in native['client_metadata']}
        def sanitize(obj):
            if isinstance(obj, str):
                for key, replacement in replacements.items(): obj = obj.replace(key, replacement)
                return obj
            if isinstance(obj, list): return [sanitize(v) for v in obj]
            if isinstance(obj, dict):
                return {k: ('<CLIENT_MESSAGE_ID>' if k == 'id' else sanitize(v)) for k, v in obj.items()}
            return obj
        for kind, obj in captured.items(): save(label + '-' + kind + '.sanitized.json', sanitize(obj))
        return {'label': label, 'evidence_class': 'localhost reconstruction, NOT historical wire capture',
                'codex_sha256': runtime['sha256'], 'openai_requests': 0, 'oauth_reads': 0,
                'tool_calls': 0, 'requests_to_synthetic_peer': 1,
                'native_fields': sorted(native), 'postgate_fields': sorted(captured['postgate']),
                'reasoning': captured['postgate'].get('reasoning'), 'text': captured['postgate'].get('text'),
                'include': captured['postgate'].get('include'), 'home_removed': True,
                'limitations': ['Different disposable home; reconstruction time/environment may affect input',
                    'Legacy session uses current hardened config with historical flat dynamicTools'] if legacy else
                    ['Different disposable home; reconstruction time/environment may affect input']}
    finally:
        if home.exists():
            resolved = home.resolve()
            assert resolved.is_relative_to(home_root.resolve()) and resolved != home_root.resolve()
            assert not any(p.is_symlink() or getattr(p.lstat(), 'st_file_attributes', 0) & 0x400 for p in [home, *home.rglob('*')])
            shutil.rmtree(resolved)


def main():
    admission = json.loads((ROOT / 'docs/stage19d-evidence/fresh-admission.json').read_text())
    sources = json.loads((OUT / 'source-before.json').read_text())
    assert all(hashlib.sha256((ROOT / p).read_bytes()).hexdigest() == h for p, h in sources.items())
    proposal = json.loads((ROOT / 'docs/stage19-final-conformance-2-evidence/prepared-scope.json').read_text())['smoke']
    policy = ExecutionPolicy(InvocationBinding(proposal['execution_id'], 'implementer', 'STAGE19-SMOKE', 1, 'gpt-6-sol', 'low'),
        'implementation', hashlib.sha256(str(Path(admission['workspace']).resolve()).encode()).hexdigest(),
        time.monotonic()+45, max_requests=1, max_tool_calls=2, max_tool_seconds=20)
    prompt = (proposal['prompt_contract']+' Use exactly these complete argument objects, in order: '
        +json.dumps([expected_arguments(policy, proposal, i) for i in (0, 1)])
        +'. Do not combine the calls; wait for each successful tool result. After both succeed return ONLY '
        +json.dumps(proposal['structured_result']))
    records = [replay('conformance-2', admission['binding']['stage18c']['codex'], policy, prompt)]
    save('replay-provenance.json', records)
    old = json.loads((ROOT / 'docs/stage19b-full-response-evidence/result.json').read_text())
    task = json.loads((ROOT / 'docs/stage19b-capture-evidence/fresh-admission.json').read_text())['task']
    policy = ExecutionPolicy(InvocationBinding('stage19b-full-response-1', 'implementer', 'STAGE19-SMOKE', 1, 'gpt-6-astra', 'low'),
        'implementation', old['binding']['execution']['workspace_id'], time.monotonic()+45)
    runtime = old['binding']['transport']['stage18c']['codex']
    if Path(runtime['path']).is_file():
        records.append(replay('last-http200', runtime, policy, original_prompt(task), True))
    else:
        records.append({'label': 'last-http200', 'replay': 'Pinned binary unavailable',
                        'historical_exact_payload': 'UNKNOWN', 'openai_requests': 0})
    save('replay-provenance.json', records)
    print(json.dumps(records))


if __name__ == '__main__': main()
