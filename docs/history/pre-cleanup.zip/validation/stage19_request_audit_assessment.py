"""Read-only historical verification and separate offline assessment publication."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'docs/stage19-request-audit-evidence'


def load(path): return json.loads(path.read_text(encoding='utf-8'))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, value): path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')


def main():
    old = load(OUT/'historical-before.json')
    assert all((ROOT/name).is_file() and sha(ROOT/name)==h for name,h in old.items())
    sources = {p.relative_to(ROOT).as_posix():sha(p) for p in (ROOT/'agent_system').rglob('*.py')}
    bundle = hashlib.sha256(json.dumps(sources,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    previous = load(OUT/'source-before.json')
    changed = [name for name,h in sources.items() if previous.get(name)!=h]
    assert set(changed)=={'agent_system/model_tool_boundary.py','agent_system/responses_http.py'}
    xml = ET.parse(OUT/'tests.xml')
    suite = xml.getroot().find('testsuite')
    assert suite.get('tests')=='266' and suite.get('errors')=='0' and suite.get('failures')=='0'
    suite.attrib.pop('hostname',None)
    xml.write(OUT/'tests.xml',encoding='utf-8',xml_declaration=True)
    test_groups = dict(Counter(test.get('classname') for test in suite.findall('testcase')))
    temporary = ['offline-stage19-error-tests-1','offline-stage19-error-tests-2',
        'offline-stage19-error-tests-3','offline-stage19-error-tests-final','offline-stage19-request-audit']
    assert all(not (ROOT/name).exists() for name in temporary)
    integrity = {'historical_files_verified':len(old),'historical_changed':[],
        'production_changed':changed,'current_source_bundle_sha256':bundle,
        'stage19d_admission_matches_current_source':False,'source_after':sources,
        'tests':dict(suite.attrib),'owned_offline_temporary_directories_absent':True}
    save(OUT/'integrity-after.json',integrity)
    audit = load(OUT/'schema-audit.json')
    record = {'date':datetime.now(timezone.utc).isoformat(),
        'assessment_kind':'Offline request audit and HTTPError metadata repair; NOT live smoke',
        'verdict':'OFFLINE_AUDIT_COMPLETE_ROOT_CAUSE_UNCONFIRMED',
        'historical_execution':'stage19-final-conformance-2',
        'historical_execution_verdict':'FAIL_LIVE_TRANSPORT',
        'new_responses_requests':0,'new_oauth_requests':0,'new_model_catalog_requests':0,
        'credential_reads':0,'model_tool_calls':0,'docker_calls':0,
        'historical_exact_request_available':False,'historical_request_body_hash_available':False,
        'historical_exact_request_reconstructed':False,
        'historical_http_error_metadata_available':False,
        'local_reconstruction':load(OUT/'replay-provenance.json'),
        'field_audit_count':len(audit['schema_rows']),'field_audit_review_paths':audit['review_rows'],
        'comparison':audit['historical_comparison'],
        'minimum_candidate_delta':audit['smallest_source_guaranteed_candidate_delta'],
        'other_candidates':audit['other_candidates'],
        'confirmed_root_cause':None,'request_semantics_patch_applied':False,
        'safe_error_capture':{'implemented':True,'fields':['status','type','code','param','message_category'],
            'unknown_machine_identifiers':'unrecognized','unknown_param':None,
            'body_limit_bytes':16384,'overflow_probe_bytes':1,'seconds':2,'read_iterations':64,
            'raw_body_exported':False,'message_prose_exported':False,'request_ids_exported':False,
            'body_hash_exported':False,'retry_added':False,
            'future_driver_requirement':'Leave HTTPError open for centralized capture; no historical driver/latch reuse'},
        'production_changed':changed,'current_source_bundle_sha256':bundle,
        'fresh_signed_admission_required_before_live':True,
        'fresh_admission_performed':False,'new_live_authorization_issued':False,
        'human_billing_confirmation_or_timestamp_modified':False,
        'tests':{'passed':266,'failed':0,'errors':0,'skipped':0,'groups':test_groups,'full_default_suite_run':False},
        'historical_files_unchanged':len(old),'offline_temporary_directories_removed':True,
        'consumed_historical_latches_unchanged':True,
        'stage19_passed':False,'stage20_technically_admissible':False,'stage20_started':False,
        'evidence_sha256':{p.name:sha(p) for p in OUT.iterdir() if p.is_file()},
        'report':'STAGE19_HTTP400_REQUEST_AUDIT.md',
        'stop_state':'No inference, refresh, reconnect, catalog request, admission or additional execution authorized by this audit'}
    save(ROOT/'STAGE19_HTTP400_REQUEST_AUDIT.json',record)
    print(json.dumps({k:record[k] for k in ('verdict','new_responses_requests','field_audit_count',
        'historical_files_unchanged','current_source_bundle_sha256','stage19_passed','stage20_technically_admissible')}))


if __name__=='__main__': main()
