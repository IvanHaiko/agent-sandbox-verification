"""Opt-in synthetic cryptographic tests; requires the chatgpt-auth extra."""
import json
import time

import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa

from agent_system import chatgpt_oauth as auth
from agent_system.errors import AgentSystemError


@pytest.fixture(scope='module')
def keys():
    private = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    jwk = json.loads(jwt.algorithms.RSAAlgorithm.to_jwk(private.public_key()))
    jwk.update(kid='synthetic-key', use='sig', alg='RS256')
    return private, jwk


class Discovery:
    def __init__(self, jwk):
        self.jwk = jwk
    def request(self, method, url):
        assert method == 'GET'
        if url == auth.DISCOVERY:
            return {'issuer': auth.ISSUER, 'jwks_uri': auth.JWKS}
        assert url == auth.JWKS
        return {'keys': [self.jwk]}


@pytest.mark.parametrize('mutation', ['valid', 'signature', 'expired', 'nonce', 'audience',
                                    'issuer', 'kid', 'algorithm', 'missing_subject', 'multi_audience'])
def test_real_id_token_signature_and_oidc_claims(keys, mutation):
    private, jwk = keys
    claims = {'iss': auth.ISSUER, 'aud': 'oaiapp_synthetic', 'sub': 'synthetic-account',
              'exp': int(time.time()) + 300, 'nonce': 'synthetic-nonce'}
    headers = {'kid': 'synthetic-key'}
    if mutation == 'expired': claims['exp'] = int(time.time()) - 10
    if mutation == 'nonce': claims['nonce'] = 'wrong'
    if mutation == 'audience': claims['aud'] = 'wrong'
    if mutation == 'issuer': claims['iss'] = 'https://example.invalid'
    if mutation == 'missing_subject': claims.pop('sub')
    if mutation == 'multi_audience': claims['aud'] = ['oaiapp_synthetic', 'another-client']
    if mutation == 'kid': headers['kid'] = 'unknown'
    signer = rsa.generate_private_key(public_exponent=65537, key_size=2048) if mutation == 'signature' else private
    token = jwt.encode(claims, 'synthetic-hmac-key-at-least-32-bytes' if mutation == 'algorithm' else signer,
                       algorithm='HS256' if mutation == 'algorithm' else 'RS256', headers=headers)
    if mutation == 'valid':
        assert auth.verify_identity(token, 'oaiapp_synthetic', 'synthetic-nonce', Discovery(jwk))['sub'] == 'synthetic-account'
    else:
        with pytest.raises(AgentSystemError, match='verification failed') as error:
            auth.verify_identity(token, 'oaiapp_synthetic', 'synthetic-nonce', Discovery(jwk))
        assert token not in str(error.value) and token not in repr(error.value)
