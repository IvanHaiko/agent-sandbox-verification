"""Summarize the single Stage20 execution; performs no inference or project work."""
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from agent_system.storage import atomic_json
OUT=ROOT/'docs/stage20-evidence'

def load(name):
    p=OUT/(name+'.json')
    return json.loads(p.read_text()) if p.exists() else None

def main():
    a=load('assessment'); task=load('frozen-task'); prepared=load('prepared')
    roles=[]
    for role in a['roles']:
        usage=(role.get('usage') or {}).get('total')
        roles.append({k:role[k] for k in ('label','role','model','reasoning','completed','requests','tool_calls','seconds') if k in role}|{'usage':usage})
    grouped=[]
    for role_name in ('orchestrator','implementer','test_engineer','reviewer'):
        rows=[r for r in roles if r['role']==role_name]
        if rows:
            grouped.append({'role':role_name,'model':rows[0]['model'],'reasoning':rows[0]['reasoning'],
                'sessions':len(rows),'requests':sum(r['requests'] for r in rows),'tool_calls':sum(r['tool_calls'] for r in rows),
                'completed':all(r['completed'] for r in rows),
                'usage':{k:sum((r['usage'] or {}).get(k,0) for r in rows) for k in (rows[0]['usage'] or {})} if all(r['usage'] is not None for r in rows) else None})
    anomalies=sorted({n['anomaly_type'] for r in a['roles'] for meta in [*r.get('gate_observations',[]),*r.get('transport_observations',[]),r.get('session_observations',{})] for n in meta.get('anomalies',[])})
    contract=load('architect-result'); impl=load('implementer-result'); design=load('test-design-result'); testing=load('test-execution-result'); review=load('reviewer-result')
    own_tools=load('implementer-tools') or []
    own_cases=[json.loads(t['stdout'])['own_cases_passed'] for t in own_tools if t['action']==['check'] and t['returncode']==0]
    independence=load('test-freeze')
    context_result={'previous_conversations_shared':False,'test_design_candidate_visible':False if independence else None,
        'test_design_context_keys':sorted((load('test-design-context') or {}).get('bundle',{})),
        'design_frozen_before_candidate_exposure':bool(independence),
        'hidden_reasoning_shared':False,'unexpected_context_leakage_observed':False}
    summary={'stage':20,'task':task,'verdict':a['verdict'],'accepted':a['accepted'],
        'routing_resolution':'Account catalog listed gpt-6-astra and gpt-5.6-sol. gpt-6-sol was absent; available Sol High explicitly disclosed before inference.',
        'roles':grouped,'sessions':roles,'total_model_requests':sum(r['requests'] for r in roles),
        'total_model_tool_calls':sum(r['tool_calls'] for r in roles),'controller_checks':a['controller_checks'],
        'independent_tests':{'cases':len(design['cases']) if design else 0,'properties':design['properties'] if design else [],
            'passed':a.get('tests',{}).get('passed'), 'implementer_own_case_counts':own_cases,
            'caught_implementation_defects':False if a.get('tests',{}).get('passed') else None},
        'review':review,'role_isolation':context_result,'containment':a['containment'],
        'capability_violations':a['capability_violations'],'protocol_anomalies':anomalies,
        'accepted_commit':a.get('accepted_commit'),'project_path':prepared['project'],
        'changed_files':a.get('changed_files',[]),'fix_cycles':a['fix_cycles'],
        'driver_validation':{'checks_passed':7,'live_model_calls':0,'real_codex_docker_synthetic_roundtrip':True},
        'containment_admission':'Inherited signed Stage19 proofs after verification of identical engine, image, configuration, containment code and Codex; rebound only to fresh project. New task actions verified with real Codex/Docker synthetic roundtrip.',
        'workflow_expense':'The second Tester session mainly reports a deterministic test result; each fresh Codex session repeats instruction/schema overhead. Two Implementer inspections repeated data already in its prompt. The input_unchanged property adds little for immutable Python strings. Architect and Reviewer added boundary clarification and confirmation but found no implementation defect.',
        'stage21_recommendation':'Review this evidence first. Consider a single bounded task with a less obvious behavioral defect, retain independent test freezing, and let Controller execute frozen tests without a second Tester narration session. Do not benchmark or redesign transport based on this run.',
        'evidence_path':'docs/stage20-evidence/assessment.json'}
    if a.get('failure_reason'): summary['failure']={k:a[k] for k in ('failed_stage','failure_type','failure_reason')}
    cleanup=a.get('cleanup_observation') or {}
    summary['cleanup_observation']={k:cleanup[k] for k in ('initial_provisional_verdict','failure_cause','model_requests','tool_calls','disposable_role_storage_removed') if k in cleanup}
    summary['cleanup_observation']['readonly_files_repaired']=len(cleanup.get('permission_repairs',[]))
    summary['driver_validation']['cleanup_regression_passed']=True
    summary['driver_validation']['cleanup_test_setup_observation']='First post-run cleanup test setup could not access shared host pytest temp; rerun with an owned workspace basetemp passed. No workflow rerun.'
    summary['controller_cleanup_fix']='Readonly handling added only to the Stage20 disposal helper after execution; executed-driver.py preserves the actual live driver. No role was rerun.'
    atomic_json(ROOT/'STAGE20_FIRST_MULTI_AGENT_WORKFLOW.json',summary)
    rows=['| Role | Actual route | Sessions | Model requests | Tool calls | Complete |',
          '|---|---|---:|---:|---:|---|']
    for r in grouped:
        rows.append(f"| {r['role']} | {r['model']} / {r['reasoning']} | {r['sessions']} | {r['requests']} | {r['tool_calls']} | {r['completed']} |")
    checks=a.get('tests',{}).get('evidence',{})
    diff=(OUT/'final.diff').read_text() if (OUT/'final.diff').exists() else '(No candidate diff produced.)'
    sections=[f"# Stage20 — First real multi-agent workflow\n\n**{a['verdict']} — accepted: {str(a['accepted']).lower()}.**",
        '## Exact frozen task\n\nImplement `src/slugify.py` with `def slugify(value: str) -> str`. '+ ' '.join(task['acceptance_criteria']) + '\n\nStandard library only; pure function; ordinary ASCII strings are the supported domain. Unicode and non-string inputs are unspecified. Punctuation removal does not introduce a separator: `a_b` becomes `ab`. Tabs/newlines count as whitespace. The Controller committed this task and a `NotImplementedError` baseline before any role ran.',
        '## Actual routing and usage\n\n'+summary['routing_resolution']+'\n\n'+'\n'.join(rows)+
        f"\n\nTotal: {summary['total_model_requests']} model requests, {summary['total_model_tool_calls']} model-selected Docker actions, {summary['controller_checks']} additional Controller Docker interface check. Tester design and execution used separate fresh sessions. No shared model history or monetary estimate. Returned numeric usage is recorded in the companion JSON; detailed per-session observations are in `docs/stage20-evidence/role-counts.json`. Seven focused driver checks passed, including one synthetic-provider real Codex/Docker roundtrip; those consumed zero live model calls.",
        '## Explicit handoffs\n\n'+ '\n\n'.join([
            '**Architect → Implementer/Tester:** task ID, contract version 1, required signature, all five frozen acceptance criteria, sole allowed file `src/slugify.py`, constraints and five compact risks. The risks highlight underscore removal, whitespace coverage and cleanup order. [Contract]('+str((OUT/'architect-result.json').as_posix())+').',
            '**Implementer → Controller/Reviewer:** completed; sole changed file `src/slugify.py`; single-pass implementation; 12 passing self-check cases and diff inspection. [Implementation result]('+str((OUT/'implementer-result.json').as_posix())+').',
            '**Tester design → frozen cases:** 18 independently selected input/expected-output pairs plus idempotence, output shape and input unchanged. Cases include every ASCII punctuation character except hyphen, form feed/vertical tab, punctuation-created adjacent hyphens, and mixed whitespace/hyphen interactions. [Frozen design]('+str((OUT/'test-design-result.json').as_posix())+'); [freeze receipt]('+str((OUT/'test-freeze.json').as_posix())+').',
            '**Tester execution → Reviewer:** passed; one Docker acceptance action executed three unittest methods covering the 18 cases, interface and 54 property subchecks. No failures. [Execution handoff]('+str((OUT/'test-execution-result.json').as_posix())+').',
            '**Reviewer → Controller:** '+(review['recommendation'] if review else 'not reached')+'. '+(review['rationale'] if review else '')+' [Review handoff]('+str((OUT/'reviewer-result.json').as_posix())+').']),
        '## Tests and Controller acceptance\n\n'+f"Implementer successful self-check case counts: {own_cases}. Independent cases: {summary['independent_tests']['cases']}; properties: {summary['independent_tests']['properties']}. Independent acceptance passed: {summary['independent_tests']['passed']}. The Controller generated a small unittest harness directly from the frozen Tester cases/property choices, then exposed the candidate. Tests and candidate hashes stayed unchanged during execution. Required public signature and self-check results were verified. Final acceptance required passing independent tests, valid structured role results, the exact allowed mutation scope, Reviewer acceptance and containment cleanup. No repair cycle was used.\n\n```text\n"+checks.get('stdout','')+checks.get('stderr','')+'```',
        '## Isolation and containment\n\nEach invocation had a distinct execution identity, private ephemeral Codex home and fresh session. All four roles had separate isolated checkouts; Tester design and later execution shared only explicit frozen handoff artifacts. Tester design received exactly task and contract. The candidate was copied only after the design artifact was frozen. Reviewer received the compact evidence bundle and had no mutation action.\n\nModel-selected project operations ran exclusively through the admitted Docker runner: network none, bounded resources, readonly tests/inspection, fixed writer path. Unknown selectors, wrong identity and readonly escalation were blocked before dispatch. A host-process trap allowed only the existing Controller Git/Docker/Codex/ACL/cleanup utilities. Credentials remained Controller-owned.\n\n'+summary['containment_admission']+'\n\nContainment result: '+json.dumps(a['containment'])+'. All role/runtime storage was removed; the disposable repository and explicit evidence remain. Production `agent_system` Python source was unchanged.',
        '## Observations and usefulness\n\n'+
        '1. Architect produced a useful compact contract: it clarified underscore removal, punctuation deletion versus separator insertion, and whitespace/order risks.\n'+
        f"2. Implementer completed: {bool(impl and impl['outcome']=='completed')}; only the permitted utility changed.\n"+
        f"3. Tester independently designed {summary['independent_tests']['cases']} cases, including behavioral combinations, plus selected properties.\n"+
        '4. No missed implementation defect was caught in this run when the independent suite passed; broader coverage is evidence of usefulness, not proof of defect detection.\n'+
        '5. Reviewer checked contract/diff/evidence consistency and gave the recorded recommendation. It found no blocker in a passing run; its marginal value on this tiny utility is limited.\n'+
        '6. No forbidden context receipt was observed. Saved context manifests show exact handoff keys; complete conversations and hidden reasoning were never serialized as workflow state.\n'+
        '7. No model-selected action escaped its capability boundary.\n'+
        f"8. Final artifact accepted: {a['accepted']}, supported by the independent suite, interface check, scope and review. Unicode behavior remains outside this task.\n"+
        '9. Actual model/tool counts and available usage are above and in the JSON; there was no routing benchmark.\n'+
        '10. '+summary['workflow_expense']+'\n\nProtocol anomalies: '+', '.join(anomalies)+'. These were observed and continued without demonstrated project/security impact. No Stage19 MIME/SSE/OAuth/lifecycle implementation was changed. A pytest cache permission warning was non-blocking; all seven pre-run checks passed.\n\nController disposal initially failed on 12 readonly copied Git object files after the project and review had passed. The provisional assessment incorrectly classified this as a capability failure despite zero violations; it is preserved in `assessment-before-storage-cleanup.json`. Controller-only cleanup repaired those 12 copied-file attributes and completed disposal without any model/role rerun. This was a storage-cleanup issue. `cleanup-recovery.json` records the correction, and `executed-driver.py` preserves the original executed driver. Readonly handling and correct failure classification were then added only to the Stage20 helper. Its cleanup regression check passed using an owned workspace temp directory after the first test setup encountered a shared-host-temp permission error.',
        '## Final diff\n\n```diff\n'+diff+'```\n\nDisposable project: `'+prepared['project']+'`. Accepted commit: `'+str(a.get('accepted_commit'))+'`.',
        '## Stage21 recommendation\n\n'+summary['stage21_recommendation']+'\n\nStopped after this workflow and assessment. No OML, Data Auditor, benchmark, routing optimization, repeated experiment or generic action platform was started.'
    ]
    if a.get('failure_reason'): sections.insert(1,'Failure at '+a['failed_stage']+': '+a['failure_reason'])
    (ROOT/'STAGE20_FIRST_MULTI_AGENT_WORKFLOW.md').write_text('\n\n'.join(sections)+'\n',encoding='utf-8')
    print(json.dumps({'verdict':a['verdict'],'requests':summary['total_model_requests'],'tools':summary['total_model_tool_calls']}))

if __name__=='__main__': main()
