"""Read-only prerequisites for the user-requested next stage; no inference."""
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from agent_system.chatgpt_oauth import CredentialStore, PLAN_SCOPE
from agent_system.config import Configuration
from agent_system.runners.tool_docker import ToolDockerRunner
from agent_system.storage import atomic_json


def main():
    out = ROOT/'docs/stage21-evidence'
    out.mkdir(exist_ok=True)
    record = {'checked_at': time.time(), 'read_only_preflight': True, 'responses_posts': 0,
        'live_role_executions': 0, 'stage21_scope_selected': False}
    try:
        stage19 = json.loads((ROOT/'docs/stage19g-smoke-8-evidence/execution.json').read_text())
        assert stage19['stage19_passed'] and stage19['complete_end_to_end_path']
        record['stage19_passed'] = True
        record['stage19_proof_execution'] = stage19['execution_id']
        hashes = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((ROOT/'agent_system').rglob('*.py'))}
        bundle = hashlib.sha256(json.dumps(hashes, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        assert bundle == stage19['source_bundle_sha256']
        record['source_bundle_unchanged'] = True
        record['source_bundle_sha256'] = bundle
        admission = json.loads((ROOT/'docs/stage19g-smoke-8-evidence/fresh-admission.json').read_text())
        runner = ToolDockerRunner(Configuration.load(Path(admission['project'])))
        assert runner.preflight() == admission['binding']
        runner.require_transport_admission()
        record['current_codex_docker_engine_image_config_binding_verified'] = True
        record['existing_signed_transport_admission_verified'] = True
        record['stale_owned_containers'] = len(runner.stale_executions())
        assert record['stale_owned_containers'] == 0
        store = CredentialStore(Path('C:/Users/4ivan/.agentctl/stage19-oauth'), [ROOT])
        credentials, registration = store.read('credentials.json'), store.read('registration.json')
        record['credential_storage_permissions_verified'] = True
        record['credentials_valid'] = bool(credentials and registration
            and credentials.get('client_id') == registration.get('client_id')
            and PLAN_SCOPE in credentials.get('scopes', [])
            and credentials.get('expires_at', 0)-time.time() > 180
            and all(isinstance(credentials.get(k), str) and credentials[k]
                for k in ('access_token', 'refresh_token', 'id_token')))
        record['common_prerequisites_passed'] = record['credentials_valid']
    except Exception:
        record['common_prerequisites_passed'] = False
        record['failure'] = 'Current prerequisite verification failed; no inference attempted'
    atomic_json(out/'preflight.json', record)
    print(json.dumps(record))
    return 0 if record.get('common_prerequisites_passed') else 1


if __name__ == '__main__': raise SystemExit(main())
