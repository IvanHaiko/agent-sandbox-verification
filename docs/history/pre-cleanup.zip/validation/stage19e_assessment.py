"""Report the actual pre-inference stop; never dispatches any HTTP request."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'docs/stage19e-evidence'

def load(path): return json.loads(path.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    catalog = load(OUT/'catalog.json')
    admission = load(OUT/'fresh-admission.json')
    auth = load(OUT/'human-authorization.json')
    assert catalog['credentials_expired'] and not catalog['catalog_requests']
    assert catalog['responses_posts'] == 0
    sources = {p.relative_to(ROOT).as_posix():sha(p) for p in sorted((ROOT/'agent_system').rglob('*.py'))}
    assert sources == admission['source_sha256']
    bundle = hashlib.sha256(json.dumps(sources, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    assert bundle == admission['source_bundle_sha256']
    suites = ET.parse(OUT/'offline.xml').getroot().findall('testsuite')
    passed = sum(int(s.attrib['tests']) for s in suites)
    assert all(int(s.attrib['failures']) == int(s.attrib['errors']) == 0 for s in suites)
    variants = [('A_BASELINE', 'None; exact production baseline'),
                ('B_TYPED_CONST', 'Add explicit types to const-only function properties'),
                ('C_NO_MESSAGE_IDS', 'Remove input message IDs'),
                ('D_NON_STRICT_CONTROL', 'Disable explicit function strict mode; admission control only'),
                ('E_CATALOG_MODEL_CONTROL', 'Catalog-justified model/reasoning substitution only')]
    rows = [{'variant':name, 'single_changed_factor':factor, 'executed':False,
             'catalog_model':None, 'http_status':None, 'error_type':None, 'code':None,
             'param':None, 'category':None, 'sse_reached':False, 'tool_call_reached':False,
             'request_shape_fingerprint':None,
             'interpretation':'Not executed: expired OAuth precondition blocker'} for name,factor in variants]
    # No variant is consumed without a dispatch. Terminal matrix status prevents
    # this stopped run from being interpreted as an open automatic allowance.
    atomic = {'matrix_status':'STOPPED_PRECONDITION_BLOCKER', 'responses_posts_max':5,
              'responses_posts_consumed':0, 'consumed_variants':[], 'automatic_resume':False,
              'reason':'Expired current plan OAuth; catalog not queried; no inference authorized by admission'}
    (OUT/'consumed-attempts.json').write_text(json.dumps(atomic, indent=2)+'\n')
    report = {'stage':'19e', 'verdict':'DIAGNOSTIC_MATRIX_INCONCLUSIVE',
              'stop_condition':'Credential/admission blocker before inference',
              'human_confirmation':auth, 'catalog':catalog, 'variants':rows,
              'executed_variants':[], 'variants_not_needed':[],
              'variants_blocked':[n for n,_ in variants], 'structured_provider_diagnostics':[],
              'controlled_comparisons':[], 'root_cause_confirmed':False,
              'observed_facts':['Fresh real Docker/Codex admission passed',
                                'Protected credentials present with verified storage permissions',
                                'Current access token expired', 'Zero catalog GETs and zero Responses POSTs'],
              'inference':'No inference about the historical HTTP 400 cause is supported',
              'production_correction':None, 'production_source_unchanged':True,
              'source_bundle_sha256':bundle, 'previous_stage19d_admission_stale':True,
              'fresh_admission':{'passed':True, 'signed_transport_proof_verified':True,
                  'codex':admission['binding']['stage18c']['codex'],
                  'image':admission['binding']['image'], 'binding':admission['binding'],
                  'evidence':'docs/stage19e-evidence/fresh-admission.json'},
              'signed_no_credit_attestation_issued':False, 'signed_live_authorization_issued':False,
              'attestation_note':'Human confirmation recorded at actual local handling time. Execution/client-bound signed approvals not issued because current credential/catalog admission failed.',
              'offline_regression':{'passed':passed, 'failures':0, 'errors':0,
                  'after_correction':False, 'evidence':'docs/stage19e-evidence/offline.xml'},
              'fresh_admission_requirement':'Revalidate binding/source freshness after credentials are restored and before any POST; issue fresh execution/client-bound approvals after catalog confirmation.',
              'another_final_smoke_required':True, 'stage19_passed':False,
              'stage19_status':'FAIL_LIVE_TRANSPORT', 'stage20_technically_admissible':False,
              'stage20_started':False, 'responses_posts':0, 'automatic_retries':0,
              'model_tools_executed':0, 'oauth_refresh_attempts':0,
              'safe_persistence':'No provider bodies, prose, credentials, request IDs, account IDs or arbitrary headers persisted'}
    (ROOT/'STAGE19E_HTTP400_DIAGNOSTIC_MATRIX.json').write_text(json.dumps(report, indent=2)+'\n')
    when = datetime.fromtimestamp(catalog['checked_at'], timezone.utc).isoformat()
    lines = ['# Stage19e — Controlled HTTP 400 diagnostic matrix', '',
        '**DIAGNOSTIC_MATRIX_INCONCLUSIVE** — stopped before inference because the current ChatGPT-plan OAuth access token is expired.', '',
        'Zero Responses POSTs, zero account-catalog GETs, zero model tools, zero refresh/reconnect attempts. The five-POST ceiling was not consumed. No production correction is justified. Stage19 remains `FAIL_LIVE_TRANSPORT`; Stage20 is not admissible and was not started.', '',
        '## Observed preconditions', '',
        f'Fresh admission passed against production source bundle `{bundle}`. Real Codex dynamic-tool roundtrip, Docker isolation, network denial, secret filtering, adversarial tool rejection and cleanup were validated with a synthetic localhost model. Signed transport proof was verified. These synthetic probes are not Stage19 live smoke.', '',
        f"Current Codex: `{admission['binding']['stage18c']['codex']['path']}`; SHA256 `{admission['codex_sha256']}`. Docker image `{admission['binding']['image']}`. The evidence contains the current engine/config/project binding. The first sandboxed admission attempt failed on Docker context filesystem access; the permitted elevated admission then passed (1 test). Both records are retained.", '',
        f'Credential verification at {when} found protected credentials present, storage permissions verified, and the access token expired. No catalog request was sent with that token. Account-specific availability of `gpt-6-sol / low` and replacement candidates is UNKNOWN; no model was silently substituted.', '',
        'The human OFF billing confirmation was recorded with the actual local handling timestamp, explicitly not represented as the message send time. No fresh execution/client-bound live or no-credit signatures were issued because credential/catalog preconditions failed. No attestation timestamps were fabricated.', '',
        '## Comparison table', '',
        '| Variant | Single changed factor | Catalog model | HTTP status | Error type | Code | Param | Category | SSE reached | Tool call reached | Interpretation |',
        '|---|---|---|---:|---|---|---|---|---|---|---|']
    for name,factor in variants:
        lines.append(f'| {name} | {factor} (planned only) | UNKNOWN | — | — | — | — | — | No | No | Not executed: credential blocker |')
    lines += ['', 'All five variants are blocked, not classified as unnecessary. No request shape fingerprints exist because no diagnostic body was prepared or dispatched. No new provider HTTP error was observed; structured diagnostics and controlled comparisons are empty. The existing centralized bounded error capture remains unchanged.', '',
        '## Conclusion and next admission', '',
        'Observed fact: credentials expired. This is a current precondition blocker, **not the confirmed cause of the historical HTTP 400**. There is no A/B, A/C or A/D evidence. Const-only strict-schema and message-ID hypotheses remain unconfirmed. Production strict mode, const values, namespace and input remain unchanged.', '',
        f'Relevant offline regression: **{passed} passed**, zero failures/errors. No correction was applied, so these are precondition/regression checks rather than post-repair evidence. The fresh admission source manifest still matches production. Previous Stage19d admission remains stale and historical failures/latches were not rewritten.', '',
        'The stopped-run attempt ledger records zero consumed variants and disables automatic resume. Credential restoration, fresh account-specific catalog confirmation, binding/source revalidation, and fresh execution/client-bound no-credit/live approvals are required before resuming diagnosis. A final Stage19 smoke remains required; no live success was established here.', '',
        'The non-strict control, if later needed, is admission-only unless independent exact Controller enforcement permits safe execution. The documented distinction between explicit strict and fallback behavior is described in [OpenAI function calling](https://developers.openai.com/api/docs/guides/function-calling); documentation does not establish the cause of this account’s historical 400.', '',
        'Evidence: [fresh admission](docs/stage19e-evidence/fresh-admission.json), [credential/catalog status](docs/stage19e-evidence/catalog.json), [attempt ledger](docs/stage19e-evidence/consumed-attempts.json), [offline tests](docs/stage19e-evidence/offline.xml), [human confirmation](docs/stage19e-evidence/human-authorization.json).']
    (ROOT/'STAGE19E_HTTP400_DIAGNOSTIC_MATRIX.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')
    print(json.dumps({'verdict':report['verdict'], 'responses_posts':0, 'offline_passed':passed, 'source_bundle':bundle}))

if __name__ == '__main__': main()
