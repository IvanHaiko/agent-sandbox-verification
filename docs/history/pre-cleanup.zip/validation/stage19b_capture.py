"""One human-authorized quarantine request. Never a smoke or tool workflow.

Unknown body stays in the existing bounded observer. No raw body is exported.
Native request preparation is localhost-only and finishes before OAuth access.
"""
import ast
import hashlib
import json
from pathlib import Path
import shutil
import sys
import time
from urllib.error import HTTPError

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tests'))
sys.path.insert(0, str(ROOT / '.test-tmp/stage18-oauth-deps'))
from agent_system.agent_transport import InvocationBinding, strict_json
from agent_system.approvals import ApprovalStore
from agent_system.chatgpt_oauth import CredentialStore, ChatGPTPlanOAuth, AuthError, PLAN_SCOPE
from agent_system.codex_tool_session import CodexToolSession
from agent_system.config import Configuration
from agent_system.errors import AgentSystemError
from agent_system.model_tool_boundary import (ExecutionPolicy, ResponsesGate, LocalModelRelay,
    IsolatedExecutionBridge, PlanUpstream, SecretFilter, UPSTREAM)
import agent_system.model_tool_boundary as boundary
from agent_system.runners.tool_docker import ToolDockerRunner
from agent_system.storage import atomic_json
from agent_system.transport_diagnostics import QuarantineObserver, diagnostic_grant, safe_headers
from test_model_tool_boundary import Runner, message, sse

OUT = ROOT / 'docs/stage19b-capture-evidence'
EXECUTION = 'stage19b-diagnostic-1'


def load(path):
    return strict_json(path.read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def original_prompt(task):
    tree = ast.parse((ROOT / 'validation/stage19_run_live.py').read_text())
    assignment = next(n for n in ast.walk(tree) if isinstance(n, ast.Assign)
        and any(isinstance(t, ast.Name) and t.id == 'prompt' for t in n.targets))
    # Exact original prompt expression, trusted immutable local source only.
    return eval(compile(ast.Expression(assignment.value), '<historical-prompt>', 'eval'),
                {'json': json, 'task': task, '__builtins__': {}})


def prepare(policy, runtime, task, home):
    captured = []
    def synthetic(body):
        if captured: raise AgentSystemError('Offline preparation emitted another request')
        captured.append(json.dumps(body).encode())
        result = {'task_id': task['task_id'], 'contract_version': 1, 'outcome': 'completed',
                  'summary': 'Offline diagnostic request preparation', 'architecture_decision': None}
        return sse([message(json.dumps(result))])
    runner = Runner()
    bridge = IsolatedExecutionBridge(runner, 'offline-request-preparation', {}, policy)
    session = None
    try:
        with LocalModelRelay(ResponsesGate(policy), synthetic) as relay:
            with CodexToolSession(Path(runtime['path']), runtime['sha256'], home, relay, bridge, policy) as session:
                session.run(original_prompt(task))
        if len(captured) != 1 or runner.calls or session.process.poll() != 0:
            raise AgentSystemError('Offline single request preparation failed')
        return captured[0]
    finally:
        if session: session.close()
        # Exact owned disposable home, checked before recursive cleanup.
        if home.exists():
            resolved = home.resolve()
            if not resolved.is_relative_to((ROOT / '.test-tmp/stage19b-capture-native').resolve()):
                raise AgentSystemError('Native home cleanup outside owned root')
            if any(p.is_symlink() or getattr(p.lstat(), 'st_file_attributes', 0) & 0x400
                   for p in [home, *home.rglob('*')]):
                raise AgentSystemError('Native home cleanup links forbidden')
            shutil.rmtree(resolved)


class StopExpectedTransport(AgentSystemError):
    pass


class SingleRequestDelegate:
    """Bind frozen body and admission before the one underlying HTTP dispatch."""
    def __init__(self, opener, frozen_sha256, approve, persist_dispatch, secrets, observed):
        self.opener, self.frozen_sha256 = opener, frozen_sha256
        self.approve, self.persist_dispatch = approve, persist_dispatch
        self.secrets, self.observed, self.used = secrets, observed, False

    def open(self, request, **kwargs):
        if (self.used or request.full_url != UPSTREAM or request.get_method() != 'POST'
                or not isinstance(request.data, bytes)
                or hashlib.sha256(request.data).hexdigest() != self.frozen_sha256):
            raise AgentSystemError('Frozen single diagnostic request mismatch')
        self.approve()
        self.used = True
        self.persist_dispatch()  # irreversible latch BEFORE even a failed send
        try:
            response = self.opener.open(request, **kwargs)
        except HTTPError as error:
            self.observed['response_headers'] = safe_headers(error.headers, self.secrets)
            self.observed['http_status'] = error.code
            error.close()  # no error body capture or retry
            raise
        self.observed['http_status'] = response.status
        self.observed['response_headers'] = safe_headers(response.headers, self.secrets)
        if response.headers.get_content_type() == 'text/event-stream':
            response.close()  # no body forwarding or successful inference claim
            raise StopExpectedTransport('Expected MIME observed; diagnostic stopped')
        return response


def main():
    global OUT, EXECUTION
    if sys.argv[1:] == ['--second-authorized-diagnostic', '--credits-fallback-confirmed-off']:
        previous = load(OUT / 'capture.json')
        reconnected = load(OUT / 'reconnection.json')
        if previous['http_dispatch_attempts'] != 0 or reconnected.get('success') is not True:
            raise AgentSystemError('New diagnostic requires preserved blocked attempt and restored session')
        OUT = OUT / 'attempt-2'
        EXECUTION = 'stage19b-diagnostic-2'
    elif sys.argv[1:] != ['--one-authorized-diagnostic', '--credits-fallback-confirmed-off']:
        raise AgentSystemError('Explicit diagnostic and fresh no-credit confirmation required')
    OUT.mkdir(parents=True, exist_ok=True)
    latch = OUT / 'one-execution-latch'
    # Exclusive create; every invocation consumes this diagnostic, including failures.
    with latch.open('x', encoding='utf-8') as stream:
        stream.write('Authorized one diagnostic; no implicit retry\n')
    observed = {'execution_id': EXECUTION, 'verdict': 'BLOCKED_BEFORE_INFERENCE',
        'model': 'gpt-6-astra', 'reasoning': 'low', 'http_dispatch_attempts': 0,
        'responses_received': 0, 'tool_calls': 0, 'live_codex_session': False,
        'raw_body_persisted': False, 'accepted_as_inference': False,
        'stage19_verdict': 'FAIL_LIVE_TRANSPORT', 'stage20_started': False, 'refresh_attempts': 0}
    path = OUT / 'capture.json'
    atomic_json(path, observed)
    original_opener = boundary.build_opener
    observer = None
    try:
        immutable = load(ROOT / 'docs/stage19b-evidence/historical-hashes.json')
        for name, expected in immutable.items():
            if sha(ROOT / name) != expected: raise AgentSystemError('Historical evidence changed')
        accepted = load(ROOT / 'STAGE18C_MODEL_TOOL_BOUNDARY.json')
        for name, expected in accepted['source_sha256'].items():
            if sha(ROOT / name) != expected: raise AgentSystemError('Accepted source changed')
        admission_path = (OUT.parent if EXECUTION == 'stage19b-diagnostic-2' else OUT) / 'fresh-admission.json'
        admission = load(admission_path)
        observer_file = ROOT / 'agent_system/transport_diagnostics.py'
        if sha(observer_file) != admission['observer_sha256']:
            raise AgentSystemError('Fresh observer admission mismatch')
        runtime = admission['binding']['stage18c']['codex']
        previous_runtime = load(ROOT / 'docs/stage19-evidence/second-live-observations.json')['binding']['stage18c']['codex']
        if runtime != previous_runtime or sha(Path(runtime['path'])) != runtime['sha256']:
            raise AgentSystemError('Pinned diagnostic runtime changed')
        config = Configuration.load(Path(admission['project']))
        runner = ToolDockerRunner(config)
        def require_admission():
            if runner.preflight() != admission['binding'] or sha(observer_file) != admission['observer_sha256']:
                raise AgentSystemError('Diagnostic runtime admission changed')
            runner.require_transport_admission()
        require_admission()
        if runner.stale_executions(): raise AgentSystemError('Stale owned containers')
        workspace = Path(admission['workspace'])
        if (workspace / 'src/example.py').read_text() != 'value = 1\n':
            raise AgentSystemError('Owned workspace changed')
        policy = ExecutionPolicy(InvocationBinding(EXECUTION, 'implementer', admission['task']['task_id'], 1,
            'gpt-6-astra', 'low'), 'implementation', hashlib.sha256(str(workspace.resolve()).encode()).hexdigest(),
            time.monotonic() + 300, max_requests=1)
        frozen = prepare(policy, runtime, admission['task'], ROOT / '.test-tmp/stage19b-capture-native/home')
        body_hash = hashlib.sha256(frozen).hexdigest()
        observed.update(offline_native_preparation=True, request_sha256=body_hash,
            request_fields=sorted(strict_json(frozen.decode())),
            request_body_exported=False, pinned_runtime=runtime)
        observed['preflight_step'] = 'protected_credentials'
        atomic_json(path, observed)
        store = CredentialStore(Path('C:/Users/4ivan/.agentctl/stage19-oauth'),
                                [ROOT, Path(admission['project']), config.worktrees_dir])
        values = store.read('credentials.json')
        if values and values['expires_at'] - time.time() < 240:
            observed['refresh_attempts'] = 1
            atomic_json(path, observed)
            ChatGPTPlanOAuth(store).refresh()  # one necessary refresh; no blind retries
            values = store.read('credentials.json')
        if not values or PLAN_SCOPE not in values['scopes'] or values['expires_at'] - time.time() < 180:
            raise AgentSystemError('Unexpired SIWC credentials required')
        catalog = load(ROOT / 'docs/stage19-evidence/account-catalog.json')
        if hashlib.sha256(values['client_id'].encode()).hexdigest() != catalog['client_sha256']:
            raise AgentSystemError('Issued OAuth client changed')
        secrets = SecretFilter([values[k] for k in ('access_token', 'refresh_token', 'id_token')])
        secrets.reject(frozen.decode())
        entry_hash = sha(Path(__file__))
        proof_binding = {'fresh_transport': admission['binding'], 'observer': sha(observer_file),
            'entrypoint': entry_hash, 'request_sha256': body_hash, 'execution': policy.identity()}
        approvals = ApprovalStore(config.runtime_root / 'stage19b-diagnostic-approvals', proof_binding)
        approvals.issue('no-credits/' + EXECUTION, {'execution_id': EXECUTION, 'client_id': values['client_id'],
            'credits_fallback_disabled': True, 'operator': 'fresh explicit operator reply: off and remains off',
            'attested_at': time.time()})
        approvals.issue('live-smoke/' + EXECUTION, {'authorized': True, **policy.identity(),
            'model': policy.binding.model, 'reasoning': policy.binding.reasoning, 'route': UPSTREAM})
        approvals.issue('diagnostic/' + EXECUTION, diagnostic_grant(policy))
        frozen_grant = {'authorized': True, 'request_sha256': body_hash, 'http_requests_max': 1,
                        'entrypoint_sha256': entry_hash, 'no_live_codex_or_tools': True}
        approvals.issue('frozen-request/' + EXECUTION, frozen_grant)
        def approve_frozen():
            require_admission()
            if sha(Path(__file__)) != entry_hash: raise AgentSystemError('Diagnostic entrypoint changed')
            approvals.verify('frozen-request/' + EXECUTION, frozen_grant)
        observer = QuarantineObserver(policy, approvals, values['client_id'], secrets,
                                      approve_frozen, enabled=True)
        def dispatch():
            observed['http_dispatch_attempts'] = 1
            atomic_json(path, observed)
        def diagnostic_opener(*args):
            delegate = SingleRequestDelegate(original_opener(*args), body_hash, approve_frozen,
                                             dispatch, secrets, observed)
            return observer.wrap_opener(delegate)
        boundary.build_opener = diagnostic_opener
        observed.update(signed_live_authorization=True, signed_diagnostic_authorization=True,
            signed_frozen_request=True, signed_fresh_no_credits=True,
            approval_directory=str(approvals.directory), binding=proof_binding)
        atomic_json(path, observed)
        PlanUpstream(store, policy, approvals, require_admission)(strict_json(frozen.decode()))
        raise AgentSystemError('Unexpected diagnostic return')
    except StopExpectedTransport:
        observed['verdict'] = 'DIAGNOSTIC_EXPECTED_MIME_STOPPED'
    except AuthError as error:
        observed.update(verdict='BLOCKED_AUTH_BEFORE_INFERENCE', auth_error_code=error.code,
                        auth_http_status=error.status)
    except Exception as error:
        observed['verdict'] = 'DIAGNOSTIC_TRANSPORT_REJECTED' if observed['http_dispatch_attempts'] else 'BLOCKED_BEFORE_INFERENCE'
        observed['failure_category'] = type(error).__name__ if isinstance(error, (AgentSystemError, OSError)) else 'local_failure'
        # Never serialize arbitrary exception/provider text or traceback.
        literals = {node.value for source in (Path(__file__), ROOT / 'agent_system/transport_diagnostics.py',
            ROOT / 'agent_system/model_tool_boundary.py', ROOT / 'agent_system/codex_tool_session.py',
            ROOT / 'agent_system/chatgpt_oauth.py') for node in ast.walk(ast.parse(source.read_text()))
            if isinstance(node, ast.Constant) and isinstance(node.value, str)}
        if isinstance(error, AgentSystemError) and str(error) in literals:
            observed['safe_failure_reason'] = str(error)
    finally:
        boundary.build_opener = original_opener
        if observer and observer.evidence: observed['quarantine'] = observer.evidence
        observed['responses_received'] = int('http_status' in observed)
        observed['historical_hashes_unchanged'] = all(sha(ROOT / name) == expected
            for name, expected in load(ROOT / 'docs/stage19b-evidence/historical-hashes.json').items())
        atomic_json(path, observed)
    print(json.dumps(observed, ensure_ascii=False))
    return 0 if observed['responses_received'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
