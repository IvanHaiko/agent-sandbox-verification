"""Frozen Stage19c response algorithm for historical offline characterization only."""
import json
from agent_system.agent_transport import strict_json
from agent_system.errors import AgentSystemError
from agent_system.model_tool_boundary import ResponsesGate as CurrentGate, TOOL

class ResponsesGate(CurrentGate):
    def response(self, raw):
        self.alive()
        if len(raw) > self.policy.max_response_bytes:
            raise AgentSystemError('Model output overflow')
        try:
            text = raw.decode('utf-8').replace('\r\n', '\n')
        except UnicodeDecodeError:
            raise AgentSystemError('Invalid model output encoding') from None
        self.secrets.reject(text)
        if not text.endswith('\n\n'):
            raise AgentSystemError('Partial model SSE frame')
        completed, response_id, calls = (False, None, {})
        for frame in text.split('\n\n')[:-1]:
            if not frame:
                continue
            event, data = (None, [])
            for line in frame.split('\n'):
                if line.startswith('event: '):
                    event = line[7:]
                elif line.startswith('data: '):
                    data.append(line[6:])
                else:
                    raise AgentSystemError('Unsupported SSE framing')
            value = strict_json('\n'.join(data))
            self.secrets.reject(json.dumps(value))
            if not isinstance(value, dict) or value.get('type') not in self.EVENTS or completed or (event is not None and event != value['type']):
                raise AgentSystemError('Unknown or out-of-order model event')
            if 'item' in value:
                self._item(value['item'], calls)
            if value['type'] in ('response.created', 'response.in_progress', 'response.completed'):
                response = value.get('response', {})
                if not isinstance(response, dict) or not isinstance(response.get('id'), str):
                    raise AgentSystemError('Missing model response identity')
                if response_id is not None and response['id'] != response_id:
                    raise AgentSystemError('Model response identity mismatch')
                response_id = response['id']
                for item in response.get('output', []):
                    self._item(item, calls)
                if value['type'] == 'response.completed':
                    if response.get('status') != 'completed' or not isinstance(response.get('output'), list):
                        raise AgentSystemError('Unsuccessful or missing model completion')
                    final_calls = {}
                    for item in response['output']:
                        self._item(item, final_calls, final=True)
                    if set(calls) - set(final_calls):
                        raise AgentSystemError('Partial tool completion')
                    for call_id, name in final_calls.items():
                        if call_id in self.seen_calls:
                            raise AgentSystemError('Replayed model tool call')
                    self.seen_calls.update(final_calls)
                    completed = True
        if not completed:
            raise AgentSystemError('Missing model completion')
        return raw
    def _item(self, item, calls, final=False):
        if not isinstance(item, dict) or item.get('type') not in ('message', 'reasoning', 'function_call'):
            raise AgentSystemError('Unsupported model output item')
        if item['type'] == 'message':
            content = item.get('content')
            if item.get('role') != 'assistant' or not isinstance(content, list) or any((not isinstance(c, dict) or c.get('type') != 'output_text' or (not isinstance(c.get('text'), str)) for c in content)):
                raise AgentSystemError('Unsupported model message content')
        if item['type'] == 'function_call':
            if item.get('name') != TOOL or item.get('namespace') not in (None, 'functions'):
                raise AgentSystemError('Built-in or unknown model tool denied')
            cid = item.get('call_id')
            if not isinstance(cid, str) or not cid or (cid in calls and calls[cid] != TOOL):
                raise AgentSystemError('Malformed model tool identity')
            calls[cid] = TOOL
            if final:
                self.authorized_arguments[cid] = json.dumps(strict_json(item.get('arguments')), sort_keys=True)
