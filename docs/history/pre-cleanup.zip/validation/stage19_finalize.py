"""Finalize recorded executions offline; never calls OpenAI or starts a role."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'docs/stage19-evidence'
sys.path.insert(0, str(ROOT))
from agent_system.chatgpt_oauth import CredentialStore
from agent_system.config import Configuration
from agent_system.evidence import Evidence
from agent_system.git import git
from agent_system.model_tool_boundary import SecretFilter
from agent_system.runners.base import AgentResult
from agent_system.runners.tool_docker import ToolDockerRunner
from agent_system.storage import atomic_json
from agent_system.telemetry import finish_invocation


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def passed(path):
    suite = ET.parse(path).getroot()
    assert not any(list(suite.iter(t)) for t in ('failure', 'error', 'skipped'))
    return len(list(suite.iter('testcase')))


def main():
    attempts = [load(OUT / name) for name in ('live-observations.json', 'second-live-observations.json')]
    assert all(a['responses_requests'] == 1 and a['real_model_executions'] == 1 for a in attempts)
    assert all(a['verdict'] == 'FAIL_LIVE_TRANSPORT' and a['tool_calls'] == 0 for a in attempts)
    assert attempts[1]['provider_content_type'] == 'text/plain'
    assert attempts[1]['safe_relay_denials'] == ['Unexpected plan response content type']
    accepted = load(ROOT / 'STAGE18C_MODEL_TOOL_BOUNDARY.json')
    for name, expected in {**accepted['historical_sha256'], **accepted['source_sha256']}.items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected
    catalog, admission = load(OUT / 'account-catalog.json'), load(OUT / 'fresh-admission.json')
    post = load(OUT / 'post-second-live-security.json')
    assert all(post['isolation_capabilities'].values()) and post['real_model_calls'] == 0
    assert passed(OUT / 'final-focused.xml') == 150 and passed(OUT / 'post-second-live-security.xml') == 1
    config = Configuration.load(Path(admission['project']))
    runner = ToolDockerRunner(config)
    runner.require_transport_admission()
    assert not runner.stale_executions()
    assert (Path(admission['workspace']) / 'src/example.py').read_text() == 'value = 1\n'
    assert git(Path(admission['workspace']), 'status', '--porcelain', '--untracked-files=all') == ''
    assert (Path(admission['project']) / 'src/example.py').read_text() == 'value = 1\n'
    for index, a in enumerate(attempts):
        invocation = Path(a['invocation'])
        start = Evidence(invocation).read('telemetry_start')
        finish_path = OUT / ('live-observations.json' if index == 0 else 'second-live-observations.json')
        end = datetime.fromtimestamp(finish_path.stat().st_mtime, timezone.utc)
        begin = datetime.fromisoformat(start['started_at'])
        binding = {k: v for k, v in start.items() if k != 'started_at'}
        result = AgentResult(a['execution_id'], a['task_id'], 'implementer', 'execution_failed',
            a['model'], a['reasoning'], 0, None, 'Live transport rejected before any Docker tool call', [])
        atomic_json(invocation / 'result.json', result.to_dict())
        finish_invocation(invocation, binding, result.to_dict(), start['started_at'], end.isoformat(),
            max(0, (end - begin).total_seconds()), protocol_error='Live transport rejection', events_required=False)
        assert not (invocation / 'model-home').exists()
    executable = Path(admission['binding']['stage18c']['codex']['path'])
    assert hashlib.sha256(executable.read_bytes()).hexdigest() == admission['codex_sha256']
    version = subprocess.run([str(executable), '--version'], capture_output=True, text=True, timeout=10).stdout.strip()
    store = CredentialStore(Path('C:/Users/4ivan/.agentctl/stage19-oauth'), [ROOT])
    values = store.read('credentials.json')
    filter_ = SecretFilter([values[k] for k in ('access_token', 'refresh_token', 'id_token')])
    scanned = 0
    for folder in (OUT, ROOT / 'agent_system', ROOT / 'validation', Path(admission['workspace']), config.runs_dir / 'STAGE19-SMOKE'):
        for path in folder.rglob('*'):
            if path.is_file() and path.stat().st_size <= 4 * 1048576:
                filter_.reject(path.read_bytes().decode('utf-8', errors='replace'))
                scanned += 1
    report = load(OUT / 'before-live-assessment.json')
    report.update(verdict='FAIL_LIVE_TRANSPORT', oauth_connection_success=True,
        operator_authorized_scope='one initial execution plus one separately authorized second execution; no further live allowance',
        real_model_executions=2, real_responses_requests=2, real_model_calls=2,
        real_inference_requests_sent=True, real_inference_occurred=None,
        provider_inference_completion_proven=False, completed_model_executions=0,
        exact_model_used='gpt-6-astra', exact_reasoning_used='low',
        model_catalog_requests=1, entitlement_proven=True,
        entitlement_proof_scope='account-specific catalog listing; successful inference not proven',
        model_and_reasoning_acceptance='catalog supports requested pair; HTTP 200 received; no completed model response observed',
        dynamic_docker_tool_execution='NOT_REACHED', host_model_selected_execution=False,
        credential_escape_observed=False,
        credential_escape_verification={'known_current_credentials_absent_from_scanned_artifacts': True,
            'scanned_files': scanned, 'live_role_visibility_probe': 'NOT_REACHED'},
        disposable_task='NOT_COMPLETED; owned and source fixtures remain value = 1',
        live_target_admission={'fresh': True, 'binding': admission['binding'],
            'capabilities': admission['isolation_capabilities'], 'signed_transport_admission': True},
        completion_status='FAILED_BEFORE_TOOL_CALL', observed_live_response_events=[],
        provider_warnings={'codex_warning_counts': [a['runtime_warning_count'] for a in attempts],
            'warning_prose': 'discarded by unchanged session; no routing change'},
        provider_error_details={'http_statuses': [200, 200], 'second_content_type': 'text/plain',
            'denial': 'Unexpected plan response content type', 'second_body_bytes_read': 0,
            'body_format_or_error_cause': 'unknown; strict transport rejected body before reading'},
        cleanup={'codex_processes_exited': True, 'owned_containers_remaining': 0,
            'ephemeral_model_homes_removed': True, 'owned_checkout_clean': True,
            'persistent_credentials_only_in_protected_controller_store': True},
        usage={'input_tokens': None, 'output_tokens': None, 'total_tokens': None,
            'remaining_plan_usage': None, 'monetary_cost': None, 'provider_usage_received': False},
        runtime={'codex_version': version, 'codex_sha256': admission['codex_sha256']},
        executions=attempts,
        regression={'final_focused_passed': 150, 'post_second_live_docker_security_case_passed': 1,
            'fresh_os_capabilities_passed': 13, 'transport_checks_passed': 9,
            'failures': 0, 'errors': 0, 'skipped': 0, 'normal_tests_remain_offline': True},
        deviations=['second execution explicitly authorized after first failure; same task/model/reasoning',
            'pinned native Codex binary differs from Stage18c historical binary; fresh admission performed',
            'provider returned text/plain rather than transport-required text/event-stream',
            'initial diagnostics insufficient; second diagnostics identify MIME rejection',
            'failure telemetry finalized offline from existing start evidence and artifact timestamps'],
        stage20_technically_admissible=False, stage20_authorized=False, stage20_started=False,
        blockers=['response content-type/stream compatibility unresolved; no completed model/tool path'],
        next_step='offline transport review and bounded diagnostic design; any further live execution requires new explicit authorization')
    report['credits'].update(signed_no_credits_attestation_created=True,
        signed_live_smoke_authorization_created=True, billing_behavior_observed=False)
    report['evidence_sha256'] = {str(p.relative_to(ROOT)).replace('\\', '/'): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in (OUT / 'live-observations.json', OUT / 'second-live-observations.json',
                  OUT / 'fresh-admission.json', OUT / 'account-catalog.json', OUT / 'final-focused.xml',
                  OUT / 'post-second-live-security.json', OUT / 'post-second-live-security.xml')}
    filter_.reject(json.dumps(report))
    atomic_json(ROOT / 'STAGE19_AUTHORIZED_LIVE_SMOKE.json', report)
    report_md = """# Stage 19 — Authorized minimal live smoke

Date: 2026-10-05, Europe/Berlin. Final verdict: **FAIL_LIVE_TRANSPORT**.

OAuth is connected. Two separately authorized executions sent **two real Responses requests**, both receiving HTTP 200. Neither produced a completed gated response or a dynamic tool call. The second attempt established the denial: the provider returned **Content-Type: text/plain**, while the existing transport requires **text/event-stream**. It rejected the response before reading its body. No more live attempts were made; Stage 20 was not started.

[Machine-readable assessment](STAGE19_AUTHORIZED_LIVE_SMOKE.json) · [First execution](docs/stage19-evidence/live-observations.json) · [Separately authorized second execution](docs/stage19-evidence/second-live-observations.json).

## 1. OAuth connection

Real Sign in with ChatGPT connection succeeded after two initial failed OAuth attempts. The unchanged verifier checked RS256 signature, issuer/audience/time claims, subject, nonce and authorized party. Plan permission was obtained; protected Controller credentials are persisted with verified ACL. Account/client identity is represented by hashes in evidence. No refresh occurred during either execution. Earlier OAuth failures remain historical; their root cause is unestablished.

[OAuth observations](docs/stage19-evidence/oauth-reconnection.json). The existing public-client flow uses no API key. [Official sign-in contract](https://developers.openai.com/siwc/token-sharing-open-source/sign-in).

## 2. Inference observations

Two real inference requests were sent to the fixed `https://api.openai.com/v1/responses` route using Controller-owned OAuth. Both returned HTTP 200. Successful backend reasoning/completion is **unproven**: no completed model response was observed, and the second response body was deliberately not read after MIME rejection. HTTP 200 is not treated as evidence of a completed model execution.

## 3. Execution count and authorization

Two live role/session execution attempts, one Responses request each. The second followed the user's explicit “попробуй еще раз” instruction after the first failure. They used the same disposable task, model and reasoning, with separate execution IDs `c0-implementation-r0-t1` and `c0-implementation-r0-t2`. Each had exact signed live authorization and current signed no-credit attestation. No automatic retries, model changes, fix cycles or full permanent-role workflow ran.

## 4. Exact model/reasoning

Both requested **gpt-6-astra / low**. No fallback or rerouting occurred. One informational native Codex warning per attempt was counted; its prose is discarded by the existing session. The provider's completed-model identifier and actual reasoning behavior are unavailable.

## 5. Entitlement

One authenticated account-specific `/v1/models` request listed `gpt-6-astra` and its `low` reasoning option. Catalog entitlement is proven; successful inference acceptance remains unproven. [Catalog evidence](docs/stage19-evidence/account-catalog.json). The account catalog, not configured aliases or a cached native list, supplied this choice. [Official discovery/inference contract](https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference).

## 6. Dynamic Docker tool boundary

**Not reached live.** Both attempts had zero gated tool calls and zero bridge executions. No live model-selected shell/file action occurred. Fresh synthetic native Codex/Docker tests proved the routing and canonical call-ID/argument checks for the exact runtime binding, but are not relabeled as a successful live path.

## 7. Host execution

The host execution trap observed no model-selected host command. Trusted Git, Docker, native Codex and exact ACL/cleanup helpers were allowed. Roles retain `network none`; no generic proxy, host HOME/.codex mount, credential forwarding or host fallback was added. Stage 18c production sources remain hash-identical.

## 8. Credentials

Access/refresh/ID tokens remained in protected Controller storage and memory. Codex received only its ephemeral local channel credential. No credential escape was observed; known current token values were absent from the scoped scan of exported evidence, source files, owned checkout and invocation records. No raw body, stderr, JWT, token or provider error prose was exported. A real live-role token-visibility probe was not reached, so that live guarantee is not claimed from these failed attempts.

## 9. Disposable task

The disposable `STAGE19-SMOKE` repository supplies `src/example.py` with `value = 1`. The model was asked to inspect it, set the value to 2, verify with a standard-library Python assertion and return the existing strict implementation result. Both stopped before any tool. The source and owned checkout remain at value 1; owned Git status is clean. The task **did not complete**. The framework repository was not a model workspace.

## 10. Cleanup and telemetry

Both Codex processes exited; both ephemeral model-home directories were removed. No owned containers survived and no live role container was started. Persistent credentials are intentionally retained in the protected account store. Existing immutable start evidence was used to finalize failure AgentResult/telemetry offline; durations derive from start evidence and final-observation artifact timestamps. Usage is unavailable rather than fabricated. Original execution observations were preserved.

## 11. Usage

Observed: two executions attempted, two Responses requests, HTTP statuses `[200, 200]`, zero tool calls, zero completed model responses. No provider token/usage fields were received. Input/output/total tokens, remaining quota and monetary cost are **unknown**. No estimate or cost conversion is made; failed requests might still have affected plan usage.

## 12. Credits/billing

The operator explicitly confirmed the required app-credit-fallback setting disabled. Fresh client/execution-bound HMAC attestations and separate exact live authorizations were issued for both attempts. There was no API-key/paid-route fallback. Account-setting state is operator-attested, not programmatically controlled; actual quota/billing effects remain unknown. [Official account controls](https://learn.chatgpt.com/docs/sign-in-with-chatgpt).

## 13. Fresh admission and final security regression

Before the first request, **13 OS capabilities and 9 transport/security facts passed**, with signed admission for the exact disposable project, image, engine, source bundle and native binary. Actual native runtime was **codex-cli 0.160.0**, SHA256 `4b01d5920e6785614727443bbecf343f4dedbb7347052b72ba805aab6353ef01`. This differs from the historical 0.159.2 binary, so fresh admission was required and performed. The original Stage 18c checkpoint remains unchanged.

After the second request, **150 focused cases passed** and a comprehensive fresh real-Docker security case passed all 13 OS capabilities and 9 transport facts again. These tests use synthetic models, never a live account. They cover credential/path visibility, fixed endpoints, dispatch/host fallback, replay, role network, timeout/cancellation/overflow cleanup and secret rejection. No failures/errors/skips in final successful regression evidence.

[Live-target admission](docs/stage19-evidence/fresh-admission.json) · [Final focused tests](docs/stage19-evidence/final-focused.xml) · [Post-second Docker evidence](docs/stage19-evidence/post-second-live-security.json) · [JUnit](docs/stage19-evidence/post-second-live-security.xml).

## 14. Deviations and precise limitation

The provider response MIME type conflicts with the current transport's strict assumption. The exact body format and why it was labeled text/plain are **unknown**, since rejection occurred before reading. It might be a stream or a different response; neither is asserted. Official SIWC documentation requires a streaming response through completion, but this task did not establish that arbitrary text/plain bodies are safe compatible responses.

Initial live diagnostics were insufficient. The separately authorized second attempt added metadata-only diagnostics in the opt-in wrapper and identified the MIME rejection; no production verifier/gate was relaxed. The only extra live execution was explicitly authorized. Native runtime drift was handled through fresh admission. No full workflow or Stage 20 was started.

## 15. Verdict and next step

**FAIL_LIVE_TRANSPORT**. Stage 19 is evaluated but **not passed**; Stage 20 is **not technically admissible from this evidence**.

Next: offline review of MIME/stream compatibility and a bounded diagnostic design that retains strict SSE, identity, credential and tool validation. Do not simply allow text/plain or replay the requests. Any further live execution requires separate explicit authorization. A successful minimal smoke would still prove only the narrow path, not multi-agent correctness, performance, billing efficiency or framework v1 readiness.
"""
    filter_.reject(report_md)
    (ROOT / 'STAGE19_AUTHORIZED_LIVE_SMOKE.md').write_text(report_md, encoding='utf-8')
    print(json.dumps({'verdict': report['verdict'], 'executions': 2, 'responses_requests': 2,
                      'tool_calls': 0, 'focused_passed': 150, 'native_codex': version}))


if __name__ == '__main__':
    main()
