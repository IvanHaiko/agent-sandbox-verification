"""No auth traffic; strict second verification never accepts a time hint."""
import base64
import json
import pytest
from stage19_reconnect import bounded_time_decoder


class Immature(Exception): pass


def token(stamp):
    payload = base64.urlsafe_b64encode(json.dumps({'iat': stamp}).encode()).decode().rstrip('=')
    return 'header.' + payload + '.signature'


def test_small_skew_waits_then_uses_same_full_verifier():
    calls, sleeps, diagnostics = [], [], {}
    def decode(*args, **kwargs):
        calls.append((args, kwargs))
        if len(calls) == 1: raise Immature()
        return {'verified': True}
    verify = bounded_time_decoder(decode, Immature, diagnostics, now=lambda: 100, sleep=sleeps.append)
    assert verify(token(102), 'key', algorithms=['RS256'], leeway=0) == {'verified': True}
    assert calls[0] == calls[1] and sleeps == [2.05]


@pytest.mark.parametrize('stamp', [106, 99, True, '102'])
def test_invalid_or_large_time_hint_never_waits_or_accepts(stamp):
    sleeps = []
    def decode(*args, **kwargs): raise Immature()
    verify = bounded_time_decoder(decode, Immature, {}, now=lambda: 100, sleep=sleeps.append)
    with pytest.raises(Immature): verify(token(stamp))
    assert not sleeps


def test_wait_cannot_bypass_later_signature_or_claim_failure():
    calls = []
    def decode(*args, **kwargs):
        calls.append(1)
        if len(calls) == 1: raise Immature()
        raise ValueError('invalid audience or signature')
    verify = bounded_time_decoder(decode, Immature, {}, now=lambda: 100, sleep=lambda _: None)
    with pytest.raises(ValueError): verify(token(102))
    assert len(calls) == 2
