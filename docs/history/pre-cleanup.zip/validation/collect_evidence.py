"""Export signed real-probe evidence without exporting Controller signing keys."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

from agent_system.approvals import ApprovalStore
from agent_system.storage import atomic_json, read_json


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('runtime_tree', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    source = args.runtime_tree.resolve()
    args.output.mkdir(parents=True, exist_ok=True)
    records = []
    for path in sorted(source.rglob('probe-results.json')):
        report = read_json(path)
        if not report.get('admitted'):
            continue
        store = ApprovalStore(path.parent, report['binding'])
        store.verify('validation', report)
        case = path.relative_to(source).parts[0]
        destination = args.output / case
        destination.mkdir(parents=True, exist_ok=True)
        files = {'probe-results.json', 'validation.json'}
        for item in report['capabilities'].values():
            for filename, expected in item['evidence']:
                candidate = path.parent / filename
                if candidate.parent != path.parent or candidate.is_symlink():
                    raise RuntimeError('Unsafe probe evidence reference')
                if hashlib.sha256(candidate.read_bytes()).hexdigest() != expected:
                    raise RuntimeError('Probe evidence hash mismatch')
                files.add(filename)
        hashes = {}
        for filename in sorted(files):
            shutil.copyfile(path.parent / filename, destination / filename)
            hashes[filename] = hashlib.sha256((destination / filename).read_bytes()).hexdigest()
        records.append({'case': case, 'controller_signature_verified_before_export': True,
                        'binding': report['binding'], 'files': hashes,
                        'passed_capabilities': [name for name, item in report['capabilities'].items() if item['passed']]})
    atomic_json(args.output / 'manifest.json', {'version': 1, 'backend': 'docker_isolated',
                'key_exported': False, 'reports': records})
    print(json.dumps({'reports': len(records), 'key_exported': False, 'output': str(args.output.resolve())}))


if __name__ == '__main__':
    main()
