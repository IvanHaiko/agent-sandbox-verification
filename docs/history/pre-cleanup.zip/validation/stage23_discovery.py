"""Read the supported native model catalog without inspecting authentication."""
import json
from pathlib import Path
import queue
import shutil
import subprocess
import threading
import time

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'docs/stage23-evidence'


def discover():
    executable = shutil.which('codex')
    if not executable:
        raise RuntimeError('Native Codex executable unavailable')
    version = subprocess.run([executable, '--version'], capture_output=True,
                             text=True, timeout=20, check=True).stdout.strip()
    messages = queue.Queue()
    process = subprocess.Popen([executable, 'app-server', '--listen', 'stdio://'],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        text=True, encoding='utf-8')

    def read():
        for line in process.stdout:
            try:
                messages.put(json.loads(line))
            except ValueError:
                pass
        messages.put(None)

    reader = threading.Thread(target=read, daemon=True)
    reader.start()

    def send(value):
        process.stdin.write(json.dumps(value) + '\n')
        process.stdin.flush()

    def rpc(identifier, method, params):
        send({'id': identifier, 'method': method, 'params': params})
        deadline = time.monotonic() + 45
        while time.monotonic() < deadline:
            value = messages.get(timeout=max(.01, deadline - time.monotonic()))
            if value is None:
                raise RuntimeError('Native catalog process ended')
            if value.get('id') == identifier:
                if 'error' in value:
                    # Do not persist arbitrary provider messages or account data.
                    raise RuntimeError('Native catalog RPC failed: ' + str(value['error'].get('code')))
                return value['result']
        raise TimeoutError('Native catalog timeout')

    result = {'executable': executable, 'version': version,
              'mechanism': 'native app-server model/list', 'models': []}
    try:
        rpc(1, 'initialize', {'clientInfo': {'name': 'stage23_discovery',
            'version': '1.0.0'}, 'capabilities': {'experimentalApi': False}})
        send({'method': 'initialized'})
        cursor = None
        for index in range(20):
            params = {'limit': 100, 'includeHidden': True}
            if cursor:
                params['cursor'] = cursor
            page = rpc(index + 2, 'model/list', params)
            for entry in page['data']:
                result['models'].append({key: entry.get(key) for key in (
                    'id', 'model', 'displayName', 'hidden', 'defaultReasoningEffort',
                    'supportedReasoningEfforts', 'isDefault')})
            cursor = page.get('nextCursor')
            if not cursor:
                break
        else:
            raise RuntimeError('Native catalog pagination did not finish')
        result['gpt61_available'] = any(m['model'] == 'gpt-6.1-sol' for m in result['models'])
    except Exception as exc:
        result['failure'] = type(exc).__name__
        result['gpt61_available'] = False
    finally:
        process.stdin.close()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.terminate()
            process.wait(timeout=10)
        reader.join(timeout=2)
        result['discovery_process_exit_code'] = process.returncode
        result['discovery_process_stopped'] = process.poll() is not None
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'native-discovery.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))
    return result


if __name__ == '__main__':
    discover()
