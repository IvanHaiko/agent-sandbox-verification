"""Bounded account discovery only; no inference or credential refresh."""
import json
from pathlib import Path
import sys
import time
from urllib.request import Request, build_opener, ProxyHandler
from urllib.error import HTTPError

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from agent_system.chatgpt_oauth import CredentialStore, PLAN_SCOPE, NoRedirect
from agent_system.agent_transport import strict_json
from agent_system.model_tool_boundary import SecretFilter
from agent_system.storage import atomic_json

def main():
    out = ROOT/'docs/stage21-evidence'
    record = {'checked_at': time.time(), 'credentials_valid': False,
              'catalog_requests': 0, 'responses_posts': 0, 'refresh_attempts': 0,
              'models': [], 'catalog_success': False}
    try:
        store = CredentialStore(Path('C:/Users/4ivan/.agentctl/stage19-oauth'), [ROOT])
        value, registration = store.read('credentials.json'), store.read('registration.json')
        record['credential_storage_permissions_verified'] = True
        record['credentials_present'] = bool(value and registration)
        record['credentials_expired'] = bool(value and time.time() >= value['expires_at'])
        valid = (value and registration and PLAN_SCOPE in value.get('scopes', [])
                 and value['expires_at'] - time.time() > 180
                 and value.get('client_id') == registration.get('client_id')
                 and all(isinstance(value.get(k), str) and value[k]
                         for k in ('access_token', 'refresh_token', 'id_token')))
        record['credentials_valid'] = bool(valid)
        if not valid:
            record['blocker'] = 'Expired or invalid current ChatGPT-plan OAuth credentials'
            return
        filter_ = SecretFilter([value[k] for k in ('access_token', 'refresh_token', 'id_token')])
        request = Request('https://api.openai.com/v1/models', headers={'Authorization': 'Bearer '+value['access_token']})
        record['catalog_requests'] = 1
        with build_opener(ProxyHandler({}), NoRedirect()).open(request, timeout=15) as response:
            raw = response.read(1048577)
            if len(raw) > 1048576: raise ValueError()
        filter_.reject(raw.decode())
        catalog = strict_json(raw.decode())
        # Keep only the explicitly known public model names and finite effort levels.
        names = {'gpt-6-sol', 'gpt-6-astra', 'gpt-6.1-sol', 'gpt-6-luna',
                 'gpt-5.6-sol', 'gpt-5.6-terra', 'gpt-5.6-luna'}
        levels = {'none', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max', 'ultra'}
        for model in catalog['models']:
            if model.get('slug') not in names or model.get('visibility') != 'list': continue
            efforts = model.get('supported_reasoning_levels', [])
            efforts = [e.get('effort') if isinstance(e, dict) else e for e in efforts]
            record['models'].append({'model': model['slug'], 'reasoning': [e for e in efforts if e in levels]})
        record['catalog_success'] = True
    except HTTPError as error:
        record['catalog_http_status'] = error.code
        error.close()
        record['blocker'] = 'Account catalog request rejected'
    except Exception:
        record['blocker'] = 'Credential verification or account catalog failed'
    finally:
        atomic_json(out/'catalog.json', record)
        print(json.dumps(record))

if __name__ == '__main__': main()
