"""Separate SIWC checkpoint. Never overwrites earlier assessments."""
import contextlib
import hashlib
import io
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import pytest

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'docs/stage18-chatgpt-evidence'


class Collector:
    def pytest_collection_finish(self, session):
        self.nodes = {item.nodeid for item in session.items}


def passed_nodes(path):
    root = ET.parse(path).getroot()
    cases = list(root.iter('testcase'))
    assert not list(root.iter('failure')) and not list(root.iter('error')) and not list(root.iter('skipped'))
    return {case.get('classname').replace('.', '/') + '.py::' + case.get('name') for case in cases}


def main():
    collector = Collector()
    with contextlib.redirect_stdout(io.StringIO()):
        result = pytest.main(['tests', '--collect-only', '-q', '-p', 'no:cacheprovider'], plugins=[collector])
    assert result == 0
    baseline = passed_nodes(ROOT / 'docs/stage18-evidence/regression/full.xml')
    focused = passed_nodes(OUT / 'focused-final-pass.xml')
    crypto = passed_nodes(OUT / 'signatures-complete.xml')
    covered = baseline | focused
    assert covered == collector.nodes, sorted(collector.nodes - covered)
    previous = json.loads((ROOT / 'docs/STAGE16_17_ASSESSMENT.json').read_text(encoding='utf-8'))
    for name, expected in previous['preserved_artifact_hashes'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
    boundary_paths = ['runners/docker_isolated.py', 'isolation_probes.py', 'isolation.py',
                      'contexts.py', 'gates.py', 'mechanical_gates.py']
    boundary_hash = hashlib.sha256(b''.join((ROOT / 'agent_system' / name).read_bytes() for name in boundary_paths)).hexdigest()
    probe = json.loads(next((ROOT / 'docs/stage16-17-evidence/real-probes').rglob('validation.json')).read_text(encoding='utf-8'))
    assert boundary_hash == probe['record']['binding']['implementation']
    historical = [ROOT / 'docs' / (name + suffix) for name in
                  ('FRAMEWORK_V1_ACCEPTANCE', 'HARDENING_ASSESSMENT', 'STAGE16_17_ASSESSMENT')
                  for suffix in ('.md', '.json')]
    historical += [ROOT / 'MASTER_PROGRESS_ASSESSMENT.md', ROOT / 'MASTER_PROGRESS_ASSESSMENT.json',
                   ROOT / 'docs/STAGE18_CREDENTIAL_TRANSPORT.md']
    immutable = {str(p.relative_to(ROOT)).replace('\\', '/'): hashlib.sha256(p.read_bytes()).hexdigest()
                 for p in historical}
    report = {
        'version': 1, 'date': '2026-10-05', 'report_kind': 'separate_chatgpt_plan_checkpoint',
        'status': 'CHATGPT_PLAN_TRANSPORT_BLOCKED', 'stage18_status': 'PARTIAL_BLOCKED',
        'highest_completed_stage': 17,
        'current_authoritative_status': 'OS_ISOLATION_OFFLINE_VERIFIED_WITH_LIMITATIONS',
        'stage18_complete': False, 'stage19_technically_ready': False, 'next_stage_admitted': False,
        'framework_real_model_invocation_count': 0, 'real_oauth_login_performed': False,
        'real_tokens_acquired': False, 'new_live_evidence': [],
        'official_flow_applicable': True, 'ordinary_api_key_required': False,
        'documentation': {'retrieved_date': '2026-10-05', 'guides_version': None,
                          'cookbook_publication_date': '2026-09-28', 'local_codex_version': '0.159.2',
                          'references': ['https://developers.openai.com/siwc/quickstart',
                            'https://developers.openai.com/siwc/token-sharing-open-source',
                            *['https://developers.openai.com/siwc/token-sharing-open-source/' + name for name in
                              ('sign-in', 'token-reference', 'profiles-and-sessions', 'models-and-inference',
                               'codex-app-server', 'preview-limitations', 'errors-and-recovery', 'self-hosted-vms')],
                            'https://developers.openai.com/codex/app-server',
                            'https://learn.chatgpt.com/docs/sign-in-with-chatgpt']},
        'architecture': {'preferred': 'B: trusted OAuth + Codex semantics + Docker-only tools',
                         'selected_live_arrangement': None, 'A_direct_role_token_rejected': True,
                         'C_custom_agent_loop_built': False, 'broker_running': False},
        'implemented': ['Controller OAuth registration, PKCE/state/nonce, exact loopback listener',
                        'JWKS/OIDC validation, issued-client/account binding',
                        'external protected store, serialized rotating refresh, disconnect/revocation',
                        'non-launching model request policy and read-only Docker tool bridge prototype',
                        'fail-closed app-server approval policy; turn/start remains denied'],
        'not_implemented': ['authenticated model relay', 'app-server tool-routing integration',
                            'pinned Codex Linux runtime', 'fresh live transport/network/image admission',
                            'verified no-credits billing policy'],
        'focused_tests': {'passed': len(focused), 'failures': 0, 'errors': 0, 'skipped': 0,
                          'evidence': 'docs/stage18-chatgpt-evidence/focused-final-pass.xml'},
        'cryptographic_tests': {'passed': len(crypto), 'evidence': 'docs/stage18-chatgpt-evidence/signatures-complete.xml',
                                'runtime': {'PyJWT': '2.15.1', 'cryptography': '50.0.2'},
                                'keys': 'synthetic RSA', 'network_calls': 0},
        'regression': {'method': 'exact current node-ID union of recent full baseline and final focused rerun',
                       'baseline_passed': len(baseline), 'focused_passed': len(focused),
                       'current_default_collected': len(collector.nodes), 'covered_unique': len(covered),
                       'missing': [], 'failures': 0, 'errors': 0, 'skipped': 0,
                       'single_fresh_full_run': False, 'historical_real_docker_rerun': False},
        'admission': {'changed_active_runtime_binding': False, 'new_transport_admitted': False,
                      'unchanged_boundary_implementation_sha256': boundary_hash,
                      'historical_artifact_hashes_match': True,
                      'new_transport_probes': 'NOT_RUN: no live runtime/relay selected',
                      'historical_stage17_evidence_reused_for_live_admission': False,
                      'role_network': 'none (existing offline binding)',
                      'role_tokens': 'none supplied', 'host_home_or_codex_mount_added': False},
        'usage': {'remaining_plan_usage': None, 'model_entitlement': 'unverified',
                  'input_tokens': None, 'output_tokens': None, 'monetary_cost': None,
                  'credits_enabled_by_framework': False, 'credits_policy_verified': False,
                  'inference_enabled': False},
        'limitations': ['OAuth tested synthetically, not a user login or entitlement proof',
                        'protected plaintext file storage; same-user trusted host remains trusted',
                        'caller must provide every repository/role mount as a forbidden storage root',
                        'single issued client/account binding, no multi-account UI',
                        'earliest_refresh_at retained opaquely; automatic refresh scheduling not implemented',
                        'RS256 JWKS path is deliberately strict; unexpected issuer/key algorithms fail closed',
                        'request counts/deadlines are local policy, not a billing/remaining-quota guarantee',
                        'tool bridge tests use a runner double; no new kernel/network acceptance'],
        'historical_sha256': immutable,
        'next_required_work': ['prove supported Codex tool delegation into docker_isolated',
                               'implement authenticated bounded model-only relay without role bearer secrets',
                               'resolve authoritative no-credits control or verify required user setting',
                               'build pinned isolated runtime if needed and obtain fresh capability-bound probes',
                               'only then request separate Stage19 live-call authorization'],
    }
    OUT.mkdir(parents=True, exist_ok=True)
    (ROOT / 'STAGE18_CHATGPT_PLAN_TRANSPORT.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    (OUT / 'coverage.json').write_text(json.dumps({'current_default_nodes': sorted(collector.nodes),
        'baseline_nodes': sorted(baseline), 'focused_nodes': sorted(focused),
        'cryptographic_nodes': sorted(crypto), 'missing': []}, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': report['status'], 'focused': len(focused), 'crypto': len(crypto),
                      'current_default_covered': len(covered), 'model_calls': 0}))


if __name__ == '__main__':
    main()
