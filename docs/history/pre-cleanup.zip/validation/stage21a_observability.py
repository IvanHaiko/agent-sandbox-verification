"""Stage21A only: pinned Codex/Docker, deterministic localhost provider, zero inference."""
import hashlib
import json
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import time
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / 'tests')]
from agent_system.agent_transport import InvocationBinding
from agent_system.codex_tool_session import CodexToolSession
from agent_system.config import Configuration
from agent_system.errors import AgentSystemError
from agent_system.git import git
from agent_system.isolation import IsolatedCheckout
from agent_system.model_tool_boundary import (ExecutionPolicy, IsolatedExecutionBridge,
    LocalModelRelay, ResponsesGate, SecretFilter)
from agent_system.runners.docker_isolated import DockerIsolatedRunner, CLEANUP, regular_tree
from agent_system.runtime_observability import diagnostic_directory
from agent_system.storage import atomic_json
from test_model_tool_boundary import function, message, sse, tool_request

OUT = ROOT / 'docs/stage21a-evidence'
OWNED = ROOT / '.test-tmp/stage21a-offline'
SOURCE = b'def utility(value):\r\n    return value + 1\r\n'
WRITE = "from pathlib import Path; import sys; Path('src/utility.py').write_bytes(sys.stdin.buffer.read()); print('written')"
CHECK = "from src.utility import utility; assert utility(1)==2; print('check passed')"


def remove(path, parent):
    path, parent = path.resolve(), parent.resolve()
    assert path != parent and path.is_relative_to(parent) and not path.is_symlink()
    if not path.exists(): return
    regular_tree(path)
    def readonly(function, filename, exc):
        candidate = Path(filename)
        assert candidate.resolve().is_relative_to(path) and not candidate.is_symlink()
        if not isinstance(exc[1], PermissionError): raise exc[1]
        candidate.chmod(stat.S_IREAD | stat.S_IWRITE)
        function(filename)
    shutil.rmtree(path, onerror=readonly)


def run():
    import yaml
    assert not OWNED.exists(), 'Refuse to reuse Stage21A disposable storage'
    previous = json.loads((ROOT / 'docs/stage19g-smoke-8-evidence/fresh-admission.json').read_text())
    project = OWNED / 'project'
    shutil.copytree(Path(previous['project']) / '.agent_system', project / '.agent_system')
    settings_path = project / '.agent_system/project.yaml'
    settings = yaml.safe_load(settings_path.read_text())
    settings['runtime'] = {'version': 2, 'root': str(OWNED / 'runtime')}
    settings_path.write_text(yaml.safe_dump(settings))
    (project / 'src').mkdir(); (project / 'src/utility.py').write_text('def utility(value):\n    raise NotImplementedError\n')
    git(project, 'init', '--initial-branch=main')
    git(project, 'add', '.')
    git(project, '-c', 'user.name=Stage21A', '-c', 'user.email=stage21a@example.invalid', 'commit', '-m', 'Synthetic fixture')
    config = Configuration.load(project)
    docker = DockerIsolatedRunner(config)
    workspace = config.worktrees_dir / 'STAGE21A/implementer'
    IsolatedCheckout.create(project, workspace, git(project, 'rev-parse', 'HEAD'), config.runs_dir / 'STAGE21A/controller')
    task = {'task_id': 'STAGE21A', 'scope': {'allowed_paths': ['src/utility.py'], 'forbidden_paths': []},
            'workflow': {'test_paths': ['tests/**']}}
    policy = ExecutionPolicy(InvocationBinding('synthetic-failure-after-write', 'implementer', 'STAGE21A', 1,
        'gpt-6-luna', 'low'), 'implementation', 'fixture-owned', time.monotonic() + 120,
        max_tool_seconds=20)
    actions = []

    class BootstrapFixture:
        # Explicit test adapter to the existing private pre-admission probe path.
        # It never issues/promotes an isolation or live transport admission.
        backend = 'docker_isolated'
        def __init__(self): self.config = config
        def isolation_capabilities(self): return self
        def require(self): pass  # fixture admission only, never production evidence
        def run_tool(self, argv, root, metadata, role, phase, readonly, stdin, timeout):
            expected = ['python', '-c', WRITE if not readonly else CHECK]
            assert argv == expected and root == workspace and metadata == task
            assert (stdin == SOURCE.decode()) if not readonly else stdin == ''
            cp, directory, paths = docker._execute(expected, workspace, timeout,
                {**task, '_role': role, '_phase': phase}, readonly, stdin)
            cp.changed_paths = paths
            actions.append({'write': not readonly, 'returncode': cp.returncode, 'changed_paths': paths,
                'ownership': json.loads((directory / 'ownership.json').read_text())})
            return cp

    bridge = IsolatedExecutionBridge(BootstrapFixture(), workspace, task, policy, SecretFilter(['stage21a-secret-canary']))
    requests = []
    def upstream(body):
        requests.append({'model': body['model'], 'reasoning': body['reasoning']['effort']})
        index = len(requests)
        if index <= 2:
            request = {**tool_request(policy), 'argv': ['python', '-c', WRITE if index == 1 else CHECK],
                'stdin': SOURCE.decode() if index == 1 else '', 'read_only': index != 1, 'timeout_seconds': 20}
            call = function(policy, call_id='fixture-call-' + str(index)); call['id'] = 'fixture-function-' + str(index)
            call['arguments'] = json.dumps(request)
            return sse([call], response_id='fixture-response-' + str(index))
        # Entire provider response completes; final role schema still fails.
        return sse([message('{"answer":"schema-failure"}')], response_id='fixture-response-3')
    executable = Path(shutil.which('codex'))
    home = config.runtime_root / 'model-homes/fixture'
    session = None
    result = {'provider': 'synthetic-localhost-only', 'real_model_requests': 0, 'astra_calls': 0,
              'validation_route': 'gpt-6-luna', 'reasoning': 'low', 'workflow_status': 'failed', 'accepted': False,
              'docker_mode': 'existing private pre-admission bootstrap; no production admission issued'}
    result['source_sha256'] = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in [ROOT / 'agent_system' / name for name in ('codex_tool_session.py',
            'model_tool_boundary.py', 'runtime_observability.py')] + [Path(__file__)]}
    real_popen = subprocess.Popen
    processes = []
    def trapped(argv, *args, **kw):
        name = Path(argv[0]).name.lower()
        allowed = name in ('git', 'git.exe', 'docker', 'docker.exe')
        if name == 'codex.exe': allowed = Path(argv[0]).resolve() == executable.resolve() and argv[1:] == ['app-server', '--listen', 'stdio://']
        if name.startswith('python'): allowed = len(argv) == 6 and argv[1:4] == ['-I', '-c', CLEANUP]
        assert allowed, 'Untrusted host process attempted'
        processes.append(name)
        return real_popen(argv, *args, **kw)
    try:
        subprocess.Popen = trapped
        with LocalModelRelay(ResponsesGate(policy), upstream) as relay:
            session = CodexToolSession(executable, hashlib.sha256(executable.read_bytes()).hexdigest(), home,
                                      relay, bridge, policy)
            try:
                with session:
                    session.run('Offline deterministic fixture. No inference.', {'type': 'object',
                        'properties': {'answer': {'const': 'ok'}}, 'required': ['answer'], 'additionalProperties': False})
            except AgentSystemError:
                pass
            else:
                raise AssertionError('Failed role incorrectly completed')
        receipt = session.failure_receipt
        assert receipt['failure_category'] == 'handoff_schema_failure', receipt['failure_category']
        assert receipt['candidate_preserved'] and receipt['completed_tool_call_count'] == 2
        assert len(requests) == 3 and len(actions) == 2 and all(a['returncode'] == 0 for a in actions)
        directory = diagnostic_directory(bridge)
        item = receipt['candidates'][0]
        assert item['sha256'] == hashlib.sha256(SOURCE).hexdigest()
        assert (directory / item['archive_path']).read_bytes() == SOURCE
        result.update(receipt=receipt, original_candidate_path=str(workspace / item['path']),
            archived_diagnostic_path=str(OUT / 'diagnostic' / item['archive_path']),
            synthetic_requests=len(requests), docker_tool_actions=actions, host_execution_trap_passed=True,
            controller_host_process_names=sorted(set(processes)), codex_process_exited=session.process.poll() is not None)
        shutil.copytree(directory, OUT / 'diagnostic')
    finally:
        subprocess.Popen = real_popen
        bridge.close()
        if session: session.close()
        result['stale_owned_containers'] = len(docker.stale_executions())
        # The default diagnostic root survives removal of the whole runtime_root.
        remove(config.runtime_root, OWNED / 'runtime')
        directory = diagnostic_directory(bridge)
        result['diagnostic_survives_runtime_cleanup'] = (directory / 'failure_receipt.json').exists()
        if session and session.failure_receipt and session.failure_receipt['candidates']:
            item = session.failure_receipt['candidates'][0]
            assert (directory / item['archive_path']).read_bytes() == SOURCE
        result.update(model_homes_removed=not home.exists(), disposable_checkout_removed=not workspace.exists())
        # The exported receipt/candidate survives final validation-only project cleanup.
        remove(OWNED, ROOT / '.test-tmp')
        result['disposable_validation_project_removed'] = not OWNED.exists()
        atomic_json(OUT / 'offline-integration.json', result)
    assert result['stale_owned_containers'] == 0 and result['diagnostic_survives_runtime_cleanup']
    print(json.dumps({k: result[k] for k in ('workflow_status', 'accepted', 'real_model_requests',
        'synthetic_requests', 'stale_owned_containers', 'diagnostic_survives_runtime_cleanup')}))


if __name__ == '__main__':
    assert sys.argv[1:] == ['--offline-only']
    run()
