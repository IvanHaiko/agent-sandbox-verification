"""Finish disposable Windows Git storage cleanup; never runs a role or model."""
import json
from pathlib import Path
import shutil
import stat
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from agent_system.config import Configuration
from agent_system.runners.docker_isolated import regular_tree
from agent_system.storage import atomic_json

def main():
    out=ROOT/'docs/stage20-evidence'
    assessment=json.loads((out/'assessment.json').read_text())
    prepared=json.loads((out/'prepared.json').read_text())
    project=Path(prepared['project']).resolve()
    owned=(ROOT/'.test-tmp/stage20-workflow').resolve()
    assert project==owned/'project'
    config=Configuration.load(project)
    target=config.runtime_root.resolve()
    assert target.parent==owned/'runtime' and target!=owned and target.is_relative_to(owned)
    # Save the provisional assessment before any correction.
    if not (out/'assessment-before-storage-cleanup.json').exists():
        shutil.copyfile(out/'assessment.json',out/'assessment-before-storage-cleanup.json')
    regular_tree(target)
    readonly=[p for p in target.rglob('*') if p.is_file() and p.stat().st_file_attributes & 1]
    record={'initial_disposable_storage_cleanup_failed':True,'initial_provisional_verdict':assessment['verdict'],
        'retry_scope':'Controller storage disposal only; no model, project execution or code changes',
        'model_requests':0,'tool_calls':0,'readonly_files_remaining':len(readonly),'permission_repairs':[],
        'resolved_target':str(target),'checked_parent':str(owned/'runtime'),'completed_at':None}
    def clear_readonly(function,filename,exc_info):
        path=Path(filename).resolve()
        assert path.is_relative_to(target) and not Path(filename).is_symlink()
        if not isinstance(exc_info[1],PermissionError): raise exc_info[1]
        record['permission_repairs'].append(path.relative_to(target).as_posix())
        path.chmod(stat.S_IREAD|stat.S_IWRITE)
        function(filename)
    shutil.rmtree(target,onerror=clear_readonly)
    assert not target.exists()
    record.update(completed_at=time.time(),disposable_role_storage_removed=True,
        failure_cause='Readonly copied Git object files' if record['permission_repairs'] else 'Transient storage deletion failure')
    atomic_json(out/'cleanup-recovery.json',record)
    assessment['containment']['disposable_role_storage_removed']=True
    assessment['cleanup_observation']=record
    # No capability violation occurred. Finalize the already passing workflow.
    assert not assessment['capability_violations']
    assert all(r['completed'] and r['process_exited'] and not r.get('host_execution_attempt') for r in assessment['roles'])
    assert assessment['tests']['passed'] and assessment['review']['recommendation']=='accept'
    assert assessment['containment']['stale_owned_containers']==0
    assert all(assessment['containment'][k] for k in ('production_source_unchanged','credential_store_unchanged','model_homes_removed','docker_cleanup_confirmed'))
    assert (project/'src/slugify.py').read_bytes()==(out/'candidate/slugify.py').read_bytes()
    assessment['accepted']=True
    assessment['verdict']='PASS_MULTI_AGENT_WORKFLOW'
    atomic_json(out/'assessment.json',assessment)
    print(json.dumps({'verdict':assessment['verdict'],'cleanup':record['failure_cause'],
        'readonly_files_remaining_before_recovery':len(readonly),'permission_repairs':len(record['permission_repairs'])}))

if __name__=='__main__': main()
