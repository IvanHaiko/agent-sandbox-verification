"""Fresh real Docker/Codex admission, synthetic localhost model only; no workflow."""
import ast
import hashlib
import json
from pathlib import Path

import test_stage18c_real as measured
from agent_system.storage import atomic_json
from agent_system.git import git


def test_fresh_repaired_transport_admission(project, hardened, tmp_path, monkeypatch):
    hardened[0]['task_id'] = 'STAGE19-SMOKE'
    # Both supported cancellation paths have the same security meaning; one
    # starts with capital C. Match the existing fixed reason case-insensitively.
    source = Path(measured.__file__).read_text().replace("match='cancel'", "match='(?i)cancel'").replace("'gpt-5.4'", "'gpt-6-astra'")
    tree = ast.parse(source)
    function = next(n for n in tree.body if isinstance(n, ast.FunctionDef)
                    and n.name == 'test_fresh_stage18c_transport_and_adversarial_boundary')
    stop = next(i for i, n in enumerate(function.body)
                if isinstance(n, ast.Expr) and isinstance(n.value, ast.Call)
                and isinstance(n.value.func, ast.Name) and n.value.func.id == 'git')
    function.body = function.body[:stop] + [ast.Return(ast.Call(ast.Name('locals', ast.Load()), [], []))]
    function.decorator_list = []
    module = ast.fix_missing_locations(ast.Module(body=[function], type_ignores=[]))
    namespace = dict(measured.__dict__)
    exec(compile(module, measured.__file__, 'exec'), namespace)
    result = namespace[function.name](project, hardened, tmp_path, monkeypatch)
    result['bridge2'].close()
    runner, proof, workspace = result['runner'], result['proof'], result['workspace']
    runner.require_transport_admission()
    git(workspace, 'checkout', '--', 'src/example.py')
    assert (workspace/'src/example.py').read_text() == 'value = 1\n'
    assert not runner.stale_executions()
    root = Path(__file__).resolve().parents[1]
    files = sorted(p for p in (root/'agent_system').rglob('*.py'))
    hashes = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    bundle = hashlib.sha256(json.dumps(hashes, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    evidence = {**proof, 'signed_admission': True, 'binding': runner.preflight(),
        'source_bundle_sha256': bundle, 'source_sha256': hashes,
        'attestation_directory': str(result['store'].directory), 'project': str(project),
        'runtime': str(tmp_path/'runtime'), 'workspace': str(workspace), 'task': result['task'],
        'full_workflow_executed': False, 'workspace_reset_to_baseline': True,
        'real_oauth_used': False, 'live_authorization_issued': False,
        'source_of_probes': 'Existing Stage18c admission prefix; stopped before Controller workflow',
        'stage19_stage20_status_changed': False}
    atomic_json(root/'docs/stage19g-smoke-4-evidence/fresh-admission.json', evidence)
