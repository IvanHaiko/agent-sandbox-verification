"""Offline guards for the human-authorized driver; never invokes its live entry point."""
import copy
import json
from pathlib import Path
from types import SimpleNamespace

import pytest
from jsonschema import Draft202012Validator

from agent_system.errors import AgentSystemError
from agent_system.model_tool_boundary import IsolatedExecutionBridge
from stage19g_live_smoke_3 import (ExactBridge, ExactGate, expected_arguments,
    fixed_result_schema, consume_latch, baseline_matches, validate_authorization_receipt, EXECUTION, MODEL, ROOT)
from test_model_tool_boundary import function, sse, body, message
from test_stage19c_reconciliation import policy


def test_manifest_excludes_current_evidence_but_preserves_historical_files(tmp_path):
    from stage19g_live_smoke_3 import file_manifest, OUT
    evidence = tmp_path/'docs'/OUT.name
    historical = tmp_path/'docs'/'historical-evidence'
    evidence.mkdir(parents=True)
    historical.mkdir()
    (evidence/'execution.json').write_text('current changing telemetry')
    (historical/'execution.json').write_text('immutable historical telemetry')
    manifest = file_manifest(tmp_path)
    assert list(manifest) == ['docs/historical-evidence/execution.json']


@pytest.fixture
def proposal():
    return json.loads((ROOT/'docs/stage19g-smoke-3-evidence/prepared-smoke.json').read_text(encoding='utf-8'))['smoke']


def test_strict_result(proposal):
    schema = fixed_result_schema(proposal)
    validator = Draft202012Validator(schema)
    assert validator.is_valid(proposal['structured_result'])
    assert not validator.is_valid({**proposal['structured_result'], 'extra': 'provider prose'})
    assert not validator.is_valid({**proposal['structured_result'], 'summary': 'something else'})


def test_exact_prepared_python_commands_compile_before_inference(proposal):
    for step in ('mutation', 'verification'):
        argv = proposal[step]['argv']
        assert argv[:2] == ['python', '-c']
        compile(argv[2], '<prepared-smoke>', 'exec')
        assert '\n' not in argv[2]  # Literal LF inside a quoted Python string is invalid.


@pytest.mark.parametrize('data,expected', [(b'value = 1\n', True), (b'value = 1\r\n', True),
    (b'value = 2\n', False), (b'value = 1', False), (b'value = 1\n\n', False),
    (b'value = 1\n# extra\n', False)])
def test_baseline_is_identical_to_mutation_template_text_semantics(tmp_path, data, expected):
    path = tmp_path/'example.py'; path.write_bytes(data)
    assert baseline_matches(path) is expected
    assert baseline_matches(path) == (path.read_text() == 'value = 1\n')


def receipt(at):
    return {'execution_id': EXECUTION, 'task_id': 'STAGE19-SMOKE', 'model': MODEL, 'reasoning': 'low',
        'human_billing_confirmation_at': at, 'credits_fallback_disabled': True, 'one_execution': True,
        'no_retry': True, 'authorized': True, 'proposal_sha256': 'proposal-hash'}


def test_confirmation_timestamp_is_used_unchanged():
    value = receipt(100.0)
    assert validate_authorization_receipt(value, 'proposal-hash', 'scope-hash', 200) == 100.0
    assert value['human_billing_confirmation_at'] == 100.0


@pytest.mark.parametrize('attack', ['old_confirmation', 'future_confirmation', 'missing_confirmation',
    'prior_execution', 'wrong_model', 'wrong_scope', 'credits_enabled'])
def test_requires_new_exact_human_receipt(attack):
    value = receipt(100.0); now = 200
    if attack == 'old_confirmation': now = 100000
    elif attack == 'future_confirmation': value['human_billing_confirmation_at'] = 300
    elif attack == 'missing_confirmation': value.pop('human_billing_confirmation_at')
    elif attack == 'prior_execution': value['execution_id'] = 'stage19-final-conformance-1'
    elif attack == 'wrong_model': value['model'] = 'gpt-6-sol'
    elif attack == 'wrong_scope': value['proposal_sha256'] = 'other'
    elif attack == 'credits_enabled': value['credits_fallback_disabled'] = False
    with pytest.raises(AgentSystemError): validate_authorization_receipt(value, 'proposal-hash', 'scope-hash', now)


def test_exclusive_latch_cannot_be_reused(tmp_path):
    path = tmp_path/'latch'
    consume_latch(path)
    before = path.read_bytes()
    with pytest.raises(FileExistsError): consume_latch(path)
    assert path.read_bytes() == before


@pytest.mark.parametrize('step', [0, 1, 2])
def test_valid_response_exact_order_and_no_final_tools(proposal, step):
    p = policy(); gate = ExactGate(p, proposal=proposal, bridge=SimpleNamespace(successful=step), observed={})
    gate.requests = step+1
    if step < 2:
        item = function(p); item['arguments'] = json.dumps(expected_arguments(p, proposal, step))
    else: item = message(json.dumps(proposal['structured_result']))
    assert gate.response(sse([item]))
    assert gate.last_response_metadata['smoke_scope_passed']
    assert len(gate.authorized_arguments) == (1 if step < 2 else 0)


@pytest.mark.parametrize('attack', ['unexpected_argv', 'wrong_step', 'multiple_calls', 'missing_tool', 'tool_in_final', 'previous_tool_not_successful'])
def test_scope_rejection_is_atomic_and_cannot_dispatch(proposal, attack):
    p = policy(); observed = {}; bridge = SimpleNamespace(successful=0)
    gate = ExactGate(p, proposal=proposal, bridge=bridge, observed=observed); gate.requests = 1
    item = function(p); item['arguments'] = json.dumps(expected_arguments(p, proposal, 0))
    items = [item]
    if attack == 'unexpected_argv':
        args = expected_arguments(p, proposal, 0); args['argv'] = ['python', '-c', 'print("unexpected")']; item['arguments'] = json.dumps(args)
    elif attack == 'wrong_step': item['arguments'] = json.dumps(expected_arguments(p, proposal, 1))
    elif attack == 'multiple_calls':
        second = copy.deepcopy(item); second.update(id='fc-second', call_id='call-second'); items.append(second)
    elif attack == 'missing_tool': items = [message()]
    elif attack == 'tool_in_final': gate.requests = 3; bridge.successful = 2
    elif attack == 'previous_tool_not_successful': gate.requests = 2
    original = gate.authorized_arguments
    with pytest.raises(AgentSystemError): gate.response(sse(items))
    assert gate.authorized_arguments is original and not gate.seen_calls and not gate.seen_items and not gate.seen_responses
    assert observed['tool_boundary_failure'] and gate.last_response_metadata['smoke_scope_passed'] is False


def test_parallel_calls_are_disabled_in_actual_provider_request(proposal):
    p = policy(); gate = ExactGate(p, proposal=proposal, bridge=SimpleNamespace(successful=0), observed={})
    request = body(p); request['parallel_tool_calls'] = True
    assert gate.request(json.dumps(request).encode())['parallel_tool_calls'] is False


def test_actual_requests_require_two_sequential_tools_then_final_result(proposal):
    p = policy(); bridge = SimpleNamespace(successful=0)
    gate = ExactGate(p, proposal=proposal, bridge=bridge, observed={})
    for step, choice in enumerate(('required', 'required', 'none')):
        bridge.successful = step
        raw = body(p)
        raw['tool_choice'] = 'auto'  # Codex/default preference cannot override the smoke contract.
        request = gate.request(json.dumps(raw).encode())
        assert request['tool_choice'] == choice
        assert request['parallel_tool_calls'] is False
        assert len(request['tools']) == 1 and request['tools'][0]['name'] == 'agentctl'
        tools = request['tools'][0]['tools']
        assert len(tools) == 1 and tools[0]['name'] == 'agentctl_execute'


def test_next_request_cannot_be_sent_before_successful_tool_result(proposal):
    p = policy(); bridge = SimpleNamespace(successful=0)
    gate = ExactGate(p, proposal=proposal, bridge=bridge, observed={})
    gate.request(json.dumps(body(p)).encode())
    with pytest.raises(AgentSystemError, match='Smoke request/tool order mismatch'):
        gate.request(json.dumps(body(p)).encode())
    assert gate.requests == 1


@pytest.mark.parametrize('attack', ['argv', 'read_only', 'timeout', 'output', 'identity', 'third_call', 'previous_failure'])
def test_bridge_denies_deviation_before_underlying_execute(proposal, attack, monkeypatch):
    p = policy(); reached = []
    monkeypatch.setattr(IsolatedExecutionBridge, 'execute', lambda *args: reached.append(True))
    runner = SimpleNamespace(backend='docker_isolated', run_tool=lambda: None)
    bridge = ExactBridge(runner, 'fixture', {}, p, proposal=proposal, observed={})
    args = expected_arguments(p, proposal, 0)
    if attack == 'argv': args['argv'] = ['python', '-c', 'print("unexpected")']
    elif attack == 'read_only': args['read_only'] = True
    elif attack == 'timeout': args['timeout_seconds'] = 19
    elif attack == 'output': args['output_bytes'] = 1024
    elif attack == 'identity': args['execution_id'] = 'other'
    elif attack == 'third_call': bridge.calls = bridge.successful = 2
    elif attack == 'previous_failure': bridge.calls = 1
    with pytest.raises(AgentSystemError): bridge.execute(args)
    assert not reached and bridge.observed['tool_boundary_failure']


def test_bridge_exact_outputs_and_sequential_success(proposal, monkeypatch):
    p = policy()
    def fake_execute(self, args):
        step = self.calls; self.calls += 1
        return {'returncode': 0, 'stdout': ['stage19-mutated\n', 'stage19-verified\n'][step], 'stderr': ''}
    monkeypatch.setattr(IsolatedExecutionBridge, 'execute', fake_execute)
    bridge = ExactBridge(SimpleNamespace(backend='docker_isolated', run_tool=lambda: None), 'fixture', {}, p,
                         proposal=proposal, observed={})
    for step in (0, 1): bridge.execute(expected_arguments(p, proposal, step))
    assert bridge.successful == bridge.calls == 2 and all(c['stdout_exact'] for c in bridge.checks)


@pytest.mark.parametrize('result', [{'returncode': 1, 'stdout': '', 'stderr': ''},
                                  {'returncode': 0, 'stdout': 'unexpected', 'stderr': ''},
                                  {'returncode': 0, 'stdout': 'stage19-mutated\n', 'stderr': 'unexpected'}])
def test_output_deviation_stops_and_is_not_success(proposal, result, monkeypatch):
    p = policy()
    def fake_execute(self, args): self.calls += 1; return result
    monkeypatch.setattr(IsolatedExecutionBridge, 'execute', fake_execute)
    bridge = ExactBridge(SimpleNamespace(backend='docker_isolated', run_tool=lambda: None), 'fixture', {}, p,
                         proposal=proposal, observed={})
    with pytest.raises(AgentSystemError): bridge.execute(expected_arguments(p, proposal, 0))
    assert bridge.successful == 0
    with pytest.raises(AgentSystemError): bridge.execute(expected_arguments(p, proposal, 1))
    assert bridge.calls == 1
