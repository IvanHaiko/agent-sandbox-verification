"""Supplementary synthetic late-timeout recovery through real Codex and Docker.

Reuses a naturally generated candidate and already frozen independent design;
this is not an additional independent live trial or an observed network outage.
"""
import json
from pathlib import Path
import time
from types import SimpleNamespace

import pytest

import stage22_workflow as v
from test_model_tool_boundary import function, sse
from agent_system.artifact_execution import implementation_handoff


def test_real_write_late_timeout_handoff_and_frozen_acceptance():
    s=v.s
    s.OUT=v.OUT/'synthetic-recovery'
    s.OWNED=v.OWNED/'synthetic-recovery'
    s.OUT.mkdir(parents=True)
    v.prepare()
    prepared=s.load(s.OUT/'prepared.json')
    config=s.Configuration.load(Path(prepared['project']))
    runner=s.ToolDockerRunner(config); runner.require_transport_admission()
    workspace=Path(prepared['manifest']['worktrees']['implementer']['path'])
    tester=Path(prepared['manifest']['worktrees']['tester']['path'])
    baseline={'hashes':s.file_map(workspace),'source':(workspace/s.TASK['file']).read_text()}
    # No implementation defect is injected. Preserve the first natural write.
    source=(v.OUT/'p1-t1/candidate/unaccepted.py').read_text()
    task={**s.TASK,'scope':{'allowed_paths':[s.TASK['file']],'forbidden_paths':[]},
        'workflow':{'test_paths':['tests/test_acceptance.py']}}
    policy=s.ExecutionPolicy(s.InvocationBinding('stage22-synthetic-recovery','implementer',s.TASK_ID,1,v.MODEL,v.EFFORT),
        'implementation','synthetic-recovery-owned',time.monotonic()+120,max_requests=1,max_tool_calls=1,output_bytes=65536)
    actions=s.Actions(policy,['write']); bridge=s.ActionBridge(runner,workspace,task,policy,s.SecretFilter(),actions=actions)
    gate=s.ActionGate(policy,actions=actions)
    request={**policy.identity(),'tool_type':'argv','argv':['write',s.TASK['file']],
        'stdin':source,'read_only':False,'timeout_seconds':20,'output_bytes':65536}
    requests=[]
    def provider(body):
        requests.append(body)
        call=function(policy); call['arguments']=json.dumps(request)
        return sse([call])
    class LateTimeout(v.ArtifactSession):
        def run_until_written(self,prompt):
            super().run_until_written(prompt)
            self.runtime_failure={'category':'socket_idle_timeout','detail':'socket_idle_timeout'}
            raise s.AgentSystemError('Synthetic late timeout; no real network failure')
    exe=prepared['binding']['stage18c']['codex']; home=config.runtime_root/'synthetic-home'
    observed={}; receipt=None
    try:
        with s.host_trap(observed,exe['path']):
            with s.LocalModelRelay(gate,provider) as relay:
                session=LateTimeout(Path(exe['path']),exe['sha256'],home,relay,bridge,policy,
                    diagnostic_directory=s.OUT/'diagnostics/implementer')
                with pytest.raises(s.AgentSystemError,match='Synthetic late timeout'):
                    with session: session.run_until_written('Synthetic Controller boundary test.')
                receipt=session.failure_receipt
        assert receipt['failure_category']=='socket_idle_timeout'
        assert receipt['candidate_archived'] and session.process.poll() is not None
        assert len(requests)==1 and bridge.calls==1 and not session.tool_result_returned
        s.remove_owned(home,config.runtime_root)
        def interface(data):
            cp=runner.run_tool(['python','-c',s.CHECK],workspace,task,'implementer','implementation',True,'[]',20)
            assert cp.returncode==0
            return s.strict_json(cp.stdout.strip())
        handoff=implementation_handoff(workspace,baseline,s.TASK['file'],s.OUT/'candidate/unaccepted.py',
            successful_write_paths=bridge.successful_write_paths,failure_category=receipt['failure_category'],
            security_violation=False,shutdown_confirmed=session.process.poll() is not None,interface_check=interface)
        assert handoff['execution_status']=='abnormal_recoverable' and not handoff['accepted']
        s.save('implementer-result',handoff)
        live=v.OUT/'scoped-p1-t1'
        design=s.load(live/'test-design-result.json')
        s.save('test-design-result',design)
        (tester/'tests').mkdir(); (tester/'tests/__init__.py').write_text('')
        (tester/'tests/test_acceptance.py').write_text(s.acceptance_source(design),encoding='utf-8')
        s.save('test-freeze',{'design_sha256':s.sha(s.OUT/'test-design-result.json'),
            'harness_sha256':s.sha(tester/'tests/test_acceptance.py'),
            'frozen_at':time.time(),'candidate_visible_during_design':False,
            'reused_independent_live_design':str(live/'test-design-result.json')})
        import shutil
        shutil.copyfile(workspace/s.TASK['file'],tester/s.TASK['file'])
        w=SimpleNamespace(runner=runner,task=task,prepared=prepared,admission=runner.require_transport_admission)
        acceptance=s.controller_execute(w,tester,design,workspace/s.TASK['file'],0)
        assert acceptance['result']['passed']
        records=[s.load(p) for p in runner.root.glob('executions/*/ownership.json')]
        assert not runner.stale_executions()
        assert all(r.get('cleanup')=='confirmed' and r.get('storage_cleanup')=='confirmed' for r in records)
        s.save('docker-ownership-receipts',records)
        s.save('result',{'synthetic_failure':True,'real_codex':True,'real_docker':True,
            'live_model_requests':0,'synthetic_requests':len(requests),'model_selected_tools':bridge.calls,
            'execution_status':handoff['execution_status'],'frozen_suite_passed':True,
            'candidate_sha256':s.sha(workspace/s.TASK['file']),'accepted_live_artifact':False,
            'failure_receipt':receipt,'process_exited':True,'model_home_removed':True,
            'stale_owned_containers':0})
    finally:
        bridge.close()
        s.remove_owned(s.OWNED,v.OWNED)
