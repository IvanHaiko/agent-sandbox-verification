"""Offline, explicitly partial documentation profile; not an API validator.

No HTTP calls. Unknown server behavior stays REVIEW, never presumed rejection.
"""
import copy
import json
from pathlib import Path
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'docs/stage19-request-audit-evidence'
SIWC = 'https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations'
CREATE = 'https://developers.openai.com/api/reference/typescript/resources/responses/methods/create'
SDK = 'https://github.com/openai/openai-python/blob/main/src/openai/types/'
FUNCTIONS = 'https://developers.openai.com/api/docs/guides/function-calling'
STRUCTURED = 'https://developers.openai.com/api/docs/guides/structured-outputs'


def audit(body, native):
    rows = []
    def check(path, passed, detail, source=CREATE):
        rows.append({'path': path, 'verdict': 'MATCH' if passed else 'REVIEW', 'detail': detail, 'source': source})
    allowed = {'model','input','instructions','store','stream','tools','tool_choice','parallel_tool_calls','text','reasoning','include'}
    check('$', not set(body)-allowed, 'Gate allowlist; no forbidden SIWC top-level parameters', SIWC)
    check('model', body.get('model') == 'gpt-6-sol', 'Exact user model amendment; account entitlement cannot be checked offline')
    check('store', body.get('store') is False, 'HTTP plan requirement', SIWC)
    check('stream', body.get('stream') is True, 'HTTP plan requirement', SIWC)
    check('instructions', 'instructions' not in body, 'Absent; developer messages provide instructions', SIWC)
    check('previous_response_id', 'previous_response_id' not in body, 'Omitted; HTTP continuation forbidden', SIWC)
    check('tool_choice', body.get('tool_choice') == 'auto', 'Documented automatic function selection', FUNCTIONS)
    check('parallel_tool_calls', body.get('parallel_tool_calls') is False, 'Explicit sequential smoke override; boolean schema', FUNCTIONS)
    reasoning = body.get('reasoning', {})
    check('reasoning', set(reasoning) == {'effort','context'}, 'Only documented effort/context members', SDK+'shared_params/reasoning.py')
    check('reasoning.effort', reasoning.get('effort') == 'low', 'Exact effort binding; documented enum value', SDK+'shared_params/reasoning.py')
    check('reasoning.context', reasoning.get('context') in ('auto','current_turn','all_turns'), 'all_turns is documented, also measured in old 0.160 replay', SDK+'shared_params/reasoning.py')
    check('text', body.get('text') == {'verbosity':'low'}, 'Documented verbosity; format omitted/default text; no provider output JSON schema', SDK+'responses/response_text_config_param.py')
    check('include', body.get('include') == ['reasoning.encrypted_content'], 'Documented stateless reasoning include; no encrypted content is present in this first request', SDK+'responses/response_create_params.py')
    check('input', isinstance(body.get('input'),list), 'Full HTTP context array; no system, audio/video or hosted tool item', SIWC)
    for i, item in enumerate(body.get('input', [])):
        path = f'input[{i}]'
        check(path+'.type', item.get('type') == 'message', 'Only message after removing additional_tools')
        check(path+'.role', item.get('role') in ('developer','user'), 'Developer/user accepted by SIWC', SIWC)
        check(path+'.content', isinstance(item.get('content'),list) and all(set(c)=={'type','text'} and c['type']=='input_text' and isinstance(c['text'],str) for c in item['content']), 'Text content list, input_text/string')
        extras = set(item)-{'type','role','content','status'}
        check(path+'.extra_fields', not extras, 'Client id is present; SDK Message/EasyInputMessage do not declare id. Server acceptance is UNKNOWN, not proven invalid.', SDK+'responses/response_input_param.py')
    tools = body.get('tools', [])
    check('tools', len(tools)==1 and tools[0].get('type')=='namespace', 'One namespace; no hosted tools/tool_search', SIWC)
    ns = tools[0]
    check('tools[0]', set(ns)=={'type','name','description','tools'} and ns['name']=='agentctl' and isinstance(ns['description'],str) and len(ns['tools'])==1, 'Exact documented namespace shape', SDK+'responses/namespace_tool_param.py')
    fn = ns['tools'][0]
    check('tools[0].tools[0]', set(fn)=={'type','name','description','strict','parameters'} and fn['type']=='function' and fn['name']=='agentctl_execute', 'Nested function fields match; no async/defer_loading/allowed_callers/output_schema')
    check('tools[0].tools[0].strict', fn.get('strict') is True, 'Explicit strict=true is source-guaranteed new versus old omitted strict. Omission may fall back; explicit true forces compatibility.', FUNCTIONS)
    schema = fn['parameters']
    Draft202012Validator.check_schema(schema)
    check('tools[0].tools[0].parameters', True, 'Generic Draft202012 schema is valid; this does NOT prove provider strict-subset acceptance', STRUCTURED)
    check('parameters.required/additionalProperties', set(schema['required'])==set(schema['properties']) and schema['additionalProperties'] is False, 'Documented strict object requirements met', FUNCTIONS)
    for name, prop in schema['properties'].items():
        check('parameters.properties.'+name, 'type' in prop,
              'Explicit type missing; const-only schema valid in generic JSON Schema, provider strict-subset compatibility unproven' if 'type' not in prop else 'Explicit supported JSON type; bounds retained. No blanket fine-tuned restriction applied to this model.', STRUCTURED)
    check('client_metadata', 'client_metadata' not in body and 'client_metadata' in native, 'Codex-added client-local metadata stripped before upstream')
    check('prompt_cache_key', 'prompt_cache_key' not in body and 'prompt_cache_key' in native, 'Codex-added key stripped before upstream')
    check('input.additional_tools', not any(i.get('type')=='additional_tools' for i in body['input']), 'Codex inventory removed; provider inventory exclusively gate-authored', SIWC)
    return rows


def candidates(body):
    typed = copy.deepcopy(body)
    operations = []
    for name, prop in typed['tools'][0]['tools'][0]['parameters']['properties'].items():
        if 'const' in prop and 'type' not in prop:
            prop['type'] = 'integer' if type(prop['const']) is int else 'string'
            operations.append({'op':'add','path':'/tools/0/tools/0/parameters/properties/'+name+'/type','value':prop['type']})
    # These are proposals only, never used by production/replayed to a model.
    return typed, operations


def main():
    body = json.loads((OUT/'conformance-2-postgate.sanitized.json').read_text())
    native = json.loads((OUT/'conformance-2-native.sanitized.json').read_text())
    rows = audit(body, native)
    typed, operations = candidates(body)
    old = json.loads((ROOT/'docs/stage19b-full-response-evidence/result.json').read_text())
    result = {'evidence_class':'Documentation profile on sanitized LOCAL REPLAY; not historical payload or provider validation',
              'openai_requests':0, 'schema_rows':rows,
              'review_rows':[r['path'] for r in rows if r['verdict']=='REVIEW'],
              'historical_comparison':{'last_http200_execution':old['execution_id'], 'status':200,
                  'historical_request_sha256':old['request_sha256'], 'exact_body_available':False,
                  'known_deltas':['gpt-6-astra -> gpt-6-sol','flat function -> namespace/function',
                      'strict omitted -> true','all additional_tools inputs removed',
                      'parallel_tool_calls forced false (old exact value UNKNOWN)',
                      'max timeout 30 -> 20; execution/workspace/prompt changed'],
                  'optional_old_values':'UNKNOWN for exact HTTP200; old synthetic replay confirms reasoning.context all_turns only'},
              'smallest_source_guaranteed_candidate_delta':{'path':'tools[0].tools[0].strict', 'old':'omitted', 'new':True,
                  'explanation':'Potential strict-subset rejection of seven unchanged const-only schemas; server cause UNKNOWN',
                  'production_change_applied':False},
              'other_candidates':['Current Codex emits input message id not declared in SDK input-message schemas; historical presence UNKNOWN',
                  'Different model entitlement/route support UNKNOWN offline'],
              'typed_const_candidate_patch':operations,
              'const_keyword_support':'Not explicitly established by consulted strict-subset docs; typed singleton enum is an alternative documented encoding',
              'future_attempt_requires_new_admission':True}
    for name, value in [('schema-audit.json',result), ('candidate-typed-const.sanitized.json',typed)]:
        (OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'schema_rows':len(rows), 'review_rows':result['review_rows'], 'openai_requests':0}))


if __name__ == '__main__': main()
