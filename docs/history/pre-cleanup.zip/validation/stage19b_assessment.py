"""Offline-only separate assessment; never writes Stage18c/19 evidence."""
import contextlib
import hashlib
import io
import json
from pathlib import Path
import sys
import time
import xml.etree.ElementTree as ET

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from agent_system.agent_transport import InvocationBinding
from agent_system.model_tool_boundary import ExecutionPolicy, ResponsesGate, tool_spec, UPSTREAM
from agent_system import transport_diagnostics as d

OUT = ROOT / 'docs/stage19b-evidence'


def load(name):
    return json.loads((ROOT / name).read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def passed_nodes(name):
    root = ET.parse(ROOT / name).getroot()
    assert not any(list(root.iter(tag)) for tag in ('failure', 'error', 'skipped')), name
    return {case.get('classname').replace('.', '/') + '.py::' + case.get('name')
            for case in root.iter('testcase')}


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


class Collector:
    def pytest_collection_finish(self, session):
        self.nodes = {item.nodeid for item in session.items}


def main():
    historical = load('docs/stage19b-evidence/historical-hashes.json')
    for name, expected in historical.items():
        assert sha(ROOT / name) == expected, name
    accepted = load('STAGE18C_MODEL_TOOL_BOUNDARY.json')
    for name, expected in accepted['source_sha256'].items():
        assert sha(ROOT / name) == expected, name
    stage19 = load('STAGE19_AUTHORIZED_LIVE_SMOKE.json')
    assert stage19['verdict'] == 'FAIL_LIVE_TRANSPORT' and stage19['real_responses_requests'] == 2
    second = load('docs/stage19-evidence/second-live-observations.json')
    assert second['provider_content_type'] == 'text/plain' and second['upstream_read_bytes'] == 0
    docker_sources = ['runners/docker_isolated.py', 'isolation_probes.py', 'isolation.py',
                      'contexts.py', 'gates.py', 'mechanical_gates.py']
    docker_hash = hashlib.sha256(b''.join((ROOT / 'agent_system' / p).read_bytes()
                                        for p in docker_sources)).hexdigest()
    assert docker_hash == second['binding']['implementation']
    transport_sources = ['runners/tool_docker.py', 'model_tool_boundary.py', 'codex_tool_session.py',
                         'runners/chatgpt_plan.py', 'chatgpt_oauth.py', 'agent_transport.py']
    transport_hash = hashlib.sha256(b''.join((ROOT / 'agent_system' / p).read_bytes()
                                           for p in transport_sources)).hexdigest()
    assert transport_hash == second['binding']['stage18c']['implementation']
    binding = second['binding']['stage18c']['codex']
    assert sha(Path(binding['path'])) == binding['sha256']
    collector = Collector()
    with contextlib.redirect_stdout(io.StringIO()):
        rc = pytest.main(['tests', '--collect-only', '-q', '-p', 'no:cacheprovider'], plugins=[collector])
    assert rc == 0
    baseline = passed_nodes('docs/stage18-evidence/regression/full.xml')
    earlier = passed_nodes('docs/stage18-chatgpt-evidence/focused-final-pass.xml')
    focused = passed_nodes('docs/stage19b-evidence/final.xml')
    covered = baseline | earlier | focused
    assert collector.nodes <= covered, sorted(collector.nodes - covered)
    assert len(focused) == 190
    diagnostic = {v for v in focused if v.startswith('tests/test_transport_diagnostics.py::')}
    assert len(diagnostic) == 40
    workspace_id = hashlib.sha256(second['workspace'].encode()).hexdigest()
    policy = ExecutionPolicy(InvocationBinding(second['execution_id'], 'implementer', second['task_id'],
        1, second['model'], second['reasoning']), 'implementation', workspace_id, time.monotonic() + 180)
    spec = tool_spec(policy)
    tool = {'type': 'function', 'name': spec['name'], 'description': spec['description'],
            'parameters': spec['inputSchema']}
    request = {
        'evidence_class': 'source reconstruction, not a captured historical request',
        'method': 'POST', 'url': UPSTREAM,
        'explicit_headers': {'Content-Type': 'application/json', 'Accept': 'text/event-stream',
                             'authorization_mechanism_category': 'SIWC OAuth bearer; value never exported'},
        'library_defaults_reconstruction': {'User-Agent': 'Python-urllib/3.13', 'Host': 'api.openai.com',
            'Content-Length': 'computed from serialized bytes; historical exact value UNKNOWN',
            'Connection': 'close', 'Accept-Encoding': 'identity', 'actual_wire_headers': 'UNKNOWN'},
        'source_guaranteed_body': {'model': 'gpt-6-astra', 'reasoning': {'effort': 'low', 'other_fields': 'UNKNOWN'},
            'stream': True, 'store': False, 'input': 'array; historical items/text UNKNOWN',
            'tools': [tool], 'tool_choice': 'auto'},
        'allowed_top_level_fields': sorted(ResponsesGate.FIELDS),
        'stripped_client_local_fields': sorted(ResponsesGate.LOCAL_ONLY),
        'omitted_fields': 'All top-level fields outside allowlist rejected; previous_response_id absent; hosted inventory replaced',
        'unknown_optional_values': ['instructions', 'parallel_tool_calls', 'text', 'include', 'reasoning subfields'],
        'nested_validation_limit': 'Effort bound; other reasoning subfields preserved. Input items not a complete SIWC schema validator.',
        'serialization': 'strict_json input; bool identity checks; json.dumps(body).encode() yields UTF-8 JSON bytes',
        'http_client': {'library': 'CPython 3.13.1 urllib.request + http.client + email.message',
            'proxy': 'ProxyHandler({})', 'redirect': 'NoRedirect; deny', 'protocol': 'HTTP/1.1 over TLS; no websocket',
            'mode': 'POST stream:true; full bounded body buffering before response gate',
            'read': 'HTTPResponse.read1(8192), chunk transfer decoding; no application decompression',
            'timeouts_seconds': {'execution': 180, 'socket': 'min(15, remaining)', 'local_relay': 5, 'codex_idle': 15},
            'request_limit': 4, 'historical_actual_requests_per_execution': 1, 'automatic_retry': False,
            'body_limit_bytes': 1048576},
        'historical_exact_body_bytes': 'UNKNOWN', 'historical_body_sha256': 'UNKNOWN',
        'offline_native_replay': 'docs/stage19b-evidence/native-replay.json; synthetic prompt, not historical exact body'
    }
    save(OUT / 'request-reconstruction.json', request)
    sources = [
        ('siwc-inference', 'https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference',
         'OAuth bearer fixed Responses POST, array input, stream:true/store:false; response.completed completion; failure events possible after HTTP200.'),
        ('siwc-limitations', 'https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations',
         'HTTP input array; system roles rejected; unsupported top-level options omitted; group function/custom tools in namespaces or supply via additional_tools input items.'),
        ('app-server', 'https://developers.openai.com/siwc/token-sharing-open-source/codex-app-server',
         'App-server integration described; HTTP/SSE provider mode available.'),
        ('streaming', 'https://developers.openai.com/api/docs/guides/streaming-responses',
         'General Responses uses SSE event/data framing; general API documentation does not override SIWC preview restrictions.'),
        ('reasoning', 'https://developers.openai.com/api/docs/guides/reasoning',
         'reasoning.context all_turns is an API parameter with model-specific support; its SIWC gpt-6-astra support is not established here.'),
        ('changelog', 'https://learn.chatgpt.com/docs/changelog',
         '0.160.0 lists provider/catalog and TUI reasoning/verbosity persistence changes; no identified MIME/Accept/SSE change in the listed notes.')
    ]
    hypotheses = [
        {'rank': 1, 'topic': 'library normalization', 'evidence': 'CONFIRMED measurement ambiguity: get_content_type synthesizes text/plain for missing/malformed MIME and strips parameters.', 'root_cause': 'UNKNOWN'},
        {'rank': 2, 'topic': 'request-shape contract gap', 'evidence': 'CONFIRMED flat function declaration differs from current documented SIWC namespace/additional_tools format.', 'root_cause': 'UNKNOWN; plain response causality unproven'},
        {'rank': 3, 'topic': 'account/plan/admission plain or JSON message', 'evidence': 'Plausible; HTTP200 can precede failure; body unread and no usage/completion evidence.', 'root_cause': 'UNKNOWN'},
        {'rank': 4, 'topic': 'mislabeled valid SSE', 'evidence': 'Plausible; synthetic classifier can distinguish prefix syntax; no historical body bytes.', 'root_cause': 'UNKNOWN'},
        {'rank': 5, 'topic': 'model/reasoning/request combination', 'evidence': 'Catalog confirms availability/low option, not successful inference. Offline native reasoning.context=all_turns preserved; SIWC/model support UNKNOWN.', 'root_cause': 'UNKNOWN'},
        {'rank': 6, 'topic': 'header content negotiation', 'evidence': 'Accept:text/event-stream explicitly set. Official curl sample omits Accept; no evidence this header caused mismatch.', 'root_cause': 'UNKNOWN'},
        {'rank': 7, 'topic': 'client streaming behavior', 'evidence': 'Fixed urllib HTTP path; correct boolean serialization; no websocket switch, redirect or configured proxy; buffering intentional.', 'root_cause': 'UNKNOWN; evidence against those specific local bugs'},
        {'rank': 8, 'topic': 'relay implementation bug', 'evidence': 'MIME observation ambiguity found; fail-closed rejection itself matches policy. No evidence stream:false/body coercion or body-to-SDK leak.', 'root_cause': 'UNKNOWN'},
        {'rank': 9, 'topic': 'other supported streaming representation', 'evidence': 'No retrieved SIWC documentation authorizes another HTTP representation or accepting plain MIME.', 'root_cause': 'UNKNOWN'},
        {'rank': 10, 'topic': 'undocumented upstream or intermediary behavior / runtime drift', 'evidence': 'Cannot identify response origin from parsed header alone; old pinned binary unavailable, release correlation is insufficient.', 'root_cause': 'UNKNOWN'}
    ]
    new_paths = ['agent_system/transport_diagnostics.py', 'tests/test_transport_diagnostics.py',
                 'validation/stage19b_native_replay.py', 'validation/stage19b_assessment.py']
    report = {
        'version': 1, 'date': '2026-10-06', 'stage': '19b',
        'verdict': 'DIAGNOSIS_READY_FOR_AUTHORIZED_CAPTURE',
        'observed': {
            'stage19_verdict': 'FAIL_LIVE_TRANSPORT', 'historical_responses_requests': 2,
            'historical_http_status_per_execution': [200, 200], 'oauth_connection_succeeded': True,
            'catalog_availability_confirmed': True, 'successful_inference_acceptance': 'UNPROVEN',
            'model': 'gpt-6-astra', 'reasoning': 'low', 'second_parsed_content_type': 'text/plain',
            'second_upstream_read_bytes': 0, 'validated_completed_responses': 0, 'dynamic_tool_calls': 0,
            'model_selected_host_execution': False, 'credential_escape_observed': False,
            'stage19b_inference_requests': 0, 'stage19b_catalog_requests': 0, 'stage19b_oauth_requests': 0,
            'credential_store_access_this_stage': False,
            'offline_native_replay': load('docs/stage19b-evidence/native-replay.json'),
            'regression': {'fresh_focused_passed': len(focused), 'fresh_diagnostic_passed': len(diagnostic),
                'default_collected': len(collector.nodes), 'default_covered_by_passed_evidence_union': len(covered & collector.nodes),
                'default_coverage_is_cumulative_not_fresh_full_suite': True,
                'additional_opt_in_passed': len(covered - collector.nodes),
                'evidence': ['docs/stage18-evidence/regression/full.xml',
                    'docs/stage18-chatgpt-evidence/focused-final-pass.xml', 'docs/stage19b-evidence/final.xml'],
                'earlier_stage19b_cancel_failure': 'focused.xml: reader shutdown race; fixed only new observer; retained as failed history',
                'new_docker_probe': False},
            'historical_artifacts_unchanged': len(historical), 'historical_sha256': historical,
            'accepted_production_source_sha256_unchanged': accepted['source_sha256'],
            'docker_boundary_implementation_sha256_unchanged': docker_hash,
            'transport_boundary_implementation_sha256_unchanged': transport_hash,
            'added_source_sha256': {name: sha(ROOT / name) for name in new_paths},
            'runtime': {'stage19': binding, 'stage18c_pinned_binary_available': False, 'runtime_updated': False},
            'production_acceptance_changed': False, 'observer_wired_into_production': False
        },
        'documented': {'retrieved_date': '2026-10-06', 'official_sources': [
            {'id': ident, 'url': url, 'scope': claim} for ident, url, claim in sources],
            'explicit_siwc_plain_mime_acceptance_found': False,
            'siwc_normative_exact_content_type_header': 'UNKNOWN; retrieved text does not establish exact raw-header requirement'},
        'inferred': {'sanitized_canonical_request': request, 'ranked_hypotheses': hypotheses,
            'most_actionable_offline_findings': ['parsed MIME is not proof of raw header', 'flat tool declaration differs from current SIWC guidance'],
            'actual_transport_root_cause_established': False,
            'architecture': {'module': new_paths[0], 'default_enabled': False, 'extra_network_capability': False,
                'read_bounds': {'body_bytes': d.MAX_CAPTURE_BYTES, 'seconds': d.MAX_READ_SECONDS,
                    'chunks': d.MAX_CHUNKS, 'chunk_bytes': d.CHUNK_BYTES, 'idle_seconds': d.SOCKET_IDLE_SECONDS,
                    'shutdown_join_seconds': d.JOIN_SECONDS},
                'unknown_always_rejected': True, 'raw_body_persisted': False, 'raw_body_returned': False,
                'raw_body_storage': 'Controller memory only; no protected temp file needed',
                'expected_sse_path': 'wrapper passes unchanged response to existing strict buffered gate',
                'required_authority': 'fresh admission + signed live grant + independently signed diagnostic grant bound to observer hash + fresh client-bound no-credit attestation',
                'known_secret_rejection': 'literal/canonical JSON and independently decodable JSON/SSE fragments before metadata export',
                'limits': 'Body prefix only, after HTTP headers. stdlib parses chunk framing. Arbitrary readers refused. Not universal DLP or cryptographic memory erasure.'},
            'mime_policy': {'recommended': 'A: continue authoritative MIME rejection', 'policy_b_implemented': False,
                'policy_b_prerequisites': 'separate reviewed change, official or strong full-stream evidence, narrow media contract, complete existing event/completion/tool validation, adversarial tests and fresh admission'},
            'future_diagnostic_technically_justified': True,
            'future_diagnostic': {'executions': 1, 'responses_posts_max': 1, 'automatic_retries': 0,
                'model': 'gpt-6-astra', 'reasoning': 'low', 'method': 'POST', 'route': UPSTREAM,
                'request_scope': 'Prepare once offline using pinned 0.160.0 and original Stage19 minimal prompt/identity, capture gate-authored request in Controller memory, freeze body hash before authorization. Same stream/store/input/tool semantics, no model/reasoning/header/schema variants. Exact historical byte identity UNKNOWN.',
                'live_path': 'Controller single frozen gated body -> existing fixed proxy/redirect-free HTTP stack with diagnostic opener. No live Codex session, no relay client, no bridge/tool dispatcher.',
                'capture_bytes_max': d.MAX_CAPTURE_BYTES, 'capture_seconds_max': d.MAX_READ_SECONDS,
                'chunks_max': d.MAX_CHUNKS, 'idle_seconds': d.SOCKET_IDLE_SECONDS,
                'retained': 'safe HTTP status/media presence/count/enums/parameters-presence/length/encoding; byte/chunk counts; stop/shutdown state; UTF8/syntax classification; prefix hash only after secret checks',
                'discarded': 'raw body, text, event payloads, function arguments, arbitrary headers, account/request identifiers; entire secret-bearing derived structure/hash',
                'stop_condition': 'unknown MIME: byte/chunk/time/idle/EOF/cancellation -> quarantine metadata -> transport failure. Expected MIME: stop diagnostic without accepting inference or running any tool; no smoke pass.',
                'authorization': 'later explicit approval for exactly one diagnostic; new execution ID/latch; no reuse of Stage19 signed approvals; freeze request hash and require fresh runtime/observer/limits admission before HTTP',
                'no_credits': 'new signed <=24h attestation bound to exact issued OAuth client/execution that Allow other apps to use credits after reaching usage limit is OFF and remains OFF; zero balance alone insufficient',
                'executed': False, 'automatically_scheduled': False,
                'future_entrypoint_status': 'proposal only; reviewed single-request integration and frozen-body approval required before any future HTTP'},
            'stage19_passed': False, 'stage20_admissible': False},
        'unknown': ['Raw Content-Type presence/value/parameters/duplicates in historical response',
            'actual upstream body format/content/events', 'direct upstream versus intermediary origin',
            'exact historical serialized request/input/instructions/optional nested fields and wire defaults',
            'whether inference started, backend reasoning/completion, usage or cost',
            'whether current SIWC tool-format gap caused historical text/plain',
            'SIWC gpt-6-astra support for replayed reasoning.context=all_turns',
            '0.159.2 versus 0.160.0 exact request/header diff and MIME causality']
    }
    save(ROOT / 'STAGE19B_TRANSPORT_DIAGNOSIS.json', report)
    print(json.dumps({'verdict': report['verdict'], 'fresh_passed': len(focused),
        'diagnostic_passed': len(diagnostic), 'default_covered': len(collector.nodes),
        'historical_unchanged': len(historical), 'live_requests': 0}))


if __name__ == '__main__':
    main()
