"""Prepare separately authorized, bounded variants; never starts inference."""
import ast
import hashlib
import json
from pathlib import Path
import shutil
import time

ROOT = Path(__file__).resolve().parents[1]


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')


def prepare(number, variant):
    execution = f'stage19g-smoke-{number}'
    out = ROOT/'docs'/f'{execution}-evidence'
    out.mkdir(exist_ok=True)
    assert not (out/'one-shot-latch').exists(), 'Consumed identities cannot be prepared again'
    source = (ROOT/'validation/stage19g_live_smoke_5.py').read_text()
    source = source.replace('stage19g-smoke-5', execution)
    source = source.replace("value['tools'][0]['tools'][0]['description'] +=", "value['instructions'] = value.get('instructions', '') + ' For this request copy this exact argument object without editing, reordering, or escaping it twice: ' + json.dumps(expected)\n            value['tools'][0]['tools'][0]['description'] +=")
    source = source.replace("self.last_response_metadata['argument_mismatch_fields'] = [key for key in expected if actual[0].get(key) != expected[key]]", "self.last_response_metadata['argument_mismatch_fields'] = [key for key in expected if actual[0].get(key) != expected[key]]\n                    self.last_response_metadata['argv_diagnostic'] = argv_diagnostic(actual[0].get('argv'), expected['argv'])")
    insertion = '''def argv_diagnostic(actual, expected):
    if not isinstance(actual, list): return {'is_array': False}
    record = {'is_array': True, 'length': min(len(actual), 65),
        'matches_by_position': [a == b for a, b in zip(actual, expected)],
        'allowed_value_indices': [expected.index(v) if v in expected else -1 for v in actual[:64]]}
    if len(actual) == len(expected) == 3 and isinstance(actual[2], str):
        script = actual[2]
        record['script_has_literal_lf'] = '\\n' in script
        record['script_has_double_escaped_lf'] = '\\\\\\\\n' in script
        record['script_length_delta'] = max(-16384, min(16384, len(script)-len(expected[2])))
        try:
            record['script_parses'] = True
            record['script_ast_matches'] = ast.dump(ast.parse(script)) == ast.dump(ast.parse(expected[2]))
        except (SyntaxError, ValueError): record['script_parses'] = False
    return record


'''
    source = source.replace('def fixed_result_schema(proposal):', insertion+'def fixed_result_schema(proposal):')
    if variant == 'selector':
        source = source.replace('def expected_arguments(policy, proposal, step):', 'def command_arguments(policy, proposal, step):')
        source = source.replace('def argv_diagnostic(actual, expected):', '''def expected_arguments(policy, proposal, step):
    value = command_arguments(policy, proposal, step)
    return {**value, 'argv': [('stage19-mutate', 'stage19-verify')[step]]}


def argv_diagnostic(actual, expected):''')
        source = source.replace('result = super().execute(request)', "result = super().execute(command_arguments(self.policy, self.proposal, step))\n            self.observed.setdefault('approved_command_resolutions', []).append({'step': step+1, 'exact_prepared_argv': True})")
        source = source.replace("Use the fixed command strings in order: python, -c, script. Every scalar is fixed for this step.", "The argv contains exactly one approved command selector. The Controller resolves it to the frozen Python command in Docker. Do not pass Python, shell code, or extra arguments. Every field is fixed for this step.")
        source = source.replace("proposal['prompt_contract']+' Use exactly", "'Use only agentctl.agentctl_execute. Its argv is a single approved command selector: stage19-mutate, then stage19-verify. The Controller maps each selector to the frozen prepared command. No other commands, paths, network, installs, models or roles. Use exactly")
    compile(source, '<prepared-driver>', 'exec')
    (ROOT/'validation'/f'stage19g_live_smoke_{number}.py').write_text(source, encoding='utf-8')
    catalog = (ROOT/'validation/stage19g_live_catalog_6.py').read_text().replace('stage19g-smoke-6', execution)
    (ROOT/'validation'/f'stage19g_live_catalog_{number}.py').write_text(catalog, encoding='utf-8')
    proposal = json.loads((ROOT/'docs/stage19g-smoke-5-evidence/prepared-smoke.json').read_text())
    proposal['smoke']['execution_id'] = execution
    proposal['smoke']['schema_scope'] = variant
    proposal['smoke']['wire_variant'] = variant
    proposal['smoke']['preparation_requirements'] = [s.replace('stage19g-smoke-5', execution) for s in proposal['smoke']['preparation_requirements']]
    proposal['new_execution_authorization'] = 'Human authorized five additional tests; this is a separate bounded variant; stop after success.'
    proposal['live_authorization_received'] = True
    proposal['live_driver_status'] = 'Prepared, subject to fresh local checks and current runtime/credentials/catalog verification.'
    proposal['smoke']['approved_command_selectors'] = ['stage19-mutate', 'stage19-verify'] if variant == 'selector' else []
    write_json(out/'prepared-smoke.json', proposal)
    shutil.copyfile(ROOT/'docs/stage19g-smoke-4-evidence/fresh-admission.json', out/'fresh-admission.json')
    test = (ROOT/'validation/test_stage19g_live_smoke_5.py').read_text().replace('stage19g_live_smoke_5', f'stage19g_live_smoke_{number}').replace('stage19g-smoke-5', execution)
    test = test.replace("argv['minItems'] == argv['maxItems'] == 3", "argv['minItems'] == argv['maxItems'] == len(expected['argv'])")
    (ROOT/'validation'/f'test_stage19g_live_smoke_{number}.py').write_text(test, encoding='utf-8')
    roundtrip = (ROOT/'validation/test_stage19g_smoke_5_roundtrip.py').read_text().replace('stage19g_live_smoke_5', f'stage19g_live_smoke_{number}').replace('stage19g-smoke-5', execution)
    (ROOT/'validation'/f'test_stage19g_smoke_{number}_roundtrip.py').write_text(roundtrip, encoding='utf-8')
    authorization = json.loads((ROOT/'docs/stage19g-smoke-6-evidence/authorization.json').read_text())
    authorization.update(execution_id=execution,
        proposal_sha256=hashlib.sha256((out/'prepared-smoke.json').read_bytes()).hexdigest(),
        execution_authorization_observed_at=time.time(),
        execution_authorization_basis='Human: пробуй несколько разных вариантов, даж разрешение еще на 5 тестов',
        confirmation_time_basis='Original actual billing confirmation retained; OFF preference persists.',
        fix_scope=variant)
    write_json(out/'authorization.json', authorization)
    print(json.dumps({'prepared': execution, 'variant': variant, 'live_requests': 0}))


if __name__ == '__main__':
    prepare(7, 'exact_argv_with_step_instructions')
    reconnect = (ROOT/'validation/stage19g_reconnect.py').read_text().replace('docs/stage19g-live-smoke-evidence', 'docs/stage19g-additional-tests-evidence')
    (ROOT/'docs/stage19g-additional-tests-evidence').mkdir(exist_ok=True)
    (ROOT/'validation/stage19g_reconnect_more.py').write_text(reconnect, encoding='utf-8')
