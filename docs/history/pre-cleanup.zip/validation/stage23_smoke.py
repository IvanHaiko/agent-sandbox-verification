"""Three sequential native smoke trials; stop at the first unusable execution."""
import ast
import hashlib
import json
from pathlib import Path
import shutil
import stat
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from agent_system.native_codex import NativeCodexRunner
from agent_system.runners.docker_isolated import regular_tree

OUT = ROOT / 'docs/stage23-evidence'
OWNED = ROOT / '.test-tmp/stage23-native'
TARGET = 'src/add_one.py'
BASELINE = 'def add_one(value: int) -> int:\n    raise NotImplementedError\n'
INPUT = '''Role: Implementer. This is one fresh, bounded native Codex smoke execution.
Read role-input.md and inspect src/add_one.py in this workspace.
Implement def add_one(value: int) -> int with the single statement return value + 1.
Supported domain: Python integer inputs. Preserve the type annotations.
Only src/add_one.py may change. No imports, I/O, dependencies, other files, commits,
other workspaces, authentication files, agent histories, subagents or network.
Use a native file edit. End immediately after writing; no final summary is required.
'''


def verify(data):
    tree = ast.parse(data.decode('utf-8'))
    expected = ast.parse('def add_one(value: int) -> int:\n    return value + 1\n')
    # The whole bounded module is verified without executing model-generated
    # host code. Location/formatting differences do not affect this check.
    return {'valid': ast.dump(tree) == ast.dump(expected),
            'interface_check': ast.dump(tree) == ast.dump(expected),
            'deterministic_check': 'entire module AST matches frozen add_one contract'}


def cleanup(path):
    absolute = path.resolve()
    if absolute == OWNED.resolve() or not absolute.is_relative_to(OWNED.resolve()):
        raise RuntimeError('Unsafe Stage23 cleanup path')
    if absolute.is_symlink():
        raise RuntimeError('Linked Stage23 cleanup root')
    regular_tree(absolute)
    def readonly(function, name, exc):
        candidate = Path(name)
        if not candidate.resolve().is_relative_to(absolute) or candidate.is_symlink():
            raise RuntimeError('Unsafe Stage23 cleanup entry')
        if not isinstance(exc[1], PermissionError):
            raise exc[1]
        candidate.chmod(stat.S_IREAD | stat.S_IWRITE)
        function(name)
    shutil.rmtree(absolute, onerror=readonly)


def main():
    discovery = json.loads((OUT / 'native-discovery.json').read_text(encoding='utf-8'))
    if not discovery['gpt61_available']:
        raise RuntimeError('STOP: native GPT-6.1 Sol not listed')
    runner = NativeCodexRunner(discovery['executable'])
    (OUT / 'smoke-input.md').write_text(INPUT, encoding='utf-8')
    (OUT / 'smoke-baseline.py').write_text(BASELINE, encoding='utf-8')
    summary = {'required': 3, 'usable': 0, 'trials': [], 'gate': 'not_passed'}
    for number in range(1, 4):
        trial = 'smoke-' + str(number)
        workspace = OWNED / trial
        workspace.mkdir(parents=True, exist_ok=False)
        (workspace / 'src').mkdir()
        (workspace / TARGET).write_text(BASELINE, encoding='utf-8')
        (workspace / 'role-input.md').write_text(INPUT, encoding='utf-8')
        for args in (['init', '--initial-branch=main'], ['add', '.'],
                     ['-c', 'user.name=Stage23 Controller', '-c',
                      'user.email=stage23@example.invalid', 'commit', '-m', 'Frozen native smoke input']):
            subprocess.run(['git', '-C', str(workspace), *args], check=True,
                           capture_output=True, timeout=20)
        print(trial + ': starting native gpt-6.1-sol/low', flush=True)
        record = None
        try:
            record = runner.run(trial_id=trial, role='implementer', workspace=workspace,
                prompt=INPUT, target=TARGET, model='gpt-6.1-sol', effort='low',
                verify=verify, timeout_seconds=90)
            if record['execution_status'] != 'unrecoverable':
                archive = OUT / (trial + '-candidate.py')
                archive.write_bytes((workspace / TARGET).read_bytes())
                if hashlib.sha256(archive.read_bytes()).hexdigest() != record['artifact_hashes'][TARGET]:
                    raise RuntimeError('Controller candidate archive mismatch')
                summary['usable'] += 1
        finally:
            cleanup(workspace)
            if record is not None:
                record['cleanup_status'] = 'passed' if not workspace.exists() else 'failed'
                (OUT / (trial + '.json')).write_text(json.dumps(record, indent=2), encoding='utf-8')
                summary['trials'].append(record)
                print(trial + ': ' + record['execution_status'] + ' / ' +
                      str(record['failure_category']), flush=True)
        if record is None or record['execution_status'] == 'unrecoverable':
            summary['stop_reason'] = record['failure_category'] if record else 'execution_failed'
            break
    if summary['usable'] == 3:
        summary['gate'] = 'passed'
    if OWNED.exists() and not any(OWNED.iterdir()):
        OWNED.rmdir()
    summary['owned_workspaces_removed'] = not OWNED.exists()
    (OUT / 'smoke-summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(json.dumps({k: v for k, v in summary.items() if k != 'trials'}), flush=True)


if __name__ == '__main__':
    main()
