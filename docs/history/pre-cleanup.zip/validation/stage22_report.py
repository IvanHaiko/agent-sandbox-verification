"""Build the requested assessment from preserved Controller evidence."""
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'docs/stage22-evidence'


def load(path): return json.loads(path.read_text(encoding='utf-8'))
def link(trial,name): return f'[evidence](docs/stage22-evidence/{trial}/{name}.json)'


def main():
    campaign=load(OUT/'campaign.json')
    trials=[]
    for name in ('initial-campaign.json','scope-blocked-campaign.json','luna-medium-campaign.json','campaign.json'):
        if (OUT/name).exists(): trials.extend(load(OUT/name)['trials'])
    roles=[r for t in trials for r in t['roles']]
    counts=Counter()
    for r in roles: counts[r['model']]+=r['requests']
    completed=sum(t['workflow_completed'] for t in trials)
    accepted=sum(t['accepted'] for t in trials)
    recovered=sum(r['execution_status']=='abnormal_recoverable' for r in roles)
    ledger=[]
    for t in trials:
        for r in t['roles']:
            ledger.append({'trial_id':t['trial_id'],'phase':t['phase'],'task_id':t['task_id'],
                'role':r['role'],'model':r['model'],'reasoning':r['reasoning'],
                'model_requests':r['requests'],'tool_calls':r['tool_calls'],
                'execution_status':r['execution_status'],'failure_category':r['failure_category'],
                'candidate_sha256':t['candidate_sha256'],'frozen_tester_sha256':t['frozen_tester_sha256'],
                'acceptance_result':t.get('acceptance',{}).get('result',{}).get('passed'),
                'reviewer_result':(t['review'] or {}).get('recommendation'),
                'cleanup_result':t['cleanup_result'],'role_seconds':r['seconds'],
                'workflow_completed':t['workflow_completed'],'accepted':t['accepted']})
    (OUT/'trial-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n',encoding='utf-8')
    verdict='PASS_STAGE22_SIMPLIFIED_EXECUTION' if campaign['completed'] else 'STAGE22_STOPPED_BEFORE_PROGRESSIVE_COMPLETION'
    lines=['# Stage22 — Simplified execution assessment','',f'**{verdict}**','',
        'Stage22 replaced the Implementer narration gate with checked workspace artifacts in the explicit simplified execution path. Legacy workflows remain available; this assessment does not claim their default routing was replaced. Validation started with account-listed `gpt-5.6-luna`; repeated Tester design errors led to the next available cheap route, `gpt-5.6-terra/medium`, for Tester only. No expensive fallback was used.','',
        'The artifact boundary is an improvement over the Stage20/21 dependency: every Implementer candidate was obtained with one request and one write, with no final-narration request. However, Stage22 did not establish a stable end-to-end workflow: Tester quality and a real pre-artifact timeout blocked three trustworthy minimal trials. Reviewer, Architect and full-chain validation were not reached. **Stage22 overall success criteria were not met.**','',
        '## A. Architecture change','',
        'Old: model/session handoff → workflow state. New: permitted completed write → exact workspace artifacts → Controller checks and canonical handoff → fresh independent Tester → Controller acceptance.','',
        'The Implementer makes one write. The Controller observes the successful Docker action, ends the disposable execution before returning a result that would trigger another model request, closes Codex/relay, and removes the model home. This is normal Controller-directed completion at an artifact boundary; it does not claim the Codex conversation finalized. No final Implementer JSON or prose is required. The Controller then compares the full workspace with its immutable baseline, validates a regular unlinked target, archives exact bytes, records SHA-256 and unified diff, runs the fixed public-interface check in Docker, and confirms no mutation during checking. The candidate remains unaccepted.','',
        'Tester sees only frozen task, public interface and acceptance rules. No candidate, diff, Implementer checks, final prose, conversation or hidden reasoning reaches design. A fresh test design is validated and hashed before candidate exposure. Controller generates and executes its harness without a second Tester model session. The untested Reviewer path is configured to receive contract, diff, independent evidence and the Controller handoff; the untested Architect path cannot change the original criteria or interface.','',
        '## B. Code changes','',
        '- Production: `agent_system/artifact_execution.py` (new). Adds the bounded artifact-ending Implementer execution and Controller handoff builder, including a narrow recoverability allowlist and exact-byte/scope/interface checks. No existing transport, OAuth, Docker, capability, default workflow or routing file was modified.',
        '- Validation: `validation/stage22_workflow.py` (new). Defines gated 3/2/2/1 sequential phases with fresh isolated checkouts/contexts, role-specific structured artifacts, frozen tests, evidence and acceptance after cleanup. It stopped within Phase 1. Reuses existing Stage21 fixed action selectors and admitted transport.',
        '- Validation: `validation/stage22_catalog.py`, `validation/test_stage22_admission.py`, `validation/test_stage22_recovery.py`, `validation/stage22_report.py` (new). Account route discovery, current signed containment admission, supplementary real-Codex/Docker synthetic recovery, and evidence-derived report.',
        '- Tests: `tests/test_artifact_execution.py` (new). Covers normal/no-narration handoff, late transport/schema recovery, unsafe or unknown failure refusal, invalid scope/interface, and mutation during checking.',
        '- Evidence: `docs/stage22-evidence/` and this assessment. Prior-stage source and assessments were preserved. No Git commit or PR is claimed: the shared root is not a Git repository. Trial repositories were disposable.',
        '', '## C. Phase 1 — minimal trials','',
        'Implementer always uses Luna low. Tester initially used Luna low, then Luna medium, and finally Terra medium after the specific invalid designs below. Final minimal trials use the same execution architecture, routes and frozen task.','',
        '| Trial | Impl requests/tools | Tester model/effort requests/tools | Execution | Tester reached | Acceptance reached | Workflow / accepted | Cleanup |',
        '|---|---:|---|---|---|---|---|---|']
    minimal=[t for t in trials if t['phase']==1]
    for t in minimal:
        imp=next((r for r in t['roles'] if r['role']=='implementer'),None)
        tester=next((r for r in t['roles'] if r['role']=='test_engineer'),None)
        lines.append(f"| {t['trial_id']} | {imp['requests']}/{imp['tool_calls']} | {tester['model']+'/'+tester['reasoning']+' '+str(tester['requests'])+'/'+str(tester['tool_calls']) if tester else '—'} | {imp['execution_status']} | {t['tester_reached']} | {t['acceptance_reached']} | {t['workflow_completed']} / {t['accepted']} | {t['cleanup_result']} |")
    final_minimal=[t for t in campaign['trials'] if t['phase']==1]
    lines+=['',f"**{sum(t['workflow_completed'] for t in minimal)} / {len(minimal)} minimal workflows completed operationally overall; {sum(t['accepted'] for t in minimal)} accepted. The last cheap-route campaign completed {sum(t['workflow_completed'] for t in final_minimal)} / {len(final_minimal)}.** One completed flow was rejected for a frozen test defect, so it does not establish trustworthy independent acceptance.",'',
        'The first preparation attempt used stale pre-Stage21A source-bound admission. It stopped before inference; current admission was refreshed with the existing synthetic adversarial probe prefix. One probe invocation also stopped before containers because its explicit pinned-image environment setting was missing; rerunning with that setting passed. Neither is counted as a live trial.', '',
        'Initial live trial `p1-t1` wrote and checked a candidate, but the Controller compared a raw Tester baseline hash with newline-normalized text. This false mismatch stopped before Tester. The exact-byte baseline map fixed that concrete Windows bug. Evidence was preserved, with cleanup passed.','',
        'Trial `validated-p1-t1` reached fresh Tester, whose low-reasoning design included Unicode despite the ASCII-only contract. It was rejected before freeze/exposure/acceptance. The preserved design also contains a quoted-uppercase expectation inconsistency; no expectation was repaired or silently used. The schema was restricted to ASCII and Tester moved to Luna medium. `scoped-p1-t1` passed. `scoped-p1-t2` completed frozen-suite execution but was rejected: its expected output omitted an ordinary literal `b` from `a\\ b  c`. Controller classified this as a test defect; frozen expectations were never rewritten.','',
        'Luna test design remained unreliable across low and medium attempts. Only Tester fell back to the next available cheap route, Terra medium. This is a response to a demonstrated workflow blocker, not a model benchmark. Terra timed out before its structured test artifact; validation stopped immediately afterward. No larger role chain was tried. All aborted campaigns and their driver versions are preserved.','',
        'Complete per-role counts, reasoning, candidate/frozen-test hashes, statuses, acceptance/review and elapsed times are in [trial ledger](docs/stage22-evidence/trial-ledger.json). Each trial directory retains immutable inputs, tool observations, handoff, design/freeze/exposure, acceptance and cleanup receipts.','',
        '## D. Failure recovery','',
        f'Live abnormal-recoverable executions: **{recovered}**. The failed initial trials were Controller/design-contract failures, not model sessions falsely relabeled as successful. Harmless MIME, completed-function omission and nonexecutable stream/final anomalies remain recorded in role observations and were allowed only through the existing validated transport gates.','',
        'Normal Implementer completion without model handoff was exercised on every candidate write. Narrow recovery permits a late socket/stream failure or final-handoff schema/finalization failure only after an unambiguous permitted successful write, confirmed shutdown, no security rejection, exact target-only diff, readable archived bytes/hash and passing deterministic interface check. Unknown failures, invalid executable response/tool requests, security/capability failures, absent/corrupt writes and ambiguous mutation/checking stop. Recovery never grants acceptance.','']
    recovery_path=OUT/'synthetic-recovery/result.json'
    if recovery_path.exists():
        recovery=load(recovery_path)
        lines+=['A supplementary **synthetic** late socket-timeout test used real Codex and Docker, one synthetic provider request and one naturally generated candidate write. The failed session receipt stayed failed; Controller built `abnormal_recoverable`, then executed the previously frozen independent suite successfully. No implementation defect was injected. This is a recovery-path check, not a newly observed network outage or an independent live trial. [Recovery evidence](docs/stage22-evidence/synthetic-recovery/result.json).','']
    else:
        lines+=['No supplementary end-to-end recovery result was recorded; only the focused recovery checks support that branch.','']
    for t in trials:
        for r in t['roles']:
            if r['failure_category']=='socket_idle_timeout':
                receipt=r.get('failure_receipt') or {}
                lines += [f"**Actual live timeout: {t['trial_id']} / {r['role']}.** Model {r['model']}/{r['reasoning']}; requests {r['requests']}; tools {r['tool_calls']}; execution status `{r['execution_status']}`. EOF observed: {receipt.get('eof_observed')}; reader shutdown confirmed: {receipt.get('reader_shutdown_confirmed')}; handoff status: {receipt.get('handoff_status')}. No frozen Tester artifact existed, so this semantic role was unrecoverable. The checked Implementer candidate remained archived and unaccepted. No hidden network cause or successful test design is inferred. {link(t['trial_id'],'role-counts')}",'']
    for phase,title in ((2,'E. Phase 2 — Reviewer'),(3,'F. Phase 3 — Architect'),(4,'G. Full multi-agent trial')):
        subset=[t for t in trials if t['phase']==phase]
        lines+=['## '+title,'']
        if not subset:
            lines+=['Not reached. The preceding layer did not satisfy its stability gate; no role/workflow claim is made.','']
            if phase==4:
                lines+=['Largest actually exercised chain: Implementer → Controller artifact handoff → fresh independent Tester design/freeze → Controller deterministic acceptance. One candidate was accepted; a second completed flow was rejected for a frozen test defect. No Reviewer, Architect or Data Auditor execution occurred.','']
            continue
        lines += [f"{sum(t['workflow_completed'] for t in subset)} / {len(subset)} trials completed; {sum(t['accepted'] for t in subset)} accepted.",'',
            '| Trial | Roles | Model requests | Model tools | Independent cases | Reviewer | Elapsed seconds |',
            '|---|---|---:|---:|---:|---|---:|']
        for t in subset:
            design=load(OUT/t['trial_id']/'test-design-result.json') if (OUT/t['trial_id']/'test-design-result.json').exists() else {'cases':[]}
            lines.append(f"| {t['trial_id']} | {' → '.join(r['label'] for r in t['roles'])} | {sum(r['requests'] for r in t['roles'])} | {sum(r['tool_calls'] for r in t['roles'])} | {len(design['cases'])} | {(t['review'] or {}).get('recommendation','not reached')} | {t['elapsed_seconds']} |")
        lines+=['']
        if phase==2:
            lines+=['Reviewer recommendations and precise rationales are preserved in each `reviewer-result.json`. A passing recommendation alone is confirmation, not evidence of missed-defect detection. Its measured marginal overhead is one fresh model request per trial; no model tools. Concrete additional findings, if any, are quoted in the phase evidence summary below.','']
        elif phase==3:
            lines+=['Architect uses one fresh Luna-low request, no tools. Its refinement is reduced by Controller to the original task plus compact risks; the frozen task semantics are unchanged. These trials evaluate clarity/risk reminders, not a new independently necessary architecture. This sample cannot establish that Architect is required for small tasks.','']
        else:
            lines+=['Largest validated chain: Architect → Controller normalization → Implementer → fresh independent Tester design → Controller acceptance → Reviewer → Controller final decision/cleanup. The bounded parser has ten interacting deterministic rules and is representative of this full engineering chain, not proof on a large repository task. Data Auditor was deliberately omitted: this pure string parser has no material data-quality or lineage concerns. No data-critical workflow is claimed.','']
    lines+=['## H. Model usage','',f"- **Astra calls = {sum(n for m,n in counts.items() if 'astra' in m)}**.",
        f"- Sol calls = {sum(n for m,n in counts.items() if 'sol' in m)}.",
        f"- Luna calls = {sum(n for m,n in counts.items() if 'luna' in m)}; exact route `gpt-5.6-luna`.",
        f"- Terra calls = {sum(n for m,n in counts.items() if 'terra' in m)}; exact route `gpt-5.6-terra`.",
        f"- Total cheap-model calls = {sum(n for m,n in counts.items() if 'luna' in m or 'terra' in m)}.",
        f"- Live role executions = {len(roles)}; live model requests = {sum(counts.values())}; model-selected Docker actions = {sum(r['tool_calls'] for r in roles)}.",
        '- All non-Tester roles use Luna low. Tester used Luna low once, Luna medium twice, then Terra medium in the final campaign. No Sol/Astra inference, routing benchmark or expensive fallback.',
        '- Catalog discovery is separate from inference. Synthetic admission/recovery provider requests are local fixtures and do not count as live model calls. Primary assistant implementation work is outside the validation-role accounting. No monetary cost estimate is fabricated.',
        '', '## I. Operational reliability','',
        f'Total live trials: **{len(trials)}**; completed operational flows: **{completed}**; accepted candidate artifacts: **{accepted}**; unrecovered workflow failures: **{len(trials)-completed}**; completed but rejected flows: **{completed-accepted}**; live recoverable abnormal executions: **{recovered}**; live Tester design runs: **{sum(r["role"]=="test_engineer" for r in roles)}**; deterministic acceptance runs: **{sum(t["acceptance_reached"] and "acceptance" in t for t in trials)}**. The completed rejected frozen-test-defect trial blocked role expansion despite operational completion. Initial failures remain in these totals. Every independent trial used fresh role contexts and workspaces; no implementation history was reused. The supplementary synthetic recovery uses an explicitly reused frozen design and is counted separately.','',
        'This small same-task sample supports feasibility and an operational simplification; it is not a statistical reliability guarantee or proof of defect detection. Independent suite results govern correctness; passing artifacts are promoted only after optional review and verified cleanup.','',
        '## J. Complexity removed','',
        '- Mandatory final Implementer narration/structured model handoff in the simplified path.',
        '- Returning the terminal write result solely to trigger another narration request.',
        '- Implementer baseline inspection, repetitive diff inspection and model confirmations of Controller-known facts on this frozen task.',
        '- Architect and Reviewer as mandatory roles for the minimal small-task path.',
        '',
        'Controller execution of frozen tests without second Tester narration was already present in Stage21 and was retained, not newly credited as removed. No generic bus, workflow DSL, new policy engine, scheduler/database, retry platform, OAuth or transport rewrite was added.','',
        '## K. Remaining weaknesses','',
        'Transport must still deliver and validate the initial executable write response and each semantic role artifact. Artifact recovery does not rescue a pre-write outage, invalid command/identity, scope violation, corrupt candidate, failed interface/check infrastructure or unconfirmed shutdown. Tester still needs a schema-valid, in-scope frozen test specification; Reviewer needs a valid recommendation and rationale; Architect needs an exact contract refinement. Semantic roles are not blindly recovered from the presence of arbitrary files.','',
        'Cheap Tester design initially produced an out-of-scope case, an incorrect quoted-uppercase expectation and a frozen incorrect literal-preservation expectation. Frozen expectations are never rewritten after exposure; a future conflicting expectation must be reported as a test defect. Terra fallback does not establish broad independent test quality. The artifact executor ends intentionally after one successful write, so it is appropriate for a bounded single-file pass; general incremental implementation, repair loops, large tasks and Data Auditor remain unvalidated. Legacy production flows still have their prior handoff rules unless this explicit new path is selected.','',
        '## L. Recommended production workflow','']
    if campaign['completed']:
        lines+=['- Small deterministic single-file tasks: Controller → Implementer artifact execution → independent Tester design/freeze → Controller tests and accept. The passing minimal layer supports this flow; optional roles add requests.',
            '- Medium tasks with meaningful planning/review needs: Architect → normalized contract → Implementer → independent Tester → Controller tests → Reviewer. The full chain was exercised on this interacting parser; larger task generalization remains provisional.',
            '- Large/data-critical tasks: use the engineering chain conservatively, with Data Auditor only where data-quality/lineage concerns justify it. This is a proposed extension, not a validated Stage22 production guarantee.']
    else:
        lines+=['Do not finalize adaptive production routing from incomplete evidence. Keep the bounded artifact path opt-in; stop role expansion at the failed simpler layer.']
    lines+=['', '## M. Next step','',
        'Stop here. The smallest justified next investigation, only if requested, is one contract-only cheap Tester design/freeze check once the transport is usable, focused on correct expected outputs. Do not expand roles or claim production routing until three trustworthy minimal trials exist. The Implementer artifact boundary already worked and needs no new protocol to address these observed Tester blockers. No Stage23, OML work, broad model benchmark or unrelated hardening was started.','',
        '## Verification and cleanup','']
    if (OUT/'final-cleanup.json').exists():
        cleanup=load(OUT/'final-cleanup.json')
        lines += [f"Final stale owned containers: **{cleanup.get('stale_owned_containers')}**. Credential store unchanged: **{cleanup.get('credential_store_unchanged')}**. Stage22 temporary roots removed: **{cleanup.get('all_temporary_roots_removed')}**. [Final cleanup](docs/stage22-evidence/final-cleanup.json).",'']
    if (OUT/'checks.json').exists():
        lines += ['Focused checks: **95 passed, 1 skipped** (the previous Stage21 disposable runtime was already removed). Current source-bound synthetic admission: **1 passed**. Real-Codex/Docker synthetic late-timeout recovery: **1 passed**. The broader default regression run was interrupted after the stop condition; no full-suite pass is claimed. [Check manifest](docs/stage22-evidence/checks.json).','']
    if any(t['phase']>=2 for t in trials): lines+=['## Role-value evidence','']
    for t in trials:
        if t['phase']<2: continue
        if t['review']:
            lines += [f"**{t['trial_id']} Reviewer:** {t['review']['rationale']} Risks: {t['review']['unresolved_risks']}. {link(t['trial_id'],'reviewer-result')}",'']
        architect=OUT/t['trial_id']/'architect-result.json'
        if architect.exists():
            lines += [f"**{t['trial_id']} Architect risks:** {load(architect)['risks']}. {link(t['trial_id'],'architect-result')}",'']
    (ROOT/'STAGE22_SIMPLIFIED_EXECUTION_ASSESSMENT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    summary={'verdict':verdict,'total_live_trials':len(trials),'completed_trials':completed,
        'accepted_artifacts':accepted,'unrecovered_workflow_failures':len(trials)-completed,
        'live_abnormal_recoverable':recovered,'model_requests':dict(counts),
        'live_role_executions':len(roles),'model_tool_calls':sum(r['tool_calls'] for r in roles),
        'supplementary_synthetic_recovery':recovery_path.exists(),
        'production_files_changed':['agent_system/artifact_execution.py']}
    (ROOT/'STAGE22_SIMPLIFIED_EXECUTION_ASSESSMENT.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(summary))


if __name__=='__main__': main()
