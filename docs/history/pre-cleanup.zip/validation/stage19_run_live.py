"""One explicitly authorized Stage19 execution. Not a default test or workflow."""
import ast
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time
from urllib.error import HTTPError

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'docs/stage19-evidence'
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / '.test-tmp/stage18-oauth-deps'))
import yaml
import agent_system.model_tool_boundary as boundary
from agent_system.agent_transport import InvocationBinding, strict_json
from agent_system.approvals import ApprovalStore
from agent_system.chatgpt_oauth import CredentialStore, ChatGPTPlanOAuth, PLAN_SCOPE
from agent_system.codex_tool_session import CodexToolSession
from agent_system.config import Configuration
from agent_system.evidence import Evidence
from agent_system.errors import AgentSystemError
from agent_system.git import git
from agent_system.model_tool_boundary import (ExecutionPolicy, IsolatedExecutionBridge,
    ResponsesGate, LocalModelRelay, PlanUpstream, SecretFilter, UPSTREAM)
from agent_system.runners.tool_docker import ToolDockerRunner
from agent_system.runners.docker_isolated import CLEANUP, regular_tree
from agent_system.runners.base import AgentResult
from agent_system.storage import atomic_json
from agent_system.telemetry import identity, finish_invocation
from agent_system.state_machine import timestamp


def main():
    second = sys.argv[1:] == ['--execute-second-authorized-smoke']
    if not second and sys.argv[1:] != ['--execute-one-authorized-smoke']:
        raise AgentSystemError('Explicit live entry point required')
    observation_path = OUT / ('second-live-observations.json' if second else 'live-observations.json')
    if second:
        first = strict_json((OUT / 'live-observations.json').read_text())
        assert first['responses_requests'] == 1 and first['verdict'] == 'FAIL_LIVE_TRANSPORT'
    previous = observation_path
    if previous.exists() and strict_json(previous.read_text()).get('responses_requests', 0) > 0:
        raise AgentSystemError('Live allowance consumed; preserve evidence and obtain separate authorization')
    observed = {'verdict': 'BLOCKED_BEFORE_INFERENCE', 'real_model_executions': 0,
        'responses_requests': 0, 'model': 'gpt-6-astra', 'reasoning': 'low',
        'provider_http_statuses': [], 'response_event_types': [], 'usage_observations': [],
        'runtime_warning_count': 0, 'runtime_error_count': 0, 'tool_calls': 0,
        'host_model_execution': False, 'credential_escape_observed': False,
        'stage20_started': False}
    observed['separate_second_execution_authorization'] = second
    atomic_json(observation_path, observed)
    session = bridge = runner = invocation = None
    real_popen, real_opener = subprocess.Popen, boundary.build_opener
    try:
        accepted = strict_json((ROOT / 'STAGE18C_MODEL_TOOL_BOUNDARY.json').read_text())
        for name, expected in accepted['source_sha256'].items():
            assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected
        catalog = strict_json((OUT / 'account-catalog.json').read_text())
        model = next(m for m in catalog['models'] if m['slug'] == observed['model'])
        assert any(v['effort'] == observed['reasoning'] for v in model['supported_reasoning_levels'])
        admission = strict_json((OUT / 'fresh-admission.json').read_text())
        project, workspace = Path(admission['project']), Path(admission['workspace'])
        assert project.resolve().is_relative_to((ROOT / '.test-tmp/stage19-fresh-admission').resolve())
        task = admission['task']
        route_path = project / '.agent_system/models.yaml'
        routes = yaml.safe_load(route_path.read_text())
        routes['models']['implementer'] = {'model': observed['model'], 'reasoning': observed['reasoning']}
        route_path.write_text(yaml.safe_dump(routes), encoding='utf-8')
        config = Configuration.load(project)
        runner = ToolDockerRunner(config)
        assert runner.preflight() == admission['binding']
        runner.require_transport_admission()
        assert not runner.stale_executions()
        assert (workspace / 'src/example.py').read_text() == 'value = 1\n'
        baseline = git(project, 'rev-parse', 'HEAD')
        store = CredentialStore(Path('C:/Users/4ivan/.agentctl/stage19-oauth'), [ROOT, project, config.worktrees_dir])
        values = store.read('credentials.json')
        refreshed = False
        if values and values['expires_at'] - time.time() < 240:
            ChatGPTPlanOAuth(store).refresh()
            values, refreshed = store.read('credentials.json'), True
        assert values and PLAN_SCOPE in values['scopes'] and values['expires_at'] - time.time() > 180
        assert hashlib.sha256(values['client_id'].encode()).hexdigest() == catalog['client_sha256']
        secret_filter = SecretFilter([values[k] for k in ('access_token', 'refresh_token', 'id_token')])
        for folder in (project, config.worktrees_dir, OUT):
            for path in folder.rglob('*'):
                if path.is_file() and path.stat().st_size < 4 * 1048576:
                    secret_filter.reject(path.read_bytes().decode('utf-8', errors='replace'))
        execution_id = 'c0-implementation-r0-t2' if second else 'c0-implementation-r0-t1'
        policy = ExecutionPolicy(InvocationBinding(execution_id, 'implementer', task['task_id'], 1,
            observed['model'], observed['reasoning']), 'implementation',
            hashlib.sha256(str(workspace.resolve()).encode()).hexdigest(), time.monotonic() + 180)
        approvals = ApprovalStore(config.runtime_root / 'stage19-live-approvals',
            {'binding': runner.preflight(), 'client_sha256': catalog['client_sha256'], 'identity': policy.identity()})
        approvals.issue('no-credits/' + execution_id, {'execution_id': execution_id,
            'client_id': values['client_id'], 'credits_fallback_disabled': True,
            'operator': 'workspace operator; explicit chat confirmation отключено', 'attested_at': time.time()})
        approvals.issue('live-smoke/' + execution_id, {'authorized': True, **policy.identity(),
            'model': policy.binding.model, 'reasoning': policy.binding.reasoning, 'route': UPSTREAM})
        boundary.require_credit_attestation(approvals, policy.binding, values['client_id'])
        invocation = config.runs_dir / task['task_id'] / 'invocations' / execution_id
        invocation.mkdir(parents=True, exist_ok=False)  # persisted single-execution latch
        observed.update(execution_id=execution_id, task_id=task['task_id'], project=str(project),
            workspace=str(workspace), invocation=str(invocation), binding=runner.preflight(),
            entitlement_catalog_verified=True, refresh_before_execution=refreshed,
            signed_no_credits=True, signed_live_authorization=True)
        prompt = ('Stage19 minimal transport smoke. Work only through agentctl_execute in the owned Docker workspace. '
            'Inspect src/example.py. Change the public variable value from 1 to 2 while preserving its interface. '
            'Verify the change with a deterministic Python assertion. Use Python standard library only, no network or installation. '
            'You MUST make at least one dynamic agentctl_execute call; all reads, writes and verification belong there. '
            'Use tool_type argv, bounded timeout/output, empty stdin unless needed, and read_only false for mutation. '
            'After successful verification return ONLY strict JSON matching this contract: '
            + json.dumps({'task_id': task['task_id'], 'contract_version': 1, 'outcome': 'completed',
                          'summary': 'Describe your verified change briefly', 'architecture_decision': None}))
        secret_filter.reject(prompt)
        context = {**policy.identity(), 'operation_id': execution_id, 'objective': 'Change value 1 to 2 and verify'}
        atomic_json(invocation / 'context_manifest.json', context)
        telemetry_binding = identity(task, config, context, git(workspace, 'rev-parse', 'HEAD'), 0, execution_id)
        started, start = timestamp(), time.monotonic()
        Evidence(invocation).write('telemetry_start', {**telemetry_binding, 'started_at': started})
        # Trap host commands while allowing only exact trusted Controller helpers.
        tree = ast.parse((ROOT / 'agent_system/chatgpt_oauth.py').read_text())
        acl_scripts = {n.value for n in ast.walk(tree) if isinstance(n, ast.Constant)
                       and isinstance(n.value, str) and n.value.startswith('$a=Get-Acl')}
        host_names = set()
        def trapped_popen(argv, *args, **kwargs):
            name = Path(argv[0]).name.lower()
            allowed = name in ('git', 'git.exe', 'docker', 'docker.exe', 'codex.exe')
            if name.startswith('python'):
                allowed = len(argv) == 6 and argv[1:4] == ['-I', '-c', CLEANUP]
            if name in ('powershell', 'powershell.exe'):
                allowed = argv[1:4] == ['-NoProfile', '-NonInteractive', '-Command'] and len(argv) == 5 and argv[4] in acl_scripts
            if not allowed:
                observed['host_model_execution'] = True
                raise AgentSystemError('Host execution trap denied unexpected process')
            host_names.add(name)
            return real_popen(argv, *args, **kwargs)
        subprocess.Popen = trapped_popen
        def tracked_opener(*args):
            opener = real_opener(*args)
            class Tracked:
                def open(self, request, **kwargs):
                    assert request.full_url == UPSTREAM
                    observed['responses_requests'] += 1
                    atomic_json(observation_path, observed)
                    try:
                        response = opener.open(request, **kwargs)
                        observed['provider_http_statuses'].append(response.status)
                        observed['provider_content_type'] = response.headers.get_content_type()
                        observed['upstream_read_bytes'] = 0
                        class Stream:
                            headers = response.headers
                            def __enter__(self): return self
                            def __exit__(self, *args): return response.__exit__(*args)
                            def read1(self, size):
                                try:
                                    chunk = response.read1(size)
                                    observed['upstream_read_bytes'] += len(chunk)
                                    return chunk
                                except Exception as error:
                                    observed['stream_read_error_type'] = type(error).__name__ if isinstance(error, (TimeoutError, OSError)) else 'read_failure'
                                    raise
                        return Stream()
                    except HTTPError as error:
                        observed['provider_http_statuses'].append(error.code)
                        raise
            return Tracked()
        boundary.build_opener = tracked_opener
        upstream = PlanUpstream(store, policy, approvals, runner.require_transport_admission)
        def observed_upstream(body):
            raw = upstream(body)
            for line in raw.decode('utf-8').splitlines():
                if line.startswith('data: '):
                    event = strict_json(line[6:])
                    event_type = event.get('type')
                    observed['response_event_types'].append(event_type if event_type in ResponsesGate.EVENTS else 'unsupported')
                    if event_type == 'response.completed':
                        response = event['response']
                        observed['usage_observations'].append(response.get('usage'))
                        observed['provider_completed_model'] = response.get('model')
            return raw
        gate = ResponsesGate(policy, secret_filter)
        bridge = IsolatedExecutionBridge(runner, workspace, task, policy, secret_filter)
        executable = Path(admission['binding']['stage18c']['codex']['path'])
        class ObservedSession(CodexToolSession):
            def handle(self, frame):
                if frame.get('method') == 'warning': observed['runtime_warning_count'] += 1
                if frame.get('method') == 'error': observed['runtime_error_count'] += 1
                return super().handle(frame)
        observed['real_model_executions'] = 1
        observed['verdict'] = 'FAIL_LIVE_TRANSPORT'
        atomic_json(observation_path, observed)
        with LocalModelRelay(gate, observed_upstream) as relay:
            with ObservedSession(executable, admission['codex_sha256'], invocation / 'model-home',
                                 relay, bridge, policy) as session:
                result = session.run(prompt)
            channel_filter = SecretFilter([values[k] for k in ('access_token', 'refresh_token', 'id_token')]
                                         + [relay.child_channel()])
            for path in (invocation / 'model-home').rglob('*'):
                if path.is_file(): channel_filter.reject(path.read_bytes().decode('utf-8', errors='replace'))
        observed.update(tool_calls=bridge.calls, canonical_dynamic_calls=len(session.call_ids),
            gated_call_count=len(gate.authorized_arguments), model_requests=gate.requests,
            codex_process_exited=session.process.poll() is not None, structured_result=result,
            changed_paths=sorted(bridge.changed_paths), host_executable_names=sorted(host_names))
        observed['verdict'] = 'FAIL_TASK_EXECUTION'
        assert bridge.calls >= 1 and session.call_ids and all(r['returncode'] == 0 for r in session.tool_results)
        assert (workspace / 'src/example.py').read_text() == 'value = 2\n'
        assert (project / 'src/example.py').read_text() == 'value = 1\n' and git(project, 'rev-parse', 'HEAD') == baseline
        assert bridge.changed_paths == {'src/example.py'} and result['outcome'] == 'completed'
        observed['verdict'] = 'FAIL_SECURITY_BOUNDARY'
        assert not runner.stale_executions()
        records = [strict_json(p.read_text()) for p in runner.root.glob('executions/*/ownership.json')]
        assert all(r['cleanup'] == 'confirmed' and r['storage_cleanup'] == 'confirmed' for r in records)
        for folder in (OUT, invocation, runner.root / 'executions'):
            for path in folder.rglob('*'):
                if path.is_file() and path.stat().st_size < 4 * 1048576:
                    secret_filter.reject(path.read_bytes().decode('utf-8', errors='replace'))
        observed.update(disposable_task_passed=True, cleanup_passed=True, mutation_only_owned_workspace=True,
            operator_credit_setting_attested=True, billing_behavior='unknown; account setting operator-attested')
        observed['verdict'] = 'PASS_LIVE_SMOKE'
        agent_result = AgentResult(execution_id, task['task_id'], 'implementer', 'success', policy.binding.model,
            policy.binding.reasoning, 0, 0, json.dumps(result), sorted(bridge.changed_paths))
        atomic_json(invocation / 'result.json', agent_result.to_dict())
        finish_invocation(invocation, telemetry_binding, agent_result.to_dict(), started, timestamp(),
                          time.monotonic() - start, events_required=False)
    except Exception as error:
        observed['failure_details'] = 'Stopped closed; raw exception/provider text suppressed; no retry'
        observed['failure_type'] = type(error).__name__ if isinstance(error, AgentSystemError) else 'local_failure'
        reviewed = [ROOT / 'agent_system/model_tool_boundary.py', ROOT / 'agent_system/codex_tool_session.py']
        literals = {node.value for source in reviewed for node in ast.walk(ast.parse(source.read_text()))
                    if isinstance(node, ast.Constant) and isinstance(node.value, str)}
        if isinstance(error, AgentSystemError) and str(error) in literals:
            observed['safe_failure_reason'] = str(error)
        if 'relay' in locals():
            observed['safe_relay_denials'] = [v if v in literals else 'denied' for v in relay.failures]
    finally:
        subprocess.Popen, boundary.build_opener = real_popen, real_opener
        if bridge:
            bridge.close()
            observed['tool_calls'] = bridge.calls
        if 'gate' in locals():
            observed['model_requests'] = gate.requests
            observed['gated_call_count'] = len(gate.authorized_arguments)
        if session:
            observed['codex_process_exited'] = session.process.poll() is not None
        if invocation and (invocation / 'model-home').exists():
            home = (invocation / 'model-home').resolve()
            assert home.is_relative_to(invocation.resolve())
            regular_tree(home)
            shutil.rmtree(home)
            observed['ephemeral_model_home_removed'] = True
        if runner:
            observed['stale_owned_containers'] = len(runner.stale_executions())
        observed['response_event_types'] = sorted(set(observed['response_event_types']))
        atomic_json(observation_path, observed)
    print(json.dumps(observed))
    return 0 if observed['verdict'] == 'PASS_LIVE_SMOKE' else 1


if __name__ == '__main__':
    raise SystemExit(main())
