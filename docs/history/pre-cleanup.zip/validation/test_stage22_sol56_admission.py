"""Refresh existing source-bound admission after Stage21A; synthetic provider only."""
import ast
import hashlib
import json
from pathlib import Path

import test_stage18c_real as measured
from agent_system.git import git
from agent_system.storage import atomic_json


def test_current_stage22_transport_admission(project, hardened, tmp_path, monkeypatch):
    hardened[0]['task_id'] = 'STAGE21A-ADMISSION'
    source = Path(measured.__file__).read_text().replace("match='cancel'", "match='(?i)cancel'")
    source = source.replace("'gpt-5.4'", "'gpt-6-luna'")  # synthetic route; zero inference
    tree = ast.parse(source)
    function = next(n for n in tree.body if isinstance(n, ast.FunctionDef)
                    and n.name == 'test_fresh_stage18c_transport_and_adversarial_boundary')
    stop = next(i for i, node in enumerate(function.body)
                if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
                and isinstance(node.value.func, ast.Name) and node.value.func.id == 'git')
    function.body = function.body[:stop] + [ast.Return(ast.Call(ast.Name('locals', ast.Load()), [], []))]
    function.decorator_list = []
    namespace = dict(measured.__dict__)
    exec(compile(ast.fix_missing_locations(ast.Module(body=[function], type_ignores=[])), measured.__file__, 'exec'), namespace)
    result = namespace[function.name](project, hardened, tmp_path, monkeypatch)
    runner, workspace, proof = result['runner'], result['workspace'], result['proof']
    result['bridge2'].close()
    runner.cancel_event.clear()
    runner.require_transport_admission()
    git(workspace, 'checkout', '--', 'src/example.py')
    assert not runner.stale_executions()
    root = Path(__file__).resolve().parents[1]
    hashes = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sorted((root / 'agent_system').rglob('*.py'))}
    # Credentials are never opened. This is the existing admission probe prefix,
    # stopped before its unrelated Controller workflow/factory demonstration.
    evidence = {**proof, 'signed_admission': True, 'binding': runner.preflight(),
        'source_sha256': hashes, 'source_bundle_sha256': hashlib.sha256(json.dumps(hashes,
            sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
        'attestation_directory': str(result['store'].directory), 'project': str(project),
        'runtime': str(tmp_path / 'runtime'), 'workspace': str(workspace),
        'full_workflow_executed': False, 'real_oauth_used': False, 'live_authorization_issued': False,
        'synthetic_route': 'gpt-6-luna/low', 'validation_only': True,
        'source_of_probes': 'Existing Stage18c admission prefix; no production policy changes'}
    atomic_json(root / 'docs/stage22-sol56-evidence/fresh-admission.json', evidence)
