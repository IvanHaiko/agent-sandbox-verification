"""Export synthetic Stage 17 workflow results, never Controller key files."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    records = []
    for case in sorted(args.source.iterdir()):
        if not case.is_dir():
            continue
        for runs in case.glob('runtime/*/runs'):
            for source in sorted(runs.rglob('*.json')):
                if source.is_symlink():
                    raise RuntimeError('Refusing linked workflow evidence')
                relative = Path(case.name) / source.relative_to(runs)
                target = args.output / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, target)
                records.append({'file': relative.as_posix(), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()})
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / 'manifest.json').write_text(json.dumps({'version': 1,
        'source': str(args.source.resolve()), 'key_exported': False,
        'scope': 'JSON evidence of synthetic real-container workflows only', 'files': records}, indent=2), encoding='utf-8')
    print(json.dumps({'files': len(records), 'key_exported': False}))


if __name__ == '__main__':
    main()
