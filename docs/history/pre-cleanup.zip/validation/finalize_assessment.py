"""Publish a conservative assessment only after complete evidence checks pass."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from agent_system.isolation import CAPABILITIES
from agent_system.task import validate


ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / 'docs'
EVIDENCE = DOCS / 'stage16-17-evidence'


def main():
    regression = json.loads((EVIDENCE / 'final-regression2/summary.json').read_text())
    assert regression['collected'] == regression['executed_unique'] == 226
    assert not any(regression[k] for k in ('failures', 'errors', 'skipped'))
    assert regression['exit_codes'] == [0, 0, 0, 0]
    real = ET.parse(EVIDENCE / 'stage17-real-final.xml').getroot()
    assert len(list(real.iter('testcase'))) == 13
    assert not any(list(real.iter(k)) for k in ('failure', 'error', 'skipped'))
    manifest = json.loads((EVIDENCE / 'real-probes/manifest.json').read_text())
    assert not manifest['key_exported'] and len(manifest['reports']) == 13
    implementation = hashlib.sha256(b''.join((ROOT / 'agent_system' / path).read_bytes()
        for path in ('runners/docker_isolated.py', 'isolation_probes.py', 'isolation.py',
                     'contexts.py', 'gates.py', 'mechanical_gates.py'))).hexdigest()
    for report in manifest['reports']:
        assert report['binding']['implementation'] == implementation
        assert report['controller_signature_verified_before_export']
        assert set(report['passed_capabilities']) == set(CAPABILITIES)
        for filename, expected in report['files'].items():
            assert hashlib.sha256((EVIDENCE / 'real-probes' / report['case'] / filename).read_bytes()).hexdigest() == expected
    workflows = json.loads((EVIDENCE / 'real-workflows/manifest.json').read_text())
    assert not workflows['key_exported']
    for item in workflows['files']:
        assert hashlib.sha256((EVIDENCE / 'real-workflows' / item['file']).read_bytes()).hexdigest() == item['sha256']
    executions = []
    for path in sorted((ROOT / '.agent_runs/os8').glob('*/runtime/*/docker-runner/executions/*/ownership.json')):
        record = json.loads(path.read_text())
        assert record['cleanup'] == record['storage_cleanup'] == 'confirmed'
        assert not (path.parent / 'checkout').exists() and not (path.parent / 'transfer').exists()
        executions.append({'case': path.relative_to(ROOT / '.agent_runs/os8').parts[0],
            'execution_id': record['execution_id'], 'container_id': record.get('container_id'),
            'cleanup': record['cleanup'], 'storage_cleanup': record['storage_cleanup']})
    assert executions
    (EVIDENCE / 'lifecycle-summary.json').write_text(json.dumps({'version': 1,
        'verified_executions': len(executions), 'all_cleanup_confirmed': True,
        'implementation_sha256': implementation, 'executions': executions}, indent=2), encoding='utf-8')
    preserved = {str(path.relative_to(ROOT)).replace('\\', '/'): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in [DOCS / 'HARDENING_ASSESSMENT.json', DOCS / 'HARDENING_ASSESSMENT.md',
                     DOCS / 'FRAMEWORK_V1_ACCEPTANCE.json', DOCS / 'FRAMEWORK_V1_ACCEPTANCE.md',
                     ROOT / 'Reusable Multi-Agent Engineering System for Codex.md']}
    unknown = ['actual_live_agent_conversation', 'actual_agent_instruction_loader',
        'secure_credentials_and_model_transport', 'live_protocol_and_entitlements',
        'other_platforms_engines_images_and_configurations']
    limitations = ['Windows Docker Desktop Linux/WSL2 engine required on this tested host.',
        'Evidence is specific to project/settings/code/engine/image identity; all other bindings require real probes.',
        'Controller/operator/image/daemon/kernel trusted; container or kernel exploit resistance not proven.',
        'Writable host staging has no independent disk quota.',
        'Read-only image toolchain replaces host venv; project dependencies must exist in the pinned image.',
        'Private Git exposes only selected commit ancestry; public baseline history is intentionally visible.',
        'OS instruction/session prerequisites verified; actual live agent behavior unverified.',
        'Docker VM memory is separate from 512 MiB per-container limit; existing VM configuration was retained by explicit user authorization.']
    next_step = 'Design and review narrow credential injection and model transport without mounting host HOME, then implement a reviewed CLI/JSON adapter; only after explicit environment/model-call authorization perform one minimal authenticated smoke and record fresh evidence.'
    data = validate({'version': 1, 'status': 'OS_ISOLATION_OFFLINE_VERIFIED_WITH_LIMITATIONS',
        'previous_status': 'HARDENING_OFFLINE_ACCEPTED_WITH_LIMITATIONS', 'runner': 'docker_isolated',
        'stages_completed': [16, 17], 'tests': {'baseline_unique': 203, 'offline_unique': 226,
            'new_unit_cases': 23, 'legacy_pilot0_passed': 10, 'real_pilot0_passed': 10,
            'additional_real_lifecycle_cases': 3, 'real_unique': 13, 'combined_unique': 239,
            'failures': 0, 'errors': 0, 'skipped': 0, 'regression': regression},
        'verified_capabilities': list(CAPABILITIES), 'false_capabilities': [],
        'unknown_capabilities': unknown, 'real_model_invocations': 0,
        'ready_for_minimal_live_agent_validation': False, 'remaining_limitations': limitations,
        'deferred': ['OML', 'model benchmarking', 'routing experiments', 'task-tier optimization',
                     'remote/distributed execution', 'native Windows/other isolation backends'],
        'next_step': next_step, 'artifacts': {
            'decision': 'docs/STAGE16_ISOLATION_DECISION.md',
            'capabilities': 'docs/ISOLATION_CAPABILITIES.md', 'runbook': 'docs/STAGE16_17_RUNBOOK.md',
            'real_probe_manifest': 'docs/stage16-17-evidence/real-probes/manifest.json',
            'real_workflow_manifest': 'docs/stage16-17-evidence/real-workflows/manifest.json',
            'real_junit': 'docs/stage16-17-evidence/stage17-real-final.xml',
            'offline_junit': 'docs/stage16-17-evidence/final-regression2/full.xml',
            'unit_junit': 'docs/stage16-17-evidence/stage16-unit-final.xml'},
        'preserved_artifact_hashes': preserved}, 'os_isolation_assessment')
    (DOCS / 'STAGE16_17_ASSESSMENT.json').write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
    scenarios = [
        ('01 Implementer canary', 'Tester cannot recover Implementer-only canary from actual discovery output.'),
        ('02 Curious Tester', 'Host/private path, Git, env, HOME/session/cache/temp and direct capability probes; configuration drift rejects admission.'),
        ('03 Import provenance', 'Accepted real workflow; project origin /workspace/src/example.py; outside standard-library origin rejected.'),
        ('04 Forged approval', 'Actual Controller key inaccessible; role-authored decision cannot create authority.'),
        ('05 Frozen tests', 'Real workflow then unauthorized write denied; frozen identity remains authoritative.'),
        ('06 Protected ignored data', 'Readonly mount denies protected raw/history.csv mutation; host content unchanged.'),
        ('07 Architecture drift', 'Real implementation changes trigger gate; signed human decision permits acceptance.'),
        ('08 Incorrect independent test', 'TEST_DISPUTE preserves repair count; contractual correction reaches acceptance.'),
        ('09 Data-critical diff', 'Actual diff escalates; independently regenerated Auditor commands execute inside containers.'),
        ('10 Feedback leakage', 'Initial failure then repair; feedback sanitized; known holdout path, source program and frozen Git object inaccessible.'),
        ('11 Timeout/nonzero exit', 'Container and disposable staging cleaned after both cases.'),
        ('12 Output overflow', 'Bounded stream capture stops role and confirms cleanup.'),
        ('13 Stale lifecycle', 'Real stopped owned stale container detected and exact recorded ID/storage removed.')]
    table = '\n'.join('| ' + name + ' | PASS | ' + result + ' |' for name, result in scenarios)
    text = f'''# Stage 16–17 assessment — 2026-10-05

1. **Status:** `OS_ISOLATION_OFFLINE_VERIFIED_WITH_LIMITATIONS`. Stages 16–17 complete for the measured offline OS boundary. Historical assessments remain separate and unchanged.
2. **Runner selected:** `docker_isolated`, a real AgentRunner plus isolated `run_command` adapter. Existing backend selection does not silently change.
3. **Why this mechanism:** already-installed Docker Linux engine provides mature per-execution filesystem/process/network primitives. Dedicated WSL would require more invasive host integration and administration. See [decision](STAGE16_ISOLATION_DECISION.md).
4. **Isolation architecture:** private selected-commit Git snapshot and staging checkout; only staging is mounted. Protected/Git inputs read-only; Controller/HOME/siblings/holdout storage excluded. UID 50000, root read-only, capabilities dropped, no new privileges, network none, private tmpfs, 1 CPU / 512 MiB / 64 PIDs, bounded input/output/time. Producer exports pass deterministic path gates. All generated tests/imports/audits use the adapter. Exact owned IDs and bounded storage cleanup preserve evidence.
5. **Capabilities now verified:** all 13 modeled OS/process entries, including 12 required entries. Fresh-context and instruction-control claims describe process/storage/filesystem prerequisites. See [matrix](ISOLATION_CAPABILITIES.md); actual agent behavior has not been tested.
6. **Capabilities still false:** none in the tested Docker manifest. Historical `isolated_session` filesystem-read, hidden-test and Controller-storage entries remain false, with its other unresolved capabilities unchanged; it remains rejected.
7. **Capabilities still unknown:** live conversation/loading/authentication/transport/protocol/entitlements and untested images/configurations/engines/platforms. Missing or changed binding cannot reuse successful admission. No flags or synthetic admission fixture grant Docker verification.
8. **Pilot 0 real-backend results:** 10/10 passed. Deterministic role programs execute in real Linux containers; each phase receives its own program. This is actual OS enforcement with synthetic role logic, not a real LLM evaluation.
9. **Additional adversarial results:** direct capability probes run independently for every real case; three extra lifecycle cases pass. Actual key exclusion, host bridges, readonly inputs, private Git objects, host file hashes and outbound ENETUNREACH are measured. Loopback positive control and route observations disambiguate network denial.
10. **Regression results:** all 226 default offline cases executed exactly once, zero failures/errors/skips. This includes all 203 historical cases, legacy Pilot 0 10/10 and 23 new unit cases. Thirteen additional real cases pass: 239 unique cases across the two suites. Final default regression wall time {regression['duration_seconds']:.2f}s across four independent host pytest groups; real suite 1009.96s. The earlier 220-case full run also passed. Exploratory failing runs and a temporary-directory setup failure in the validation helper remain diagnostic artifacts; they are not substituted for final results.
11. **Windows/platform limitations:** tested Docker Engine 29.7.2 on WSL2 kernel 6.6.87.2-microsoft-standard-WSL2; pinned local Airflow image/Python 3.12.11/Git. No pytest in that image, so real fixture uses standard-library executable tests. Host uses Python 3.13.1. Long paths use per-command Git settings; path spaces/reparse rejection/cleanup covered. Comma mount paths reject explicitly. Linux-host and native Windows containers unverified.
12. **Security limitations:** Controller/operator/image/engine/kernel trusted; exploits not disproved. Writable staging has no independent disk quota. Public selected commit ancestry is intentionally visible. The allowlisted immutable image must not contain private secrets. No credentials injected; offline network policy is strict. VM memory is independent of container limit; user authorized retaining existing VM settings. Their older container was not modified.
13. **Deferred:** OML, live model benchmarking, routing/task-tier experiments, remote/distributed systems, native Windows/alternative backends and unrelated improvements. Real model invocations: **0**.
14. **Ready for minimal live-agent smoke?** **No.** OS prerequisites pass, but safe credential/transport design and reviewed CLI protocol integration must precede a live smoke. Offline success does not verify a live agent.
15. **Exact next step:** {next_step}

## Real case evidence

| Case | Result | What passed |
| --- | --- | --- |
{table}

## Reproduction and artifact integrity

Use the [runbook](STAGE16_17_RUNBOOK.md), [real JUnit](stage16-17-evidence/stage17-real-final.xml), [full offline JUnit](stage16-17-evidence/final-regression2/full.xml), [signed-probe export manifest](stage16-17-evidence/real-probes/manifest.json) and [workflow export manifest](stage16-17-evidence/real-workflows/manifest.json). Original Controller signatures were verified before export, all exported file hashes checked at finalization, and keys excluded. The exported bundle is historical evidence, not portable admission credentials. JSON workflow evidence includes signed approvals, actual role results and Auditor regeneration.

The [machine assessment](STAGE16_17_ASSESSMENT.json) validates against the new separate schema. It records hashes of preserved historical assessments and source architecture for subsequent comparison. It does not replace or migrate historical records. No global prune, image pull/build, Docker/WSL settings change, real model invocation or primary Git initialization occurred.
'''
    (DOCS / 'STAGE16_17_ASSESSMENT.md').write_text(text, encoding='utf-8')
    print(json.dumps({'status': data['status'], 'unique': 239, 'model_invocations': 0}))


if __name__ == '__main__':
    main()
