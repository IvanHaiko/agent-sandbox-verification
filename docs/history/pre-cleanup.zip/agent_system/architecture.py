import re

from .errors import AgentSystemError
from .policies import matches
from .task import validate


SENSITIVE_CATEGORIES = {
    "service_boundary", "storage", "database", "public_api", "data_model", "deployment",
    "security", "platform", "destructive_migration", "temporal_semantics", "identity_resolution",
    "public_schema", "source_of_truth", "dependency_direction", "permission_boundary", "migration_strategy",
    "agent_topology", "approval_gate",
}


def architecture_reasons(task, project):
    declaration = task.get("architecture", {})
    categories = set(declaration.get("categories", []))
    sensitive = SENSITIVE_CATEGORIES | set(project["architecture"].get("sensitive_categories", []))
    reasons = ["category:" + category for category in sorted(categories & sensitive)]
    if declaration.get("proposal"):
        reasons.append("explicit architectural proposal")
    for path in task["scope"]["allowed_paths"]:
        for pattern in project["architecture"].get("sensitive_paths", []):
            if matches(path, pattern) or matches(pattern, path):
                reasons.append("sensitive path:" + path)
    text = (task["title"] + " " + task["objective"]).lower()
    if re.search(r"\b(add|introduce|replace|change|migrate|redesign|remove)\b.{0,100}"
                 r"\b(database|storage technology|public api|public schema|data model|deployment architecture|trust boundary|"
                 r"security boundary|destructive migration|service boundary|temporal semantics|source of truth|"
                 r"identity resolution|migration strategy|approval gate|agent topology)\b", text):
        reasons.append("architecture-sensitive objective")
    return sorted(set(reasons))


def validate_decision(package, task):
    validate(package, "architecture_decision")
    if package["task_id"] != task["task_id"]:
        raise AgentSystemError("Architecture package belongs to a different task")
    options = [option["id"] for option in package["options"]]
    if len(options) != len(set(options)):
        raise AgentSystemError("Architecture option IDs must be unique")
    if package["recommended_option"] is not None and package["recommended_option"] not in options:
        raise AgentSystemError("Architecture recommendation names a nonexistent option")
    return package
