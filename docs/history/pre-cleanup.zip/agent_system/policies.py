from fnmatch import fnmatchcase
import hashlib

from .errors import AgentSystemError
from .git import git
from .roles import ROLES, Role
from .storage import contained


def matches(path, pattern):
    return path == pattern or path.startswith(pattern.rstrip("/") + "/") or fnmatchcase(path, pattern)


def changed_paths(workspace, base):
    tracked = git(workspace, "diff", "--name-only", "-z", "--no-renames", base, "--")
    untracked = git(workspace, "ls-files", "--others", "--exclude-standard", "-z")
    return sorted(set(filter(None, (tracked + "\0" + untracked).split("\0"))))


def check_paths(role: Role, paths, task, project):
    if ROLES[role].read_only and paths:
        raise AgentSystemError(f"Read-only role {role} modified files: {paths}")
    forbidden = [*task["scope"]["forbidden_paths"], *project["protected_paths"],
                 ".git", ".agent_runs", ".agent_worktrees"]
    for path in paths:
        if any(matches(path, pattern) for pattern in forbidden):
            raise AgentSystemError(f"Forbidden modification: {path}")
        if not any(matches(path, pattern) for pattern in task["scope"]["allowed_paths"]):
            raise AgentSystemError(f"Out-of-scope modification: {path}")


def protected_snapshot(root, project):
    """Protect configured data even when it is deliberately untracked/ignored."""
    result = {}
    for pattern in project["protected_paths"]:
        contained(root, pattern.removesuffix("/**"))
        for entry in root.glob(pattern.removesuffix("/**")):
            paths = list(entry.rglob("*")) if entry.is_dir() else [entry]
            for path in paths:
                relative = path.relative_to(root).as_posix()
                contained(root, relative)
                if path.is_file():
                    with path.open("rb") as stream:
                        result[relative] = hashlib.file_digest(stream, "sha256").hexdigest()
    return result


def ignored_snapshot(root):
    """Inspect ignored files as real side effects; caches are not Git diffs."""
    result = {}
    paths = git(root, 'ls-files', '--others', '--ignored', '--exclude-standard', '-z')
    for relative in filter(None, paths.split('\0')):
        path = contained(root, relative)
        if path.is_file():
            with path.open('rb') as stream:
                result[relative] = hashlib.file_digest(stream, 'sha256').hexdigest()
    return result


def path_manifest(root, patterns):
    """Version-3 manifest includes empty directories and symlink identity."""
    result = protected_snapshot(root, {'protected_paths': patterns})
    for pattern in patterns:
        contained(root, pattern.removesuffix('/**'))
        for entry in root.glob(pattern.removesuffix('/**')):
            for path in [entry, *entry.rglob('*')] if entry.is_dir() else [entry]:
                relative = path.relative_to(root).as_posix()
                contained(root, relative)
                if path.is_symlink():
                    result[relative] = 'symlink:' + str(path.readlink())
                elif path.is_dir():
                    result[relative] = 'directory'
    return result
