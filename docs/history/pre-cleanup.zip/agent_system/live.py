"""Explicit live validation and project pilot entry points. Never used by pytest."""
import json
import re
import shlex
import shutil
import subprocess
import sys
from pathlib import Path
from uuid import uuid4

import yaml

from .config import Configuration
from .errors import AgentSystemError
from .evidence import Evidence, digest
from .git import WorktreeManager, git, repository_root, resolve_commit
from .orchestrator import Orchestrator
from .roles import Role
from .state_machine import timestamp
from .storage import contained, read_json
from .task import load_task, validate

STATUSES = ("NOT_RUN", "BLOCKED_BY_ENVIRONMENT", "FAILED", "PASSED")
REQUIRED_FLAGS = ("--ignore-user-config", "--ephemeral", "--json", "--output-last-message", "--sandbox", "--model", "--output-schema")


def safe_diagnostic(exc):
    """Useful failure classes without copying arbitrary backend/auth output."""
    if isinstance(exc, OSError):
        return f"Local filesystem/process error: {type(exc).__name__}, errno={exc.errno}, winerror={getattr(exc, 'winerror', None)}"
    if isinstance(exc, subprocess.TimeoutExpired):
        return "Local preflight command timed out"
    if isinstance(exc, AgentSystemError):
        message = str(exc)
        if "'$GIT_DIR' too big" in message or "Filename too long" in message:
            return "Git for Windows path limit exceeded; use a shorter project/runtime root"
        for marker, diagnostic in (("Telemetry", "Invocation telemetry integrity failed"),
                                   ("Immutable evidence", "Immutable evidence integrity failed"),
                                   ("git ", "Git setup/worktree operation failed; inspect the preserved fixture"),
                                   ("protocol", "Backend protocol validation failed"),
                                   ("schema", "Structured protocol schema validation failed")):
            if marker in message:
                return diagnostic
    return "Local validation failed: " + type(exc).__name__


def backend_preflight(config):
    """No inference, no auth-file inspection, no secret-bearing diagnostic dumps."""
    executable = config.project["runner"]["executable"]
    commands = [[executable, "--version"], [executable, "exec", "--help"], [executable, "login", "status"]]
    version = None
    try:
        checks = [subprocess.run(argv, capture_output=True, encoding="utf-8", errors="replace", timeout=15)
                  for argv in commands]
    except (OSError, subprocess.TimeoutExpired):
        return {"ready": False, "cli_version": None, "commands": commands,
                "diagnostic": "Codex CLI could not be launched or timed out during preflight", "model_access": "unverified"}
    match = re.search(r"codex-cli\s+([0-9]+\.[0-9]+\.[0-9]+[A-Za-z0-9.+-]*)", checks[0].stdout)
    if match:
        version = match[0]
    diagnostic = None
    if checks[0].returncode or checks[1].returncode:
        diagnostic = "Codex CLI version/help preflight failed"
    elif any(flag not in checks[1].stdout for flag in REQUIRED_FLAGS):
        diagnostic = "Installed Codex exec protocol lacks required flags"
    elif checks[2].returncode != 0:
        diagnostic = "Codex login status did not confirm authentication; run codex login"
    return {"ready": diagnostic is None, "cli_version": version, "commands": commands,
            "diagnostic": diagnostic, "model_access": "unverified_until_successful_invocation"}


def project_preflight(config, task):
    """Validate the committed project and command availability before any model call."""
    root = config.root
    if repository_root(root) != root:
        raise AgentSystemError("Pilot must target an existing Git repository root")
    base = resolve_commit(root, task["base_ref"])
    if base != git(root, "rev-parse", "HEAD"):
        raise AgentSystemError("Pilot base must equal the clean committed primary HEAD")
    if git(root, "status", "--porcelain", "--untracked-files=all"):
        raise AgentSystemError("Pilot requires a clean committed working tree, including task/configuration")
    WorktreeManager(config)
    if "workflow" not in task:
        raise AgentSystemError("Pilot requires an executable workflow contract")
    for relative in [*task["workflow"]["public_context"], *task["workflow"]["implementation_context"]]:
        path = contained(root, relative)
        if not path.is_file() or not git(root, "ls-files", "--", relative):
            raise AgentSystemError("Pilot context files must exist and be committed: " + relative)
    for relative in config.project["protected_paths"]:
        if not contained(root, relative.removesuffix("/**")).exists():
            raise AgentSystemError("Configured protected/historical path missing: " + relative)
    argv_list = [shlex.split(command) for command in config.project["testing"]["commands"]]
    argv_list += [c["argv"] for c in task["workflow"]["checks"]]
    argv_list.append(task["workflow"]["independent_command"])
    known = {c["id"] for c in task["workflow"]["checks"]} | {"independent_tests", "reviewer", "data_auditor"}
    if set(task["required_checks"]) - known:
        raise AgentSystemError("Pilot required checks lack executable mappings")
    for argv in argv_list:
        if not argv or shutil.which(argv[0]) is None:
            raise AgentSystemError("Required local executable unavailable")
        if len(argv) >= 3 and argv[1] == "-m":
            check = subprocess.run([argv[0], "-c", "import importlib.util,sys; sys.exit(0 if importlib.util.find_spec(sys.argv[1]) else 1)", argv[2]],
                                   capture_output=True, timeout=15)
            if check.returncode:
                raise AgentSystemError("Required local Python module unavailable: " + argv[2])
    if not config.project.get("live_limits"):
        raise AgentSystemError("Explicit live_limits are required for a pilot")
    return {"base_commit": base, "task_digest": digest(task), "configuration_digest": digest(
            {"project": config.project, "routing": config.routing}), "checks": "PASSED"}


def new_report(config, kind):
    directory = contained(config.runs_dir, "validations/" + str(uuid4()))
    directory.mkdir(parents=True, exist_ok=False)
    report = {"version": 1, "kind": kind, "status": "NOT_RUN", "started_at": timestamp(),
              "finished_at": None, "cli_version": None, "backend": config.project["runner"]["backend"],
              "protocol": "codex exec JSONL, turn.completed usage, output-last-message",
              "routing": config.routing["models"], "commands": [], "executed": False,
              "telemetry_available": False, "sandbox_observations": [], "deviations": [],
              "failures": [], "unresolved_risks": ["Filesystem worktrees are not OS-level read isolation."],
              "fixture_directory": None, "task_id": None, "task_outcome": None,
              "telemetry": None, "evaluation": None}
    Evidence(directory).write("intent", report)
    return directory, report


def save_report(directory, report):
    report["finished_at"] = timestamp()
    Evidence(directory).write("report", validate(report, "live_validation"))
    lines = [f"Live validation: {report['kind']}", f"Status: {report['status']}",
             f"Real role invocation executed: {report['executed']}", *report["failures"],
             "", *report["unresolved_risks"]]
    # Human view is derived, local; JSON envelope remains authoritative.
    (directory / "report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {**report, "report_directory": str(directory)}


def disposable_fixture(directory, config, workflow):
    # Keep disposable repositories beside validation reports. Deeply nesting
    # another task runtime beneath a UUID report hits Git for Windows' fixed
    # internal $GIT_DIR limit even with core.longpaths enabled.
    root = contained(config.runs_dir, "fixtures/" + uuid4().hex[:12])
    root.mkdir(parents=True, exist_ok=False)
    (root / ".agent_system").mkdir()
    project = json.loads(json.dumps(config.project))
    project["project"]["id"] = "live-validation"
    project["protected_paths"] = []
    project["data_critical_patterns"] = []
    project["architecture"] = {"adr_root": "docs/adr", "require_user_approval": True}
    python = sys.executable.replace("\\", "/")
    project["testing"]["commands"] = [shlex.quote(python) + " -m pytest -q"] if workflow else []
    project["runner"]["timeout_seconds"] = min(project["runner"]["timeout_seconds"], 180)
    project["runner"]["max_infrastructure_retries"] = 0
    project["live_limits"] = {"max_role_invocations": 4 if workflow else 1,
                               "max_infrastructure_retries": 0, "max_autonomous_fix_cycles": 0}
    (root / ".agent_system/project.yaml").write_text(yaml.safe_dump(project), encoding="utf-8")
    (root / ".agent_system/models.yaml").write_text(yaml.safe_dump(config.routing), encoding="utf-8")
    (root / ".gitignore").write_text(".agent_runs/\n.agent_worktrees/\n__pycache__/\n.pytest_cache/\n", encoding="utf-8")
    (root / "docs/contracts").mkdir(parents=True)
    (root / "docs/contracts/label.md").write_text("Public interface: src.labels.normalize_label(value: str) -> str.\n"
        "Strip surrounding whitespace, lowercase, join internal whitespace-separated words with one hyphen.\n"
        "An empty or whitespace-only input returns an empty string. Preserve punctuation.\n", encoding="utf-8")
    (root / "src").mkdir()
    (root / "src/labels.py").write_text("def normalize_label(value: str) -> str:\n    return value\n", encoding="utf-8")
    (root / "tests").mkdir()
    (root / "tests/test_baseline.py").write_text("def test_existing_api():\n    from src.labels import normalize_label\n    assert isinstance(normalize_label('x'), str)\n", encoding="utf-8")
    task = {"task_id": "LIVE-WORKFLOW" if workflow else "LIVE-RUNNER", "title": "Normalize public labels" if workflow else "Read-only protocol smoke",
            "objective": "Implement the frozen normalize_label contract." if workflow else
                "Read docs/contracts/label.md without changing any files. Return exactly LIVE_SMOKE_OK.",
            "task_type": "bugfix", "base_ref": "HEAD", "major_phase": False, "data_critical": False,
            "scope": {"allowed_paths": ["src/**", "tests/**"], "forbidden_paths": []},
            "invariants": ["Preserve existing project tests and the public interface."],
            "acceptance_criteria": ["Leading/trailing and repeated whitespace normalize, letters lowercase, punctuation preserved.",
                                    "Empty and whitespace-only input produce an empty string."],
            "required_checks": ["pytest", "independent_tests", "reviewer"] if workflow else [],
            "architecture_change_allowed": False, "completion": {"requires_user_approval": False}}
    if workflow:
        task["workflow"] = {"public_context": ["docs/contracts/label.md"], "implementation_context": ["src/labels.py"],
                            "test_paths": ["tests/acceptance/**"], "independent_command": [python, "-m", "pytest", "-q"],
                            "checks": [{"id": "pytest", "argv": [python, "-m", "pytest", "-q"]}], "test_timeout_seconds": 30}
    task_path = root / "task.yaml"
    task_path.write_text(yaml.safe_dump(validate(task, "task")), encoding="utf-8")
    git(root, "init", "--initial-branch=main")
    # Nested validation evidence creates long paths on Windows. This setting
    # belongs only to the newly created disposable repository.
    git(root, "config", "core.longpaths", "true")
    git(root, "config", "user.name", "Framework Live Validation")
    git(root, "config", "user.email", "validation@example.invalid")
    git(root, "-c", "core.hooksPath=", "add", ".")
    git(root, "-c", "core.hooksPath=", "commit", "-m", "Disposable validation baseline")
    return root, task_path, task


def live_smoke(config, workflow=False, allow_live=False, runner_report=None):
    if not allow_live:
        raise AgentSystemError("Live validation requires --allow-live (real model quota)")
    directory, report = new_report(config, "workflow_smoke" if workflow else "runner_smoke")
    preflight = backend_preflight(config)
    report.update(cli_version=preflight["cli_version"], commands=preflight["commands"])
    if not preflight["ready"]:
        report.update(status="BLOCKED_BY_ENVIRONMENT", failures=[preflight["diagnostic"]])
        return save_report(directory, report)
    if workflow:
        if runner_report is None:
            report.update(status="BLOCKED_BY_ENVIRONMENT", failures=["Provide --runner-report from a successful live runner smoke"])
            return save_report(directory, report)
        try:
            prior = validate(Evidence(Path(runner_report)).read("report"), "live_validation")
        except (AgentSystemError, OSError, ValueError):
            report.update(status="BLOCKED_BY_ENVIRONMENT", failures=["Runner smoke report is missing, malformed or has failed integrity verification"])
            return save_report(directory, report)
        if prior["kind"] != "runner_smoke" or prior["status"] != "PASSED" or not prior["executed"] or prior["routing"] != report["routing"] or prior["cli_version"] != report["cli_version"]:
            report.update(status="BLOCKED_BY_ENVIRONMENT", failures=["Runner smoke must pass with the same CLI version and routing"])
            return save_report(directory, report)
    try:
        root, task_path, task = disposable_fixture(directory, config, workflow)
        report.update(fixture_directory=str(root), task_id=task["task_id"])
        orchestrator = Orchestrator(root)
        project_preflight(orchestrator.config, task) if workflow else None
        orchestrator.plan(task_path)
        if workflow:
            state = orchestrator.resume(task["task_id"])
            report["task_outcome"] = state["state"]
            from .evaluation import build_reports
            report["telemetry"], report["evaluation"] = build_reports(orchestrator.run_dir(task["task_id"]))
            report["status"] = "PASSED" if state["state"] == "ACCEPTED" else "FAILED"
        else:
            orchestrator.resume(task["task_id"])
            from .runners import create_runner
            bundle = {"task_id": task["task_id"], "role": "reviewer", "files": ["docs/contracts/label.md"],
                      "implementation_visible": False, "agent_history_visible": False}
            result = create_runner(orchestrator.config).run(Role.REVIEWER, config.model_for(Role.REVIEWER), bundle,
                          orchestrator.config.worktrees_dir / task["task_id"] / "reviewer", task)
            report["status"] = "PASSED" if result.status == "success" and result.message.strip() == "LIVE_SMOKE_OK" else "FAILED"
            report["task_outcome"] = result.status
        invocation_root = orchestrator.run_dir(task["task_id"]) / "invocations"
        folders = list(invocation_root.glob("*"))
        report["executed"] = bool(folders)
        report["telemetry_available"] = bool(folders) and all(Evidence(p).exists("telemetry") for p in folders)
        report["commands"] += [read_json(p / "command.json") for p in folders if (p / "command.json").exists()]
        report["sandbox_observations"] = ["Primary committed HEAD and tracked files unchanged" if
            not git(root, "status", "--porcelain", "--untracked-files=all") else "Primary checkout changed"]
        if git(root, "status", "--porcelain", "--untracked-files=all"):
            report["status"] = "FAILED"
        if report["status"] == "FAILED":
            report["failures"].append("Role protocol, isolation or mandatory workflow acceptance failed; inspect local invocation evidence")
            report["deviations"].append("Live behavior did not meet offline validated expectations")
    except (AgentSystemError, OSError, ValueError, subprocess.TimeoutExpired) as exc:
        report.update(status="FAILED", failures=[safe_diagnostic(exc)])
        if report["fixture_directory"]:
            report["executed"] = bool(list((Path(report["fixture_directory"]) / ".agent_runs").glob("*/invocations/*/result.json")))
    return save_report(directory, report)


def pilot(config, task_path, allow_live=False):
    if not allow_live:
        raise AgentSystemError("Pilot requires --allow-live (real model quota)")
    directory, report = new_report(config, "project_pilot")
    try:
        task = load_task(task_path)
        report["task_id"] = task["task_id"]
        project_preflight(config, task)
        preflight = backend_preflight(config)
        report.update(cli_version=preflight["cli_version"], commands=preflight["commands"])
        if not preflight["ready"]:
            report.update(status="BLOCKED_BY_ENVIRONMENT", failures=[preflight["diagnostic"]])
            return save_report(directory, report)
    except (AgentSystemError, OSError, ValueError, subprocess.TimeoutExpired) as exc:
        report.update(status="BLOCKED_BY_ENVIRONMENT", failures=["Deterministic project preflight failed: " + str(exc)])
        return save_report(directory, report)
    try:
        orchestrator = Orchestrator(config.root)
        # Ordinary workflow retains all human gates; no automatic approval here.
        orchestrator.plan(task_path)
        state = orchestrator.resume(task["task_id"])
        from .evaluation import build_reports
        report["telemetry"], report["evaluation"] = build_reports(orchestrator.run_dir(task["task_id"]))
    except (AgentSystemError, OSError, ValueError) as exc:
        report.update(status="FAILED", failures=[safe_diagnostic(exc)])
        report["executed"] = bool(list((config.runs_dir / task['task_id'] / 'invocations').glob('*/result.json')))
        return save_report(directory, report)
    report.update(task_outcome=state["state"], executed=report["telemetry"]["invocation_count"] > 0,
                  telemetry_available=not report["telemetry"]["telemetry_unavailable"],
                  status="PASSED" if state["state"] == "ACCEPTED" else "FAILED")
    report["commands"] += [read_json(p) for p in (orchestrator.run_dir(task['task_id']) / 'invocations').glob('*/command.json')]
    if state['state'] in ("ARCHITECTURE_DECISION_REQUIRED", "USER_COMPLETION_APPROVAL"):
        report["failures"].append("Acceptance validation incomplete: explicit human gate remains pending")
        report["unresolved_risks"].append("Pilot awaiting explicit human gate; resume and inspect final task telemetry/evaluation afterwards")
    return save_report(directory, report)
