import subprocess
import os
from pathlib import Path

from .errors import AgentSystemError
from .storage import atomic_json, contained, read_json
from .task import validate


def git(root: Path, *args: str) -> str:
    windows_options = ["-c", "core.longpaths=true"] if os.name == 'nt' else []
    result = subprocess.run(["git", *windows_options, "-C", str(root), *args], capture_output=True, encoding="utf-8", errors="replace")
    if result.returncode:
        raise AgentSystemError(f"git {' '.join(args)}: {result.stderr.strip()}")
    return result.stdout.strip()


def repository_root(path: Path) -> Path:
    return Path(git(path, "rev-parse", "--show-toplevel")).resolve()


def resolve_commit(root: Path, ref: str) -> str:
    if ref.startswith("-"):
        raise AgentSystemError("Git refs cannot start with '-'")
    return git(root, "rev-parse", "--verify", ref + "^{commit}")


def registered_worktrees(root: Path) -> dict:
    result = {}
    for block in git(root, "worktree", "list", "--porcelain").split("\n\n"):
        fields = dict(line.split(" ", 1) for line in block.splitlines() if " " in line)
        if "worktree" in fields:
            result[str(Path(fields["worktree"]).resolve())] = fields
    return result


class WorktreeManager:
    """Own only explicitly recorded worktrees; never delete branches or force cleanup."""

    NAMES = ("implementer", "tester", "integration", "reviewer", "auditor", "orchestrator")

    def __init__(self, config):
        self.config = config
        self.root = config.root
        if repository_root(self.root) != self.root:
            raise AgentSystemError("Project root must be the Git repository root")
        self.check_ignored()

    def check_ignored(self):
        for directory in (".agent_runs", ".agent_worktrees"):
            if git(self.root, "ls-files", "--", directory):
                raise AgentSystemError(f"Runtime artifacts are already tracked: {directory}")
            if self.config.project['runtime'].get('version') == 2:
                # External storage does not require repository-local runtime
                # directories or their old ignore layout. Tracked legacy logs
                # still fail closed because they would enter baseline bundles.
                continue
            result = subprocess.run(
                ["git", "-C", str(self.root), "check-ignore", "--no-index", "-q", directory + "/privacy-probe"],
                capture_output=True,
            )
            if result.returncode:
                raise AgentSystemError(f"Add {directory}/ to .gitignore before preparation")

    def manifest_path(self, task_id):
        validate({"task_id": task_id, "role": "utility", "files": [],
                  "implementation_visible": False, "agent_history_visible": False}, "context")
        return contained(self.config.runs_dir, task_id) / "worktrees.json"

    def prepare(self, task_id: str, base_commit: str, data_critical: bool, include_architect=False, isolated_tester=False):
        manifest_path = self.manifest_path(task_id)
        names = ["implementer", "tester", "integration", "reviewer"]
        if data_critical:
            names.append("auditor")
        if include_architect:
            names.append("orchestrator")
        expected = {
            "task_id": task_id,
            "base_commit": base_commit,
            "worktrees": {
                name: {"path": str(contained(self.config.worktrees_dir, f"{task_id}/{name}")),
                       "branch": f"agent/{task_id}/{name}"}
                for name in names
            },
        }
        if isolated_tester:
            for name in ('tester', 'implementer'):
                expected['worktrees'][name]['kind'] = 'isolated_checkout'
        if manifest_path.exists():
            old = read_json(manifest_path)
            if isolated_tester and old != expected and old == {**expected, 'worktrees': {k: v for k, v in expected['worktrees'].items() if k != 'auditor'}}:
                entry = expected['worktrees']['auditor']
                if Path(entry['path']).exists() or git(self.root, 'branch', '--list', entry['branch']):
                    raise AgentSystemError('Unowned auditor escalation checkout')
                atomic_json(manifest_path, expected)
            elif old != expected:
                raise AgentSystemError("Worktree manifest conflicts with this task")
        else:
            # Validate all collisions before recording intent. Partial creation is resumable.
            registrations = registered_worktrees(self.root)
            for entry in expected["worktrees"].values():
                if Path(entry["path"]).exists() or entry["path"] in registrations:
                    raise AgentSystemError(f"Unowned worktree path: {entry['path']}")
                if git(self.root, "branch", "--list", entry["branch"]):
                    raise AgentSystemError(f"Unowned branch: {entry['branch']}")
            atomic_json(manifest_path, expected)
        for entry in expected["worktrees"].values():
            if entry.get('kind') == 'isolated_checkout':
                from .isolation import IsolatedCheckout
                IsolatedCheckout.create(self.root, Path(entry['path']), base_commit,
                                        manifest_path.parent / 'controller' / 'checkouts' / Path(entry['path']).name)
            else:
                self._ensure(entry, base_commit)
        return expected

    def _ensure(self, entry, base):
        path = Path(entry["path"])
        registrations = registered_worktrees(self.root)
        registered = registrations.get(str(path))
        if registered:
            if registered.get("branch") != "refs/heads/" + entry["branch"]:
                raise AgentSystemError(f"Unexpected branch at {path}")
            if not path.is_dir():
                raise AgentSystemError(f"Registered worktree is missing: {path}; repair it explicitly")
            # Advanced commits are preserved; the frozen base must remain an ancestor.
            git(path, "merge-base", "--is-ancestor", base, "HEAD")
            return
        if path.exists():
            raise AgentSystemError(f"Refusing to overwrite unregistered path: {path}")
        branch_exists = bool(git(self.root, "branch", "--list", entry["branch"]))
        if branch_exists:
            git(self.root, "merge-base", "--is-ancestor", base, entry["branch"])
            git(self.root, "worktree", "add", str(path), entry["branch"])
        else:
            git(self.root, "worktree", "add", "-b", entry["branch"], str(path), base)

    def cleanup(self, task_id):
        manifest_path = self.manifest_path(task_id)
        if not manifest_path.exists():
            return
        manifest = read_json(manifest_path)
        if manifest["task_id"] != task_id:
            raise AgentSystemError("Worktree task identity mismatch")
        registrations = registered_worktrees(self.root)
        removable = []
        for name, entry in manifest["worktrees"].items():
            if name not in self.NAMES:
                raise AgentSystemError("Unknown worktree in manifest")
            expected_path = contained(self.config.worktrees_dir, f"{task_id}/{name}")
            if entry != {"path": str(expected_path), "branch": f"agent/{task_id}/{name}"}:
                raise AgentSystemError("Worktree manifest ownership mismatch")
            registered = registrations.get(str(expected_path))
            if registered:
                if registered.get("branch") != "refs/heads/" + entry["branch"] or "locked" in registered:
                    raise AgentSystemError(f"Worktree branch mismatch or lock: {expected_path}")
                if git(expected_path, "status", "--porcelain", "--untracked-files=all", "--ignored"):
                    raise AgentSystemError(f"Cleanup would lose dirty or ignored files: {expected_path}")
                removable.append(expected_path)
            elif expected_path.exists():
                raise AgentSystemError(f"Unregistered worktree path: {expected_path}")
        for path in removable:
            git(self.root, "worktree", "remove", str(path))
        # Keep the manifest, runtime reports and branches so resume can recreate checkouts.
