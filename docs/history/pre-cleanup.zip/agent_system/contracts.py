"""Public contract packages exclude implementer scope and implementation context."""
import re

from .errors import AgentSystemError
from .git import git
from .storage import contained


def public_contract(task):
    return {'task_id': task['task_id'], 'contract_version': task['hardening']['contract_version'],
            'objective': task['objective'], 'invariants': task['invariants'],
            'acceptance_criteria': task['acceptance_criteria'],
            'interface': task['hardening']['interface']}


def lint_contract(package, implementation_paths=()):
    import json
    text = json.dumps(package)
    warnings = []
    rules = {
        'private_symbol': r'\b_[A-Za-z][A-Za-z0-9_]*\s*\(',
        'prescriptive_steps': r'\b(?:implement by|first implement|then modify|use an? (?:internal|private)|algorithm must)\b',
        'private_runtime': r'\.agent_(?:runs|worktrees)|controller/key',
        'architecture_hint': r'\b(?:use a singleton|internal cache|private helper)\b',
        'internal_file_path': r'\b(?:src|internal|private)/[^\s"\\]+',
    }
    for code, pattern in rules.items():
        if re.search(pattern, text, re.I):
            warnings.append({'code': code, 'severity': 'warning', 'message': 'Potential implementation leakage; clarify the public contract'})
    for path in implementation_paths:
        if path.rstrip('/*') in text:
            warnings.append({'code': 'implementer_path', 'severity': 'warning', 'message': 'Implementer-only path appears in public contract'})
    return warnings


def interface_package(task, workspace, base):
    package = public_contract(task)
    package['interface_blobs'] = {}
    for path in task['hardening']['interface']['files']:
        contained(workspace, path)
        if path not in task['workflow']['public_context']:
            raise AgentSystemError('Interface files must be explicit public context')
        package['interface_blobs'][path] = git(workspace, 'rev-parse', f'{base}:{path}')
    return package
