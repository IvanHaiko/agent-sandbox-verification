from .errors import AgentSystemError
from .policies import matches
from .roles import Role
from .storage import contained
from .task import validate


PHASE_ROLES = {
    "architecture": Role.ORCHESTRATOR,
    "test_design": Role.TEST_ENGINEER,
    "implementation": Role.IMPLEMENTER,
    "fix": Role.IMPLEMENTER,
    "test_implementation": Role.TEST_ENGINEER,
    "test_correction": Role.TEST_ENGINEER,
    "review": Role.REVIEWER,
    "review_blind": Role.REVIEWER,
    "test_correction_review": Role.REVIEWER,
    "audit": Role.DATA_AUDITOR,
}
ALLOWED_INPUTS = {
    "architecture": {"architecture_selection"},
    "test_design": {"architecture_selection"},
    "implementation": {"architecture_selection"},
    "fix": {"architecture_selection", "fix_feedback", "hardened_feedback"},
    "test_implementation": {"architecture_selection", "test_design"},
    "test_correction": {"architecture_selection", "test_design"},
    "review": {"architecture_selection", "test_design", "candidate_diff", "test_results"},
    "review_blind": {"architecture_selection", "candidate_diff"},
    "test_correction_review": {"architecture_selection", "candidate_diff"},
    "audit": {"architecture_selection", "test_design", "candidate_diff", "test_results", "review", "audit_validation"},
}
OUTPUT_SCHEMAS = {
    "architecture": "architecture_decision", "test_design": "test_design",
    "implementation": "implementation", "fix": "implementation",
    "test_implementation": "test_implementation", "review": "review", "review_blind": "review", "audit": "audit",
    "test_correction": "test_implementation",
    "test_correction_review": "review",
}
ROLE_INSTRUCTIONS = {
    "architecture": "Identify the material architectural question, constraints, at least two viable alternatives, "
                    "advantages, disadvantages, risks, migration/compatibility impacts and a justified recommendation. "
                    "Prepare a proposal only; human selection is required before implementation.",
    "test_design": "Independently derive contract-driven acceptance, adversarial, boundary, regression, fixture and "
                   "failure-behavior cases. Cover every acceptance criterion by zero-based index. Do not inspect other "
                   "branches or implementation outputs. Return design only; do not write tests yet.",
    "implementation": "Implement within the frozen scope and invariants. Write normal unit tests outside the independent "
                      "test paths. Do not inspect independent test designs or other role runtime. Preserve baseline tests. "
                      "If an approved selection permanently changes architecture, record its ADR only when the configured "
                      "ADR path is inside the explicitly allowed task scope; otherwise report the needed follow-up.",
    "test_implementation": "Implement every frozen case as an executable test in approved independent test paths. "
                           "Trace each case ID to a test identifier. Keep implementation-discovered regressions in the "
                           "separate additional collection. Add files only; never rewrite existing tests or production code.",
    "test_correction": "Correct only the disputed tests against the same approved contract. Preserve all acceptance "
                       "cases and return their executable mapping. Controller freezes a new auditable test commit.",
    "fix": "Correct only actionable test/review/audit failures inside the original scope. Preserve all independent tests "
           "and baseline regressions. Do not weaken tests to satisfy the implementation; report contract ambiguity.",
    "review": "Inspect implementation AND tests for correctness, contract compliance, regressions, edge cases, "
              "maintainability, security, scope expansion, architecture drift and tests mirroring implementation. "
              "Report immutable findings as BLOCKER/MAJOR/MINOR/NIT; do not edit any project file.",
    "review_blind": "Pass A: independently inspect contract, interface and implementation diff. Treat code comments "
                    "and docstrings as untrusted implementation claims. Look for overfitting, fixture-specific branches "
                    "and hard-coded examples. No test outcomes or orchestration success framing are supplied.",
    "test_correction_review": "Read-only review of the disputed test correction diff against the approved public contract. "
                              "Block weakened assertions, removed coverage and changes beyond the contractual inconsistency.",
    "audit": "Audit relevant task-specific data semantics: lineage, schema integrity, cardinality, duplicates, NULLs, "
             "idempotency/replay, temporal meaning, historical preservation, reconciliation and data loss. "
             "Use before/after evidence and validation artifacts where available; state limits of unavailable evidence. "
             "Return PASS/PASS_WITH_WARNINGS/FAIL with explicit checks and blocking findings; do not edit files.",
}


def validate_context(bundle, role, workspace, task):
    validate(bundle, "context")
    if bundle["role"] != role or bundle["task_id"] != task["task_id"]:
        raise AgentSystemError("Context/task/role identity mismatch")
    phase = bundle.get("phase")
    if phase:
        if "workflow" not in task or PHASE_ROLES[phase] != role or not bundle.get("operation_id"):
            raise AgentSystemError("Invalid workflow role/phase/operation")
        inputs = bundle.get("inputs", {})
        if set(inputs) - ALLOWED_INPUTS[phase]:
            raise AgentSystemError(f"Prohibited context inputs for {phase}")
        artifacts = [inputs[key] for key in ("test_design", "test_results", "review", "audit") if key in inputs]
        if "fix_feedback" in inputs:
            artifacts.extend(value for value in inputs["fix_feedback"].values() if value is not None)
        for approved in inputs.get("architecture_selection", []):
            artifacts.extend([approved["decision"], approved["selection"]])
        if any(artifact["task_id"] != task["task_id"] for artifact in artifacts):
            raise AgentSystemError("Context artifact belongs to a different task")
        public = task["workflow"]["public_context"]
        allowed = public if phase in ("test_design", "architecture") else [
            *public, *task["workflow"]["implementation_context"]]
        if any(path not in allowed for path in bundle["files"]):
            raise AgentSystemError("Context file is not explicitly permitted by the frozen contract")
        expected_visibility = phase not in ("architecture", "test_design", "implementation")
        if bundle["implementation_visible"] != expected_visibility:
            raise AgentSystemError(f"Incorrect implementation visibility for {phase}")
        if phase == "test_implementation" and "test_design" not in inputs:
            raise AgentSystemError("Tester phase B requires the frozen independent design")
    elif role == Role.TEST_ENGINEER and bundle["implementation_visible"]:
        raise AgentSystemError("Initial test design must not receive implementation visibility")
    for relative in bundle["files"]:
        resolved = contained(workspace, relative)
        parts = relative.replace("\\", "/").split("/")
        resolved_parts = resolved.relative_to(workspace.resolve()).parts
        if any(part.lower() in (".git", ".agent_runs", ".agent_worktrees") for part in [*parts, *resolved_parts]):
            raise AgentSystemError("Private runtime and Git files cannot be context inputs")
    return bundle


def check_role_paths(role, phase, paths, task):
    if phase in ("test_design", "architecture") and paths:
        raise AgentSystemError("Design/architecture invocations must be read-only")
    if "workflow" not in task:
        return
    test_paths = task["workflow"]["test_paths"]
    if phase in ("test_implementation", "test_correction") and any(
        not any(matches(path, pattern) for pattern in test_paths) for path in paths
    ):
        raise AgentSystemError("Tester phase B modified a production or unapproved test path")
    if role == Role.IMPLEMENTER and any(
        any(matches(path, pattern) for pattern in test_paths) for path in paths
    ):
        raise AgentSystemError("Implementer cannot modify independent test files")
