"""Reusable engineering foundation. Role workflows are deliberately not implemented."""

