from dataclasses import dataclass
from enum import StrEnum


class Role(StrEnum):
    ORCHESTRATOR = "orchestrator"
    IMPLEMENTER = "implementer"
    TEST_ENGINEER = "test_engineer"
    REVIEWER = "reviewer"
    DATA_AUDITOR = "data_auditor"
    UTILITY = "utility"


@dataclass(frozen=True)
class RoleDefinition:
    workspace_name: str | None
    read_only: bool
    gating: bool


ROLES = {
    Role.ORCHESTRATOR: RoleDefinition(None, True, True),
    Role.IMPLEMENTER: RoleDefinition("implementer", False, False),
    Role.TEST_ENGINEER: RoleDefinition("tester", False, True),
    Role.REVIEWER: RoleDefinition("reviewer", True, True),
    Role.DATA_AUDITOR: RoleDefinition("auditor", True, True),
    Role.UTILITY: RoleDefinition(None, True, False),
}

