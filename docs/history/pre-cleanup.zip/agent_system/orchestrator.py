import fnmatch
from pathlib import Path

from .config import Configuration
from .errors import AgentSystemError
from .git import WorktreeManager, resolve_commit
from .state_machine import State, initial_state, transition, validate_history
from .storage import atomic_json, contained, lock, read_json
from .task import load_task, validate
from .evidence import Evidence, digest
from .workflow import Workflow


class Orchestrator:
    """Prepare legacy runs or execute a versioned full engineering workflow."""

    def __init__(self, root: Path, runner_factory=None):
        self.config = Configuration.load(root)
        self.worktrees = WorktreeManager(self.config)
        self.runner_factory = runner_factory

    def run_dir(self, task_id):
        validate({"task_id": task_id, "role": "utility", "files": [],
                  "implementation_visible": False, "agent_history_visible": False}, "context")
        current = contained(self.config.runs_dir, task_id)
        legacy = contained(self.config.root / '.agent_runs', task_id)
        if current != legacy and (legacy / 'state.json').exists():
            if (current / 'state.json').exists():
                raise AgentSystemError('Task ID exists in both runtime layouts; resolve explicitly')
            return legacy
        return current

    def plan(self, task_file: Path):
        task = load_task(task_file)
        if 'hardening' in task and ('workflow' not in task or self.config.project['runtime'].get('version') != 2):
            raise AgentSystemError('Hardened task requires workflow and external runtime v2')
        directory = self.run_dir(task["task_id"])
        with lock(directory):
            task_path = directory / "task.json"
            if task_path.exists() and read_json(task_path) != task:
                raise AgentSystemError("Task ID already exists with a different contract")
            snapshot = {"project": self.config.project, "routing": self.config.routing}
            config_path = directory / "configuration.json"
            if config_path.exists() and read_json(config_path) != snapshot:
                raise AgentSystemError("Configuration changed; resume uses the frozen run configuration")
            state_path = directory / "state.json"
            if state_path.exists():
                return self._read_state(directory)
            # Freeze contract/configuration before first state write. A partial plan can resume.
            base = resolve_commit(self.config.root, task["base_ref"])
            atomic_json(task_path, task)
            atomic_json(config_path, snapshot)
            state = initial_state(task, base, snapshot)
            if state["version"] >= 2:
                Evidence(directory).write("observability", {"version": 1, "task_digest": digest(task),
                                                          "configuration_digest": digest(snapshot)})
            atomic_json(state_path, state)
            return state

    def _read_state(self, directory):
        raw = read_json(directory / "state.json")
        if raw.get("version") not in (1, 2, 3):
            raise AgentSystemError("Unsupported persisted-state version; explicit migration required")
        state = validate_history(raw)
        task = validate(read_json(directory / "task.json"), "task")
        if state["task_id"] != task["task_id"] or directory.name != state["task_id"]:
            raise AgentSystemError("Persisted task identity mismatch")
        if (state["version"] >= 2) != ("workflow" in task) or (state['version'] == 3) != ('hardening' in task):
            raise AgentSystemError("Persisted state/task version mismatch; explicit migration required")
        if state["version"] >= 2 and (state["task_digest"] != digest(task) or
                state["configuration_digest"] != digest(read_json(directory / "configuration.json"))):
            raise AgentSystemError("Frozen task/configuration identity mismatch")
        return state

    def status(self, task_id):
        return self._read_state(self.run_dir(task_id))

    def resume(self, task_id):
        directory = self.run_dir(task_id)
        with lock(directory):
            state = self._read_state(directory)
            task = read_json(directory / "task.json")
            snapshot = read_json(directory / "configuration.json")
            if state["version"] >= 2:
                from .hardened_workflow import HardenedWorkflow
                cls = HardenedWorkflow if state['version'] == 3 else Workflow
                return cls(self.config.root, directory, state, task, snapshot, self.runner_factory).drive()
            config = Configuration(self.config.root, validate(snapshot["project"], "project"),
                                   validate(snapshot["routing"], "models"))
            config.validate_paths()
            manager = WorktreeManager(config)
            while state["state"] not in (State.WORKTREES_READY, State.ARCHITECTURE_DECISION_REQUIRED):
                current = State(state["state"])
                if current == State.NEW:
                    target = State.CLASSIFY
                elif current == State.CLASSIFY:
                    paths = task["scope"]["allowed_paths"]
                    patterns = config.project["data_critical_patterns"]
                    state["data_critical"] = task["data_critical"] or any(
                        fnmatch.fnmatchcase(path, pattern) or fnmatch.fnmatchcase(pattern, path)
                        for path in paths for pattern in patterns
                    )
                    target = State.CONTRACT_READY
                elif current == State.CONTRACT_READY:
                    target = State.ARCHITECTURE_CHECK
                else:
                    # Detection/report generation and explicit approval are Stage 7.
                    # A caller may persist a block; there is no automatic approval path.
                    manager.prepare(task_id, state["base_commit"], state["data_critical"])
                    target = State.WORKTREES_READY
                state = transition(state, target)
                atomic_json(directory / "state.json", state)
            if state["state"] == State.WORKTREES_READY:
                manager.prepare(task_id, state["base_commit"], state["data_critical"])
            return state

    def block_architecture(self, task_id):
        directory = self.run_dir(task_id)
        with lock(directory):
            state = transition(self._read_state(directory), State.ARCHITECTURE_DECISION_REQUIRED)
            atomic_json(directory / "state.json", state)
            return state

    def cleanup(self, task_id):
        directory = self.run_dir(task_id)
        with lock(directory):
            self._read_state(directory)
            snapshot = read_json(directory / 'configuration.json')
            config = Configuration(self.config.root, snapshot['project'], snapshot['routing'])
            WorktreeManager(config).cleanup(task_id)

    def workflow(self, task_id):
        directory = self.run_dir(task_id)
        state = self._read_state(directory)
        if state["version"] < 2:
            raise AgentSystemError("Legacy preparation-only run; create a new task with an explicit workflow contract")
        from .hardened_workflow import HardenedWorkflow
        cls = HardenedWorkflow if state['version'] == 3 else Workflow
        return cls(self.config.root, directory, state, read_json(directory / "task.json"),
                        read_json(directory / "configuration.json"), self.runner_factory)

    def architecture(self, task_id):
        return self.workflow(task_id).architecture_package()

    def approve_architecture(self, task_id, decision_id, option, approved_by):
        with lock(self.run_dir(task_id)):
            return self.workflow(task_id).approve_architecture(decision_id, option, approved_by)

    def approve_completion(self, task_id, approved_by):
        with lock(self.run_dir(task_id)):
            return self.workflow(task_id).approve_completion(approved_by)

    def approve_contract(self, task_id, approved_by, package_sha256):
        with lock(self.run_dir(task_id)):
            return self.workflow(task_id).approve_contract(approved_by, package_sha256)

    def resolve_dispute(self, task_id, approved_by, changes_semantics=False):
        with lock(self.run_dir(task_id)):
            return self.workflow(task_id).resolve_dispute(approved_by, changes_semantics)

    def inspect(self, task_id):
        state = self.status(task_id)
        directory = self.run_dir(task_id)
        result = {"state": state, "runtime_directory": str(directory)}
        if state["version"] >= 2:
            result["evidence_files"] = sorted(str(p.relative_to(directory)) for p in directory.rglob("*.json")
                                               if "invocations" not in p.parts)
            if state["state"] == State.ARCHITECTURE_DECISION_REQUIRED:
                result["architecture"] = self.architecture(task_id)
            if state['version'] == 3 and state['state'] == State.CONTRACT_APPROVAL:
                package = self.workflow(task_id).evidence.read('contract/package')
                result['contract'] = package
                result['package_sha256'] = digest(package)
        return result
