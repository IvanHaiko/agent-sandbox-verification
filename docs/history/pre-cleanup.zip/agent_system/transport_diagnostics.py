"""Opt-in quarantine observer. No network client, model loop or tool dispatch.

Unknown responses are always rejected, including perfectly SSE-like prefixes.
Raw bytes stay in bounded Controller memory and are never persisted or returned.
This module is intentionally not wired into normal production transport.
"""
import hashlib
import http.client
import json
import re
import socket
import threading
import time

from .agent_transport import strict_json
from .errors import AgentSystemError
from .model_tool_boundary import UPSTREAM, require_credit_attestation

MAX_CAPTURE_BYTES = 8192
MAX_READ_SECONDS = 2.0
MAX_CHUNKS = 8
CHUNK_BYTES = 1024
JOIN_SECONDS = 0.5
SOCKET_IDLE_SECONDS = 0.05


def diagnostic_grant(policy):
    return {'authorized': True, 'diagnostic_only': True, **policy.identity(),
        'model': policy.binding.model, 'reasoning': policy.binding.reasoning, 'route': UPSTREAM,
        'max_capture_bytes': MAX_CAPTURE_BYTES, 'max_read_seconds': MAX_READ_SECONDS,
        'max_chunks': MAX_CHUNKS,
        'observer_sha256': hashlib.sha256(__import__('pathlib').Path(__file__).read_bytes()).hexdigest()}


def safe_headers(headers, secret_filter):
    """No arbitrary header values, cookies, account IDs or request IDs escape."""
    names = ('Content-Type', 'Content-Length', 'Transfer-Encoding', 'Content-Encoding')
    values = {name: headers.get_all(name, []) for name in names}
    try:
        secret_filter.reject(json.dumps(values))
    except AgentSystemError:
        return {'header_secret_rejected': True}
    types = values['Content-Type']
    value = types[0] if len(types) == 1 else None
    token = value.split(';', 1)[0].strip().lower() if isinstance(value, str) else None
    valid = bool(token and re.fullmatch(r'[a-z0-9!#$&^_.+-]+/[a-z0-9!#$&^_.+-]+', token))
    known = {'text/plain', 'text/event-stream', 'application/json', 'application/octet-stream'}
    result = {'content_type_count': len(types), 'content_type_present': bool(types),
        'raw_media_token': token if valid and token in known else ('other' if valid else 'invalid_or_missing'),
        'content_type_parameters_present': bool(value and ';' in value),
        'library_media_type': headers.get_content_type() if headers.get_content_type() in known else 'other',
        'raw_headers_exported': False}
    lengths = values['Content-Length']
    result['content_length'] = int(lengths[0]) if len(lengths) == 1 and re.fullmatch(r'[0-9]{1,20}', lengths[0]) else None
    result['content_length_malformed_or_duplicate'] = bool(lengths) and result['content_length'] is None
    for name in ('Transfer-Encoding', 'Content-Encoding'):
        tokens = values[name]
        result[name.lower().replace('-', '_')] = (tokens[0].strip().lower()
            if len(tokens) == 1 and tokens[0].strip().lower() in ('chunked', 'identity', 'gzip', 'deflate', 'br')
            else ('absent' if not tokens else 'other_or_malformed'))
    return result


def classify_prefix(raw, secret_filter):
    """Observational syntax only; no event/function argument becomes authority."""
    result = {'bytes_observed': len(raw), 'utf8_valid': False, 'classification': 'binary_or_unknown',
              'sse_like': False, 'json_like': False, 'prefix_sha256': None}
    if len(raw) > MAX_CAPTURE_BYTES:
        raise AgentSystemError('Diagnostic prefix bound exceeded')
    try:
        text = raw.decode('utf-8')
    except UnicodeDecodeError:
        # Known literal secret values are still checked in replacement decoding.
        try: secret_filter.reject(raw.decode('utf-8', errors='replace'))
        except AgentSystemError:
            result['classification'] = 'secret_rejected'
            return result
        result['prefix_sha256'] = hashlib.sha256(raw).hexdigest()
        return result
    result['utf8_valid'] = True
    try:
        secret_filter.reject(text)
        result['prefix_sha256'] = hashlib.sha256(raw).hexdigest()
        normal = text.replace('\r\n', '\n')
        if not normal.strip():
            result['classification'] = 'empty_or_whitespace'
            return result
        lines = normal.splitlines()
        data = [line[5:].lstrip(' ') for line in lines if line.startswith('data:')]
        events = [line[6:].lstrip(' ') for line in lines if line.startswith('event:')]
        # Check independently decodable fragments even when a later malformed
        # line makes the whole prefix ambiguous. Escaped secrets must not gain
        # a hash or classification merely by appending invalid framing.
        for candidate in [text, *lines, *data]:
            try:
                fragment = strict_json(candidate)
            except AgentSystemError:
                continue
            secret_filter.reject(json.dumps(fragment))
        framing = bool(data) and all(not line or line.startswith(('event:', 'data:', ':')) for line in lines)
        result.update(data_prefix_count=len(data), event_prefix_count=len(events),
                      recognizable_response_event_prefix=any(v.startswith('response.') for v in events))
        if framing:
            valid_data, malformed = 0, False
            for value in data:
                try:
                    parsed = strict_json(value)
                    secret_filter.reject(json.dumps(parsed))
                    valid_data += int(isinstance(parsed, dict))
                except AgentSystemError as error:
                    if str(error) == 'Credential-bearing output rejected': raise
                    malformed = True
            result.update(sse_like=True, classification='sse_like_prefix',
                sse_data_objects=valid_data, malformed_or_partial_data=malformed,
                complete_frame_suffix=normal.endswith('\n\n'))
        else:
            parsed = None
            try: parsed = strict_json(text)
            except AgentSystemError: pass
            if parsed is not None:
                secret_filter.reject(json.dumps(parsed))
                result.update(json_like=True, classification='json_value')
            elif len(lines) > 1:
                json_lines = []
                for line in lines:
                    if line.strip():
                        try: json_lines.append(strict_json(line))
                        except AgentSystemError:
                            json_lines = []
                            break
                if json_lines:
                    secret_filter.reject(json.dumps(json_lines))
                    result.update(json_like=True, classification='json_lines')
                else:
                    result['classification'] = 'plain_or_ambiguous_utf8'
            else:
                result['classification'] = 'plain_or_ambiguous_utf8'
    except AgentSystemError:
        # Do not export structure, hashes or body-derived fields for a secret.
        return {'bytes_observed': len(raw), 'utf8_valid': True, 'classification': 'secret_rejected',
                'prefix_sha256': None, 'sse_like': False, 'json_like': False}
    return result


class QuarantineObserver:
    def __init__(self, policy, approvals, client_id, secret_filter, admission_check,
                 cancel_event=None, enabled=False):
        if type(enabled) is not bool:
            raise AgentSystemError('Diagnostic opt-in must be boolean')
        self.policy, self.approvals, self.client_id = policy, approvals, client_id
        self.secrets, self.admission = secret_filter, admission_check
        self.cancel = cancel_event or threading.Event()
        self.enabled, self.evidence, self.used = enabled, None, False

    def __repr__(self):
        return 'QuarantineObserver(<disabled-or-bound>)'

    def _authorize(self):
        if not self.enabled or self.used or self.cancel.is_set() or time.monotonic() >= self.policy.deadline:
            raise AgentSystemError('Diagnostic capture not admitted')
        self.admission()
        require_credit_attestation(self.approvals, self.policy.binding, self.client_id)
        expected = {'authorized': True, **self.policy.identity(), 'model': self.policy.binding.model,
                    'reasoning': self.policy.binding.reasoning, 'route': UPSTREAM}
        self.approvals.verify('live-smoke/' + self.policy.binding.execution_id, expected)
        self.approvals.verify('diagnostic/' + self.policy.binding.execution_id, diagnostic_grant(self.policy))
        self.used = True

    def inspect_and_reject(self, response):
        self._authorize()
        return self._capture_and_reject(response)

    def _capture_and_reject(self, response):
        # Only owned standard-library HTTPResponse + interruptible socket.
        # Arbitrary reader implementations are not an accepted runtime adapter.
        if not isinstance(response, http.client.HTTPResponse):
            raise AgentSystemError('Unsupported diagnostic response adapter')
        try:
            sock = response.fp.raw._sock
            if not isinstance(sock, socket.socket): raise ValueError()
        except (AttributeError, ValueError):
            raise AgentSystemError('Owned diagnostic socket required') from None
        metadata = safe_headers(response.headers, self.secrets)
        metadata.update(http_status=response.status if type(response.status) is int and 100 <= response.status <= 599 else None,
            accepted_as_inference=False, passed_to_codex=False, tool_execution_allowed=False,
            limits={'bytes': MAX_CAPTURE_BYTES, 'seconds': MAX_READ_SECONDS, 'chunks': MAX_CHUNKS},
            body_representation='stdlib-decoded body prefix, not raw chunk framing')
        if response.headers.get_content_type() == 'text/event-stream':
            raise AgentSystemError('Expected transport belongs to normal strict gate')
        chunks, state = [], {'stop_reason': 'chunk_limit', 'read_error': False}
        deadline = min(self.policy.deadline, time.monotonic() + MAX_READ_SECONDS)
        def reader():
            total = 0
            try:
                for _ in range(MAX_CHUNKS):
                    if self.cancel.is_set():
                        state['stop_reason'] = 'cancelled'; return
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        state['stop_reason'] = 'timeout'; return
                    # Winsock shutdown may not immediately wake a blocking
                    # select. A short idle bound also caps cancellation latency.
                    # Timeout stops capture; a timed-out BufferedReader is not reused.
                    sock.settimeout(min(remaining, SOCKET_IDLE_SECONDS))
                    chunk = response.read1(min(CHUNK_BYTES, MAX_CAPTURE_BYTES - total))
                    if not chunk:
                        state['stop_reason'] = 'eof'; return
                    total += len(chunk)
                    chunks.append(chunk)
                    if total >= MAX_CAPTURE_BYTES:
                        state['stop_reason'] = 'byte_limit'; return
            except TimeoutError:
                state['stop_reason'] = 'timeout'
                state['read_error'] = True
            except (OSError, ValueError, http.client.HTTPException):
                state['stop_reason'] = 'read_error'
                state['read_error'] = True
        worker = threading.Thread(target=reader, name='agentctl-quarantine-reader', daemon=True)
        worker.start()
        while worker.is_alive() and not self.cancel.is_set() and time.monotonic() < deadline:
            worker.join(timeout=min(0.02, max(0, deadline - time.monotonic())))
        if worker.is_alive():
            reason = 'cancelled' if self.cancel.is_set() else 'timeout'
            try: sock.shutdown(socket.SHUT_RDWR)
            except OSError: pass
            sock.close()
            worker.join(timeout=JOIN_SECONDS)
            state['stop_reason'] = reason
        metadata['reader_shutdown_confirmed'] = not worker.is_alive()
        if worker.is_alive():
            self.evidence = {**metadata, 'classification': 'reader_shutdown_unconfirmed'}
            raise AgentSystemError('Diagnostic reader shutdown unconfirmed')
        response.close()
        raw = b''.join(chunks)
        metadata.update(classify_prefix(raw, self.secrets), **state, chunks_observed=len(chunks))
        chunks.clear()
        del raw
        self.secrets.reject(json.dumps(metadata))
        self.evidence = metadata
        raise AgentSystemError('Unknown transport quarantined and rejected')

    def wrap_opener(self, delegate):
        observer = self
        class DiagnosticOpener:
            def open(self, request, **kwargs):
                if request.full_url != UPSTREAM or request.get_method() != 'POST':
                    raise AgentSystemError('Diagnostic route forbidden')
                if observer.enabled:
                    observer._authorize()  # must pass before any delegated HTTP
                # No extra network capability or credentials are added here.
                response = delegate.open(request, **kwargs)
                if observer.enabled and response.headers.get_content_type() != 'text/event-stream':
                    try:
                        observer._capture_and_reject(response)
                    finally:
                        response.close()
                return response  # normal PlanUpstream still enforces its gate
        return DiagnosticOpener()
