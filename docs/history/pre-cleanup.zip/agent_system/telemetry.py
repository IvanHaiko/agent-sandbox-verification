"""Measured local invocation evidence; no inferred usage or billing."""
import hashlib
import json
import re

from .errors import AgentSystemError, WorkflowFailure
from .evidence import Evidence, digest
from .storage import read_json
from .task import validate

TOKEN_FIELDS = ("input_tokens", "output_tokens", "cached_input_tokens", "reasoning_tokens", "total_tokens")


def file_digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_events(path, require_completed=False):
    """Recognize exec turn completion, ignoring unknown *optional* event fields.

    One exec prompt is one turn. Multiple completion events are ambiguous, not
    additive usage; reject rather than double count. Missing usage stays null.
    """
    usage = dict.fromkeys(TOKEN_FIELDS)
    completed = 0
    if path.exists():
        with path.open(encoding="utf-8") as stream:
            for number, line in enumerate(stream, 1):
                if not line.strip():
                    continue
                try:
                    event = json.loads(line)
                except ValueError as exc:
                    raise AgentSystemError(f"Malformed backend JSON event at line {number}") from exc
                if not isinstance(event, dict) or not isinstance(event.get("type"), str) or not event["type"]:
                    raise AgentSystemError(f"Backend event missing required type at line {number}")
                if event["type"] == "turn.completed":
                    completed += 1
                    if completed > 1:
                        raise AgentSystemError("Multiple turn.completed events in one invocation")
                    raw = event.get("usage")
                    if raw is None:
                        continue
                    if not isinstance(raw, dict):
                        raise AgentSystemError("Malformed turn.completed usage")
                    for field in TOKEN_FIELDS:
                        value = raw.get(field)
                        if field == "reasoning_tokens" and value is None:
                            value = raw.get("reasoning_output_tokens")
                        if value is not None and (type(value) is not int or value < 0):
                            raise AgentSystemError(f"Malformed usage field: {field}")
                        usage[field] = value
    if require_completed and completed != 1:
        raise AgentSystemError("Successful backend missing turn.completed event")
    return usage


def identity(task, config, context, candidate, attempt, execution_id):
    operation = context.get("operation_id")
    match = re.fullmatch(r"c([0-2])-([a-z_]+)-r(\d+)(?:-t(\d+))?", operation or "")
    if context.get("phase") and (not match or match[2] != context["phase"]):
        raise AgentSystemError("Telemetry operation/cycle identity mismatch")
    return {"version": 1, "task_id": task["task_id"], "execution_id": execution_id,
            "role": context["role"], "phase": context.get("phase"), "operation_id": operation,
            "cycle": int(match[1]) if match else None, "attempt": attempt,
            "backend": config.project["runner"]["backend"],
            "configured_model": config.model_for(context["role"]).model,
            "configured_reasoning_effort": config.model_for(context["role"]).reasoning,
            "candidate_commit": candidate, "context_manifest_digest": digest(context),
            "task_digest": digest(task),
            "configuration_digest": digest({"project": config.project, "routing": config.routing})}


def finish_invocation(directory, binding, result, started_at, finished_at, duration_seconds,
                      timed_out=False, protocol_error=None, events_required=True):
    try:
        usage = parse_events(directory / "events.jsonl", events_required and result["status"] == "success")
    except AgentSystemError as exc:
        usage, protocol_error = dict.fromkeys(TOKEN_FIELDS), str(exc)
    record = {**binding, "started_at": started_at, "finished_at": finished_at,
              "duration_seconds": duration_seconds, "result_status": result["status"],
              "exit_code": result["returncode"], "timeout": timed_out,
              "infrastructure_retry_number": result["attempt"],
              "failure_kind": "policy" if result["status"] == "policy_violation" else "protocol" if protocol_error else (
                  None if result["status"] == "success" else "infrastructure"),
              "protocol_error": protocol_error, "usage": usage, "monetary_cost": None,
              "result_digest": digest(result), "events_digest": file_digest(directory / "events.jsonl")
                  if (directory / "events.jsonl").exists() else None}
    return Evidence(directory).write("telemetry", validate(record, "telemetry"))


def invocations(directory, task, snapshot):
    """Read and bind normalized evidence. Never regenerate missing historical metrics."""
    records, unavailable, seen = [], [], set()
    for folder in sorted((directory / "invocations").glob("*")):
        if not folder.is_dir():
            continue
        if not (folder / "result.json").exists():
            if Evidence(folder).exists("telemetry"):
                raise AgentSystemError("Finalized telemetry has no authoritative invocation result")
            unavailable.append(folder.name)
            continue
        result = validate(read_json(folder / "result.json"), "agent_result")
        context = read_json(folder / "context_manifest.json")
        if result["execution_id"] in seen or folder.name != result["execution_id"]:
            raise AgentSystemError("Duplicated or mismatched execution ID")
        seen.add(result["execution_id"])
        if result["task_id"] != task["task_id"] or context["task_id"] != task["task_id"]:
            raise AgentSystemError("Cross-task invocation evidence")
        if not Evidence(folder).exists("telemetry"):
            unavailable.append(folder.name)
            continue
        record = validate(Evidence(folder).read("telemetry"), "telemetry")
        if Evidence(folder).exists("telemetry_start"):
            start = Evidence(folder).read("telemetry_start")
            if any(record.get(key) != value for key, value in start.items()):
                raise AgentSystemError("Telemetry start/final binding mismatch")
        from .config import Configuration
        config = Configuration(directory.parent.parent, snapshot["project"], snapshot["routing"])
        expected = identity(task, config, context, record["candidate_commit"], result["attempt"], folder.name)
        if any(record[key] != value for key, value in expected.items()) or (
            record["role"] != result["role"] or record["configured_model"] != result["model"] or
            record["configured_reasoning_effort"] != result["reasoning"] or
            record["result_digest"] != digest(result) or record["result_status"] != result["status"] or
            record["exit_code"] != result["returncode"] or record["infrastructure_retry_number"] != result["attempt"]):
            raise AgentSystemError("Telemetry invocation/result binding mismatch")
        events = folder / "events.jsonl"
        if record["events_digest"] != (file_digest(events) if events.exists() else None):
            raise AgentSystemError("Telemetry raw events digest mismatch")
        operation = record["operation_id"]
        if operation:
            phase = record["phase"]
            round_number = operation.rsplit("-r", 1)[1]
            intent = Evidence(directory).read(f"cycles/{record['cycle']}/roles/{phase}-r{round_number}/intent")
            if (intent["input_commit"] != record["candidate_commit"] or intent["context"] != context or
                intent["role"] != record["role"] or intent["cycle"] != record["cycle"]):
                raise AgentSystemError("Telemetry candidate/role/cycle differs from invocation intent")
        records.append(record)
    return records, unavailable


def usage_summary(records, missing=0):
    return {field: {"measured": sum(r["usage"][field] for r in records if r["usage"][field] is not None)
                               if any(r["usage"][field] is not None for r in records) else None,
                    "unavailable_invocations": missing + sum(r["usage"][field] is None for r in records)}
            for field in TOKEN_FIELDS}


def enforce_limits(directory, task, snapshot, cycle, retry=False):
    limits = snapshot["project"].get("live_limits")
    if not limits:
        return
    # Count persisted attempts, including interrupted starts, before any new call.
    folders = [p for p in (directory / "invocations").glob("*") if p.is_dir()]
    records, unavailable = invocations(directory, task, snapshot)
    retries = sum(r["attempt"] > 0 for r in records)
    if unavailable:
        # Missing historical usage cannot safely satisfy a measured token ceiling.
        if "max_measured_tokens" in limits or retry:
            raise WorkflowFailure("usage_limit", "LIVE_USAGE_LIMIT_REACHED: historical usage/retry evidence unavailable")
    reasons = []
    if len(folders) >= limits["max_role_invocations"]:
        reasons.append("role invocation ceiling")
    if retry and retries >= limits["max_infrastructure_retries"]:
        reasons.append("infrastructure retry ceiling")
    if cycle is not None and cycle > limits["max_autonomous_fix_cycles"]:
        reasons.append("fix cycle ceiling")
    if "max_measured_tokens" in limits:
        # The backend must expose total_tokens; input/output are not a guessed total.
        if any(r["usage"]["total_tokens"] is None for r in records):
            reasons.append("authoritative total token usage unavailable")
        elif sum(r["usage"]["total_tokens"] for r in records) >= limits["max_measured_tokens"]:
            reasons.append("measured token ceiling")
    if reasons:
        raise WorkflowFailure("usage_limit", "LIVE_USAGE_LIMIT_REACHED: " + ", ".join(reasons))
