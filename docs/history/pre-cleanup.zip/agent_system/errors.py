class AgentSystemError(Exception):
    """An actionable configuration, safety, or lifecycle error."""


class WorkflowFailure(AgentSystemError):
    def __init__(self, kind, message):
        super().__init__(message)
        self.kind = kind
