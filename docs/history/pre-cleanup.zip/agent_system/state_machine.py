from datetime import datetime, timezone
from enum import StrEnum

from .errors import AgentSystemError
from .task import validate
from .evidence import digest


class State(StrEnum):
    NEW = "NEW"
    CLASSIFY = "CLASSIFY"
    CONTRACT_READY = "CONTRACT_READY"
    CONTRACT_APPROVAL = "CONTRACT_APPROVAL"
    INTERFACE_FREEZE = "INTERFACE_FREEZE"
    TEST_DISPUTE = "TEST_DISPUTE"
    ARCHITECTURE_CHECK = "ARCHITECTURE_CHECK"
    ARCHITECTURE_DECISION_REQUIRED = "ARCHITECTURE_DECISION_REQUIRED"
    WORKTREES_READY = "WORKTREES_READY"
    ARCHITECTURE_APPROVED = "ARCHITECTURE_APPROVED"
    TEST_DESIGN = "TEST_DESIGN"
    TEST_DESIGN_FROZEN = "TEST_DESIGN_FROZEN"
    IMPLEMENTING = "IMPLEMENTING"
    IMPLEMENTATION_READY = "IMPLEMENTATION_READY"
    TESTING = "TESTING"
    INTEGRATING = "INTEGRATING"
    INTEGRATED = "INTEGRATED"
    EXECUTING_TESTS = "EXECUTING_TESTS"
    TESTS_PASSED = "TESTS_PASSED"
    TESTS_FAILED = "TESTS_FAILED"
    REVIEWING = "REVIEWING"
    REVIEW_PASSED = "REVIEW_PASSED"
    REVIEW_FAILED = "REVIEW_FAILED"
    AUDITING = "AUDITING"
    AUDIT_PASSED = "AUDIT_PASSED"
    AUDIT_FAILED = "AUDIT_FAILED"
    GATE_DECISION = "GATE_DECISION"
    FIX_REQUIRED = "FIX_REQUIRED"
    FIXING = "FIXING"
    COMPLETION_CANDIDATE = "COMPLETION_CANDIDATE"
    USER_COMPLETION_APPROVAL = "USER_COMPLETION_APPROVAL"
    ACCEPTED = "ACCEPTED"
    ESCALATION_REQUIRED = "ESCALATION_REQUIRED"
    FAILED = "FAILED"


TRANSITIONS = {
    State.NEW: {State.CLASSIFY},
    State.CLASSIFY: {State.CONTRACT_READY},
    State.CONTRACT_READY: {State.ARCHITECTURE_CHECK},
    State.ARCHITECTURE_CHECK: {State.WORKTREES_READY, State.ARCHITECTURE_DECISION_REQUIRED},
    State.ARCHITECTURE_DECISION_REQUIRED: set(),
    State.WORKTREES_READY: set(),
}

WORKFLOW_TRANSITIONS = {
    **TRANSITIONS,
    State.ARCHITECTURE_DECISION_REQUIRED: {State.ARCHITECTURE_APPROVED},
    State.ARCHITECTURE_APPROVED: {State.WORKTREES_READY, State.IMPLEMENTING, State.FIXING, State.REVIEWING, State.AUDITING},
    State.WORKTREES_READY: {State.TEST_DESIGN},
    State.TEST_DESIGN: {State.TEST_DESIGN_FROZEN},
    State.TEST_DESIGN_FROZEN: {State.IMPLEMENTING},
    State.IMPLEMENTING: {State.IMPLEMENTATION_READY, State.ARCHITECTURE_DECISION_REQUIRED},
    State.IMPLEMENTATION_READY: {State.TESTING},
    State.TESTING: {State.INTEGRATING},
    State.INTEGRATING: {State.INTEGRATED},
    State.INTEGRATED: {State.EXECUTING_TESTS},
    State.EXECUTING_TESTS: {State.TESTS_PASSED, State.TESTS_FAILED},
    State.TESTS_PASSED: {State.REVIEWING},
    State.TESTS_FAILED: {State.REVIEWING},
    State.REVIEWING: {State.REVIEW_PASSED, State.REVIEW_FAILED, State.ARCHITECTURE_DECISION_REQUIRED},
    State.REVIEW_PASSED: {State.AUDITING, State.GATE_DECISION},
    State.REVIEW_FAILED: {State.AUDITING, State.GATE_DECISION},
    State.AUDITING: {State.AUDIT_PASSED, State.AUDIT_FAILED, State.ARCHITECTURE_DECISION_REQUIRED},
    State.AUDIT_PASSED: {State.GATE_DECISION},
    State.AUDIT_FAILED: {State.GATE_DECISION},
    State.GATE_DECISION: {State.COMPLETION_CANDIDATE, State.FIX_REQUIRED, State.ESCALATION_REQUIRED},
    State.FIX_REQUIRED: {State.FIXING},
    State.FIXING: {State.IMPLEMENTATION_READY, State.ARCHITECTURE_DECISION_REQUIRED},
    State.COMPLETION_CANDIDATE: {State.ACCEPTED, State.USER_COMPLETION_APPROVAL},
    State.USER_COMPLETION_APPROVAL: {State.ACCEPTED},
    State.ACCEPTED: set(), State.ESCALATION_REQUIRED: set(), State.FAILED: set(),
}
for current in WORKFLOW_TRANSITIONS:
    if current not in (State.ACCEPTED, State.ESCALATION_REQUIRED, State.FAILED):
        WORKFLOW_TRANSITIONS[current] = {*WORKFLOW_TRANSITIONS[current], State.FAILED}

HARDENED_TRANSITIONS = {state: set(targets) for state, targets in WORKFLOW_TRANSITIONS.items()}
HARDENED_TRANSITIONS.update({
    State.CONTRACT_READY: {State.CONTRACT_APPROVAL, State.INTERFACE_FREEZE, State.FAILED},
    State.CONTRACT_APPROVAL: {State.INTERFACE_FREEZE, State.FAILED},
    State.INTERFACE_FREEZE: {State.ARCHITECTURE_CHECK, State.FAILED},
    State.TESTS_FAILED: {State.REVIEWING, State.TEST_DISPUTE, State.FAILED},
    State.TEST_DISPUTE: {State.TESTING, State.ESCALATION_REQUIRED, State.FAILED},
    State.TESTING: {State.INTEGRATING, State.ARCHITECTURE_DECISION_REQUIRED, State.FAILED},
    State.IMPLEMENTATION_READY: {State.TESTING, State.ARCHITECTURE_DECISION_REQUIRED, State.FAILED},
})
HARDENED_TRANSITIONS[State.ARCHITECTURE_APPROVED].add(State.ESCALATION_REQUIRED)
HARDENED_TRANSITIONS[State.ARCHITECTURE_APPROVED].add(State.IMPLEMENTATION_READY)
HARDENED_TRANSITIONS[State.REVIEWING].add(State.TEST_DISPUTE)


def graph_for(state):
    return HARDENED_TRANSITIONS if state['version'] == 3 else WORKFLOW_TRANSITIONS if state['version'] == 2 else TRANSITIONS


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def initial_state(task, base_commit, configuration=None):
    state = {
        "version": 1, "task_id": task["task_id"], "state": State.NEW,
        "base_commit": base_commit, "fix_cycle": 0,
        "data_critical": task["data_critical"],
        "requires_user_approval": task["major_phase"] or task["completion"]["requires_user_approval"],
        "history": [{"state": State.NEW, "at": timestamp()}],
    }
    if "workflow" in task:
        state.update(version=2, architecture_round=0, resume_state=str(State.WORKTREES_READY),
                     task_digest=digest(task), configuration_digest=digest(configuration),
                     last_role=None, test_status="pending", review_status="pending",
                     audit_status="pending" if task["data_critical"] else "not_required",
                     failure_kind=None, detail="")
        state["commits"] = {}
        state["history"][0]["cycle"] = 0
        if 'hardening' in task:
            state.update(version=3, dispute_count=0, test_version=1,
                         contract_version=task['hardening']['contract_version'])
    return validate(state, "state")


def transition(state, target):
    validate(state, "state")
    current = State(state["state"])
    graph = graph_for(state)
    if target not in graph[current]:
        raise AgentSystemError(f"Illegal transition: {current} -> {target}")
    cycle = state["fix_cycle"]
    if state["version"] >= 2 and target == State.FIXING and current == State.FIX_REQUIRED:
        if cycle >= 2:
            raise AgentSystemError("Third autonomous fix cycle is forbidden")
        cycle += 1
    if target == State.ACCEPTED and state["requires_user_approval"] and current != State.USER_COMPLETION_APPROVAL:
        raise AgentSystemError("Major phase requires explicit completion approval")
    entry = {"state": str(target), "at": timestamp()}
    if state["version"] >= 2:
        entry["cycle"] = cycle
    return validate({**state, "state": str(target), "fix_cycle": cycle,
                     "history": [*state["history"], entry]}, "state")


def validate_history(state):
    """Reject corrupt or manually skipped lifecycle steps on resume."""
    validate(state, "state")
    try:
        history = [State(entry["state"]) for entry in state["history"]]
    except ValueError as exc:
        raise AgentSystemError("Unknown lifecycle state in history") from exc
    if history[0] != State.NEW or history[-1] != State(state["state"]):
        raise AgentSystemError("Persisted lifecycle history does not match state")
    graph = graph_for(state)
    if any(after not in graph[before] for before, after in zip(history, history[1:])):
        raise AgentSystemError("Persisted lifecycle history has an illegal transition")
    if state["version"] >= 2:
        expected_cycle = 0
        for index, entry in enumerate(state["history"]):
            if index and history[index - 1] == State.FIX_REQUIRED and history[index] == State.FIXING:
                expected_cycle += 1
            if entry["cycle"] != expected_cycle or expected_cycle > 2:
                raise AgentSystemError("Persisted fix-cycle history is invalid")
        if state["fix_cycle"] != expected_cycle:
            raise AgentSystemError("Persisted fix-cycle counter disagrees with history")
        if state['version'] == 3:
            disputes = sum(value == State.TEST_DISPUTE for value in history)
            resolved = sum(before == State.TEST_DISPUTE and after == State.TESTING for before, after in zip(history, history[1:]))
            if state['dispute_count'] != disputes or state['test_version'] != resolved + 1:
                raise AgentSystemError('Persisted dispute/test version counter disagrees with history')
    return state
