"""Capability admission is controller policy, never a runner prompt promise."""
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
import os
import subprocess
import venv

from .errors import AgentSystemError
from .git import git
from .storage import atomic_json, read_json


class CheckoutKind(StrEnum):
    OWNED_WORKTREE = "owned_worktree"
    ISOLATED_CHECKOUT = "isolated_checkout"


CAPABILITIES = (
    "fresh_context", "filesystem_read", "filesystem_write", "session_storage",
    "private_home", "private_cache", "instruction_control", "network_denied",
    "isolated_checkout", "readonly_mounts", "environment", "hidden_tests",
    "controller_storage",
)
REQUIRED = set(CAPABILITIES) - {"readonly_mounts"}


@dataclass(frozen=True)
class Capability:
    available: bool | None = None
    verified: bool = False
    evidence: str | None = None


@dataclass(frozen=True)
class IsolationCapabilities:
    backend: str
    capabilities: dict[str, Capability] = field(default_factory=dict)

    def manifest(self, required=REQUIRED):
        from .task import validate
        return validate({"version": 1, "backend": self.backend, "capabilities": {
            name: {"required": name in required, **self.capabilities.get(name, Capability()).__dict__}
            for name in CAPABILITIES}}, 'isolation')

    def require(self, required=REQUIRED):
        self.manifest(required)
        missing = [name for name in sorted(required) if not (
            (c := self.capabilities.get(name, Capability())).available is True
            and c.verified and c.evidence)]
        if missing:
            raise AgentSystemError("Required isolation unavailable/unverified: " + ", ".join(missing))


class IsolatedCheckout:
    """Transfer only the selected commit and its ancestors, with no remotes/alternates.

    A Git bundle is deliberately used instead of a local clone (which can copy all
    objects or create hardlinks). This prevents ordinary Git discovery of other refs.
    Filesystem access to the source still requires an enforcing runner.
    """
    kind = CheckoutKind.ISOLATED_CHECKOUT

    @staticmethod
    def create(source: Path, destination: Path, base: str, controller_dir: Path):
        ownership = controller_dir / "checkout.json"
        expected = {"kind": str(CheckoutKind.ISOLATED_CHECKOUT), "path": str(destination.resolve()), "base": base}
        if ownership.exists():
            if read_json(ownership) != expected:
                raise AgentSystemError("Isolated checkout ownership mismatch")
            if destination.exists():
                IsolatedCheckout.verify(destination, base)
                return destination
        elif destination.exists():
            raise AgentSystemError("Refusing to adopt an unowned isolated checkout")
        atomic_json(ownership, expected)
        controller_dir.mkdir(parents=True, exist_ok=True)
        bundle = controller_dir / "baseline.bundle"
        # rev-list traversal begins at exactly this commit, not --all.
        from uuid import uuid4
        ref = "refs/agentctl-baselines/" + uuid4().hex
        git(source, "update-ref", ref, base)
        try:
            git(source, "bundle", "create", str(bundle), ref)
        finally:
            git(source, "update-ref", "-d", ref, base)
        destination.mkdir(parents=True, exist_ok=False)
        git(destination, "init", "--initial-branch=baseline")
        git(destination, "fetch", str(bundle), base)
        git(destination, "checkout", "-B", "baseline", "FETCH_HEAD")
        git(destination, "reflog", "expire", "--expire=all", "--all")
        IsolatedCheckout.verify(destination, base)
        return destination

    @staticmethod
    def verify(path, base):
        if not (path / ".git").is_dir() or (path / ".git/objects/info/alternates").exists():
            raise AgentSystemError("Isolated checkout shares Git metadata/objects")
        if git(path, "remote") or git(path, "for-each-ref", "--format=%(refname)") != "refs/heads/baseline":
            raise AgentSystemError("Unexpected isolated checkout refs/remotes")
        git(path, "merge-base", "--is-ancestor", base, "HEAD")


def local_environment(checkout: Path):
    directory = checkout / ".venv"
    interpreter = directory / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if not interpreter.exists():
        venv.EnvBuilder(with_pip=False, system_site_packages=False).create(directory)
    return interpreter


def verify_imports(checkout: Path, modules: list[str], runner=None, task=None):
    if runner is not None and hasattr(runner, 'prepare_command') and (task is None or 'hardening' not in task):
        raise AgentSystemError('Container imports require hardened task metadata; no host fallback')
    interpreter = 'python' if runner is not None and hasattr(runner, 'prepare_command') else local_environment(checkout)
    script = """import importlib, json, pathlib, sys
root = pathlib.Path(sys.argv[1]).resolve()
sys.path[:0] = [str(root), str(root / 'src')]
paths = {}
for name in sys.argv[2:]:
    module = importlib.import_module(name)
    origins = list(getattr(module, '__path__', []))
    if getattr(module, '__file__', None): origins.append(module.__file__)
    if not origins: raise RuntimeError('Unverifiable module origin: ' + name)
    paths[name] = [str(pathlib.Path(p).resolve()) for p in origins]
    if any(not pathlib.Path(p).resolve().is_relative_to(root) for p in origins):
        raise RuntimeError('Import escaped role checkout: ' + name)
print(json.dumps(paths))
"""
    env = {k: v for k, v in os.environ.items() if k not in {"PYTHONPATH", "PYTHONHOME", "VIRTUAL_ENV"}}
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    argv = [str(interpreter), "-I", "-c", script, str(checkout.resolve()), *modules]
    if task is not None and 'hardening' in task:
        if runner is None:
            raise AgentSystemError('Hardened imports require verified isolated command execution')
        runner.isolation_capabilities().require()
        result = runner.run_command(argv, checkout, env, task['workflow']['test_timeout_seconds'], task, read_only=True)
    else:
        result = subprocess.run(argv, cwd=checkout, env=env, capture_output=True, text=True)
    if result.returncode:
        raise AgentSystemError("Role-local import validation failed: " + result.stderr)
    import json
    return {"interpreter": str(interpreter.resolve()) if isinstance(interpreter, Path) else interpreter,
            "origins": json.loads(result.stdout)}
