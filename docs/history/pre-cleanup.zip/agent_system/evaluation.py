"""Read-only deterministic reports over immutable engineering evidence."""
from collections import Counter
from datetime import datetime

from .errors import AgentSystemError
from .evidence import Evidence, digest
from .state_machine import validate_history
from .storage import read_json
from .task import validate
from .telemetry import invocations, usage_summary

FINAL = {"ACCEPTED", "FAILED", "ESCALATION_REQUIRED"}


def normalized_test_id(value):
    # Normalize only the path component: parameter values may contain backslashes.
    path, separator, selector = value.partition("::")
    return path.replace("\\", "/") + separator + selector


def sources(directory):
    evidence, records = Evidence(directory), {}
    for path in sorted(directory.rglob("*.json")):
        relative = path.relative_to(directory).as_posix()
        if relative.startswith(("telemetry/", "evaluation/", "invocations/", "controller/")):
            continue
        plain = {"task.json", "configuration.json", "state.json", "worktrees.json"}
        if relative not in plain:
            records[relative[:-5]] = evidence.read(relative[:-5])
    # Versioned mappings retain historical records; use the newest mapping for
    # coverage summaries without rewriting or replaying older evidence.
    mappings = [(int(k.rsplit('-t', 1)[1]), v) for k, v in records.items() if k.startswith('tester/test_mapping-t')]
    if mappings:
        records['tester/test_mapping'] = max(mappings, key=lambda item: item[0])[1]
    return records


def build_reports(directory):
    state = validate_history(read_json(directory / "state.json"))
    task = validate(read_json(directory / "task.json"), "task")
    snapshot = read_json(directory / "configuration.json")
    if directory.name != task["task_id"] or state["task_id"] != task["task_id"]:
        raise AgentSystemError("Report task identity mismatch")
    if state["version"] >= 2 and (state["task_digest"] != digest(task) or state["configuration_digest"] != digest(snapshot)):
        raise AgentSystemError("Report frozen identity mismatch")
    records = sources(directory)
    if "observability" in records and records["observability"] != {
            "version": 1, "task_digest": digest(task), "configuration_digest": digest(snapshot)}:
        raise AgentSystemError("Observability marker differs from frozen task/configuration")
    calls, unavailable = invocations(directory, task, snapshot)
    # A custom runner may supply only a workflow execution envelope. Historical
    # executions without a process directory remain visible, never replayed.
    known = {r["execution_id"] for r in calls} | set(unavailable)
    for key, record in records.items():
        if key.endswith("/execution"):
            validate(record, "agent_result")
            if record["task_id"] != task["task_id"]:
                raise AgentSystemError("Cross-task role execution evidence")
            if record["execution_id"] not in known:
                unavailable.append(record["execution_id"])
                known.add(record["execution_id"])
    for key, record in records.items():
        if key.endswith("/complete") and key.startswith("cycles/"):
            cycle = int(key.split("/")[1])
            if record["cycle"] != cycle or record["report"]["task_id"] != task["task_id"]:
                raise AgentSystemError("Evaluation role/task/cycle identity mismatch")
            phase = key.split("/")[3].rsplit("-r", 1)[0]
            from .contexts import OUTPUT_SCHEMAS, PHASE_ROLES
            validate(record["report"], OUTPUT_SCHEMAS[phase])
            if record["role"] != PHASE_ROLES[phase]:
                raise AgentSystemError("Evaluation phase/role mismatch")
            execution = records[key.removesuffix("complete") + "execution"]
            intent = records[key.removesuffix("complete") + "intent"]
            if (record["execution_id"] != execution["execution_id"] or record["role"] != execution["role"] or
                record["input_commit"] != intent["input_commit"] or intent["cycle"] != cycle):
                raise AgentSystemError("Evaluation completed invocation binding mismatch")
            candidates = [r['commit'] for k, r in records.items() if k.startswith(f'cycles/{cycle}/') and k.endswith('/integration')]
            if phase in ("review", "audit", "review_blind") and record["input_commit"] not in candidates:
                raise AgentSystemError("Evaluation validation role refers to a different candidate")
    source_digest = digest({"state": state, "task": task, "configuration": snapshot,
                            "evidence": records, "invocations": calls, "unavailable": unavailable})
    human_gates = [{"state": h["state"], "cycle": h.get("cycle"), "at": h["at"]}
                   for h in state["history"] if h["state"] in ("ARCHITECTURE_DECISION_REQUIRED", "CONTRACT_APPROVAL", "USER_COMPLETION_APPROVAL")]
    summaries = []
    groups = sorted({(r["role"], r["configured_model"], r["configured_reasoning_effort"]) for r in calls})
    for role, model, reasoning in groups:
        subset = [r for r in calls if (r["role"], r["configured_model"], r["configured_reasoning_effort"]) == (role, model, reasoning)]
        summaries.append({"role": role, "model": model, "reasoning": reasoning,
                          "invocations": len(subset), "duration_seconds": sum(r["duration_seconds"] for r in subset),
                          "usage": usage_summary(subset)})
    elapsed = (datetime.fromisoformat(state["history"][-1]["at"]) - datetime.fromisoformat(state["history"][0]["at"])).total_seconds()
    aggregate = {"version": 1, "task_id": task["task_id"], "source_digest": source_digest,
                 "outcome": state["state"], "candidate_commit": state.get("commits", {}).get("integration"),
                 "invocation_count": len(calls) + len(unavailable), "telemetry_unavailable": unavailable,
                 "invocations": calls, "roles": summaries, "usage": usage_summary(calls, len(unavailable)),
                 "monetary_cost": None, "role_duration_seconds": sum(r["duration_seconds"] for r in calls),
                 "elapsed_to_last_transition_seconds": elapsed,
                 "infrastructure_retries": sum(r["attempt"] > 0 for r in calls),
                 "infrastructure_failures": sum(r["failure_kind"] in ("infrastructure", "protocol") for r in calls),
                 "fix_cycles": state["fix_cycle"], "human_gates": human_gates}
    evaluation = evaluate_records(task, state, records, source_digest)
    for name, value in (("aggregate", aggregate), ("report", evaluation)):
        validate(value, "aggregate" if name == "aggregate" else "evaluation")
        parent = "telemetry" if name == "aggregate" else "evaluation"
        if Evidence(directory).exists(parent + "/" + name):
            if Evidence(directory).read(parent + "/" + name) != value:
                raise AgentSystemError("Finalized report differs from immutable source evidence")
    return aggregate, evaluation


def evaluate_records(task, state, records, source_digest):
    findings, test_reports, reviews, audits, architectures = [], {}, [], [], []
    for key, record in records.items():
        if key.endswith("/tests/result"):
            validate(record, "test_results")
            cycle = int(key.split("/")[1])
            if record["task_id"] != task["task_id"] or record["cycle"] != cycle:
                raise AgentSystemError("Evaluation test/task/cycle mismatch")
            integration = records.get(key.rsplit('/tests/', 1)[0] + '/integration')
            if integration is None or integration["commit"] != record["candidate_commit"]:
                raise AgentSystemError("Evaluation test candidate mismatch")
            test_reports[cycle] = record
            for command in record["commands"]:
                role = "test_engineer" if command["id"] in ("independent_tests", "holdout_tests", "additional_regressions") else "project_tests"
                for test_id in command["failing_test_ids"]:
                    test_id = normalized_test_id(test_id)
                    findings.append(finding(task, cycle, role, "test_failure", "BLOCKER", record["candidate_commit"],
                                            test_id, "Executable test failed: " + test_id, True, True, key,
                                            {"test_id": test_id}, command["id"]))
                if command["returncode"] != 0 or command["timed_out"]:
                    if not command["failing_test_ids"]:
                        findings.append(finding(task, cycle, role, "command_failure", "BLOCKER", record["candidate_commit"],
                                                command["id"], "Executable command failed", True, None, key,
                                                {"command_id": command["id"]}, command["id"]))
        if key.endswith("/complete") and record.get("role") in ("reviewer", "data_auditor"):
            phase = "review" if record["role"] == "reviewer" else "audit"
            report = record["report"]
            (reviews if phase == "review" else audits).append((record["cycle"], report))
            for index, item in enumerate(report["findings"]):
                blocking = item.get("blocking", item.get("severity") in ("BLOCKER", "MAJOR"))
                findings.append(finding(task, record["cycle"], record["role"], "engineering_finding",
                                        item.get("severity", "BLOCKER" if blocking else "WARNING"), record["input_commit"],
                                        item["location"], item["problem"], blocking, None, key,
                                        {"location": item["location"], "problem": item["problem"], "evidence": item["evidence"]}, str(index)))
            if phase == "audit":
                for index, check in enumerate(report["checks"]):
                    if not check["passed"]:
                        findings.append(finding(task, record["cycle"], record["role"], "audit_check", "BLOCKER",
                                                record["input_commit"], check["name"], "Audit check failed: " + check["name"],
                                                True, None, key, {"check": check["name"], "evidence": check["evidence"]}, "check-" + str(index)))
        if key.startswith("architecture/") and key.endswith("/decision"):
            selection = records.get(key.removesuffix("decision") + "selection")
            architectures.append({"decision_id": record["decision_id"], "alternatives": len(record["options"]),
                                  "selected_option": selection["option"] if selection else None})
    # Exact test IDs or identical location/problem/evidence establish duplicates.
    # Location alone only establishes a possible relationship, never equivalence.
    for item in findings:
        duplicates = [f["finding_id"] for f in findings if f["finding_id"] != item["finding_id"] and
                      f["cycle"] == item["cycle"] and f["equivalence_key"] == item["equivalence_key"]]
        item["duplicates"] = sorted(duplicates)
        item["possibly_related"] = sorted(f["finding_id"] for f in findings if f["cycle"] == item["cycle"] and
                    f["finding_id"] != item["finding_id"] and f["affected_location"] == item["affected_location"] and
                    f["finding_id"] not in duplicates)
        if item["category"] == "test_failure":
            for cycle, report in sorted(test_reports.items()):
                if cycle <= item["cycle"]:
                    continue
                executed = [c for c in report["commands"] if item["affected_location"] in [normalized_test_id(a) for a in c["argv"]]]
                if executed and all(c["returncode"] == 0 and not c["timed_out"] for c in executed):
                    item.update(resolution_status="resolved_by_test", resolved_in_cycle=cycle)
                    break
        elif item["source_role"] in ("reviewer", "data_auditor"):
            later = reviews if item["source_role"] == "reviewer" else audits
            if any(c > item["cycle"] and not any(f.get("location") == item["affected_location"] and
                   f.get("problem") == item["summary"] for f in report["findings"]) for c, report in later) and item["category"] != "audit_check":
                item["resolution_status"] = "no_longer_reported"
                # Absence in a subsequent LLM report is not confirmed resolution.
    design = records.get("tester/frozen_design")
    mapping = records.get("tester/test_mapping")
    frozen_count = len(design["cases"]) if design else None
    counts = Counter(f["severity"] for _, r in reviews for f in r["findings"])
    reviewer_findings = [f for f in findings if f["source_role"] == "reviewer"]
    auditor_findings = [f for f in findings if f["source_role"] == "data_auditor"]
    tests = [f for f in findings if f["category"] == "test_failure"]
    unique_confirmed = {}
    for role in ("test_engineer", "project_tests", "reviewer", "data_auditor"):
        # Shared discoveries are not claimed as unique to either role.
        unique_confirmed[role] = len({f["equivalence_key"] for f in findings if f["source_role"] == role and
             f["confirmed"] is True and not any(g["source_role"] != role and g["equivalence_key"] == f["equivalence_key"] for g in findings)})
    executed_cases = None
    if mapping and test_reports:
        executed_cases = len({m["case_id"] for m in mapping["independent"] if any(
            m["test_id"] in c["argv"] for r in test_reports.values() for c in r["commands"] if c["id"] == "independent_tests")})
    initial_decision = records.get("cycles/0/decision")
    caused_fix = None
    if mapping:
        caused_fix = any(f["source_role"] == "test_engineer" and f["category"] == "test_failure" and any(
            key.startswith(f"cycles/{f['cycle'] + 1}/roles/fix-") and key.endswith("/intent") and
            any(normalized_test_id(test_id) == f["affected_location"] for command in
                intent["context"]["inputs"].get("fix_feedback", {}).get("tests", {}).get("commands", [])
                for test_id in command["failing_test_ids"])
            for key, intent in records.items()) for f in findings)
    return {"version": 1, "task_id": task["task_id"], "source_digest": source_digest,
            "outcome": state["state"], "findings": findings, "unique_confirmed_findings": unique_confirmed,
            "tester": {"frozen_cases": frozen_count, "executed_cases": executed_cases,
                       "design_digest": digest(design) if design else None,
                       "acceptance_stable": True if design and mapping else None,
                       "additional_regressions": len(mapping["additional"]) if mapping else None,
                       "failure_observations": len(tests), "resolved_by_test": sum(f["resolution_status"] == "resolved_by_test" for f in tests),
                       "caused_fix": caused_fix},
            "reviewer": {"severity_counts": {k: counts[k] for k in ("BLOCKER", "MAJOR", "MINOR", "NIT")},
                         "blocking_findings": sum(f["blocking"] for f in reviewer_findings),
                         "confirmed_fixes": 0, "overlap_with_tests": None,
                         "final_findings": [f for f in reviewer_findings if f["cycle"] == state["fix_cycle"]]},
            "auditor": {"checks_performed": sum(len(r["checks"]) for _, r in audits),
                        "blocking_findings": sum(f["blocking"] for f in auditor_findings),
                        "warnings": sum(not f["blocking"] for f in auditor_findings), "confirmed_fixes": 0,
                        "unique_confirmed_data_issues": unique_confirmed["data_auditor"]} if state["data_critical"] else None,
            "architect": {"triggered": bool(architectures), "trigger_sources": [
                          *records.get("architecture/detection", {}).get("reasons", []),
                          *("agent:" + r["role"] for k, r in records.items() if k.endswith("/complete") and
                             r.get("report", {}).get("architecture_decision") is not None)],
                          "decisions": architectures, "resumed_after_selection": any(
                              h["state"] == "ARCHITECTURE_APPROVED" and state["history"][i + 1]["state"] != "FAILED"
                              for i, h in enumerate(state["history"][:-1]))},
            "implementer": {"initial_candidate_accepted": initial_decision["passed"] if initial_decision else None,
                            "fix_cycles": state["fix_cycle"], "test_failure_observations": len(tests),
                            "blocking_findings_received": sum(f["blocking"] for f in findings if f["cycle"] < state["fix_cycle"]),
                            "final_outcome": state["state"]},
            "fix_loop": [{"cycle": int(k.split('/')[1]), "tests_passed": r["tests_passed"],
                          "review_blocking": sum(f["severity"] in ("BLOCKER", "MAJOR") for f in r["review"]["findings"]),
                          "audit_verdict": r["audit"]["verdict"] if r["audit"] else None,
                          "passed": r["passed"]} for k, r in records.items() if k.startswith("cycles/") and k.endswith("/decision")],
            "limitations": ["Single-task observations do not establish routing superiority or justify removing a role.",
                            "Unconfirmed role findings and absent findings do not prove defects or causal fixes.",
                            "Executed selectors do not prove every test was collected; raw test output remains evidence."]}


def finding(task, cycle, role, category, severity, candidate, location, summary, blocking, confirmed, source, equivalence, discriminator):
    return {"finding_id": digest([task["task_id"], cycle, role, source, discriminator, equivalence]),
            "task_id": task["task_id"], "cycle": cycle, "source_role": role, "category": category,
            "severity": severity, "candidate_commit": candidate, "affected_location": location,
            "summary": summary, "blocking": blocking, "confirmed": confirmed,
            "resolution_status": "unresolved", "resolved_in_cycle": None,
            "source_evidence": source, "equivalence_key": digest([category, equivalence]),
            "duplicates": [], "possibly_related": []}


def persist_reports(directory):
    aggregate, evaluation = build_reports(directory)
    evidence = Evidence(directory)
    fingerprint = aggregate["source_digest"]
    evidence.write(f"telemetry/snapshots/{fingerprint}", aggregate)
    evidence.write(f"evaluation/snapshots/{fingerprint}", evaluation)
    if aggregate["outcome"] in FINAL:
        evidence.write("telemetry/aggregate", aggregate)
        evidence.write("evaluation/report", evaluation)
        evidence.write("evaluation/pilot_report", pilot_report(directory, aggregate, evaluation))
    return aggregate, evaluation


def pilot_report(directory, aggregate=None, evaluation=None):
    if aggregate is None or evaluation is None:
        aggregate, evaluation = build_reports(directory)
    records = sources(directory)
    report = {"version": 1, "task_id": aggregate["task_id"], "source_digest": aggregate["source_digest"],
              "telemetry": aggregate, "evaluation": evaluation,
              "test_results": [r for key, r in records.items() if key.endswith("/tests/result")],
              "final_nonblocking_findings": [f for f in evaluation["findings"] if not f["blocking"] and
                    f["source_role"] in ("reviewer", "data_auditor") and f["cycle"] == aggregate["fix_cycles"]],
              "observations": {"tester_executable_failure_observations": sum(f["source_role"] == "test_engineer" and
                    f["category"] == "test_failure" for f in evaluation["findings"]),
                    "reviewer_additional_confirmed_unique_findings": evaluation["unique_confirmed_findings"]["reviewer"],
                    "auditor_additional_confirmed_unique_findings": evaluation["unique_confirmed_findings"]["data_auditor"],
                    "interpretation": "Counts are observed evidence, not a causal value estimate or routing recommendation."}}
    validate(report, "pilot_report")
    if Evidence(directory).exists("evaluation/pilot_report") and Evidence(directory).read("evaluation/pilot_report") != report:
        raise AgentSystemError("Finalized pilot report differs from source evidence")
    return report


def compare_runs(directories):
    if len(directories) < 2 or len({str(d.resolve()) for d in directories}) != len(directories):
        raise AgentSystemError("Comparison requires at least two distinct runs")
    contracts, bases, projects, reports = [], [], [], []
    for directory in directories:
        task = read_json(directory / "task.json")
        state = read_json(directory / "state.json")
        if state["version"] < 2 or state["state"] not in FINAL:
            raise AgentSystemError("Comparison requires completed executable runs")
        # Only task ID and base_ref notation may differ. Resolved bases must match.
        contracts.append(digest({k: v for k, v in task.items() if k not in ("task_id", "base_ref")}))
        bases.append(state["base_commit"])
        projects.append(digest(read_json(directory / "configuration.json")["project"]))
        aggregate, evaluation = build_reports(directory)
        reports.append({"telemetry": aggregate, "evaluation": evaluation})
    if len(set(contracts)) != 1 or len(set(bases)) != 1 or len(set(projects)) != 1:
        raise AgentSystemError("Runs do not have equivalent contracts, frozen base and project configuration")
    return validate({"version": 1, "equivalent_contract_digest": contracts[0], "base_commit": bases[0],
            "runs": reports, "limitations": "Sequential independent runs; raw dimensions only, no composite score."}, "comparison")
