import json
from importlib.resources import files
from pathlib import Path

import yaml
from jsonschema import Draft202012Validator
from jsonschema.exceptions import ValidationError

from .errors import AgentSystemError


def validate(data, schema_name: str):
    schema = json.loads(files("agent_system").joinpath("schemas", schema_name + ".schema.json").read_text())
    try:
        Draft202012Validator(schema).validate(data)
    except ValidationError as exc:
        location = ".".join(map(str, exc.absolute_path)) or "<root>"
        raise AgentSystemError(f"{schema_name}: {location}: {exc.message}") from exc
    return data


def load_document(path: Path):
    try:
        value = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as exc:
        raise AgentSystemError(f"Cannot read {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise AgentSystemError(f"Expected an object in {path}")
    return value


def load_task(path: Path):
    return validate(load_document(path), "task")

