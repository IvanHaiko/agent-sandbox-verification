from .errors import AgentSystemError
from .git import git, registered_worktrees
from .policies import changed_paths, check_paths, matches
from .roles import Role
from .storage import contained
from .contexts import check_role_paths


class GitWorkflow:
    def __init__(self, config, task, base, evidence):
        self.config, self.task, self.base, self.evidence = config, task, base, evidence

    def path(self, name):
        return contained(self.config.worktrees_dir, f"{self.task['task_id']}/{name}")

    def verify(self, name, expected=None, clean=True):
        path = self.path(name)
        if name in ('tester', 'implementer') and 'hardening' in self.task:
            from .isolation import IsolatedCheckout
            IsolatedCheckout.verify(path, self.base)
            head = git(path, 'rev-parse', 'HEAD')
            if expected and head != expected:
                raise AgentSystemError('Unexpected isolated Tester commit divergence')
            if clean and git(path, 'status', '--porcelain', '--untracked-files=all'):
                raise AgentSystemError('Dirty isolated Tester checkout')
            check_paths(Role.IMPLEMENTER, changed_paths(path, self.base), self.task, self.config.project)
            return head
        entry = registered_worktrees(self.config.root).get(str(path))
        branch = f"refs/heads/agent/{self.task['task_id']}/{name}"
        if not entry or entry.get("branch") != branch or git(path, "symbolic-ref", "HEAD") != branch:
            raise AgentSystemError(f"Unexpected integration source branch/worktree: {name}")
        head = git(path, "rev-parse", "HEAD")
        if expected and head != expected:
            raise AgentSystemError(f"Unexpected branch divergence: {name}")
        git(path, "merge-base", "--is-ancestor", self.base, head)
        if clean and git(path, "status", "--porcelain", "--untracked-files=all"):
            raise AgentSystemError(f"Dirty integration source: {name}")
        check_paths(Role.IMPLEMENTER, changed_paths(path, self.base), self.task, self.config.project)
        return head

    def fast_forward(self, name, expected, target, operation):
        key = f"git/{operation}"
        intent = {"worktree": name, "from": expected, "to": target}
        self.evidence.write(key, intent)
        head = self.verify(name)
        if head == target:
            return head
        if head != expected:
            raise AgentSystemError(f"Unexpected branch divergence before fast-forward: {name}")
        git(self.path(name), "merge-base", "--is-ancestor", head, target)
        # ff-only cannot create a merge conflict or silently resolve a semantic conflict.
        git(self.path(name), "-c", "core.hooksPath=" + str(self.config.runs_dir / "disabled-hooks"),
            "merge", "--ff-only", target)
        return self.verify(name, target)

    def commit_result(self, name, role, phase, start, operation):
        path = self.path(name)
        self.verify(name, clean=False)
        paths = changed_paths(path, start)
        check_paths(role, paths, self.task, self.config.project)
        check_role_paths(role, phase, paths, self.task)
        original_tests = set(filter(None, git(path, "ls-tree", "-r", "--name-only", self.base, "--", "tests").splitlines()))
        if original_tests.intersection(paths):
            raise AgentSystemError("Existing baseline tests cannot be modified or deleted")
        if role == Role.IMPLEMENTER:
            independent_patterns = self.task["workflow"]["test_paths"]
            if any(any(matches(p, pattern) for pattern in independent_patterns) for p in paths):
                raise AgentSystemError("Implementer changed independent tests")
        if phase == "test_implementation":
            existing = set(filter(None, git(path, "ls-tree", "-r", "--name-only", start).splitlines()))
            if existing.intersection(paths):
                raise AgentSystemError("Tester may add independent tests but cannot rewrite candidate files")
        if git(path, "status", "--porcelain", "--untracked-files=all"):
            # Include deletions; path checks have already validated the complete diff.
            git(path, "add", "--all")
            git(path, "-c", "user.name=Agent Framework", "-c", "user.email=agent-framework@example.invalid",
                "-c", "core.hooksPath=" + str(self.config.runs_dir / "disabled-hooks"),
                "commit", "-m", f"agent: {operation}")
        return self.verify(name)
