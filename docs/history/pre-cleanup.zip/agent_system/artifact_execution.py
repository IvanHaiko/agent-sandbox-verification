"""Small Controller artifact boundary; transport and capability gates stay intact."""
import ast
import difflib
import hashlib
from pathlib import Path
import stat

from .codex_tool_session import CodexToolSession
from .errors import AgentSystemError
from .runners.docker_isolated import file_map, regular_tree
from .storage import contained


# Unknown failures, executable validation failures and security rejections never
# grant recovery. A later narration/transport failure can leave a valid write.
RECOVERABLE = frozenset(("socket_idle_timeout", "stream_transport_failure",
    "handoff_schema_failure", "handoff_finalization_failure"))


class ArtifactImplementerSession(CodexToolSession):
    """Finish the bounded execution at its successful write, without a prose turn.

    This is Controller-directed normal termination, not a claim that Codex's
    conversation finished. The Controller must still check the artifact.
    """
    def send(self, message):
        # A successful terminal write has no model continuation. Keep its result
        # Controller-visible rather than triggering an unnecessary prose request.
        if (self.bridge.successful_write_paths and isinstance(message.get('result'), dict)
                and 'contentItems' in message['result']):
            return
        super().send(message)

    def _handle(self, value):
        result = super()._handle(value)
        if value.get('method') == 'item/tool/call' and self.bridge.successful_write_paths:
            self.tool_result_returned = False
            self.last_completed_phase = 'controller_artifact_boundary'
        return result

    def run_until_written(self, prompt):
        if self.policy.binding.role != 'implementer' or self.policy.phase != 'implementation':
            raise AgentSystemError('Artifact execution requires implementation role')
        if self.turn_id or self.completed:
            raise AgentSystemError('One ephemeral turn per role execution')
        result = self.rpc(3, 'turn/start', {'threadId': self.thread_id,
            'input': [{'type': 'text', 'text': prompt}], 'model': self.policy.binding.model,
            'effort': self.policy.binding.reasoning})
        if self.turn_id and self.turn_id != result['turn']['id']:
            raise AgentSystemError('Turn identity mismatch')
        self.turn_id = result['turn']['id']
        while not self.completed:
            if self.bridge.successful_write_paths:
                self.last_completed_phase = 'controller_artifact_boundary'
                return
            self.handle(self.read())
        if not self.bridge.successful_write_paths:
            raise AgentSystemError('Implementation ended without candidate')


def implementation_handoff(workspace, baseline, target, archive, *,
        successful_write_paths, failure_category, security_violation,
        shutdown_confirmed, interface_check, model_handoff_received=False,
        self_checks=()):
    """Inspect exact bytes, scope, diff and interface before creating workflow state.

    interface_check(bytes) runs the Controller's fixed check in its admitted
    sandbox and returns structured evidence. It never accepts model commands.
    Baseline is the Controller's immutable pre-execution file-hash map.
    """
    def require(ok, message):
        if not ok:
            raise AgentSystemError(message)
    require(not security_violation and shutdown_confirmed, 'Unsafe execution cannot recover')
    require(failure_category is None or failure_category in RECOVERABLE,
            'Execution failure is not artifact-recoverable')
    require(set(successful_write_paths) == {target}, 'No unambiguous permitted write')
    workspace = Path(workspace)
    regular_tree(workspace)
    before = baseline['hashes']
    after = file_map(workspace)
    changed = sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))
    require(changed == [target], 'Implementation mutation scope violated')
    candidate = contained(workspace, target)
    info = candidate.lstat()
    require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, 'Unsafe candidate file')
    data = candidate.read_bytes()
    source = data.decode('utf-8')
    ast.parse(source)
    digest = hashlib.sha256(data).hexdigest()
    require(after[target] == digest, 'Ambiguous candidate snapshot')
    diff = ''.join(difflib.unified_diff(baseline['source'].splitlines(True),
        source.splitlines(True), fromfile='a/' + target, tofile='b/' + target))
    require(bool(diff), 'Candidate diff missing')
    archive = Path(archive)
    require(not archive.resolve().is_relative_to(workspace.resolve()), 'Archive inside role workspace')
    archive.parent.mkdir(parents=True, exist_ok=True)
    with archive.open('xb') as stream:
        stream.write(data)
    require(archive.read_bytes() == data, 'Candidate archive mismatch')
    check = interface_check(data)
    require(isinstance(check, dict) and check.get('public_interface_verified') is True,
            'Required deterministic interface check failed')
    require(file_map(workspace) == after and candidate.read_bytes() == data,
            'Candidate changed during interface check')
    return {'role': 'implementer', 'execution_status':
        'abnormal_recoverable' if failure_category else 'completed',
        'failure_category': failure_category, 'candidate_files': [target],
        'candidate_hashes': {target: digest}, 'diff_summary': diff,
        'mutation_scope_valid': True, 'interface_check': check,
        'self_checks': list(self_checks), 'model_handoff_received': model_handoff_received,
        'accepted': False, 'authority': 'controller_observed_artifacts'}
