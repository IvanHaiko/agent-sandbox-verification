"""Controller-side SIWC public-client OAuth. Never starts inference or Codex.

Contract researched 2026-10-05: developers.openai.com/siwc/token-sharing-open-source.
Secrets never cross the role boundary. Host Codex login state is never read.
"""
import base64
import csv
from dataclasses import dataclass, field
import hashlib
from http.server import BaseHTTPRequestHandler, HTTPServer
import io
import json
import os
from pathlib import Path
import re
import secrets
import stat
import subprocess
import time
from urllib.parse import parse_qs, urlencode, urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler, ProxyHandler
from urllib.error import HTTPError, URLError
from uuid import uuid4

from .agent_transport import strict_json
from .errors import AgentSystemError

ISSUER = 'https://auth.openai.com'
RESOURCE = 'https://api.openai.com/v1'
AUTHORIZE = ISSUER + '/api/accounts/authorize'
TOKEN = ISSUER + '/api/accounts/oauth/token'
DISCOVERY = ISSUER + '/.well-known/openid-configuration'
JWKS = ISSUER + '/.well-known/jwks.json'
SCOPES = 'openid profile email offline_access resource.invoke chatgpt.tokens.use.direct'
PLAN_SCOPE = 'chatgpt.tokens.use.direct'
APP_NAME = 'codex_multi_agent_engineering'
TERMINAL_REFRESH = {'invalid_grant', 'invalid_refresh_token', 'token_expired',
                    'refresh_token_expired', 'refresh_token_invalidated', 'refresh_token_reused'}


class AuthError(AgentSystemError):
    """Only allowlisted machine codes, never upstream error prose or tokens."""
    def __init__(self, code, status=None):
        safe = {'http_error', 'network_error', 'malformed_response', 'invalid_grant',
                'invalid_client', 'invalid_refresh_token', 'token_expired', 'refresh_token_expired',
                'refresh_token_invalidated', 'refresh_token_reused'}
        self.code = code if isinstance(code, str) and code in safe else 'http_error'
        self.status = status if type(status) is int else None
        super().__init__('ChatGPT OAuth: ' + self.code)


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class OAuthHttp:
    """Only documented auth endpoints; no inherited proxies or redirects."""
    def __init__(self):
        self._revocation = None

    def revocation_endpoint(self):
        data = self.request('GET', DISCOVERY)
        endpoint = data.get('revocation_endpoint')
        if not isinstance(endpoint, str) or data.get('issuer') != ISSUER:
            raise AgentSystemError('Revocation discovery invalid')
        uri = urlsplit(endpoint)
        if uri.scheme != 'https' or uri.netloc != 'auth.openai.com' or not uri.path or uri.query or uri.fragment:
            raise AgentSystemError('Revocation endpoint outside issuer')
        self._revocation = endpoint
        return endpoint

    def request(self, method, url, form=None):
        allowed = {DISCOVERY, JWKS, TOKEN}
        if self._revocation:
            allowed.add(self._revocation)
        # Revocation URL is taken from validated discovery, on the exact issuer.
        if url not in allowed or method not in ('GET', 'POST'):
            raise AgentSystemError('OAuth endpoint not allowed')
        if (method == 'GET') != (url in {DISCOVERY, JWKS}):
            raise AgentSystemError('OAuth method not allowed')
        data = urlencode(form).encode() if form is not None else None
        request = Request(url, data=data, method=method,
                          headers={'Content-Type': 'application/x-www-form-urlencoded'})
        try:
            with build_opener(ProxyHandler({}), NoRedirect()).open(request, timeout=15) as response:
                data = response.read(128 * 1024 + 1)
                if len(data) > 128 * 1024:
                    raise AuthError('malformed_response')
                if url == self._revocation and not data:
                    return {}
                return strict_json(data.decode('utf-8'))
        except HTTPError as error:
            try:
                value = strict_json(error.read(128 * 1024).decode('utf-8'))
                code = value.get('error') if isinstance(value, dict) else None
                if isinstance(code, dict):
                    code = code.get('code')
            except (AgentSystemError, UnicodeDecodeError):
                code = None
            raise AuthError(code, error.code) from None
        except (URLError, TimeoutError, OSError):
            raise AuthError('network_error') from None
        except (UnicodeDecodeError, AgentSystemError):
            raise AuthError('malformed_response') from None


def verify_identity(token, client_id, nonce, http):
    """Verify JWKS signature and OIDC claims using maintained PyJWT, not decoding."""
    try:
        import jwt
        discovery = http.request('GET', DISCOVERY)
        if discovery.get('issuer') != ISSUER or discovery.get('jwks_uri') != JWKS:
            raise ValueError()
        header = jwt.get_unverified_header(token)
        if header.get('alg') != 'RS256' or not isinstance(header.get('kid'), str):
            raise ValueError()
        keys = http.request('GET', JWKS).get('keys', [])
        matches = [key for key in keys if key.get('kid') == header['kid'] and key.get('kty') == 'RSA'
                   and key.get('use', 'sig') == 'sig' and key.get('alg', 'RS256') == 'RS256']
        if len(matches) != 1:
            raise ValueError()
        key = jwt.PyJWK.from_dict(matches[0], algorithm='RS256').key
        claims = jwt.decode(token, key, algorithms=['RS256'], audience=client_id, issuer=ISSUER,
                            options={'require': ['iss', 'aud', 'exp', 'sub']})
        if not isinstance(claims.get('sub'), str) or not claims['sub']:
            raise ValueError()
        if isinstance(claims['aud'], list) and len(claims['aud']) > 1 and claims.get('azp') != client_id:
            raise ValueError()
        if nonce is not None and (not isinstance(claims.get('nonce'), str)
                                  or not secrets.compare_digest(claims['nonce'], nonce)):
            raise ValueError()
        return claims
    except ImportError:
        raise AgentSystemError('Install the chatgpt-auth optional dependencies before sign-in') from None
    except Exception:
        raise AgentSystemError('ChatGPT ID token verification failed') from None


class CredentialStore:
    """Protected external Controller directory; one exclusive writer per operation.

    Windows DACL is limited to the current SID and SYSTEM. POSIX uses 0700/0600.
    A trusted same-user host process remains trusted; this is not a kernel boundary.
    """
    def __init__(self, directory, forbidden_roots):
        self.directory = Path(directory).absolute()
        roots = [Path(root).resolve() for root in forbidden_roots]
        if not roots or any(self.directory.resolve().is_relative_to(root) for root in roots):
            raise AgentSystemError('OAuth storage must be outside repositories and role mounts')
        for parent in [self.directory, *self.directory.parents]:
            if parent.exists() and (parent.is_symlink() or getattr(parent.lstat(), 'st_file_attributes', 0) & 0x400):
                raise AgentSystemError('OAuth storage links/reparse points forbidden')
        if self.directory.exists():
            self._verify_permissions()
        else:
            self.directory.mkdir(mode=0o700, parents=True)
            if os.name == 'nt':
                # Replace the DACL, including explicit creator/admin entries.
                # icacls /grant:r alone preserves unrelated explicit grants.
                sid = self._sid()
                self._command(['icacls', str(self.directory), '/inheritance:r', '/grant:r',
                               '*' + sid + ':(OI)(CI)F', '*S-1-5-18:(OI)(CI)F'])
                script = """$ErrorActionPreference='Stop';
$a=Get-Acl -LiteralPath $env:AGENTCTL_AUTH_STORE;
@($a.Access | ForEach-Object {$_.IdentityReference.Translate([System.Security.Principal.SecurityIdentifier]).Value}) | ConvertTo-Json -Compress"""
                result = subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-Command', script],
                    env={**{k: v for k, v in os.environ.items() if k.lower() != 'psmodulepath'},
                         'AGENTCTL_AUTH_STORE': str(self.directory)},
                    capture_output=True, timeout=15, creationflags=subprocess.CREATE_NO_WINDOW)
                if result.returncode:
                    raise AgentSystemError('OAuth storage permission operation failed')
                identities = strict_json(result.stdout.decode('utf-8-sig'))
                if isinstance(identities, str):
                    identities = [identities]
                if not isinstance(identities, list) or any(not isinstance(i, str) or not re.fullmatch(r'S-[0-9-]+', i) for i in identities):
                    raise AgentSystemError('OAuth storage permission inventory failed')
                for identity in set(identities) - {sid, 'S-1-5-18'}:
                    self._command(['icacls', str(self.directory), '/remove', '*' + identity])
            self._verify_permissions()

    def __repr__(self):
        return 'CredentialStore(<controller-private>)'

    @staticmethod
    def _command(argv):
        result = subprocess.run(argv, capture_output=True, timeout=15,
                                creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
        if result.returncode:
            raise AgentSystemError('OAuth storage permission operation failed')
        return result.stdout.decode('utf-8', 'replace')

    def _sid(self):
        rows = list(csv.reader(io.StringIO(self._command(['whoami', '/user', '/fo', 'csv', '/nh']))))
        sid = rows[0][1] if len(rows) == 1 and len(rows[0]) == 2 else ''
        if not re.fullmatch(r'S-1-5-[0-9-]+', sid):
            raise AgentSystemError('Cannot determine Controller SID')
        return sid

    def _verify_permissions(self):
        if os.name != 'nt':
            info = self.directory.stat()
            if info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) != 0o700:
                raise AgentSystemError('OAuth storage permissions unsafe')
            return
        # A fixed trusted script, path passed via env; no shell interpolation.
        script = """$a=Get-Acl -LiteralPath $env:AGENTCTL_AUTH_STORE;
$s=[System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value;
if(-not $a.AreAccessRulesProtected){exit 2};
foreach($r in $a.Access){$i=$r.IdentityReference.Translate([System.Security.Principal.SecurityIdentifier]).Value;
if($i -ne $s -and $i -ne 'S-1-5-18'){exit 3}};
if($a.Access.Count -lt 1){exit 4}"""
        result = subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-Command', script],
                                env={**{k: v for k, v in os.environ.items() if k.lower() != 'psmodulepath'},
                                     'AGENTCTL_AUTH_STORE': str(self.directory)},
                                capture_output=True, timeout=15, creationflags=subprocess.CREATE_NO_WINDOW)
        if result.returncode:
            raise AgentSystemError('OAuth storage DACL verification failed')

    def _path(self, name):
        if name not in ('host.json', 'registration.json', 'credentials.json', 'session.lock'):
            raise AgentSystemError('Invalid OAuth storage record')
        path = self.directory / name
        if path.exists() and (path.is_symlink() or getattr(path.lstat(), 'st_file_attributes', 0) & 0x400):
            raise AgentSystemError('OAuth storage record link forbidden')
        return path

    def read(self, name):
        self._verify_permissions()
        path = self._path(name)
        try:
            return strict_json(path.read_text(encoding='utf-8')) if path.exists() else None
        except (OSError, AgentSystemError):
            raise AgentSystemError('Cannot read protected OAuth record') from None

    def write(self, name, value):
        self._verify_permissions()
        path = self._path(name)
        temporary = self.directory / ('.pending-' + uuid4().hex)
        try:
            fd = os.open(temporary, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            with os.fdopen(fd, 'w', encoding='utf-8') as stream:
                json.dump(value, stream)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
        except OSError:
            raise AgentSystemError('Cannot persist protected OAuth record') from None
        finally:
            if temporary.exists():
                temporary.unlink()

    def clear_tokens(self):
        self._verify_permissions()
        self._path('credentials.json').unlink(missing_ok=True)

    def host_id(self):
        value = self.read('host.json')
        if value is None:
            value = {'ext_agent_host_id': 'urn:uuid:' + str(uuid4())}
            self.write('host.json', value)
        if not re.fullmatch(r'urn:uuid:[0-9a-f-]{36}', value.get('ext_agent_host_id', '')):
            raise AgentSystemError('Invalid saved host identifier')
        return value['ext_agent_host_id']

    def lock(self):
        return StoreLock(self)


class StoreLock:
    def __init__(self, store):
        self.store, self.fd = store, None
    def __enter__(self):
        self.store._verify_permissions()
        try:
            self.fd = os.open(self.store._path('session.lock'), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            raise AgentSystemError('OAuth session locked; inspect stale writer before retry') from None
        return self
    def __exit__(self, *args):
        if self.fd is not None:
            os.close(self.fd)
            self.store._path('session.lock').unlink()


@dataclass(repr=False)
class PendingAuthorization:
    state: str = field(repr=False)
    nonce: str = field(repr=False)
    verifier: str = field(repr=False)
    redirect_uri: str
    client_id: str
    deadline: float
    consumed: bool = False

    def __repr__(self):
        return 'PendingAuthorization(<private>)'


class ChatGPTPlanOAuth:
    def __init__(self, store, http=None):
        self.store, self.http = store, http or OAuthHttp()
        self.pending = None

    def begin(self, redirect_uri):
        uri = urlsplit(redirect_uri)
        if uri.scheme != 'http' or uri.hostname != '127.0.0.1' or uri.path != '/auth/callback' or not uri.port or uri.query or uri.fragment:
            raise AgentSystemError('OAuth callback must use exact loopback /auth/callback')
        if self.pending and not self.pending.consumed and time.monotonic() < self.pending.deadline:
            raise AgentSystemError('OAuth authorization already pending')
        with self.store.lock():
            saved = self.store.read('registration.json')
            host = self.store.host_id()
        client = saved['client_id'] if saved else 'dynamic_agent_client'
        verifier = secrets.token_urlsafe(48)
        self.pending = PendingAuthorization(secrets.token_urlsafe(32), secrets.token_urlsafe(32), verifier,
                                            redirect_uri, client, time.monotonic() + 300)
        query = {'client_id': client, 'ext_agent_host_id': host, 'response_type': 'code',
                 'redirect_uri': redirect_uri, 'scope': SCOPES, 'resource': RESOURCE,
                 'state': self.pending.state, 'nonce': self.pending.nonce, 'code_challenge_method': 'S256',
                 'code_challenge': base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('=')}
        if not saved:
            query['agent_name_hint'] = APP_NAME
        return AUTHORIZE + '?' + urlencode(query)

    def callback(self, callback_uri):
        pending = self.pending
        if not pending or pending.consumed or time.monotonic() >= pending.deadline:
            raise AgentSystemError('OAuth authorization expired or already consumed')
        try:
            uri, expected = urlsplit(callback_uri), urlsplit(pending.redirect_uri)
            if (uri.scheme, uri.netloc, uri.path) != (expected.scheme, expected.netloc, expected.path) or uri.fragment:
                raise ValueError()
            query = parse_qs(uri.query, keep_blank_values=True, strict_parsing=True, max_num_fields=16)
            if any(len(values) != 1 for values in query.values()):
                raise ValueError()
            state = query.get('state', [''])[0]
            if not secrets.compare_digest(state, pending.state):
                raise ValueError()
        except (ValueError, TypeError):
            raise AgentSystemError('OAuth callback validation failed') from None
        pending.consumed = True
        if 'error' in query:
            raise AgentSystemError('ChatGPT authorization denied or failed')
        issued = query.get('client_id', [pending.client_id])[0]
        if not issued.startswith('oaiapp_') or (pending.client_id != 'dynamic_agent_client' and issued != pending.client_id):
            raise AgentSystemError('OAuth registration missing or client mismatch')
        code = query.get('code', [''])[0]
        if not code or len(code) > 8192:
            raise AgentSystemError('OAuth authorization code missing or oversized')
        with self.store.lock():
            old = self.store.read('registration.json')
            if old and old['client_id'] != issued:
                raise AgentSystemError('Concurrent OAuth registration mismatch')
            # Issued registration survives invalid_grant; do not reuse the code.
            self.store.write('registration.json', old or {'client_id': issued})
            data = self.http.request('POST', TOKEN, {'grant_type': 'authorization_code', 'client_id': issued,
                        'code': code, 'code_verifier': pending.verifier, 'redirect_uri': pending.redirect_uri, 'resource': RESOURCE})
            record = self._record(data, issued, pending.nonce, old)
            self.store.write('registration.json', {'client_id': issued, 'subject': record['subject'], 'issuer': ISSUER})
            self.store.write('credentials.json', record)
        return self.status()

    def _record(self, data, issued, nonce, old):
        if (not isinstance(data, dict) or not isinstance(data.get('token_type'), str)
                or data['token_type'].lower() != 'bearer'
                or any(not isinstance(data.get(key), str) or not data[key] for key in ('access_token', 'refresh_token', 'id_token', 'scope'))
                or type(data.get('expires_in')) is not int or not 0 < data['expires_in'] <= 3600):
            raise AgentSystemError('Malformed ChatGPT OAuth token response')
        claims = verify_identity(data['id_token'], issued, nonce, self.http)
        if old and old.get('subject') and old['subject'] != claims['sub']:
            raise AgentSystemError('OAuth account identity mismatch')
        scopes = data['scope'].split()
        return {'client_id': issued, 'subject': claims['sub'], 'issuer': ISSUER,
                'access_token': data['access_token'], 'refresh_token': data['refresh_token'],
                'id_token': data['id_token'], 'scopes': scopes, 'expires_at': time.time() + data['expires_in'],
                'earliest_refresh_at': data.get('earliest_refresh_at'), 'saved_at': time.time()}

    def status(self):
        data = self.store.read('credentials.json')
        return {'connected': data is not None, 'plan_permission': bool(data and PLAN_SCOPE in data['scopes']),
                'access_token_expired': bool(data and time.time() >= data['expires_at']),
                'model_entitlement': 'unverified', 'remaining_usage': None,
                'credits_policy_verified': False, 'inference_enabled': False}

    def refresh(self):
        with self.store.lock():
            old = self.store.read('credentials.json')
            if old is None:
                raise AgentSystemError('ChatGPT account disconnected')
            try:
                data = self.http.request('POST', TOKEN, {'grant_type': 'refresh_token', 'client_id': old['client_id'],
                            'refresh_token': old['refresh_token'], 'resource': RESOURCE})
            except AuthError as error:
                if error.code in TERMINAL_REFRESH:
                    self.store.clear_tokens()
                raise
            # Refresh is not a new OIDC authorization attempt; no fresh nonce.
            record = self._record(data, old['client_id'], None, old)
            self.store.write('credentials.json', record)
        return self.status()

    def sign_in(self, open_browser):
        """Real local callback setup only; never automatically invoked by workflows."""
        received = []
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                if len(self.path) > 16384 or not self.path.startswith('/auth/callback?'):
                    self.send_error(400)
                    return
                received.append(self.path)
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b'Authorization received. Return to the framework terminal.')
            def log_message(self, *args):
                pass  # callback query contains code; never log it
        with HTTPServer(('127.0.0.1', 0), Handler) as server:
            server.timeout = 1
            uri = 'http://127.0.0.1:' + str(server.server_port) + '/auth/callback'
            open_browser(self.begin(uri))
            while not received and time.monotonic() < self.pending.deadline:
                server.handle_request()
            if not received:
                self.pending.consumed = True
                raise AgentSystemError('ChatGPT sign-in timed out')
            return self.callback(uri + received[0][len('/auth/callback'):])

    def disconnect_local(self):
        """Local deletion only; explicitly does not claim remote revocation."""
        with self.store.lock():
            self.store.clear_tokens()
        return {'connected': False, 'remote_revocation_confirmed': False,
                'action': 'Disconnect the app in ChatGPT Settings; only local deletion was requested'}

    def disconnect(self):
        with self.store.lock():
            old = self.store.read('credentials.json')
            if old is None:
                return {'connected': False, 'remote_revocation_confirmed': False}
            try:
                endpoint = self.http.revocation_endpoint()
                self.http.request('POST', endpoint, {'token': old['refresh_token'],
                    'token_type_hint': 'refresh_token', 'client_id': old['client_id']})
            except (AuthError, AgentSystemError):
                # No blind retry of a bearer-bearing request, and no claim that
                # deleting local tokens revokes the remote renewable session.
                self.store.clear_tokens()
                return {'connected': False, 'remote_revocation_confirmed': False,
                        'action': 'Remote revocation unconfirmed; disconnect in ChatGPT Settings'}
            self.store.clear_tokens()
        return {'connected': False, 'remote_revocation_confirmed': True}
