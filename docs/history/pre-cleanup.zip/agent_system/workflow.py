import hashlib
import json
import time
from pathlib import Path

from .architecture import architecture_reasons, validate_decision
from .config import Configuration
from .contexts import OUTPUT_SCHEMAS, PHASE_ROLES, check_role_paths, validate_context
from .errors import AgentSystemError, WorkflowFailure
from .evidence import Evidence, digest
from .gates import acceptance, audit_passes, review_passes, run_tests, validate_design, validate_test_mapping
from .git import WorktreeManager, git
from .integration import GitWorkflow
from .policies import changed_paths, check_paths, protected_snapshot
from .roles import ROLES, Role
from .runners import create_runner
from .runners.base import AgentResult
from .state_machine import State, timestamp, transition
from .storage import atomic_json, contained, read_json
from .task import validate


TERMINAL = {State.ACCEPTED, State.FAILED, State.ESCALATION_REQUIRED,
            State.ARCHITECTURE_DECISION_REQUIRED, State.USER_COMPLETION_APPROVAL}


class Workflow:
    """One local, serialized lifecycle using existing runner and worktree abstractions."""

    def __init__(self, root, directory, state, task, snapshot, runner_factory=None):
        self.directory, self.state, self.task = directory, state, task
        if state["task_digest"] != digest(task) or state["configuration_digest"] != digest(snapshot):
            raise AgentSystemError("Frozen task/configuration identity mismatch")
        self.config = Configuration(root, validate(snapshot["project"], "project"),
                                    validate(snapshot["routing"], "models"))
        self.config.validate_paths()
        self.manager = WorktreeManager(self.config)
        self.evidence = Evidence(directory)
        self.git = GitWorkflow(self.config, task, state["base_commit"], self.evidence)
        self.runner = (runner_factory or create_runner)(self.config)

    def save(self):
        atomic_json(self.directory / "state.json", validate(self.state, "state"))

    def advance(self, target):
        self.state = transition(self.state, target)
        self.save()

    @property
    def cycle(self):
        return self.state["fix_cycle"]

    def role_key(self, phase):
        key = f"cycles/{self.cycle}/roles/{phase}-r{self.state['architecture_round']}"
        if self.state['version'] == 3:
            key += f"-t{self.state['test_version']}"
        return key

    def checkpoint(self, name):
        """A test seam after durable evidence and before the next transition."""

    def prepare(self):
        manifest = self.manager.prepare(self.task["task_id"], self.state["base_commit"],
                                        self.state["data_critical"], include_architect=True)
        for name in manifest["worktrees"]:
            if name not in self.state["commits"]:
                self.git.verify(name, self.state["base_commit"])
                self.state["commits"][name] = self.state["base_commit"]
        self.save()

    def selections(self):
        selected = []
        for number in range(self.state["architecture_round"] + 1):
            key = f"architecture/{number}"
            if self.evidence.exists(key + "/selection"):
                decision = self.evidence.read(key + "/decision")
                selection = self.evidence.read(key + "/selection")
                self._validate_selection(decision, selection)
                selected.append({"decision": decision, "selection": selection})
        return selected

    def _validate_selection(self, decision, selection):
        validate_decision(decision, self.task)
        validate(selection, "architecture_selection")
        if (selection["task_id"] != self.task["task_id"] or selection["decision_id"] != decision["decision_id"]
                or selection["package_sha256"] != digest(decision)
                or selection["option"] not in {o["id"] for o in decision["options"]}):
            raise AgentSystemError("Architecture approval does not match this task/package/option")

    def block_architecture(self, decision, resume_state):
        validate_decision(decision, self.task)
        # A new issue must use a new decision ID; prior approval is never inferred.
        if any(item["decision"]["decision_id"] == decision["decision_id"] for item in self.selections()):
            raise AgentSystemError("Previously approved decision cannot be silently reused as a new issue")
        key = f"architecture/{self.state['architecture_round']}"
        self.evidence.write(key + "/decision", decision)
        self.state["resume_state"] = str(resume_state)
        self.advance(State.ARCHITECTURE_DECISION_REQUIRED)

    def approve_architecture(self, decision_id, option, approved_by):
        if self.state["state"] != State.ARCHITECTURE_DECISION_REQUIRED:
            raise AgentSystemError("Task is not awaiting an architecture decision")
        key = f"architecture/{self.state['architecture_round']}"
        package = self.evidence.read(key + "/decision")
        if decision_id != package["decision_id"] or option not in {o["id"] for o in package["options"]}:
            raise AgentSystemError("Invalid decision ID or nonexistent architecture option")
        if not approved_by.strip():
            raise AgentSystemError("Explicit approver identity is required")
        if self.evidence.exists(key + "/selection"):
            selection = self.evidence.read(key + "/selection")
            if selection["option"] != option or selection["approved_by"] != approved_by:
                raise AgentSystemError("Human architecture selection is immutable")
        else:
            selection = {"task_id": self.task["task_id"], "decision_id": decision_id,
                         "package_sha256": digest(package), "option": option,
                         "approved_by": approved_by, "approved_at": timestamp()}
            self.evidence.write(key + "/selection", validate(selection, "architecture_selection"))
        self._validate_selection(package, selection)
        self.advance(State.ARCHITECTURE_APPROVED)
        return self.state

    def architecture_package(self):
        for number in range(self.state["architecture_round"], -1, -1):
            key = f"architecture/{number}/decision"
            if self.evidence.exists(key):
                return self.evidence.read(key)
        raise AgentSystemError("This task has no architecture decision package")

    def approve_completion(self, approved_by):
        if self.state["state"] != State.USER_COMPLETION_APPROVAL or not approved_by.strip():
            raise AgentSystemError("Explicit completion approval is required for a completion candidate")
        self.assert_acceptance()
        self.evidence.write("completion/selection", {"task_id": self.task["task_id"],
                            "candidate_commit": self.state["commits"]["integration"], "approved_by": approved_by})
        self.advance(State.ACCEPTED)
        self.persist_observations()
        return self.state

    def _boundary(self, active):
        paths = [self.config.root, *(self.git.path(name) for name in self.state["commits"] if name != active)]
        snapshot = {}
        for path in paths:
            extra = []
            for relative in filter(None, git(path, "ls-files", "--others", "--exclude-standard", "-z").split("\0")):
                candidate = path / relative
                extra.append((relative, hashlib.sha256(candidate.read_bytes()).hexdigest() if candidate.is_file() else "directory"))
            snapshot[str(path)] = digest([git(path, "rev-parse", "HEAD"), git(path, "diff", "--binary", "HEAD"), extra])
        return snapshot

    def _protected_boundary(self):
        paths = [self.config.root, *(self.git.path(name) for name in self.state["commits"])]
        return {str(path): protected_snapshot(path, self.config.project) for path in paths}

    def _recover_execution(self, operation):
        completed = []
        incomplete = False
        folder = self.directory / "invocations"
        if folder.exists():
            for invocation in folder.iterdir():
                context = invocation / "context_manifest.json"
                result = invocation / "result.json"
                if context.exists() and read_json(context).get("operation_id") == operation:
                    if result.exists():
                        value = validate(read_json(result), "agent_result")
                        completed.append(value)
                    else:
                        incomplete = True
        if not completed or incomplete:
            raise WorkflowFailure("ambiguous_execution", "Interrupted role has no completed execution evidence; refusing to rerun it")
        return max(completed, key=lambda item: item["attempt"])

    def invoke(self, phase, inputs=None):
        role = PHASE_ROLES[phase]
        name = ROLES[role].workspace_name or "orchestrator"
        workspace = self.git.path(name)
        key = self.role_key(phase)
        if self.evidence.exists(key + "/complete"):
            record = self.evidence.read(key + "/complete")
            self.git.verify(name, record["output_commit"])
            self.state["commits"][name] = record["output_commit"]
            self.save()
            return record["report"]
        public = self.task["workflow"]["public_context"]
        context_files = public if phase in ("test_design", "architecture") else [
            *public, *self.task["workflow"]["implementation_context"]]
        operation = f"c{self.cycle}-{phase}-r{self.state['architecture_round']}"
        if self.state['version'] == 3:
            operation += f"-t{self.state['test_version']}"
        bundle = {"task_id": self.task["task_id"], "role": str(role), "phase": phase,
                  "operation_id": operation, "files": list(dict.fromkeys(context_files)),
                  "implementation_visible": phase not in ("test_design", "architecture", "implementation"),
                  "agent_history_visible": False, "inputs": {"architecture_selection": self.selections(), **(inputs or {})}}
        if self.state['version'] == 3:
            bundle.update(contract_version=self.state['contract_version'],
                          public_interface=self.task['hardening']['interface'])
        validate_context(bundle, role, workspace, self.task)
        if phase == "test_design":
            for producer in ("implementer", "tester"):
                self.git.verify(producer, self.state["base_commit"])
        fresh = not self.evidence.exists(key + "/intent")
        if fresh:
            start = self.git.verify(name, self.state["commits"][name])
            intent = {"phase": phase, "role": str(role), "cycle": self.cycle, "input_commit": start,
                      "context": bundle, "model": self.config.model_for(role).__dict__, "boundary": self._boundary(name),
                      "protected_boundary": self._protected_boundary()}
            self.evidence.write(key + "/intent", intent)
        else:
            intent = self.evidence.read(key + "/intent")
            start = intent["input_commit"]
            if intent["context"] != bundle:
                raise AgentSystemError("Resumed role context differs from the frozen invocation")
        self.state["last_role"] = str(role)
        self.save()
        if self.evidence.exists(key + "/execution"):
            result_data = self.evidence.read(key + "/execution")
        elif fresh:
            from .telemetry import enforce_limits, finish_invocation, identity
            snapshot = {"project": self.config.project, "routing": self.config.routing}
            enforce_limits(self.directory, self.task, snapshot, self.cycle)
            started_at, started_clock = timestamp(), time.monotonic()
            result = self.runner.run(role, self.config.model_for(role), bundle, workspace, self.task)
            finished_at, elapsed = timestamp(), time.monotonic() - started_clock
            # Injected/fake AgentRunner implementations may not create process
            # artifacts. Measure the actual call but leave unexposed usage null.
            invocation = contained(self.directory, f"invocations/{result.execution_id}")
            if not invocation.exists():
                invocation.mkdir(parents=True, exist_ok=False)
                atomic_json(invocation / "context_manifest.json", bundle)
                atomic_json(invocation / "result.json", result.to_dict())
                binding = identity(self.task, self.config, bundle, start, result.attempt, result.execution_id)
                self.evidence.write(key + "/runner", {"implementation": type(self.runner).__name__, "process_events": False})
                finish_invocation(invocation, binding, result.to_dict(), started_at, finished_at, elapsed,
                                  result.status == "timeout", events_required=False)
            result_data = self.evidence.write(key + "/execution", result.to_dict())
        else:
            result_data = self.evidence.write(key + "/execution", self._recover_execution(operation))
        result = AgentResult(**validate(result_data, "agent_result"))
        if result.role != role or result.task_id != self.task["task_id"] or (
            result.model, result.reasoning) != (self.config.model_for(role).model, self.config.model_for(role).reasoning):
            raise AgentSystemError("Role result identity or routing mismatch")
        if self._boundary(name) != intent["boundary"]:
            raise AgentSystemError("Agent modified the primary worktree or another role workspace")
        if self._protected_boundary() != intent["protected_boundary"]:
            raise AgentSystemError("Agent modified protected data, including untracked/ignored data")
        if result.status == "policy_violation":
            raise WorkflowFailure("policy", result.message)
        if result.status != "success":
            raise WorkflowFailure("infrastructure", result.message)
        paths = changed_paths(workspace, start)
        check_paths(role, paths, self.task, self.config.project)
        check_role_paths(role, phase, paths, self.task)
        if (ROLES[role].read_only or phase == "test_design") and git(workspace, "rev-parse", "HEAD") != start:
            raise AgentSystemError("Read-only role changed Git history")
        report = validate(json.loads(result.message), OUTPUT_SCHEMAS[phase])
        if self.state['version'] == 3 and report.get('contract_version') != self.state['contract_version']:
            raise AgentSystemError('Role result contract version mismatch or missing')
        if report["task_id"] != self.task["task_id"]:
            raise AgentSystemError("Structured output belongs to a different task")
        if phase == "test_design":
            validate_design(report, self.task)
        if phase in ("test_implementation", "test_correction"):
            validate_test_mapping(report, self.evidence.read("tester/frozen_design"), self.task, workspace)
        if report.get("architecture_decision") is not None and paths:
            raise AgentSystemError("Agent changed files while reporting an unapproved architecture change")
        output_commit = self.git.commit_result(name, role, phase, start, operation)
        record = {"role": str(role), "cycle": self.cycle, "execution_id": result.execution_id,
                  "input_commit": start, "output_commit": output_commit, "report": report}
        self.evidence.write(key + "/complete", record)
        self.state["commits"][name] = output_commit
        self.save()
        self.checkpoint(phase)
        return report

    def sync(self, name, source, label):
        target = self.git.verify(source, self.state["commits"][source])
        operation = f"c{self.cycle}-{label}-r{self.state['architecture_round']}"
        key = "git/" + operation
        if self.evidence.exists(key):
            expected = self.evidence.read(key)["from"]
        else:
            expected = self.state["commits"][name]
        head = self.git.fast_forward(name, expected, target, operation)
        self.state["commits"][name] = head
        self.save()
        return head

    def current_report(self, phase):
        for number in range(self.state["architecture_round"], -1, -1):
            key = f"cycles/{self.cycle}/roles/{phase}-r{number}/complete"
            if self.evidence.exists(key):
                report = self.evidence.read(key)["report"]
                validate(report, OUTPUT_SCHEMAS[phase])
                if report["task_id"] != self.task["task_id"]:
                    raise AgentSystemError("Stored role report belongs to a different task")
                if report.get("architecture_decision") is None:
                    return report
        raise AgentSystemError(f"Missing completed {phase} report for this candidate")

    def candidate_evidence(self):
        design = validate_design(self.evidence.read("tester/frozen_design"), self.task)
        mapping = self.evidence.read("tester/test_mapping")
        integration = self.evidence.read(f"cycles/{self.cycle}/integration")
        tests = self.evidence.read(f"cycles/{self.cycle}/tests/result")
        validate(tests, "test_results")
        if tests["task_id"] != self.task["task_id"] or tests["cycle"] != self.cycle:
            raise AgentSystemError("Test evidence belongs to a different task or cycle")
        for key in ("task_id", "base_commit", "task_digest", "configuration_digest"):
            if integration[key] != self.state[key]:
                raise AgentSystemError("Integration evidence has a different frozen identity")
        review = self.current_report("review")
        audit = self.current_report("audit") if self.state["data_critical"] else None
        phase = "implementation" if self.cycle == 0 else "fix"
        implementation = self.current_report(phase)
        candidate = self.git.verify("integration", self.state["commits"]["integration"])
        if integration["commit"] != candidate or tests["candidate_commit"] != candidate:
            raise AgentSystemError("Gate evidence refers to a different candidate commit")
        validate_test_mapping(mapping, design, self.task, self.git.path("integration"))
        self.selections()
        return implementation, design, integration, tests, review, audit

    def assert_acceptance(self):
        values = self.candidate_evidence()
        if not acceptance(*values, self.state["data_critical"]):
            raise AgentSystemError("Mandatory acceptance gate did not pass")
        return values

    def drive(self):
        try:
            while State(self.state["state"]) not in TERMINAL:
                self.step()
        except WorkflowFailure as exc:
            self.fail(exc.kind, str(exc))
        except (AgentSystemError, ValueError, KeyError, OSError) as exc:
            self.fail("policy", str(exc))
        self.persist_observations()
        return self.state

    def persist_observations(self):
        # Older runs are not silently upgraded or replayed to obtain telemetry.
        if self.evidence.exists("observability"):
            from .evaluation import persist_reports
            persist_reports(self.directory)

    def fail(self, kind, detail):
        self.state.update(failure_kind=kind, detail=detail)
        self.evidence.write(f"failures/c{self.cycle}-{self.state['state']}-r{self.state['architecture_round']}",
                            {"kind": kind, "detail": detail, "state": self.state["state"]})
        self.advance(State.FAILED)

    def step(self):
        current = State(self.state["state"])
        if current == State.NEW:
            self.advance(State.CLASSIFY)
        elif current == State.CLASSIFY:
            from fnmatch import fnmatchcase
            self.state["data_critical"] = self.task["data_critical"] or any(
                fnmatchcase(path, pattern) or fnmatchcase(pattern, path)
                for path in self.task["scope"]["allowed_paths"] for pattern in self.config.project["data_critical_patterns"])
            self.state["audit_status"] = "pending" if self.state["data_critical"] else "not_required"
            self.advance(State.CONTRACT_READY)
        elif current == State.CONTRACT_READY:
            self.advance(State.ARCHITECTURE_CHECK)
        elif current == State.ARCHITECTURE_CHECK:
            reasons = architecture_reasons(self.task, self.config.project)
            self.prepare()
            if reasons:
                self.evidence.write("architecture/detection", {"reasons": reasons})
                package = self.task.get("architecture", {}).get("proposal") or self.invoke("architecture")
                self.block_architecture(package, State.WORKTREES_READY)
            else:
                self.advance(State.WORKTREES_READY)
        elif current == State.ARCHITECTURE_APPROVED:
            key = f"architecture/{self.state['architecture_round']}"
            self._validate_selection(self.evidence.read(key + "/decision"), self.evidence.read(key + "/selection"))
            target = State(self.state["resume_state"])
            self.state["architecture_round"] += 1
            self.advance(target)
        elif current == State.WORKTREES_READY:
            self.prepare()
            self.advance(State.TEST_DESIGN)
        elif current == State.TEST_DESIGN:
            design = self.invoke("test_design")
            self.evidence.write("tester/frozen_design", validate_design(design, self.task))
            self.checkpoint("frozen_design")
            self.advance(State.TEST_DESIGN_FROZEN)
        elif current == State.TEST_DESIGN_FROZEN:
            validate_design(self.evidence.read("tester/frozen_design"), self.task)
            self.advance(State.IMPLEMENTING)
        elif current in (State.IMPLEMENTING, State.FIXING):
            phase = "implementation" if current == State.IMPLEMENTING else "fix"
            inputs = None
            if phase == "fix":
                if not self.evidence.exists(self.role_key(phase) + "/intent"):
                    self.sync("implementer", "integration", "fix-source")
                previous = self.cycle - 1
                # Only actionable failures/reports, never the private test-design invocation.
                review = self.evidence.read(f"cycles/{previous}/decision")["review"]
                audit = self.evidence.read(f"cycles/{previous}/decision")["audit"]
                inputs = {"fix_feedback": {"tests": self.evidence.read(f"cycles/{previous}/tests/result"),
                          "review": review, "audit": audit}}
            report = self.invoke(phase, inputs)
            if report["outcome"] in ("architecture_required", "ARCH_BLOCKED"):
                if report["architecture_decision"] is None:
                    raise AgentSystemError("Architecture stop requires a concrete decision package")
                self.block_architecture(report["architecture_decision"], current)
            elif report["architecture_decision"] is not None:
                raise AgentSystemError("Completed implementation cannot contain an unresolved architecture decision")
            else:
                self.advance(State.IMPLEMENTATION_READY)
        elif current == State.IMPLEMENTATION_READY:
            self.advance(State.TESTING)
        elif current == State.TESTING:
            if self.cycle == 0:
                if not self.evidence.exists(self.role_key("test_implementation") + "/intent"):
                    self.sync("tester", "implementer", "tester-candidate")
                mapping = self.invoke("test_implementation", {"test_design": self.evidence.read("tester/frozen_design")})
                self.evidence.write("tester/test_mapping", mapping)
            else:
                # Fixes reuse the immutable independent suite; no weakening or replacement.
                self.evidence.read("tester/test_mapping")
            self.advance(State.INTEGRATING)
        elif current == State.INTEGRATING:
            self.git.verify("implementer", self.state["commits"]["implementer"])
            self.git.verify("tester", self.state["commits"]["tester"])
            source = "tester" if self.cycle == 0 else "implementer"
            try:
                commit = self.sync("integration", source, "integration")
            except AgentSystemError as exc:
                raise WorkflowFailure("conflict", str(exc)) from exc
            self.evidence.write(f"cycles/{self.cycle}/integration", {"task_id": self.task["task_id"], "commit": commit,
                                "source": source, "base_commit": self.state["base_commit"],
                                "task_digest": self.state["task_digest"], "configuration_digest": self.state["configuration_digest"]})
            self.checkpoint("integration")
            self.advance(State.INTEGRATED)
        elif current == State.INTEGRATED:
            self.advance(State.EXECUTING_TESTS)
        elif current == State.EXECUTING_TESTS:
            self.git.verify("integration", self.state["commits"]["integration"])
            tests = run_tests(self.config, self.task, self.git.path("integration"),
                              self.evidence.read("tester/test_mapping"), self.cycle, self.evidence,
                              self.runner if self.state['version'] == 3 else None)
            self.state["test_status"] = "passed" if tests["passed"] else "failed"
            self.checkpoint("test_results")
            self.advance(State.TESTS_PASSED if tests["passed"] else State.TESTS_FAILED)
        elif current in (State.TESTS_PASSED, State.TESTS_FAILED):
            self.advance(State.REVIEWING)
        elif current == State.REVIEWING:
            self.sync("reviewer", "integration", "review-candidate")
            report = self.invoke("review", self.validation_inputs())
            if report["architecture_decision"] is not None:
                self.block_architecture(report["architecture_decision"], current)
            else:
                passed = review_passes(report)
                self.state["review_status"] = "passed" if passed else "failed"
                self.advance(State.REVIEW_PASSED if passed else State.REVIEW_FAILED)
        elif current in (State.REVIEW_PASSED, State.REVIEW_FAILED):
            self.advance(State.AUDITING if self.state["data_critical"] else State.GATE_DECISION)
        elif current == State.AUDITING:
            self.sync("auditor", "integration", "audit-candidate")
            report = self.invoke("audit", {**self.validation_inputs(), "review": self.current_report("review")})
            if report["architecture_decision"] is not None:
                self.block_architecture(report["architecture_decision"], current)
            else:
                passed = audit_passes(report)
                self.state["audit_status"] = "passed" if passed else "failed"
                self.advance(State.AUDIT_PASSED if passed else State.AUDIT_FAILED)
        elif current in (State.AUDIT_PASSED, State.AUDIT_FAILED):
            self.advance(State.GATE_DECISION)
        elif current == State.GATE_DECISION:
            implementation, design, integration, tests, review, audit = self.candidate_evidence()
            passed = acceptance(implementation, design, integration, tests, review, audit, self.state["data_critical"])
            record = {"task_id": self.task["task_id"], "cycle": self.cycle, "passed": passed,
                      "candidate_commit": integration["commit"], "tests_passed": tests["passed"], "review": review, "audit": audit,
                      "nonblocking_findings_policy": "MINOR/NIT retained with their report and recommended correction; no severity downgrade"}
            self.evidence.write(f"cycles/{self.cycle}/decision", record)
            if passed:
                self.advance(State.COMPLETION_CANDIDATE)
            elif self.cycle == 2:
                self.state.update(failure_kind="candidate", detail="Two automatic repair cycles exhausted")
                attempted_fixes = []
                for cycle in range(1, self.cycle + 1):
                    for round_number in range(self.state["architecture_round"], -1, -1):
                        key = f"cycles/{cycle}/roles/fix-r{round_number}/complete"
                        if self.evidence.exists(key):
                            fix = self.evidence.read(key)
                            if fix["report"]["outcome"] == "completed":
                                attempted_fixes.append({"cycle": cycle, "summary": fix["report"]["summary"],
                                    "execution_id": fix["execution_id"], "commit": fix["output_commit"]})
                                break
                self.evidence.write("escalation/report", {**record, "unresolved_tests": tests,
                                    "attempted_fix_cycles": 2, "attempted_fixes": attempted_fixes,
                                    "specification_ambiguity": "Not inferred automatically; investigate against the frozen task contract",
                                    "recommended_action": "Human investigation; create a new approved task if needed"})
                self.advance(State.ESCALATION_REQUIRED)
            else:
                self.advance(State.FIX_REQUIRED)
        elif current == State.FIX_REQUIRED:
            limits = self.config.project.get("live_limits")
            if limits and self.cycle >= limits["max_autonomous_fix_cycles"]:
                raise WorkflowFailure("usage_limit", "LIVE_USAGE_LIMIT_REACHED: fix cycle ceiling")
            self.advance(State.FIXING)
        elif current == State.COMPLETION_CANDIDATE:
            self.assert_acceptance()
            self.advance(State.USER_COMPLETION_APPROVAL if self.state["requires_user_approval"] else State.ACCEPTED)
        else:
            raise AgentSystemError(f"No execution handler for {current}")

    def validation_inputs(self):
        return {"test_design": self.evidence.read("tester/frozen_design"),
                "candidate_diff": git(self.git.path("integration"), "diff", self.state["base_commit"], "HEAD", "--"),
                "test_results": self.evidence.read(f"cycles/{self.cycle}/tests/result")}
