import hashlib
import json
from pathlib import Path

from .errors import AgentSystemError
from .storage import atomic_json, contained, read_json


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":")).encode("utf-8")).hexdigest()


class Evidence:
    """Write-once JSON envelopes. Digest checks detect changes on every read."""

    def __init__(self, root: Path):
        self.root = root

    def exists(self, name):
        return contained(self.root, name + ".json").exists()

    def read(self, name):
        envelope = read_json(contained(self.root, name + ".json"))
        if not isinstance(envelope, dict) or set(envelope) != {"sha256", "data"} or digest(envelope["data"]) != envelope["sha256"]:
            raise AgentSystemError(f"Immutable evidence digest mismatch: {name}")
        return envelope["data"]

    def write(self, name, data):
        path = contained(self.root, name + ".json")
        if path.exists():
            if self.read(name) != data:
                raise AgentSystemError(f"Cannot overwrite immutable evidence: {name}")
        else:
            atomic_json(path, {"sha256": digest(data), "data": data})
        return data
