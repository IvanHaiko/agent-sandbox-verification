"""Controller-owned test identities and deliberately narrow repair disclosure."""
import ast
import hashlib
import re

from .errors import AgentSystemError
from .git import git
from .policies import matches


def test_manifest(workspace, commit, patterns):
    paths = git(workspace, 'ls-tree', '-r', '--name-only', commit).splitlines()
    return {path: git(workspace, 'rev-parse', f'{commit}:{path}') for path in paths
            if any(matches(path, pattern) for pattern in patterns)}


def freeze_tests(store, workspace, commit, patterns, version):
    files = test_manifest(workspace, commit, patterns)
    if not files:
        raise AgentSystemError('Cannot freeze an empty independent test commit')
    return store.issue(f'tests/{version}', {'commit': commit, 'files': files})


def verify_frozen_tests(store, workspace, commit, version):
    frozen = store.verify(f'tests/{version}')
    for path, blob in frozen['files'].items():
        try:
            current = git(workspace, 'rev-parse', f'{commit}:{path}')
        except AgentSystemError as exc:
            raise AgentSystemError('Frozen independent test was deleted: ' + path) from exc
        if current != blob:
            before = git(workspace, 'show', f"{frozen['commit']}:{path}")
            after = git(workspace, 'show', f'{commit}:{path}')
            raise AgentSystemError('Frozen independent test mutation: ' + path + ': ' + ', '.join(mutation_flags(before, after)))
        candidate = workspace / path
        # Compare working-tree bytes too: a matching commit cannot conceal dirty tests.
        if not candidate.is_file() or git(workspace, 'diff', '--name-only', commit, '--', path):
            raise AgentSystemError('Frozen independent test working file mutation: ' + path)
    return frozen


def mutation_flags(before, after):
    flags = ['changed_test_source']
    for marker in ('skip', 'xfail'):
        if len(re.findall(r'\b' + marker + r'\b', after)) > len(re.findall(r'\b' + marker + r'\b', before)):
            flags.append('introduced_' + marker)
    try:
        a, b = ast.parse(before), ast.parse(after)
        assertions_a = [ast.dump(n) for n in ast.walk(a) if isinstance(n, ast.Assert)]
        assertions_b = [ast.dump(n) for n in ast.walk(b) if isinstance(n, ast.Assert)]
        cases_a = {n.name for n in ast.walk(a) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name.startswith('test')}
        cases_b = {n.name for n in ast.walk(b) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name.startswith('test')}
        if len(assertions_b) < len(assertions_a): flags.append('deleted_assertion')
        if assertions_a != assertions_b: flags.append('changed_assertion_or_expected_value_or_tolerance')
        if cases_a - cases_b: flags.append('removed_case')
    except SyntaxError:
        flags.append('malformed_test_source')
    return flags


def repair_feedback(task, tests, review, audit):
    """Never forward stdout, stderr, test identifiers, reviewer prose or hidden source.

    Acceptance clauses are approved public behavior. Unknown failing clauses are
    reported as all clauses needing verification, not inferred by an LLM.
    """
    return {'task_id': task['task_id'], 'tests_passed': tests['passed'],
            'behavior': [{'contract_clause': i, 'requirement': clause}
                         for i, clause in enumerate(task['acceptance_criteria'])],
            'review_blocking': sum(f['severity'] in ('BLOCKER', 'MAJOR') for f in review['findings']),
            'audit_blocking': sum(f['blocking'] for f in audit['findings']) if audit else 0,
            'minimal_input': None,
            'disclosure': 'public contract only; failure logs and independent source withheld'}


def check_feedback(feedback, hidden_sources):
    def strings(value):
        if isinstance(value, dict):
            return '\n'.join(strings(v) for v in value.values())
        if isinstance(value, list):
            return '\n'.join(strings(v) for v in value)
        return str(value)
    text = strings(feedback)
    for source in hidden_sources:
        for line in source.splitlines():
            line = line.strip()
            if len(line) >= 16 and line in text:
                raise AgentSystemError('Independent test source leaked into repair feedback')
    if re.search(r'\b(assert|pytest\.skip|pytest\.xfail)\b', text):
        raise AgentSystemError('Possible assertion source in repair feedback')
    return feedback


def detect_test_dispute(workspace, files, assertions):
    """Only adjudicate mechanically comparable, explicitly approved expectations.

    General natural-language inconsistency is not guessed from a failing test.
    """
    for path in files:
        if not path.endswith('.py'):
            continue
        try:
            tree = ast.parse((workspace / path).read_text(encoding='utf-8'))
        except SyntaxError as exc:
            return {'reason': 'malformed_test', 'clause': 0, 'evidence': f'{path}: {exc.msg}'}
        for node in ast.walk(tree):
            if not isinstance(node, ast.Assert) or not isinstance(node.test, ast.Compare):
                continue
            comparison = node.test
            if len(comparison.ops) != 1 or not isinstance(comparison.ops[0], ast.Eq) or not isinstance(comparison.comparators[0], ast.Constant):
                continue
            expression = ast.unparse(comparison.left)
            for requirement in assertions:
                if expression == requirement['expression'] and comparison.comparators[0].value != requirement['expected']:
                    return {'reason': 'contradicts_contract', 'clause': requirement['criterion'],
                            'evidence': f'{path}:{node.lineno}: equality contradicts the approved interface expectation'}
    return None


def validate_correction(before, after, assertions, reviewer_contract_resolution=False):
    flags = mutation_flags(before, after)
    if any(f in flags for f in ('introduced_skip', 'introduced_xfail', 'removed_case', 'deleted_assertion')):
        raise AgentSystemError('Test correction weakens coverage; new human-approved contract required')
    try:
        original, corrected = ast.parse(before), ast.parse(after)
    except SyntaxError:
        # A malformed original is reviewable, but the corrected source must parse.
        ast.parse(after)
        return flags
    old = [n.test for n in ast.walk(original) if isinstance(n, ast.Assert)]
    new = [n.test for n in ast.walk(corrected) if isinstance(n, ast.Assert)]
    for a, b in zip(old, new):
        if ast.dump(a) == ast.dump(b):
            continue
        if not (isinstance(a, ast.Compare) and isinstance(b, ast.Compare)
                and len(a.ops) == len(b.ops) == 1 and isinstance(a.ops[0], ast.Eq) and isinstance(b.ops[0], ast.Eq)
                and ast.dump(a.left) == ast.dump(b.left) and isinstance(b.comparators[0], ast.Constant)
                and (any(ast.unparse(b.left) == r['expression'] and b.comparators[0].value == r['expected'] for r in assertions)
                     or reviewer_contract_resolution)):
            raise AgentSystemError('Unjustified test assertion correction; explicit semantic reconciliation required')
    return flags
