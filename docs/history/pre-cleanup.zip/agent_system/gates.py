import re
import shlex
import subprocess

from .errors import AgentSystemError, WorkflowFailure
from .policies import changed_paths, matches, protected_snapshot
from .git import git
from .task import validate


def validate_design(design, task):
    validate(design, "test_design")
    if design["task_id"] != task["task_id"]:
        raise AgentSystemError("Test design belongs to another task")
    cases = design["cases"]
    if len({case["id"] for case in cases}) != len(cases):
        raise AgentSystemError("Duplicate independent test case IDs")
    covered = {case["criterion"] for case in cases}
    if covered != set(range(len(task["acceptance_criteria"]))):
        raise AgentSystemError("Independent design must cover every acceptance criterion")
    return design


def validate_test_mapping(report, design, task, workspace):
    validate(report, "test_implementation")
    if report["task_id"] != task["task_id"]:
        raise AgentSystemError("Independent test mapping belongs to a different task")
    case_ids = [case["id"] for case in design["cases"]]
    mapped = [item["case_id"] for item in report["independent"]]
    if set(mapped) != set(case_ids) or len(mapped) != len(set(mapped)):
        raise AgentSystemError("Independent test mapping must cover each frozen case exactly once")
    holdout = task.get('hardening', {}).get('holdout_paths', [])
    if holdout and not any(any(matches(item['path'], pattern) for pattern in holdout) for item in report['independent']):
        raise AgentSystemError('Declared holdout paths have no mapped independent tests; refusing isolation downgrade')
    all_items = [*report["independent"], *report["additional"]]
    if len({item["test_id"] for item in all_items}) != len(all_items):
        raise AgentSystemError("Independent and additional test identifiers must be distinct")
    from .storage import contained
    for item in all_items:
        path = contained(workspace, item["path"])
        if not path.is_file() or not any(matches(item["path"], p) for p in task["workflow"]["test_paths"]):
            raise AgentSystemError("Mapped test file is missing or outside approved test paths")
        if item["test_id"].split("::", 1)[0] != item["path"] or item["test_id"].startswith("-"):
            raise AgentSystemError("Test identifier must name its approved test file")
    return report


def review_passes(report):
    validate(report, "review")
    return report["architecture_decision"] is None and report.get('test_dispute') is None and not any(
        f["severity"] in ("BLOCKER", "MAJOR") for f in report["findings"])


def audit_passes(report):
    validate(report, "audit")
    return (report["architecture_decision"] is None and report["verdict"] != "FAIL"
            and all(c["passed"] for c in report["checks"])
            and not any(f["blocking"] for f in report["findings"]))


def acceptance(implementation, design, integration, tests, review, audit, data_critical):
    return (implementation["outcome"] == "completed" and bool(design["cases"])
            and bool(integration["commit"]) and tests["passed"] and review_passes(review)
            and (not data_critical or (audit is not None and audit_passes(audit))))


def run_tests(config, task, workspace, mapping, cycle, evidence, runner=None):
    if config.project['runner']['backend'] == 'docker_isolated' and ('hardening' not in task or runner is None):
        raise AgentSystemError('Container tests require hardened task metadata and an isolated runner; no host fallback')
    workflow = task["workflow"]
    commands = [{"id": f"project-{i}", "argv": shlex.split(command)}
                for i, command in enumerate(config.project["testing"]["commands"])]
    commands += workflow["checks"]
    known = {command["id"] for command in workflow["checks"]} | {"independent_tests", "reviewer", "data_auditor"}
    if set(task["required_checks"]) - known:
        raise AgentSystemError("Required checks are not mapped to executable commands")
    holdout_paths = task.get('hardening', {}).get('holdout_paths', [])
    holdout = [item['test_id'] for item in mapping['independent'] if any(matches(item['path'], p) for p in holdout_paths)]
    independent = [item["test_id"] for item in mapping["independent"] if item['test_id'] not in holdout]
    if 'hardening' in task and not independent:
        raise AgentSystemError('Hardened acceptance needs a visible diagnostic subset')
    commands.append({"id": "independent_tests", "argv": [*workflow["independent_command"], *independent]})
    if holdout:
        commands.append({'id': 'holdout_tests', 'argv': [*workflow['independent_command'], *holdout]})
    if mapping["additional"]:
        commands.append({"id": "additional_regressions", "argv": [*workflow["independent_command"],
                         *(item["test_id"] for item in mapping["additional"])]})
    results = []
    baseline = git(workspace, "rev-parse", "HEAD")
    protected = protected_snapshot(workspace, config.project)
    for index, command in enumerate(commands):
        key = f"cycles/{cycle}/tests/command-{index}"
        if evidence.exists(key):
            results.append(evidence.read(key))
            continue
        # Commands are frozen local configuration, executed as argv without a shell.
        record = {"id": command["id"], "argv": command["argv"], "returncode": None,
                  "timed_out": False, "stdout": "", "stderr": "", "failing_test_ids": []}
        try:
            extra = {}
            argv = command['argv']
            if 'hardening' in task:
                from .mechanical_gates import role_command
                argv, environment = (runner.prepare_command(argv, workspace) if runner is not None and hasattr(runner, 'prepare_command')
                                     else role_command(argv, workspace))
                record['argv'] = argv
                if runner is None:
                    raise AgentSystemError('Hardened tests require verified isolated command execution')
                runner.isolation_capabilities().require()
                result = runner.run_command(argv, workspace, environment, workflow['test_timeout_seconds'], task, read_only=True)
            else:
                result = subprocess.run(argv, cwd=workspace, capture_output=True,
                                        encoding="utf-8", errors="replace", timeout=workflow["test_timeout_seconds"], **extra)
            record.update(returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)
        except subprocess.TimeoutExpired as exc:
            record.update(timed_out=True, stderr=str(exc))
        except OSError as exc:
            raise WorkflowFailure("infrastructure", f"Test command infrastructure failure: {exc}") from exc
        record["failing_test_ids"] = re.findall(r"^FAILED\s+(\S+)", record["stdout"], re.MULTILINE)
        if changed_paths(workspace, baseline):
            raise AgentSystemError("Test command modified candidate project files")
        if protected_snapshot(workspace, config.project) != protected:
            raise AgentSystemError("Test command modified protected data")
        # Test frameworks may create ignored caches; tracked/untracked mutations fail closed.
        evidence.write(key, record)
        results.append(record)
    report = {"task_id": task["task_id"], "cycle": cycle, "candidate_commit": baseline,
              "passed": bool(results) and all(r["returncode"] == 0 and not r["timed_out"] for r in results),
              "commands": results}
    return evidence.write(f"cycles/{cycle}/tests/result", validate(report, "test_results"))
