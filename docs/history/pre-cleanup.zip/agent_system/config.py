from dataclasses import dataclass
from pathlib import Path

from .errors import AgentSystemError
from .roles import Role
from .storage import contained
from .task import load_document, validate


@dataclass(frozen=True)
class ModelConfig:
    model: str
    reasoning: str


@dataclass(frozen=True)
class Configuration:
    root: Path
    project: dict
    routing: dict

    @classmethod
    def load(cls, root: Path):
        root = root.resolve()
        project = validate(load_document(root / ".agent_system/project.yaml"), "project")
        routing = validate(load_document(root / ".agent_system/models.yaml"), "models")
        config = cls(root, project, routing)
        config.validate_paths()
        return config

    def validate_paths(self):
        runtime = self.project["runtime"]
        if runtime.get("version") == 2:
            external = Path(runtime["root"]).expanduser()
            if not external.is_absolute():
                raise AgentSystemError("Runtime v2 root must be an absolute path")
            external = external.resolve()
            if external == self.root or external.is_relative_to(self.root) or self.root.is_relative_to(external):
                raise AgentSystemError("Runtime v2 must be outside and separate from the repository")
            runs, trees = self.runs_dir, self.worktrees_dir
        else:
            runs = contained(self.root, runtime["runs_dir"])
            trees = contained(self.root, runtime["worktrees_dir"])
            if runtime != {"runs_dir": ".agent_runs", "worktrees_dir": ".agent_worktrees"}:
                raise AgentSystemError("Stages 1–4 use .agent_runs and .agent_worktrees")
        if runs.is_relative_to(trees) or trees.is_relative_to(runs):
            raise AgentSystemError("Runtime directories must be separate")
        # These canonical roots are part of the approved runtime privacy contract.
        for entry in self.project["protected_paths"]:
            contained(self.root, entry.removesuffix("/**"))
        contained(self.root, self.project["state_document"]["path"])
        contained(self.root, self.project["architecture"]["adr_root"])
        for entry in self.project["contracts"]["roots"]:
            contained(self.root, entry)

    @property
    def runs_dir(self):
        if self.project["runtime"].get("version") == 2:
            return contained(self.runtime_root, 'runs')
        return contained(self.root, self.project["runtime"]["runs_dir"])

    @property
    def worktrees_dir(self):
        if self.project["runtime"].get("version") == 2:
            return contained(self.runtime_root, 'worktrees')
        return contained(self.root, self.project["runtime"]["worktrees_dir"])

    @property
    def runtime_root(self):
        import hashlib
        identity = self.project["project"]["id"] + "-" + hashlib.sha256(str(self.root).encode()).hexdigest()[:16]
        return contained(Path(self.project["runtime"]["root"]).expanduser().resolve(), identity)

    def model_for(self, role: Role) -> ModelConfig:
        value = self.routing["models"][str(role)]
        return ModelConfig(value["model"], value["reasoning"])
