"""Ephemeral trusted Codex process; only dynamic tools cross the Docker bridge."""
import hashlib
import json
import os
from pathlib import Path
import queue
import subprocess
import threading
import time

from .agent_transport import strict_json
from .chatgpt_oauth import APP_NAME
from .errors import AgentSystemError
from .model_tool_boundary import TOOL, NAMESPACE, tool_spec
from .contexts import OUTPUT_SCHEMAS
from .task import validate
from jsonschema import Draft202012Validator
from .runtime_observability import preserve_failure, safe_failure


class CodexToolSession:
    NOTIFICATIONS = {'thread/started', 'thread/status/changed', 'thread/tokenUsage/updated',
        'turn/started', 'turn/completed', 'item/started', 'item/completed', 'item/agentMessage/delta',
        'item/reasoning/summaryTextDelta', 'item/reasoning/textDelta', 'item/reasoning/summaryPartAdded',
        'account/rateLimits/updated', 'remoteControl/status/changed', 'model/rerouted', 'warning', 'error'}

    def __init__(self, executable, expected_sha256, home, relay, bridge, policy, diagnostic_directory=None):
        self.executable, self.expected_sha256, self.home = Path(executable), expected_sha256, Path(home)
        self.relay, self.bridge, self.policy = relay, bridge, policy
        self.process, self.thread_id, self.turn_id = None, None, None
        self.frames, self.threads, self.messages, self.tool_results = queue.Queue(maxsize=128), [], [], []
        self.failure, self.response_ids, self.server_ids, self.call_ids = None, set(), set(), set()
        self.protocol_bytes, self.stderr_bytes = 0, 0
        self.closed, self.completed = False, False
        self.message_items, self.final_message = {}, None
        self.observation_metadata = {'anomalies': []}
        self.diagnostic_directory, self.failure_receipt = diagnostic_directory, None
        self.runtime_failure = None
        self.last_completed_phase, self.parser_status, self.handoff_status = 'not_started', 'pending', 'pending'
        self.tool_result_returned = False

    def __repr__(self):
        return 'CodexToolSession(<bound-private-session>)'

    def __enter__(self):
        try:
            return self._start()
        except BaseException as error:
            try:
                self.close()
            finally:
                self._preserve_failure(error)
            raise

    def _start(self):
        if hashlib.sha256(self.executable.read_bytes()).hexdigest() != self.expected_sha256:
            raise AgentSystemError('Codex executable binding changed')
        if self.home.exists():
            raise AgentSystemError('Fresh Codex home required')
        self.home.mkdir(parents=True, mode=0o700)
        (self.home / 'tmp').mkdir(mode=0o700)
        config = '\n'.join([
            'model_provider="agentctl_relay"', 'web_search="disabled"', 'approval_policy="never"',
            'cli_auth_credentials_store="ephemeral"', 'check_for_update_on_startup=false',
            'sandbox_mode="read-only"', 'model_reasoning_effort=' + json.dumps(self.policy.binding.reasoning),
            '[analytics]', 'enabled=false', '[feedback]', 'enabled=false', '[features]',
            *[name + '=false' for name in ('shell_tool', 'unified_exec', 'shell_snapshot', 'apps', 'plugins',
              'browser_use', 'computer_use', 'multi_agent', 'hooks', 'skill_mcp_dependency_install',
              'image_generation', 'code_mode', 'code_mode_host', 'view_image', 'sleep_tool',
              'daemon_auto_start', 'system_proxy_fallback')],
            '[model_providers.agentctl_relay]', 'name="Controller model gate"',
            'base_url=' + json.dumps(self.relay.url), 'env_key="AGENTCTL_MODEL_CHANNEL"',
            'wire_api="responses"', 'requires_openai_auth=false', 'supports_websockets=false',
            'request_max_retries=0', 'stream_max_retries=0', 'stream_idle_timeout_ms=65000'])
        (self.home / 'config.toml').write_text(config, encoding='utf-8')
        env = {k: v for k, v in os.environ.items() if k.upper() in ('SYSTEMROOT', 'WINDIR')}
        env.update(HOME=str(self.home), USERPROFILE=str(self.home), CODEX_HOME=str(self.home),
            TEMP=str(self.home / 'tmp'), TMP=str(self.home / 'tmp'), TMPDIR=str(self.home / 'tmp'),
            AGENTCTL_MODEL_CHANNEL=self.relay.child_channel(),
            PATH=os.path.join(os.environ.get('SystemRoot', '/usr'), 'System32') if os.name == 'nt' else '/usr/bin:/bin')
        self.process = subprocess.Popen([str(self.executable), 'app-server', '--listen', 'stdio://'],
            cwd=self.home, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
        def stdout():
            try:
                while line := self.process.stdout.readline(self.policy.max_response_bytes + 1):
                    self.protocol_bytes += len(line)
                    if self.protocol_bytes > self.policy.max_response_bytes or not line.endswith(b'\n'):
                        raise AgentSystemError('Protocol overflow or partial frame')
                    self.frames.put_nowait(strict_json(line.decode('utf-8')))
            except Exception:
                self.failure = 'Malformed, partial or overflowing Codex protocol'
        def stderr():
            while chunk := self.process.stderr.read(4096):
                self.stderr_bytes += len(chunk)
                if self.stderr_bytes > self.policy.max_response_bytes:
                    self.failure = 'Codex stderr overflow'
                # Never export raw stderr. It can contain provider/auth errors.
        for function in (stdout, stderr):
            thread = threading.Thread(target=function, daemon=True)
            self.threads.append(thread)
            thread.start()
        self.rpc(1, 'initialize', {'clientInfo': {'name': APP_NAME, 'title': 'Codex Multi-Agent Engineering',
                'version': '1.0.0'}, 'capabilities': {'experimentalApi': True}})
        self.send({'method': 'initialized', 'params': {}})
        result = self.rpc(2, 'thread/start', {'model': self.policy.binding.model, 'cwd': str(self.home),
                'ephemeral': True, 'approvalPolicy': 'never', 'sandbox': 'read-only',
                'dynamicTools': [{'type': 'namespace', 'name': NAMESPACE, 'description': 'Controller-owned isolated execution',
                    'tools': [tool_spec(self.policy)]}], 'config': {'model_reasoning_effort': self.policy.binding.reasoning}})
        self.thread_id = result['thread']['id']
        self.last_completed_phase = 'thread_started'
        return self

    def send(self, message):
        if self.closed or not self.process or self.process.poll() is not None:
            raise AgentSystemError('Codex process unavailable')
        raw = (json.dumps(message) + '\n').encode()
        if len(raw) > self.policy.max_request_bytes:
            raise AgentSystemError('Codex input overflow')
        self.process.stdin.write(raw)
        self.process.stdin.flush()

    def read(self):
        while True:
            if self.failure or self.relay.failures:
                raise AgentSystemError('Codex/model protocol denied')
            if self.closed or time.monotonic() >= self.policy.deadline:
                raise AgentSystemError('Codex execution cancelled or timed out')
            if getattr(self.bridge.runner, 'cancel_event', threading.Event()).is_set():
                raise AgentSystemError('Codex execution cancelled')
            try:
                value = self.frames.get(timeout=0.05)
                if not isinstance(value, dict): raise AgentSystemError('Invalid Codex frame')
                self.bridge.secrets.reject(json.dumps(value))
                self.parser_status = 'passed'
                return value
            except queue.Empty:
                if self.process.poll() is not None:
                    raise AgentSystemError('Codex process crashed or missing completion')

    def rpc(self, rpc_id, method, params):
        self.send({'id': rpc_id, 'method': method, 'params': params})
        while True:
            value = self.read()
            if value.get('id') == rpc_id and 'method' not in value:
                if rpc_id in self.response_ids or 'error' in value or 'result' not in value:
                    raise AgentSystemError('Codex RPC rejected or replayed')
                self.response_ids.add(rpc_id)
                return value['result']
            self.handle(value)

    def handle(self, value):
        try:
            return self._handle(value)
        except Exception as error:
            # This is a protocol boundary. Tool execution retains its own more
            # specific receipt; no notification/provider prose is exported.
            self.runtime_failure = safe_failure(error, 'model_protocol_failure')
            raise

    def _handle(self, value):
        if 'method' not in value:
            raise AgentSystemError('Unexpected Codex response')
        method, params = value['method'], value.get('params', {})
        if not isinstance(params, dict): raise AgentSystemError('Invalid Codex event params')
        if 'id' in value:
            rid = value['id']
            if type(rid) not in (str, int) or rid in self.server_ids:
                raise AgentSystemError('Replayed Codex server request')
            self.server_ids.add(rid)
            if method != 'item/tool/call':
                raise AgentSystemError('Built-in or unknown Codex server request denied')
            if (params.get('threadId') != self.thread_id or params.get('turnId') != self.turn_id
                    or params.get('tool') != TOOL or params.get('namespace') != NAMESPACE
                    or not isinstance(params.get('callId'), str) or params['callId'] in self.call_ids
                    or params['callId'] not in self.relay.gate.authorized_arguments):
                raise AgentSystemError('Codex dynamic tool binding mismatch')
            if json.dumps(params['arguments'], sort_keys=True) != self.relay.gate.authorized_arguments[params['callId']]:
                raise AgentSystemError('Codex tool arguments differ from gated model response')
            self.call_ids.add(params['callId'])
            result = self.bridge.execute(params['arguments'])
            self.tool_results.append({'returncode': result['returncode']})
            self.send({'id': rid, 'result': {'success': result['returncode'] == 0,
                'contentItems': [{'type': 'inputText', 'text': json.dumps(result)}]}})
            self.tool_result_returned = True
            self.last_completed_phase = 'tool_result_returned'
            return
        if method == 'remoteControl/status/changed' and params.get('status') != 'disabled':
            raise AgentSystemError('Remote control must remain disabled')
        if params.get('threadId') not in (None, self.thread_id):
            raise AgentSystemError('Cross-thread Codex notification')
        if params.get('turnId') not in (None, self.turn_id):
            raise AgentSystemError('Cross-turn Codex notification')
        if method not in self.NOTIFICATIONS:
            from .responses_lifecycle import record_anomaly
            record_anomaly(self.observation_metadata, 'unknown_codex_notification', scope='codex_session')
            return
        if method == 'warning':
            return  # Known informational event; never repairs or changes routing.
        if method in ('error', 'model/rerouted'):
            # Prose never becomes an authority to change model/provider or repair.
            raise AgentSystemError('Codex warning/error/reroute denied')
        if method == 'turn/started':
            turn = params.get('turn', {})
            if self.turn_id and self.turn_id != turn.get('id'): raise AgentSystemError('Cross-turn event')
            self.turn_id = turn.get('id')
        if method in ('item/started', 'item/completed'):
            item = params.get('item', {})
            if item.get('type') not in ('userMessage', 'agentMessage', 'reasoning', 'dynamicToolCall'):
                raise AgentSystemError('Local Codex tool execution item denied')
            if method == 'item/completed' and item.get('type') == 'agentMessage':
                text = item.get('text')
                if not isinstance(text, str): raise AgentSystemError('Final message missing')
                streamed = ''.join(self.message_items.get(item.get('id'), []))
                if streamed and streamed != text:
                    from .responses_lifecycle import record_anomaly
                    record_anomaly(self.observation_metadata, 'codex_message_stream_final_mismatch', scope='codex_session')
                self.final_message = text
        if method == 'item/agentMessage/delta':
            if not isinstance(params.get('delta'), str) or not isinstance(params.get('itemId'), str):
                from .responses_lifecycle import record_anomaly
                record_anomaly(self.observation_metadata, 'malformed_codex_message_delta', scope='codex_session')
                return
            self.message_items.setdefault(params['itemId'], []).append(params['delta'])
        if method == 'turn/completed':
            if params.get('turn', {}).get('id') != self.turn_id or params['turn'].get('status') != 'completed':
                raise AgentSystemError('Unsuccessful Codex completion')
            self.completed = True
            self.last_completed_phase = 'turn_completed'

    def run(self, prompt, result_schema=None):
        if self.turn_id or self.completed:
            raise AgentSystemError('One ephemeral turn per role execution')
        result = self.rpc(3, 'turn/start', {'threadId': self.thread_id,
            'input': [{'type': 'text', 'text': prompt}], 'model': self.policy.binding.model,
            'effort': self.policy.binding.reasoning})
        if self.turn_id and self.turn_id != result['turn']['id']:
            raise AgentSystemError('Turn identity mismatch')
        self.turn_id = result['turn']['id']
        self.last_completed_phase = 'turn_started'
        while not self.completed:
            self.handle(self.read())
        if self.final_message is None:
            raise AgentSystemError('Final structured agent message missing')
        text = self.final_message
        self.bridge.secrets.reject(text)
        self.handoff_status = 'schema_validation'
        try:
            result = strict_json(text)
            if result_schema is None:
                validate(result, OUTPUT_SCHEMAS[self.policy.phase])
            else:
                Draft202012Validator(result_schema).validate(result)
        except Exception:
            raise AgentSystemError('Structured Codex role result schema mismatch') from None
        if not isinstance(result, dict) or any(result[k] != v for k, v in self.policy.identity().items() if k in result):
            raise AgentSystemError('Structured Codex role identity mismatch')
        if result_schema is None and result.get('contract_version') != self.policy.binding.contract_version:
            raise AgentSystemError('Structured Codex contract version missing or mismatched')
        self.handoff_status = 'completed'
        self.last_completed_phase = 'handoff_completed'
        return result

    def _preserve_failure(self, error):
        if self.failure_receipt is not None:
            return
        if self.handoff_status == 'schema_validation':
            self.runtime_failure = safe_failure(error, 'handoff_schema_failure')
        self.parser_status = 'failed' if self.failure else self.parser_status
        self.handoff_status = 'failed'
        self.failure_receipt = preserve_failure(self, error, self.diagnostic_directory)

    def close(self):
        if self.closed: return
        self.closed = True
        self.bridge.close()
        if self.process:
            if self.process.poll() is None:
                self.process.stdin.close()
                try: self.process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    self.process.kill()
                    self.process.wait(timeout=5)
            for thread in self.threads:
                thread.join(timeout=5)
                if thread.is_alive(): raise AgentSystemError('Codex pipe shutdown unconfirmed')
            self.process.stdout.close()
            self.process.stderr.close()

    def __exit__(self, exc_type, error, traceback):
        try:
            self.close()
        except BaseException as shutdown_error:
            self._preserve_failure(error or shutdown_error)
            raise
        if error is not None:
            self._preserve_failure(error)
