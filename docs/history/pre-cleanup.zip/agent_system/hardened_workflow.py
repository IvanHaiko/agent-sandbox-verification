"""Version-3 controller lifecycle, preserving Workflow's durable commit points."""
from pathlib import Path

from .approvals import ApprovalStore
from .contracts import interface_package, lint_contract
from .errors import AgentSystemError
from .evidence import digest
from .git import git
from .independent_tests import freeze_tests, verify_frozen_tests, repair_feedback, check_feedback, detect_test_dispute, validate_correction
from .isolation import IsolationCapabilities, verify_imports
from .policies import protected_snapshot, matches, ignored_snapshot, check_paths, path_manifest, changed_paths
from .state_machine import State, timestamp, transition
from .storage import atomic_json
from .workflow import Workflow, TERMINAL
from .evidence import Evidence
from .errors import WorkflowFailure
from .mechanical_gates import architecture_drift, actual_data_paths, regenerate_audit


class TestVersionEvidence(Evidence):
    def __init__(self, root, state):
        super().__init__(root)
        self.state = state

    def key(self, name):
        parts = name.split('/')
        if len(parts) >= 3 and parts[0] == 'cycles' and parts[2] in ('tests', 'integration'):
            return '/'.join([*parts[:2], 'test-versions', str(self.state['test_version']), *parts[2:]])
        if name == 'tester/test_mapping':
            return name + f"-t{self.state['test_version']}"
        return name

    def read(self, name):
        return super().read(self.key(name))

    def write(self, name, value):
        return super().write(self.key(name), value)

    def exists(self, name):
        return super().exists(self.key(name))


class HardenedWorkflow(Workflow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.config.project['runtime'].get('version') != 2:
            raise AgentSystemError('Hardened workflow requires external runtime v2; legacy runs are not migrated')
        self.control = ApprovalStore(self.directory / 'controller', {
            'task_id': self.task['task_id'], 'task_digest': self.state['task_digest'],
            'configuration_digest': self.state['configuration_digest'], 'base_commit': self.state['base_commit']})
        self.evidence = TestVersionEvidence(self.directory, self.state)
        self.git.evidence = self.evidence

    def save(self):
        if isinstance(self.evidence, TestVersionEvidence):
            self.evidence.state = self.state
        super().save()

    def sync(self, name, source, label):
        # A corrected test epoch has a new integration/review identity even
        # when it remains in the same implementation repair cycle.
        return super().sync(name, source, label + f"-t{self.state['test_version']}")

    def prepare(self):
        manifest = self.manager.prepare(self.task['task_id'], self.state['base_commit'],
                                        self.state['data_critical'], include_architect=True, isolated_tester=True)
        for name in manifest['worktrees']:
            if name not in self.state['commits']:
                self.git.verify(name, self.state['base_commit'])
                self.state['commits'][name] = self.state['base_commit']
        self.save()

    def _validate_selection(self, decision, selection):
        super()._validate_selection(decision, selection)
        self.control.verify('architecture/' + decision['decision_id'], selection)

    def _approve_architecture(self, decision_id, option, approved_by):
        if self.state['state'] != State.ARCHITECTURE_DECISION_REQUIRED or not approved_by.strip():
            raise AgentSystemError('Explicit architecture approval required')
        key = f"architecture/{self.state['architecture_round']}"
        package = self.evidence.read(key + '/decision')
        if decision_id != package['decision_id'] or option not in {o['id'] for o in package['options']}:
            raise AgentSystemError('Invalid architecture decision/option')
        name = 'architecture/' + decision_id
        if (self.control.directory / (name + '.json')).exists():
            selection = self.control.verify(name)
            if selection['option'] != option or selection['approved_by'] != approved_by:
                raise AgentSystemError('Human architecture selection is immutable')
        else:
            selection = {'task_id': self.task['task_id'], 'decision_id': decision_id,
                         'package_sha256': digest(package), 'option': option,
                         'approved_by': approved_by, 'approved_at': timestamp()}
            self.control.issue(name, selection)
        self.evidence.write(key + '/selection', selection)
        self._validate_selection(package, selection)
        self.advance(State.ARCHITECTURE_APPROVED)
        return self.state

    def approve_completion(self, approved_by):
        if self.state['state'] != State.USER_COMPLETION_APPROVAL or not approved_by.strip():
            raise AgentSystemError('Explicit completion approval required')
        self.assert_acceptance()
        selection = {'task_id': self.task['task_id'], 'candidate_commit': self.state['commits']['integration'],
                     'approved_by': approved_by}
        self.control.issue('completion', selection)
        self.evidence.write('completion/selection', selection)
        self.advance(State.ACCEPTED)
        self.persist_observations()
        return self.state

    def approve_contract(self, approved_by, package_sha256):
        if self.state['state'] != State.CONTRACT_APPROVAL or not approved_by.strip():
            raise AgentSystemError('Task is not awaiting explicit contract approval')
        package = self.evidence.read('contract/package')
        if package_sha256 != digest(package):
            raise AgentSystemError('Contract approval package identity mismatch')
        self.control.issue('contract', {'package_sha256': package_sha256, 'approved_by': approved_by})
        self.advance(State.INTERFACE_FREEZE)
        return self.state

    def _readonly_snapshot(self, workspace):
        # Include ignored files, directories and symlinks. .git is checked separately.
        return path_manifest(workspace, ['*'])

    def _protected_boundary(self):
        paths = [self.config.root, *(self.git.path(name) for name in self.state['commits'])]
        return {str(path): path_manifest(path, self.config.project['protected_paths']) for path in paths}

    def invoke(self, phase, inputs=None):
        from .contexts import PHASE_ROLES
        from .roles import ROLES
        capabilities = self.runner.isolation_capabilities() if hasattr(self.runner, 'isolation_capabilities') else IsolationCapabilities(type(self.runner).__name__)
        self.evidence.write('isolation/admission', capabilities.manifest())
        capabilities.require()
        self.control.verify('interface', self.evidence.read('contract/package'))
        if self.task['major_phase']:
            approved = self.control.verify('contract')
            if approved['package_sha256'] != digest(self.evidence.read('contract/package')):
                raise AgentSystemError('Contract approval integrity mismatch')
        name = ROLES[PHASE_ROLES[phase]].workspace_name or 'orchestrator'
        workspace = self.git.path(name)
        readonly = ROLES[PHASE_ROLES[phase]].read_only or phase in ('test_design', 'architecture')
        if phase in ('test_design', 'test_implementation', 'test_correction') and self.task['hardening']['python_modules']:
            imports = verify_imports(workspace, self.task['hardening']['python_modules'], self.runner, self.task)
            self.evidence.write(self.role_key(phase) + '/imports', imports)
        before = self._readonly_snapshot(workspace) if readonly else None
        ignored_before = ignored_snapshot(workspace)
        report = super().invoke(phase, inputs)
        if readonly and self._readonly_snapshot(workspace) != before:
            raise AgentSystemError('Read-only role modified ignored/untracked project state')
        ignored_after = ignored_snapshot(workspace)
        mutations = [path for path in ignored_before.keys() | ignored_after.keys()
                     if ignored_before.get(path) != ignored_after.get(path)]
        if mutations:
            check_paths(PHASE_ROLES[phase], mutations, self.task, self.config.project)
        return report

    def drive(self):
        if self.state['state'] == State.ACCEPTED:
            # Accepted resumes still verify authoritative approvals and test identity.
            self.control.verify('interface', self.evidence.read('contract/package'))
            if self.state['requires_user_approval']:
                self.control.verify('completion', self.evidence.read('completion/selection'))
            self.assert_acceptance()
        try:
            while State(self.state['state']) not in TERMINAL | {State.CONTRACT_APPROVAL, State.TEST_DISPUTE}:
                self.step()
        except WorkflowFailure as exc:
            self.fail(exc.kind, str(exc))
        except (AgentSystemError, ValueError, KeyError, OSError) as exc:
            self.fail('policy', str(exc))
        self.persist_observations()
        return self.state

    def candidate_evidence(self):
        package = self.evidence.read('contract/package')
        self.control.verify('interface', package)
        if self.task['major_phase']:
            approved = self.control.verify('contract')
            if approved['package_sha256'] != digest(package):
                raise AgentSystemError('Mandatory contract approval does not match frozen interface')
        verify_frozen_tests(self.control, self.git.path('integration'),
                            self.state['commits']['integration'], self.state['test_version'])
        values = list(super().candidate_evidence())
        for report in (values[0], values[1], values[4], values[5]):
            if report is not None and report.get('contract_version') != self.state['contract_version']:
                raise AgentSystemError('Cannot integrate mismatched contract versions')
        blind = self.current_report('review_blind')
        values[4] = {**values[4], 'findings': [*blind['findings'], *values[4]['findings']]}
        if self.state['data_critical']:
            regenerated = self.evidence.read(f'cycles/{self.cycle}/auditor/regenerated')
            if regenerated['candidate_commit'] != self.state['commits']['integration']:
                raise AgentSystemError('Regenerated auditor evidence belongs to a different candidate')
            values[5] = {**values[5], 'checks': [*values[5]['checks'], {
                'name': 'Pre-registered quantitative expectations',
                'evidence': str(regenerated['expectations']['results']),
                'passed': regenerated['expectations']['passed']}]}
        return tuple(values)

    def current_report(self, phase):
        from .contexts import OUTPUT_SCHEMAS
        from .task import validate
        for number in range(self.state['architecture_round'], -1, -1):
            key = f"cycles/{self.cycle}/roles/{phase}-r{number}-t{self.state['test_version']}/complete"
            if self.evidence.exists(key):
                report = validate(self.evidence.read(key)['report'], OUTPUT_SCHEMAS[phase])
                if report.get('architecture_decision') is None:
                    return report
        # Implementation was produced before a contractual test correction, so
        # it retains its original test epoch while using the same contract version.
        if phase in ('implementation', 'fix'):
            for version in range(self.state['test_version'] - 1, 0, -1):
                for number in range(self.state['architecture_round'], -1, -1):
                    key = f'cycles/{self.cycle}/roles/{phase}-r{number}-t{version}/complete'
                    if self.evidence.exists(key):
                        report = validate(self.evidence.read(key)['report'], OUTPUT_SCHEMAS[phase])
                        if report.get('architecture_decision') is None:
                            return report
        raise AgentSystemError('Missing completed ' + phase + ' report for this candidate')

    def dispute(self, reason, clause, evidence):
        if self.state['state'] not in (State.TESTS_FAILED, State.REVIEWING) or reason not in ('contradicts_contract', 'unapproved_assumption', 'malformed_test'):
            raise AgentSystemError('Invalid test dispute state/reason')
        if not isinstance(clause, int) or not 0 <= clause < len(self.task['acceptance_criteria']) or not evidence.strip():
            raise AgentSystemError('Test dispute requires a contract clause and evidence')
        if self.state['dispute_count'] >= self.task['hardening']['max_disputes']:
            raise AgentSystemError('Test dispute bound exhausted; human investigation required')
        count = self.state['dispute_count'] + 1
        self.evidence.write(f'disputes/{count}/request', {'reason': reason, 'clause': clause, 'evidence': evidence,
                                                     'old_test_version': self.state['test_version']})
        self.state['dispute_count'] = count
        self.advance(State.TEST_DISPUTE)
        return self.state

    def resolve_dispute(self, approved_by, changes_semantics=False, reviewer_resolution=False):
        if self.state['state'] != State.TEST_DISPUTE or not approved_by.strip():
            raise AgentSystemError('Explicit dispute resolution required')
        if changes_semantics:
            raise AgentSystemError('Material clarification requires a new versioned task and human contract approval')
        if reviewer_resolution:
            report = self.evidence.read(f'disputes/{self.state["dispute_count"]}/reviewer-resolution')
            if (report.get('contract_version') != self.state['contract_version'] or report['task_id'] != self.task['task_id']
                    or report.get('test_dispute') is None or report['test_dispute']['changes_semantics']):
                raise AgentSystemError('Reviewer resolution is not purely contractual against this approved version')
        # Controller resolution authorization is recorded before the Tester correction.
        self.control.issue(f'disputes/{self.state["dispute_count"]}', {'approved_by': approved_by,
                           'changes_semantics': False, 'reviewer_resolution': reviewer_resolution,
                           'contract_version': self.state['contract_version']})
        self.state['test_version'] += 1
        self.advance(State.TESTING)
        return self.state

    def reviewer_dispute(self, report):
        dispute = report['test_dispute']
        self.dispute(dispute['reason'], dispute['clause'], dispute['evidence'])
        self.evidence.write(f'disputes/{self.state["dispute_count"]}/reviewer-resolution', report)
        if not dispute['changes_semantics']:
            self.resolve_dispute('Reviewer contractual resolution', reviewer_resolution=True)

    def step(self):
        current = State(self.state['state'])
        if current == State.CLASSIFY:
            self.state['data_critical'] = self.task['data_critical']
            self.state['audit_status'] = 'pending' if self.state['data_critical'] else 'not_required'
            self.advance(State.CONTRACT_READY)
        elif current == State.CONTRACT_READY:
            package = interface_package(self.task, self.config.root, self.state['base_commit'])
            warnings = lint_contract(package, self.task['workflow']['implementation_context'])
            self.evidence.write('contract/package', package)
            self.evidence.write('contract/lint', {'warnings': warnings})
            if warnings:
                raise AgentSystemError('Public contract lint warnings require a clarified new task')
            self.advance(State.CONTRACT_APPROVAL if self.task['major_phase'] else State.INTERFACE_FREEZE)
        elif current == State.INTERFACE_FREEZE:
            self.control.issue('interface', self.evidence.read('contract/package'))
            self.advance(State.ARCHITECTURE_CHECK)
        elif current == State.TEST_DESIGN_FROZEN:
            design = self.evidence.read('tester/frozen_design')
            mapping = self.invoke('test_implementation', {'test_design': design})
            self.evidence.write('tester/test_mapping', mapping)
            freeze_tests(self.control, self.git.path('tester'), self.state['commits']['tester'],
                         self.task['workflow']['test_paths'], self.state['test_version'])
            self.checkpoint('frozen_tests')
            self.advance(State.IMPLEMENTING)
        elif current == State.IMPLEMENTATION_READY:
            candidate = self.state['commits']['implementer']
            detected = architecture_drift(self.git.path('implementer'), self.state['base_commit'], candidate,
                                           self.config.project['architecture'], self.task['hardening']['interface']['files'])
            self.evidence.write(f'cycles/{self.cycle}/actual-diff', detected)
            data_paths = actual_data_paths(detected['changed_paths'], self.config.project['data_critical_patterns'])
            if data_paths and not self.state['data_critical']:
                self.state.update(data_critical=True, audit_status='pending')
                self.evidence.write('auditor/escalation', {'reason': 'actual changed paths matched data_critical_patterns', 'paths': data_paths})
                self.prepare()
            identity = digest(detected)
            approved = any(selection['decision']['decision_id'] == 'DRIFT-' + identity[:24] for selection in self.selections())
            if detected['reasons'] and not approved:
                package = self.drift_package(identity, detected)
                self.block_architecture(package, State.IMPLEMENTATION_READY)
            else:
                self.advance(State.TESTING)
        elif current == State.TESTING:
            # Tests were committed before implementation. Import only the candidate,
            # never send independent test objects back to the Implementer.
            tester = self.git.path('tester')
            if self.state['test_version'] > 1 and not (self.control.directory / f'tests/{self.state["test_version"]}.json').exists():
                request = self.evidence.read(f'disputes/{self.state["dispute_count"]}/request')
                resolution = self.control.verify(f'disputes/{self.state["dispute_count"]}')
                mapping = self.invoke('test_correction', {'test_design': self.evidence.read('tester/frozen_design')})
                self.evidence.write('tester/test_mapping', mapping)
                old = self.control.verify(f'tests/{self.state["test_version"] - 1}')
                corrections = {}
                for path in old['files']:
                    before = git(tester, 'show', f"{old['commit']}:{path}")
                    after = git(tester, 'show', f"{self.state['commits']['tester']}:{path}")
                    corrections[path] = validate_correction(before, after, self.task['hardening']['interface'].get('assertions', []),
                                                            resolution.get('reviewer_resolution', False))
                corrected = self.state['commits']['tester']
                git(self.git.path('reviewer'), 'fetch', str(tester), corrected)
                self.sync('reviewer', 'tester', f'correction-review-t{self.state["test_version"]}')
                report = self.invoke('test_correction_review', {'candidate_diff': git(tester, 'diff', old['commit'], corrected, '--')})
                from .gates import review_passes
                if not review_passes(report):
                    raise AgentSystemError('Reviewer did not approve the contractual test correction')
                frozen = freeze_tests(self.control, tester, self.state['commits']['tester'],
                                      self.task['workflow']['test_paths'], self.state['test_version'])
                self.evidence.write(f'disputes/{self.state["dispute_count"]}/correction',
                                    {'request': request, 'frozen': frozen, 'changes': corrections, 'review': report,
                                     'contract_version': self.state['contract_version']})
            candidate = self.state['commits']['implementer']
            key = f'cycles/{self.cycle}/tester-candidate-t{self.state["test_version"]}'
            if not self.evidence.exists(key):
                git(tester, 'fetch', str(self.git.path('implementer')), candidate)
                git(tester, '-c', 'user.name=Agent Framework', '-c', 'user.email=agent-framework@example.invalid',
                    '-c', 'core.hooksPath=' + str(self.directory / 'disabled-hooks'), 'merge', '--no-edit', candidate)
                commit = git(tester, 'rev-parse', 'HEAD')
                self.evidence.write(key, {'commit': commit, 'candidate': candidate})
            commit = self.evidence.read(key)['commit']
            self.state['commits']['tester'] = commit
            verify_frozen_tests(self.control, tester, commit, self.state['test_version'])
            self.save()
            self.advance(State.INTEGRATING)
        elif current == State.INTEGRATING:
            tester = self.git.path('tester')
            target = self.state['commits']['tester']
            git(self.git.path('integration'), 'fetch', str(tester), target)
            commit = self.sync('integration', 'tester', f'integration-t{self.state["test_version"]}')
            self.evidence.write(f'cycles/{self.cycle}/integration', {'task_id': self.task['task_id'], 'commit': commit,
                'source': 'tester', 'base_commit': self.state['base_commit'], 'task_digest': self.state['task_digest'],
                'configuration_digest': self.state['configuration_digest']})
            data_paths = actual_data_paths(changed_paths(self.git.path('integration'), self.state['base_commit']),
                                          self.config.project['data_critical_patterns'])
            if data_paths and not self.state['data_critical']:
                self.state.update(data_critical=True, audit_status='pending')
                self.evidence.write('auditor/escalation', {'reason': 'actual integrated paths matched data_critical_patterns', 'paths': data_paths})
                self.prepare()
            self.advance(State.INTEGRATED)
        elif current == State.FIXING:
            previous = self.cycle - 1
            decision = self.evidence.read(f'cycles/{previous}/decision')
            feedback = repair_feedback(self.task, self.evidence.read(f'cycles/{previous}/tests/result'),
                                       decision['review'], decision['audit'])
            frozen = self.control.verify(f'tests/{self.state["test_version"]}')
            hidden = [git(self.git.path('tester'), 'show', f"{frozen['commit']}:{path}")
                      for path in frozen['files'] if any(matches(path, p) for p in self.task['hardening']['holdout_paths'])]
            check_feedback(feedback, hidden)
            report = self.invoke('fix', {'hardened_feedback': feedback})
            if report['outcome'] in ('architecture_required', 'ARCH_BLOCKED'):
                self.block_architecture(report['architecture_decision'], current)
            else:
                self.advance(State.IMPLEMENTATION_READY)
        elif current == State.REVIEWING:
            self.sync('reviewer', 'integration', 'review-candidate')
            report = self.invoke('review_blind', {'candidate_diff': git(self.git.path('implementer'), 'diff', self.state['base_commit'], 'HEAD', '--')})
            if report['architecture_decision'] is not None:
                self.block_architecture(report['architecture_decision'], current)
            elif report.get('test_dispute') is not None:
                self.reviewer_dispute(report)
            else:
                report = self.invoke('review', self.validation_inputs())
                if report['architecture_decision'] is not None:
                    self.block_architecture(report['architecture_decision'], current)
                elif report.get('test_dispute') is not None:
                    self.reviewer_dispute(report)
                else:
                    from .gates import review_passes
                    passed = review_passes(report)
                    self.state['review_status'] = 'passed' if passed else 'failed'
                    self.advance(State.REVIEW_PASSED if passed else State.REVIEW_FAILED)
        elif current == State.TESTS_FAILED:
            frozen = self.control.verify(f'tests/{self.state["test_version"]}')
            dispute = detect_test_dispute(self.git.path('integration'), frozen['files'],
                                          self.task['hardening']['interface'].get('assertions', []))
            if dispute:
                if self.state['dispute_count'] >= self.task['hardening']['max_disputes']:
                    raise AgentSystemError('Bounded test disputes exhausted; human investigation required')
                self.dispute(**dispute)
            else:
                super().step()
        elif current == State.AUDITING:
            self.sync('auditor', 'integration', 'audit-candidate')
            candidate = self.state['commits']['integration']
            before = self._protected_boundary()
            key = f'cycles/{self.cycle}/auditor/regenerated'
            if not self.evidence.exists(key):
                regenerate_audit(self.config, self.task, self.git.path('auditor'), candidate, self.evidence, self.cycle, self.runner)
            if self._protected_boundary() != before:
                raise AgentSystemError('Auditor regeneration modified protected historical inputs')
            regenerated = self.evidence.read(key)
            report = self.invoke('audit', {**self.validation_inputs(), 'review': self.current_report('review'),
                                          'audit_validation': regenerated})
            if report['architecture_decision'] is not None:
                self.block_architecture(report['architecture_decision'], current)
            else:
                from .gates import audit_passes
                passed = audit_passes(report) and regenerated['expectations']['passed']
                self.state['audit_status'] = 'passed' if passed else 'failed'
                self.advance(State.AUDIT_PASSED if passed else State.AUDIT_FAILED)
        elif current == State.EXECUTING_TESTS:
            workspace = self.git.path('integration')
            verify_frozen_tests(self.control, workspace, self.state['commits']['integration'], self.state['test_version'])
            if self.task['hardening']['python_modules']:
                imports = verify_imports(workspace, self.task['hardening']['python_modules'], self.runner, self.task)
                self.evidence.write(f'cycles/{self.cycle}/tests/imports', imports)
            super().step()
        else:
            super().step()

    def drift_package(self, identity, detected):
        def option(name, description):
            return {'id': name, 'description': description,
                    'advantages': ['Retain the observed candidate for mandatory downstream validation'] if name == 'approve' else ['Prevent adoption of unapproved architectural changes'],
                    'disadvantages': ['Human must assess repository-specific compatibility and migration effects'] if name == 'approve' else ['A replacement task is needed to revise the implementation'],
                    'risks': ['Dependency, interface or layer consequences are not established by path detection alone'] if name == 'approve' else ['Partial candidate evidence remains local and must not be mistaken for accepted work'],
                    'migration_impact': 'Review the exact candidate diff before approval',
                    'compatibility_impact': 'No implicit authorization of future changes'}
        return {'task_id': self.task['task_id'], 'contract_version': self.state['contract_version'],
                'decision_id': 'DRIFT-' + identity[:24],
                'problem': 'Actual diff requires architecture approval: ' + ', '.join(detected['reasons']),
                'why_architectural': 'Mechanical architecture-sensitive change detection',
                'constraints': ['Candidate: ' + detected['candidate'], 'Diff identity: ' + identity],
                'options': [option('approve', 'Approve exactly this observed architectural diff'),
                            option('stop', 'Stop this task; prepare a replacement task reverting or redesigning the change')],
                'recommended_option': None}

    def approve_architecture(self, decision_id, option, approved_by):
        result = self._approve_architecture(decision_id, option, approved_by)
        if decision_id.startswith('DRIFT-') and option == 'stop':
            self.state.update(resume_state=str(State.ESCALATION_REQUIRED), failure_kind='candidate',
                              detail='Human declined the observed architecture drift; replacement task required')
            self.save()
        return result
