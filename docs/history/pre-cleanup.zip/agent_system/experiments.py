"""Prepare sequential, independent ordinary runs with explicitly different routing."""
import json

from .config import Configuration
from .errors import AgentSystemError
from .evaluation import FINAL
from .evidence import Evidence
from .orchestrator import Orchestrator
from .storage import contained, read_json
from .task import load_document, validate


def plan_experiment(root, source_id, new_id, models_path):
    original = Orchestrator(root)
    source = original.run_dir(source_id)
    state = original.status(source_id)
    if state["version"] < 2 or state["state"] not in FINAL or new_id == source_id:
        raise AgentSystemError("Experiment requires a completed executable source and a fresh identity")
    for path in original.config.runs_dir.glob("*/state.json"):
        saved = read_json(path)
        if saved["version"] >= 2 and saved["state"] not in FINAL:
            raise AgentSystemError("Finish existing runs before preparing a sequential routing experiment")
    original.run_dir(new_id)  # validate identity before using it in a path
    if original.run_dir(new_id).exists():
        raise AgentSystemError("Experiment task identity already exists")
    task = read_json(source / "task.json")
    if task.get("architecture", {}).get("proposal"):
        raise AgentSystemError("Prepare an explicit new contract for tasks containing task-bound architecture proposals")
    task = {**task, "task_id": new_id, "base_ref": state["base_commit"]}
    routing = validate(load_document(models_path), "models")
    project = read_json(source / "configuration.json")["project"]
    original.config = Configuration(root.resolve(), project, routing)
    contract_path = contained(original.config.runs_dir, f"experiment_contracts/{new_id}.json")
    contract_path.parent.mkdir(parents=True, exist_ok=True)
    # Explicit preparation only: no backend execution or model resolver.
    contract_path.write_text(json.dumps(validate(task, "task"), indent=2), encoding="utf-8")
    result = original.plan(contract_path)
    Evidence(original.run_dir(new_id)).write("experiment", {"source_task_id": source_id,
                 "base_commit": state["base_commit"], "routing_file": models_path.name,
                 "execution_policy": "sequential_explicit_resume"})
    return result
