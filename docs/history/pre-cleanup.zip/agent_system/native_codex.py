"""Small native CLI boundary. Codex owns model authentication and tool execution.

Experimental and opt-in: no legacy runner or transport routing is changed.
Only sanitized lifecycle/action metadata is retained; reasoning and raw provider
output are discarded. Controller artifact checks determine usability.
"""
import difflib
import hashlib
import json
import os
from pathlib import Path
import queue
import shutil
import subprocess
import threading
import time

from .errors import AgentSystemError
from .runners.docker_isolated import file_map, regular_tree


def native_environment():
    """Retain OS/runtime discovery; remove inherited chat and API credentials.

    CODEX_HOME is left untouched so native Codex can use its own login. No
    authentication file is opened, copied, or passed to the role.
    """
    blocked = {'OPENAI_API_KEY', 'OPENAI_BASE_URL', 'OPENAI_ORG_ID',
               'OPENAI_PROJECT_ID', 'CODEX_THREAD_ID', 'CODEX_SESSION_ID',
               'CODEX_APP_TOOLS_PIPE_PATH', 'CODEX_PERMISSION_PROFILE',
               'CODEX_INTERNAL_ORIGINATOR_OVERRIDE'}
    return {k: v for k, v in os.environ.items() if k.upper() not in blocked}


def failure_kind(message):
    """Classify, never store arbitrary error text (which may contain secrets)."""
    text = message.lower()
    if any(s in text for s in ('not logged in', 'unauthorized', '401',
                              'missing bearer', 'authentication', 'api key')):
        return 'native_authentication_unavailable'
    if any(s in text for s in ('not supported', 'not found', 'unavailable')) and 'model' in text:
        return 'native_model_unavailable'
    if any(s in text for s in ('sandbox', 'permission profile', 'permission denied')):
        return 'native_sandbox_failure'
    return 'native_execution_failure'


class NativeCodexRunner:
    """One fresh ephemeral exec per role; never resume or fork another role."""
    def __init__(self, executable=None):
        self.executable = str(Path(executable or shutil.which('codex') or '').resolve())
        if not Path(self.executable).is_file():
            raise AgentSystemError('Native Codex executable unavailable')
        self.version = subprocess.run([self.executable, '--version'],
            capture_output=True, text=True, timeout=20, check=True).stdout.strip()

    def command(self, workspace, model, effort, target):
        # Supported native permission profile: bounded reads, exact artifact
        # write, no project network. No custom relay or model/tool protocol.
        access = {':minimal': 'read', ':workspace_roots': {'.': 'read', target: 'write'},
                  ':tmpdir': 'deny', ':slash_tmp': 'deny'}
        # Build a TOML inline table, with every path quoted as a literal key.
        filesystem = ', '.join(json.dumps(k) + '=' + (
            '{' + ', '.join(json.dumps(a) + '=' + json.dumps(b) for a, b in v.items()) + '}'
            if isinstance(v, dict) else json.dumps(v)) for k, v in access.items())
        profile = '{filesystem={' + filesystem + '},network={enabled=false}}'
        argv = [self.executable, '--no-daemon', '-a', 'never', 'exec',
                '--ignore-user-config', '--ephemeral', '--json', '--color', 'never',
                '--cd', str(workspace), '--model', model,
                '-c', 'model_reasoning_effort=' + json.dumps(effort),
                '-c', 'default_permissions="stage23"',
                '-c', 'permissions.stage23=' + profile,
                '-c', 'shell_environment_policy.inherit="core"',
                '-c', 'features.multi_agent=false',
                '-c', 'web_search="disabled"']
        if os.name == 'nt':
            argv.extend(['-c', 'windows.sandbox="elevated"'])
        return [*argv, '-']

    def run(self, *, trial_id, role, workspace, prompt, target, model, effort,
            verify, timeout_seconds=120):
        workspace = Path(workspace).resolve()
        regular_tree(workspace)
        artifact = workspace / target
        if (not target or Path(target).is_absolute() or '..' in Path(target).parts
                or not artifact.resolve().is_relative_to(workspace)):
            raise AgentSystemError('Invalid native artifact target')
        before = file_map(workspace)
        original = artifact.read_bytes() if artifact.exists() else b''
        if timeout_seconds <= 0:
            raise AgentSystemError('Native execution timeout must be positive')
        argv = self.command(workspace, model, effort, target)
        record = {'trial_id': trial_id, 'role': role, 'model': model,
            'reasoning': effort, 'codex_version': self.version, 'invocation_mode': 'exec',
            'command': argv, 'workspace': str(workspace),
            'workspace_identity': hashlib.sha256(str(workspace).encode()).hexdigest(),
            'prompt_sha256': hashlib.sha256(prompt.encode()).hexdigest(),
            'baseline_hashes': before,
            'fresh_context': True, 'ephemeral': True, 'conversation_history_inherited': False,
            'process_exit_code': None, 'execution_status': 'unrecoverable',
            'failure_category': None, 'actions': [], 'thread_id': None,
            'native_turn_completed': False, 'artifact_boundary_observed': False,
            'shutdown_confirmed': False, 'candidate_status': 'missing',
            'model_resolution': 'explicit_native_cli_selection; inference_not_yet_verified',
            'resolved_model': None}
        started = time.monotonic()
        events = queue.Queue()
        process = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, encoding='utf-8', errors='replace',
            cwd=workspace, env=native_environment())

        def read(stream, kind):
            for line in stream:
                events.put((kind, line))
            events.put((kind, None))

        readers = [threading.Thread(target=read, args=(process.stdout, 'out'), daemon=True),
                   threading.Thread(target=read, args=(process.stderr, 'err'), daemon=True)]
        for reader in readers:
            reader.start()
        try:
            process.stdin.write(prompt)
            process.stdin.close()
            ended = set()
            while len(ended) < 2:
                remaining = timeout_seconds - (time.monotonic() - started)
                if remaining <= 0:
                    record['failure_category'] = 'native_timeout'
                    break
                try:
                    kind, line = events.get(timeout=min(.25, remaining))
                except queue.Empty:
                    continue
                if line is None:
                    ended.add(kind)
                    continue
                if kind == 'err':
                    category = failure_kind(line)
                    if category != 'native_execution_failure':
                        record['failure_category'] = category
                    continue
                try:
                    event = json.loads(line)
                except ValueError:
                    record['failure_category'] = 'native_output_invalid'
                    continue
                etype = event.get('type')
                if etype == 'thread.started':
                    record['thread_id'] = event.get('thread_id')
                elif etype == 'turn.completed':
                    record['native_turn_completed'] = True
                elif etype in ('error', 'turn.failed'):
                    record['failure_category'] = failure_kind(json.dumps(event))
                elif etype == 'item.completed':
                    item = event.get('item', {})
                    itype = item.get('type')
                    if itype in ('file_change', 'command_execution'):
                        # Exclude raw command/output/agent/reasoning content.
                        record['actions'].append({'type': itype, 'status': item.get('status'),
                            'exit_code': item.get('exit_code'), 'id': item.get('id')})
                        success = (item.get('status') == 'completed' and
                                   (itype != 'command_execution' or item.get('exit_code') == 0))
                        if success and artifact.is_file() and file_map(workspace) != before:
                            data = artifact.read_bytes()
                            try:
                                checked = verify(data)
                            except Exception:
                                checked = None
                            if checked and checked.get('valid') is True:
                                record['artifact_boundary_observed'] = True
                                break
        finally:
            if process.poll() is None:
                # Kill only this owned process tree; inspect stable artifacts
                # after all native tools have stopped. No extra narration turn.
                if os.name == 'nt':
                    stopped = subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'],
                        capture_output=True, timeout=20)
                    record['tree_stop_exit_code'] = stopped.returncode
                    if stopped.returncode != 0 and process.poll() is None:
                        # The process handle can still end the launcher, but
                        # that does not prove descendants ended: refuse recovery.
                        process.terminate()
                else:
                    process.terminate()
            try:
                process.wait(timeout=20)
                record['shutdown_confirmed'] = record.get('tree_stop_exit_code', 0) == 0
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=10)
            for reader in readers:
                reader.join(timeout=2)
            record['process_exit_code'] = process.returncode
            record['elapsed_seconds'] = round(time.monotonic() - started, 3)
            process.stdout.close()
            process.stderr.close()
        try:
            after = file_map(workspace)
            changed = sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))
            record['changed_files'] = changed
            record['mutation_scope_valid'] = changed == [target]
            record['artifact_hashes'] = {p: after[p] for p in changed if p in after}
            valid_file = artifact.is_file() and artifact.stat().st_nlink == 1
            check = verify(artifact.read_bytes()) if valid_file and changed == [target] else None
            record['artifact_check'] = check
            # Arbitrary native failures are not an allowlist. Only a known
            # timeout or Controller stop at a completed tool artifact boundary
            # is eligible for deterministic recovery.
            recoverable = record['failure_category'] in (None, 'native_timeout')
            usable = (check and check.get('valid') is True and record['shutdown_confirmed'] and
                      recoverable and (record['native_turn_completed'] or record['artifact_boundary_observed']))
            if usable:
                record['execution_status'] = ('completed' if record['native_turn_completed'] and
                    record['process_exit_code'] == 0 else 'abnormal_recoverable')
                record['candidate_status'] = 'unaccepted'
                record['model_resolution'] = 'explicit_native_cli_selection; artifact_produced; resolved_identifier_unobserved'
                record['diff'] = ''.join(difflib.unified_diff(
                    original.decode('utf-8').splitlines(True), artifact.read_text(encoding='utf-8').splitlines(True),
                    fromfile='a/' + target, tofile='b/' + target))
            elif not record['failure_category']:
                record['failure_category'] = 'required_artifact_invalid_or_missing'
        except Exception as exc:
            record['failure_category'] = 'artifact_inspection_' + type(exc).__name__
        return record
