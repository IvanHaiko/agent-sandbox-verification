"""Non-launching transport policy prototype for SIWC + isolated Codex runtime.

No HTTP listener, inference request or host tool executor exists in this module.
Policy tests are not OS/network admission. Live use remains blocked.
"""
from dataclasses import dataclass
import json
import time

from .agent_transport import strict_json
from .chatgpt_oauth import APP_NAME
from .errors import AgentSystemError
from .roles import Role


@dataclass(frozen=True)
class ModelRequestPolicy:
    execution_id: str
    task_id: str
    role: str
    model: str
    deadline: float
    max_requests: int = 4
    max_input_bytes: int = 262144


class PlanModelBoundary:
    """Authorize one fixed upstream operation, never a caller-controlled URL.

    The eventual relay must authenticate its channel independently. Identity
    fields alone are not credentials. This prototype accepts no upstream token
    and has no network dispatch method.
    """
    ALLOWED = {'model', 'input', 'instructions', 'store', 'stream', 'tools', 'tool_choice',
               'parallel_tool_calls', 'text', 'reasoning', 'include'}

    def __init__(self, policy):
        if (type(policy.max_requests) is not int or policy.max_requests < 1
                or type(policy.max_input_bytes) is not int or policy.max_input_bytes < 1):
            raise AgentSystemError('Invalid model boundary limits')
        self.policy, self.requests, self.closed = policy, 0, False

    def authorize(self, execution_id, task_id, role, body_bytes):
        p = self.policy
        if self.closed or time.monotonic() >= p.deadline:
            raise AgentSystemError('Stale model execution')
        if (execution_id, task_id, role) != (p.execution_id, p.task_id, p.role):
            raise AgentSystemError('Model execution identity mismatch')
        if self.requests >= p.max_requests:
            raise AgentSystemError('Model request ceiling reached')
        if not isinstance(body_bytes, bytes) or len(body_bytes) > p.max_input_bytes:
            raise AgentSystemError('Model request oversized')
        try:
            body = strict_json(body_bytes.decode('utf-8'))
        except (UnicodeDecodeError, AgentSystemError):
            raise AgentSystemError('Malformed model request') from None
        if (not isinstance(body, dict) or set(body) - self.ALLOWED
                or body.get('model') != p.model or body.get('store') is not False
                or body.get('stream') is not True or not isinstance(body.get('input'), list)):
            raise AgentSystemError('Unsupported ChatGPT plan request')
        if any(isinstance(item, dict) and item.get('role') == 'system' for item in body['input']):
            raise AgentSystemError('System message items unsupported on plan route')
        tools = body.get('tools', [])
        if not isinstance(tools, list):
            raise AgentSystemError('Invalid plan tools')
        # Narrower than upstream: no hosted tools or caller-controlled remote MCP.
        for namespace in tools:
            if not isinstance(namespace, dict) or namespace.get('type') != 'namespace' or not isinstance(namespace.get('tools'), list):
                raise AgentSystemError('Only namespaced local function/custom tools allowed')
            if any(not isinstance(tool, dict) or tool.get('type') not in ('function', 'custom') for tool in namespace['tools']):
                raise AgentSystemError('Hosted/unsupported tool forbidden')
        self.requests += 1
        return body

    def close(self):
        self.closed = True

    def require_live(self):
        raise AgentSystemError('Plan transport not admitted: relay, isolated runtime and credit policy unverified')


class IsolatedToolBridge:
    """Read-only command bridge for future dynamic tools; no host fallback.

    File mutations require existing authenticated role lifecycle, not this helper.
    The role cannot supply a workspace path or runtime identity.
    """
    def __init__(self, runner, workspace, task, execution_id, role, timeout_seconds=30):
        if getattr(runner, 'backend', None) != 'docker_isolated' or type(timeout_seconds) is not int or not 1 <= timeout_seconds <= 60:
            raise AgentSystemError('Tool bridge requires bounded Docker execution')
        self.runner, self.workspace, self.task = runner, workspace, task
        self.execution_id, self.role, self.timeout_seconds = execution_id, str(Role(role)), timeout_seconds
        self.closed = False

    def execute(self, request):
        if self.closed or not isinstance(request, dict) or set(request) != {'execution_id', 'task_id', 'role', 'argv'}:
            raise AgentSystemError('Invalid or stale isolated tool request')
        if (request['execution_id'], request['task_id'], request['role']) != (self.execution_id, self.task['task_id'], self.role):
            raise AgentSystemError('Isolated tool identity mismatch')
        argv = request['argv']
        if (not isinstance(argv, list) or not 1 <= len(argv) <= 64
                or any(not isinstance(arg, str) or not arg or '\0' in arg for arg in argv)
                or len(json.dumps(argv).encode()) > 16384):
            raise AgentSystemError('Invalid isolated command')
        self.runner.isolation_capabilities().require()
        return self.runner.run_command(argv, self.workspace, {}, self.timeout_seconds, self.task, read_only=True)

    def close(self):
        self.closed = True


class AppServerBoundary:
    """Fail closed on host built-in tool requests. Approval is not delegation.

    No turn/start is exposed until a measured isolated execution arrangement is
    available. Auth, generic fs/process/config RPCs never go to an untrusted role.
    """
    def __init__(self, binding):
        self.binding = binding

    def initialize(self):
        return {'id': 1, 'method': 'initialize', 'params': {'clientInfo': {
            'name': APP_NAME, 'title': 'Codex Multi-Agent Engineering', 'version': '1.0.0'}}}

    def handle_server_request(self, message):
        if not isinstance(message, dict) or 'id' not in message:
            raise AgentSystemError('Invalid app-server request')
        method = message.get('method')
        if method in ('item/commandExecution/requestApproval', 'item/fileChange/requestApproval'):
            return {'id': message['id'], 'result': {'decision': 'decline'}}
        raise AgentSystemError('App-server tool/execution delegation not admitted')

    def start_turn(self):
        raise AgentSystemError('Trusted app-server cannot start a role turn before isolated tool routing is measured')
