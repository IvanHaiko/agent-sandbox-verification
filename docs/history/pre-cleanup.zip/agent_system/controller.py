"""Deterministic workflow authority; no LLM may override a mandatory gate.

Orchestrator remains a backward-compatible import name. LLM proposal generation
is the orchestrator role, not this controller's workflow authority.
"""
from .orchestrator import Orchestrator


class Controller(Orchestrator):
    pass
