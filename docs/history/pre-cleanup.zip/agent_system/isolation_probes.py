"""Independent offline probe harness. Results, not declarations, attest Docker."""
import errno
import hashlib
import json
from pathlib import Path
import socket
import subprocess
from uuid import uuid4

from .errors import AgentSystemError
from .git import git
from .isolation import CAPABILITIES
from .storage import atomic_json


def host_candidates(path):
    """Probe the known host path and common Docker Desktop/WSL host bridges."""
    path = Path(path).resolve()
    result = [str(path)]
    if path.drive:
        drive = path.drive[0].lower()
        tail = path.as_posix().split(':', 1)[1]
        result += [prefix + '/' + drive + tail for prefix in
                   ('/mnt', '/host_mnt', '/mnt/host', '/run/desktop/mnt/host')]
    return result


def validate_docker_isolation(runner):
    store = runner._store()
    if (store.directory / 'validation.json').exists():
        return store.verify('validation')
    root = runner.root / 'probe-inputs' / uuid4().hex
    root.mkdir(parents=True, exist_ok=False)
    checkout = root / 'role source with spaces'
    checkout.mkdir()
    git(checkout, 'init', '--initial-branch=baseline')
    git(checkout, 'config', 'user.name', 'Isolation Probe')
    git(checkout, 'config', 'user.email', 'probe@example.invalid')
    (checkout / 'example.py').write_text('value = 2\n', encoding='utf-8')
    (checkout / '.gitignore').write_text('raw/\n', encoding='utf-8')
    git(checkout, 'add', '.')
    git(checkout, 'commit', '-m', 'Public probe baseline')
    (checkout / 'raw').mkdir()
    (checkout / 'raw/history.csv').write_text('protected history\n', encoding='utf-8')
    # Bind the actual Controller attestation key, not merely an approval forgery.
    store._key(create=True)
    secret_paths = [store.directory / 'key']
    canaries = []
    for relative in ('implementer/private.txt', 'tester/holdout.py', 'controller/state.json',
                     'host-home/AGENTS.md', 'global-history/session.json', 'shared-cache/private.txt',
                     'host-temp/private.txt', 'other-task/state.json'):
        path = root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        canary = 'PRIVATE_' + uuid4().hex
        path.write_text(canary, encoding='utf-8')
        secret_paths.append(path)
        canaries.append(canary)
    # Secret commit exists only in a sibling repository, not in the role baseline.
    sibling = root / 'implementer-repo'
    sibling.mkdir()
    git(sibling, 'init', '--initial-branch=implementer-secret')
    git(sibling, 'config', 'user.name', 'Isolation Probe')
    git(sibling, 'config', 'user.email', 'probe@example.invalid')
    canary = 'GIT_PRIVATE_' + uuid4().hex
    (sibling / 'secret.txt').write_text(canary)
    git(sibling, 'add', '.')
    git(sibling, 'commit', '-m', canary)
    secret_commit = git(sibling, 'rev-parse', 'HEAD')
    canaries.append(canary)
    secret_paths.append(sibling / 'secret.txt')
    hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in secret_paths}
    candidates = [c for p in secret_paths for c in host_candidates(p)]
    directory_candidates = [c for p in (root, runner.config.root, Path.home(), runner.root, runner.config.runs_dir)
                            for c in host_candidates(p)]
    probe = r'''import errno, importlib, json, os, pathlib, socket, subprocess, sys
paths, directories, secret_commit = json.loads(sys.argv[1])
result = {'forbidden_reads': {}, 'forbidden_writes': {}, 'directory_visibility': {}, 'git': {}}
for value in paths:
    path = pathlib.Path(value)
    try:
        result['forbidden_reads'][value] = {'leaked': path.read_bytes().decode('utf-8', 'replace')}
    except OSError:
        result['forbidden_reads'][value] = 'inaccessible'
    try:
        with path.open('wb') as stream: stream.write(b'FORBIDDEN_MUTATION')
        result['forbidden_writes'][value] = 'writable'
    except OSError:
        result['forbidden_writes'][value] = 'denied'
for value in directories:
    try: result['directory_visibility'][value] = [str(p) for p in pathlib.Path(value).iterdir()]
    except OSError: result['directory_visibility'][value] = 'inaccessible'
for argv in (['branch','-a'], ['log','--all'], ['for-each-ref'], ['reflog','--all'],
             ['cat-file','-p', secret_commit], ['show','implementer-secret:secret.txt']):
    cp = subprocess.run(['git',*argv], capture_output=True, text=True)
    result['git'][' '.join(argv)] = {'returncode':cp.returncode,'stdout':cp.stdout,'stderr':cp.stderr}
result['environment'] = dict(os.environ)
result['uid'] = os.getuid()
result['parent_listing'] = [str(p) for p in pathlib.Path('/').iterdir()]
result['discovery'] = []
for root in ('/workspace','/role','/home','/tmp','/mnt','/run'):
    for directory, dirs, files in os.walk(root, followlinks=False):
        if len(result['discovery']) > 2000: dirs[:] = []; continue
        for name in files:
            path = pathlib.Path(directory) / name
            try:
                if path.stat().st_size < 8192:
                    text = path.read_text(errors='replace')
                    result['discovery'].append({'path':str(path),'text':text if 'PRIVATE_' in text else ''})
            except OSError: pass
result['socket_visible'] = pathlib.Path('/var/run/docker.sock').exists()
result['root_write_denied'] = False
try: pathlib.Path('/tmp/escape').write_text('bad')
except OSError: result['root_write_denied'] = True
result['git_write_denied'] = False
try: pathlib.Path('/workspace/.git/config').write_text('bad')
except OSError: result['git_write_denied'] = True
pathlib.Path('/role/home/session-marker').write_text('private invocation')
pathlib.Path('/role/cache/cache-marker').write_text('private invocation')
pathlib.Path('/role/state/history-marker').write_text('private invocation')
sys.path.insert(0, '/workspace')
module = importlib.import_module('example')
result['import_origin'] = module.__file__
listener = socket.socket(); listener.bind(('127.0.0.1', 0)); listener.listen(1)
client = socket.create_connection(listener.getsockname(), timeout=2)
accepted, _ = listener.accept(); accepted.close(); client.close(); listener.close()
result['loopback_control'] = True
try:
    socket.create_connection(('1.1.1.1', 443), timeout=3).close()
    result['outbound'] = {'connected':True}
except OSError as exc:
    result['outbound'] = {'connected':False,'errno':exc.errno,'error_code':errno.errorcode.get(exc.errno),'error':str(exc)}
result['routes'] = pathlib.Path('/proc/net/route').read_text()
print(json.dumps(result))
'''
    records = []
    cp, directory, _ = runner._execute(['python', '-I', '-c', probe,
        json.dumps([candidates, directory_candidates, secret_commit])], checkout, 30, {})
    records.append(directory)
    if cp.returncode:
        raise AgentSystemError('Isolation read probe failed: ' + cp.stderr[:4000])
    observed = json.loads(cp.stdout)
    private_unchanged = all(p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest() == hashes[str(p)] for p in secret_paths)
    reads = all(v == 'inaccessible' for v in observed['forbidden_reads'].values())
    writes = all(v == 'denied' for v in observed['forbidden_writes'].values())
    directories_hidden = all(v == 'inaccessible' for v in observed['directory_visibility'].values())
    leakage_absent = not any(canary in cp.stdout or canary in cp.stderr for canary in canaries)
    git_isolated = (observed['git']['cat-file -p ' + secret_commit]['returncode'] != 0
                    and observed['git']['show implementer-secret:secret.txt']['returncode'] != 0
                    and leakage_absent and 'implementer-secret' not in observed['git']['branch -a']['stdout'])
    fresh = r'''import json, os, pathlib
print(json.dumps({'fresh': not any(pathlib.Path(p).exists() for p in
 ('/role/home/session-marker', '/role/cache/cache-marker', '/role/state/history-marker')),
 'uid':os.getuid(), 'git_exists':pathlib.Path('/workspace/.git').is_dir()}))'''
    cp2, directory2, _ = runner._execute(['python', '-I', '-c', fresh], checkout, 15, {})
    records.append(directory2)
    fresh_ok = cp2.returncode == 0 and json.loads(cp2.stdout)['fresh']
    # Test actual read-only bind mounts inside an otherwise writable role checkout.
    original_protected = runner.config.project['protected_paths']
    runner.config.project['protected_paths'] = [*original_protected, 'raw/**']
    mutation = r'''import json, pathlib
result = {}
for name in ('.git/config', 'raw/history.csv'):
    try: pathlib.Path(name).write_text('FORBIDDEN_MUTATION'); result[name] = False
    except OSError: result[name] = True
pathlib.Path('allowed.txt').write_text('allowed scratch project change')
print(json.dumps(result))'''
    task = {'_role': 'implementer', '_phase': 'implementation',
            'scope': {'allowed_paths': ['allowed.txt'], 'forbidden_paths': []},
            'workflow': {'test_paths': ['tests/acceptance/**']}}
    try:
        cp3, directory3, exported = runner._execute(['python', '-I', '-c', mutation], checkout, 15, task, False)
    finally:
        runner.config.project['protected_paths'] = original_protected
    records.append(directory3)
    protected_ok = (cp3.returncode == 0 and all(json.loads(cp3.stdout).values())
                    and exported == ['allowed.txt'] and (checkout / 'raw/history.csv').read_text() == 'protected history\n')
    cleanup_ok = all(json.loads((d / 'ownership.json').read_text())['cleanup'] == 'confirmed'
                     and not (d / 'checkout').exists() and not (d / 'transfer').exists() for d in records)
    # Network evidence is a kernel no-route result, plus a functioning loopback
    # connection. It cannot be explained by a dead remote service or DNS failure.
    network_ok = (observed['loopback_control'] and observed['outbound'].get('error_code') == 'ENETUNREACH'
                  and len(observed['routes'].strip().splitlines()) == 1)
    facts = {'filesystem_read': reads and directories_hidden and leakage_absent,
             'filesystem_write': writes and private_unchanged and protected_ok and observed['root_write_denied'],
             'private_home': reads and fresh_ok and observed['environment']['HOME'] == '/role/home',
             'session_storage': reads and fresh_ok and cleanup_ok,
             'private_cache': reads and fresh_ok and observed['environment']['XDG_CACHE_HOME'] == '/role/cache',
             'instruction_control': reads and directories_hidden and leakage_absent,
             'network_denied': network_ok, 'isolated_checkout': git_isolated,
             'readonly_mounts': protected_ok and observed['git_write_denied'],
             'environment': observed['import_origin'] == '/workspace/example.py' and observed['uid'] == 50000,
             'hidden_tests': reads and leakage_absent and git_isolated,
             'controller_storage': reads and writes and private_unchanged,
             'fresh_context': fresh_ok and cleanup_ok}
    store.directory.mkdir(parents=True, exist_ok=True)
    evidence_paths = []
    for index, execution in enumerate(records):
        for filename in ('enforcement.json', 'command.json', 'ownership.json', 'stdout.txt', 'stderr.txt'):
            name = f'probe-{index}-{filename}'
            content = (execution / filename).read_bytes()
            (store.directory / name).write_bytes(content)
            evidence_paths.append([name, hashlib.sha256(content).hexdigest()])
    report = {'version': 1, 'backend': runner.backend, 'binding': store.binding,
              'capabilities': {name: {'passed': facts[name], 'evidence': evidence_paths} for name in CAPABILITIES},
              'private_files_unchanged': private_unchanged, 'cleanup_confirmed': cleanup_ok,
              'admitted': all(facts.values()), 'model_calls': 0,
              'limits': {'instruction_loader': 'Filesystem prerequisite only; live agent loader unverified',
                         'live_agent': 'JSON-stdin deterministic driver only; authentication/model calls unverified'},
              'probe_input_root': str(root)}
    # Partial/failed probes are retained but never signed as an accepted report.
    atomic_json(store.directory / 'probe-results.json', report)
    if not report['admitted']:
        return report
    store.issue('validation', report)
    return report
