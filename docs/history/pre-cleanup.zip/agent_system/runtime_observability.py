"""Controller-only failure receipts. Never export exception prose or raw streams."""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import stat

from .contexts import check_role_paths
from .errors import AgentSystemError
from .policies import check_paths
from .roles import Role
from .state_machine import timestamp
from .storage import atomic_json, contained


CATEGORIES = frozenset(('model_request_failure', 'model_protocol_failure',
    'stream_transport_failure', 'socket_idle_timeout', 'response_validation_failure',
    'tool_request_validation_failure', 'tool_execution_failure', 'handoff_schema_failure',
    'handoff_finalization_failure', 'relay_or_session_failure', 'controller_rejection',
    'unknown_runtime_failure'))

# Only exact local literals can become details; arbitrary provider/exception text
# is discarded, including when it happens to contain a familiar category name.
DETAILS = {
    'Malformed, partial or overflowing Codex protocol': 'model_protocol_failure',
    'Codex stderr overflow': 'model_protocol_failure',
    'Invalid Codex frame': 'model_protocol_failure',
    'Codex executable binding changed': 'controller_rejection',
    'Fresh Codex home required': 'controller_rejection',
    'Codex RPC rejected or replayed': 'model_protocol_failure',
    'Codex warning/error/reroute denied': 'relay_or_session_failure',
    'Codex process unavailable': 'relay_or_session_failure',
    'Codex process crashed or missing completion': 'relay_or_session_failure',
    'Codex execution cancelled or timed out': 'relay_or_session_failure',
    'Codex execution cancelled': 'relay_or_session_failure',
    'Codex pipe shutdown unconfirmed': 'relay_or_session_failure',
    'Relay shutdown unconfirmed': 'relay_or_session_failure',
    'Unsuccessful Codex completion': 'handoff_finalization_failure',
    'Final structured agent message missing': 'handoff_finalization_failure',
    'Structured Codex role result schema mismatch': 'handoff_schema_failure',
    'Structured Codex role identity mismatch': 'handoff_schema_failure',
    'Structured Codex contract version missing or mismatched': 'handoff_schema_failure',
    'Credential-bearing output rejected': 'controller_rejection',
    'Built-in or unknown Codex server request denied': 'controller_rejection',
    'Codex dynamic tool binding mismatch': 'tool_request_validation_failure',
    'Codex tool arguments differ from gated model response': 'tool_request_validation_failure',
}


def safe_failure(error, layer=None, metadata=None):
    """Classify the current failed boundary, never a previous successful response."""
    metadata = metadata or {}
    body = metadata.get('body_failure')
    if layer == 'model_request_failure' and body == 'socket_idle_timeout':
        return {'category': 'socket_idle_timeout', 'detail': 'socket_idle_timeout'}
    if layer == 'model_request_failure' and body in {
            'body_deadline', 'truncated_content_length', 'body_overflow', 'body_read_limit',
            'http_framing_or_truncation', 'socket_error', 'local_reader_error',
            'cancelled', 'reader_shutdown_failed', 'execution_deadline'}:
        return {'category': 'stream_transport_failure', 'detail': body}
    if layer == 'model_request_failure' and metadata.get('secret_checked') is False:
        return {'category': 'controller_rejection', 'detail': 'Credential-bearing output rejected'}
    if layer == 'model_request_failure' and metadata.get('secret_checked') is True and metadata.get('validation_passed') is False:
        return {'category': 'response_validation_failure', 'detail': 'Response validation rejected'}
    message = str(error) if isinstance(error, AgentSystemError) else ''
    if message in DETAILS:
        return {'category': DETAILS[message], 'detail': message}
    if layer in CATEGORIES:
        return {'category': layer, 'detail': layer}
    return {'category': 'unknown_runtime_failure', 'detail': 'Unclassified runtime failure'}


def diagnostic_directory(bridge):
    """A Controller root separate from both role roots and disposable runtime_root."""
    config = getattr(bridge.runner, 'config', None)
    if config is None:
        return None
    runtime = config.runtime_root
    root = runtime.parent / 'diagnostics' / runtime.name
    return contained(root, bridge.policy.binding.task_id + '/' + bridge.policy.binding.execution_id)


def preserve_failure(session, error, directory=None):
    bridge, policy = session.bridge, session.policy
    directory = Path(directory) if directory is not None else diagnostic_directory(bridge)
    if directory is None:
        return None  # Synthetic callers without a configured Controller may opt in.
    if any(directory.resolve().is_relative_to(p.resolve()) for p in (Path(bridge.workspace), session.home)):
        raise AgentSystemError('Diagnostic archive must be outside disposable role storage')
    failure = getattr(bridge, 'failure_receipt', None) or getattr(session, 'runtime_failure', None)
    relay_failures = getattr(session.relay, 'failure_receipts', [])
    if failure is None and relay_failures:
        failure = relay_failures[0]
    if failure is None:
        failure = safe_failure(AgentSystemError(session.failure) if session.failure else error)
    written = getattr(bridge, 'successful_write_paths', set())
    candidates, skipped = [], 0
    if policy.binding.role == str(Role.IMPLEMENTER) and policy.phase in ('implementation', 'fix'):
        for relative in sorted(written):
            try:
                check_paths(Role.IMPLEMENTER, [relative], bridge.task, bridge.runner.config.project)
                check_role_paths(Role.IMPLEMENTER, policy.phase, [relative], bridge.task)
                source = contained(Path(bridge.workspace), relative)
                # Inspect the original path components too: contained() resolves links.
                path = Path(bridge.workspace)
                for part in Path(relative).parts:
                    path /= part
                    info = path.lstat()
                    if path.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
                        raise AgentSystemError('Unsafe diagnostic candidate')
                info = source.lstat()
                if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                    raise AgentSystemError('Unsafe diagnostic candidate')
                data = source.read_bytes()
                bridge.secrets.reject(data.decode('utf-8', errors='replace'))
            except (AgentSystemError, OSError):
                skipped += 1
                continue
            sha = hashlib.sha256(data).hexdigest()
            archive = contained(directory, 'candidates/' + relative)
            archive.parent.mkdir(parents=True, exist_ok=True)
            with archive.open('xb') as stream:
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            candidates.append({'path': relative, 'sha256': sha,
                'archive_path': archive.relative_to(directory).as_posix(),
                'originating_invocation_id': policy.binding.execution_id,
                'archived_at': timestamp(), 'status': 'unaccepted_diagnostic_candidate', 'accepted': False})
    upstream = session.relay.upstream
    transport = getattr(upstream, 'response_metadata_history', [])
    responses = session.relay.gate.response_metadata_history
    last = transport[-1] if transport else {}
    gate_last = responses[-1] if responses else {}
    # Anomaly types are fixed local codes emitted by existing parsers. No raw
    # item, provider ID, request, stderr, environment or exception is included.
    counters = Counter(a['anomaly_type'] for m in [*responses, *transport, session.observation_metadata]
                       for a in m.get('anomalies', []))
    receipt = {'schema_version': 1, 'invocation_id': policy.binding.execution_id,
        'role': policy.binding.role, 'model': policy.binding.model, 'reasoning': policy.binding.reasoning,
        'role_status': 'failed', 'accepted': False, 'recorded_at': timestamp(),
        'failure_category': failure['category'], 'failure_detail': failure['detail'],
        'request_count': session.relay.gate.requests, 'tool_call_count': bridge.calls,
        'completed_tool_call_count': getattr(bridge, 'completed_calls', 0),
        'tool_result_returned': session.tool_result_returned,
        'last_completed_phase': session.last_completed_phase,
        'response_validation_passed': gate_last.get('validation_passed', last.get('validation_passed')),
        'eof_observed': last.get('eof'), 'reader_shutdown_confirmed': last.get('reader_shutdown_confirmed'),
        'socket_idle_timeout_observed': any(m.get('body_failure') == 'socket_idle_timeout' for m in transport),
        'parser_status': session.parser_status, 'handoff_status': session.handoff_status,
        'protocol_bytes': session.protocol_bytes, 'stderr_bytes': session.stderr_bytes,
        'protocol_anomaly_counters': dict(counters), 'candidate_written': bool(written),
        'candidate_preserved': bool(candidates), 'candidate_archived': bool(candidates),
        'candidate_skipped_count': skipped, 'candidates': candidates}
    bridge.secrets.reject(json.dumps(receipt, ensure_ascii=False))
    atomic_json(directory / 'failure_receipt.json', receipt)
    return receipt
