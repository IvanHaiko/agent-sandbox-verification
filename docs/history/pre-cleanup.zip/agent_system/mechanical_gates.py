"""Conservative diff detectors and quantitative gates over frozen expectations."""
import ast
import json
import os
from pathlib import Path
import subprocess

from .errors import AgentSystemError
from .git import git
from .isolation import local_environment, verify_imports
from .policies import changed_paths, matches, protected_snapshot, path_manifest


DEFAULT_SENSITIVE = ('pyproject.toml', 'requirements*.txt', '*.lock', '**/*.lock',
                     '*lock.json', '**/*lock.json', '**/*.schema.json', 'schemas/**', 'migrations/**', '**/migrations/**')


def _source(workspace, ref, path):
    try:
        return git(workspace, 'show', f'{ref}:{path}')
    except AgentSystemError:
        return ''


def public_signatures(source):
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return {'unparseable': source}
    result = {}
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and not node.name.startswith('_'):
            result[node.name] = (ast.dump(node.args), ast.dump(node.returns) if node.returns else None)
        elif isinstance(node, ast.ClassDef) and not node.name.startswith('_'):
            result[node.name] = [ast.dump(b) for b in node.bases]
            for method in node.body:
                if isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef)) and not method.name.startswith('_'):
                    result[node.name + '.' + method.name] = ast.dump(method.args)
    return result


def architecture_drift(workspace, base, candidate, configuration, interface_paths=()):
    changed = changed_paths(workspace, base)
    config = configuration.get('drift', {})
    patterns = [*DEFAULT_SENSITIVE, *configuration.get('sensitive_paths', []), *config.get('sensitive_paths', [])]
    reasons = ['sensitive_diff:' + path for path in changed if any(matches(path, p) for p in patterns)]
    old_paths = git(workspace, 'ls-tree', '-r', '--name-only', base).splitlines()
    roots = config.get('package_roots', ['src'])
    for path in changed:
        parts = path.split('/')
        if path.endswith('.py'):
            for root in roots:
                prefix = root.rstrip('/') + '/'
                if path.startswith(prefix):
                    module = path[len(prefix):].split('/')[0]
                    if not any(p.startswith(prefix + module + '/') or p == prefix + module for p in old_paths):
                        reasons.append('new_top_level_module:' + prefix + module)
            if len(parts) == 1 and path not in old_paths:
                reasons.append('new_top_level_module:' + path)
        if path in interface_paths or any(matches(path, p) for p in config.get('public_api_paths', [])):
            before, after = _source(workspace, base, path), _source(workspace, candidate, path)
            if (public_signatures(before) != public_signatures(after)) if path.endswith('.py') else before != after:
                reasons.append('public_interface_diff:' + path)
        for boundary in config.get('import_boundaries', []):
            if not path.endswith('.py') or not matches(path, boundary['from']):
                continue
            try:
                tree = ast.parse(_source(workspace, candidate, path))
            except SyntaxError:
                reasons.append('unparseable_boundary_module:' + path)
                continue
            for node in ast.walk(tree):
                imports = [alias.name for alias in node.names] if isinstance(node, ast.Import) else [node.module or ''] if isinstance(node, ast.ImportFrom) else []
                if any(any(matches(name.replace('.', '/'), rule.replace('.', '/')) for rule in boundary['deny']) for name in imports):
                    reasons.append('import_boundary:' + path)
    return {'changed_paths': changed, 'reasons': sorted(set(reasons)), 'candidate': candidate,
            'diff': git(workspace, 'diff', '--binary', base, candidate, '--')}


def actual_data_paths(paths, patterns):
    return sorted(p for p in paths if any(matches(p, pattern) for pattern in patterns))


def evaluate_expectations(expectations, metrics):
    results = []
    for item in expectations:
        if item['availability'] == 'unavailable':
            results.append({'metric': item['metric'], 'status': 'no_pre_registered_expectation', 'reason': item['reason']})
            continue
        low, high = item.get('minimum'), item.get('maximum')
        if low is None and high is None:
            raise AgentSystemError('Registered expectation needs an explicit bound')
        value = metrics.get(item['metric'])
        if type(value) not in (int, float) or not __import__('math').isfinite(value):
            results.append({'metric': item['metric'], 'status': 'observation_requiring_human_judgment', 'value': None})
        else:
            passed = (low is None or value >= low) and (high is None or value <= high)
            results.append({'metric': item['metric'], 'status': 'validated' if passed else 'violated', 'value': value,
                            'minimum': low, 'maximum': high})
    return {'results': results, 'passed': all(r['status'] in ('validated', 'no_pre_registered_expectation') for r in results),
            'expectations_available': bool(expectations)}


def role_command(argv, workspace):
    """No inherited editable-install/Python path; Python must use the local venv."""
    env = {k: v for k, v in os.environ.items() if k not in ('PYTHONPATH', 'PYTHONHOME', 'VIRTUAL_ENV')}
    interpreter = local_environment(workspace)
    env.update(VIRTUAL_ENV=str(workspace / '.venv'), UV_PROJECT_ENVIRONMENT=str(workspace / '.venv'),
               PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1',
               PATH=str(interpreter.parent) + os.pathsep + env.get('PATH', ''))
    command = list(argv)
    if Path(command[0]).name.lower() in ('python', 'python.exe', 'python3', 'python3.exe') or Path(command[0]).name.lower().startswith('python3.'):
        command[0] = str(interpreter)
    elif Path(command[0]).name.lower() in ('uv', 'uv.exe'):
        if command[1:2] != ['run']:
            raise AgentSystemError('Role-local uv commands must use uv run')
        command[2:2] = ['--offline', '--no-sync']
    return command, env


def regenerate_audit(config, task, workspace, candidate, evidence, cycle, runner):
    hardening = task['hardening']
    commands = hardening.get('audit_commands', [])
    if not hasattr(runner, 'prepare_command'):
        local_environment(workspace)
    imports = verify_imports(workspace, hardening['python_modules'], runner, task) if hardening['python_modules'] else None
    before = path_manifest(workspace, ['*'])
    inputs = protected_snapshot(workspace, config.project)
    metrics, results = {}, []
    for specification in commands:
        argv, env = (runner.prepare_command(specification, workspace) if hasattr(runner, 'prepare_command')
                     else role_command(specification, workspace))
        runner.isolation_capabilities().require()
        result = runner.run_command(argv, workspace, env, task['workflow']['test_timeout_seconds'], task, read_only=True)
        if result.returncode:
            raise AgentSystemError('Auditor regeneration command failed: ' + result.stderr)
        observed = json.loads(result.stdout)
        if not isinstance(observed, dict) or set(observed).intersection(metrics):
            raise AgentSystemError('Auditor metrics must be distinct named observations')
        metrics.update(observed)
        results.append({'argv': argv, 'returncode': result.returncode, 'stdout': result.stdout})
        if git(workspace, 'rev-parse', 'HEAD') != candidate or path_manifest(workspace, ['*']) != before:
            raise AgentSystemError('Auditor regeneration mutated read-only project/input state')
    expectations = evaluate_expectations(hardening.get('data_expectations', []), metrics)
    return evidence.write(f'cycles/{cycle}/auditor/regenerated', {
        'task_id': task['task_id'],
        'candidate_commit': candidate, 'contract_version': hardening['contract_version'],
        'input_hashes': inputs, 'environment': str(workspace / '.venv'), 'commands': results,
        'imports': imports,
        'metrics': metrics, 'expectations': expectations,
        'provenance': 'controller-executed auditor commands, not Implementer validation output',
        'limitation': None if commands else 'No deterministic regeneration command supplied'})
