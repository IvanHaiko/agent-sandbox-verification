"""Local HMAC integrity. Access isolation of the key depends on the runner.

This is not protection from the operating-system user/controller administrator.
Only trusted controller entry points may call issue().
"""
import hashlib
import hmac
import os

from .errors import AgentSystemError
from .evidence import digest
from .storage import atomic_json, contained, read_json


class ApprovalStore:
    def __init__(self, directory, binding):
        self.directory = directory
        self.binding = binding

    def _key(self, create=False):
        path = self.directory / "key"
        if not path.exists() and create:
            path.parent.mkdir(parents=True, exist_ok=True)
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, "wb") as stream:
                stream.write(os.urandom(32))
                stream.flush()
                os.fsync(stream.fileno())
        if not path.exists():
            raise AgentSystemError("Controller integrity key unavailable; cannot trust approval")
        return path.read_bytes()

    def issue(self, name, payload):
        record = {"version": 1, "binding": self.binding, "name": name, "payload": payload}
        signature = hmac.new(self._key(create=True), digest(record).encode(), hashlib.sha256).hexdigest()
        path = contained(self.directory, name + ".json")
        if path.exists():
            if self.verify(name) != payload:
                raise AgentSystemError("Controller approval is immutable")
        else:
            atomic_json(path, {"record": record, "hmac": signature})
        return payload

    def verify(self, name, expected=None):
        path = contained(self.directory, name + ".json")
        if not path.exists():
            raise AgentSystemError("Missing controller approval: " + name)
        envelope = read_json(path)
        record = envelope.get("record", {})
        signature = hmac.new(self._key(), digest(record).encode(), hashlib.sha256).hexdigest()
        if (not hmac.compare_digest(signature, str(envelope.get("hmac", "")))
                or record.get("binding") != self.binding or record.get("name") != name):
            raise AgentSystemError("Controller approval integrity mismatch")
        payload = record["payload"]
        if expected is not None and payload != expected:
            raise AgentSystemError("Controller approval does not match evidence")
        return payload
