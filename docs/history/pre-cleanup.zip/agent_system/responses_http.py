"""Missing-MIME compatibility requires an entire bounded, validated SSE response."""
import http.client
import re
import socket
import threading
import time
import json
from types import SimpleNamespace

from .errors import AgentSystemError


def mime_category(headers):
    values = headers.get_all('Content-Type', [])
    if not values: return 'absent'
    if len(values) != 1: raise AgentSystemError('Duplicate plan response content type')
    value = values[0]
    if len(value) > 512 or any(ord(c) < 32 and c != '\t' for c in value):
        raise AgentSystemError('Unsafe plan response content type')
    token = value.split(';', 1)[0].strip().lower()
    if re.fullmatch(r"[a-z0-9!#$&^_.+-]+/[a-z0-9!#$&^_.+-]+", token):
        if token != 'text/event-stream': return 'explicit_incompatible'
        charset = headers.get_content_charset()
        if charset not in (None, 'utf-8', 'utf8'): raise AgentSystemError('Unsupported SSE charset')
        return 'event_stream'
    # A damaged incompatible header must not hide a valid leading media type.
    if re.match(r'[a-z0-9!#$&^_.+-]+/[a-z0-9!#$&^_.+-]+', token):
        raise AgentSystemError('Malformed explicit media type')
    return 'malformed' if not token else 'unrecognized'


def read_bounded_response(response, policy, cancel_event=None, metadata=None):
    if not isinstance(response, http.client.HTTPResponse) or response.status != 200:
        raise AgentSystemError('Unexpected plan response status or reader')
    category = mime_category(response.headers)
    if category == 'explicit_incompatible': raise AgentSystemError('Unexpected plan response content type')
    return _read_owned_body(response, policy, cancel_event, metadata), category


def _read_owned_body(response, policy, cancel_event=None, metadata=None, seconds=60, reads=4096):
    if response.headers.get_all('Content-Encoding', []) not in ([], ['identity']):
        raise AgentSystemError('Unsupported plan response encoding')
    length = response.headers.get_all('Content-Length', [])
    transfer = response.headers.get_all('Transfer-Encoding', [])
    if (len(length) > 1 or len(transfer) > 1 or (length and transfer)
            or (transfer and transfer[0].strip().lower() != 'chunked')):
        raise AgentSystemError('Ambiguous plan response framing')
    if length and (not length[0].isascii() or not length[0].isdigit() or len(length[0]) > 10
                   or int(length[0]) > policy.max_response_bytes):
        raise AgentSystemError('Invalid plan response length')
    try: owned_socket = response.fp.raw._sock
    except AttributeError: raise AgentSystemError('Owned plan response socket required') from None
    if not isinstance(owned_socket, socket.socket): raise AgentSystemError('Owned plan response socket required')
    chunks, state = [], {'bytes': 0, 'eof': False, 'failed': False, 'failure': None}
    # Same Stage19b whole-body resource ceilings; bound slow chunk framing too.
    deadline = min(policy.deadline, time.monotonic() + seconds)
    def reader():
        try:
            for _ in range(reads):
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    state['failure'] = 'body_deadline'
                    break
                owned_socket.settimeout(min(15, remaining))
                chunk = response.read1(min(8192, policy.max_response_bytes - state['bytes'] + 1))
                if not chunk:
                    if length and state['bytes'] != int(length[0]):
                        state['failure'] = 'truncated_content_length'
                        break
                    state['eof'] = True
                    return
                state['bytes'] += len(chunk)
                if state['bytes'] > policy.max_response_bytes:
                    state['failure'] = 'body_overflow'
                    break
                chunks.append(chunk)
            else: state['failure'] = 'body_read_limit'
        except socket.timeout: state['failure'] = 'socket_idle_timeout'
        except http.client.HTTPException: state['failure'] = 'http_framing_or_truncation'
        except OSError: state['failure'] = 'socket_error'
        except ValueError: state['failure'] = 'local_reader_error'
        state['failed'] = True
    worker = threading.Thread(target=reader, daemon=True, name='bounded-plan-response-reader')
    worker.start()
    cancelled = False
    while worker.is_alive() and time.monotonic() < deadline:
        if cancel_event is not None and cancel_event.is_set():
            cancelled = True
            break
        worker.join(min(.05, max(0, deadline - time.monotonic())))
    if worker.is_alive():
        try: owned_socket.shutdown(socket.SHUT_RDWR)
        except OSError: pass
        owned_socket.close()
        worker.join(5.5)
    if metadata is not None:
        metadata.update(response_bytes=state['bytes'], eof=state['eof'], reader_shutdown_confirmed=not worker.is_alive())
    if (worker.is_alive() or cancelled or (cancel_event is not None and cancel_event.is_set())
            or not state['eof'] or state['failed'] or time.monotonic() >= policy.deadline):
        if metadata is not None:
            metadata['body_failure'] = ('cancelled' if cancelled or (cancel_event is not None and cancel_event.is_set())
                else 'reader_shutdown_failed' if worker.is_alive()
                else 'execution_deadline' if time.monotonic() >= policy.deadline
                else state['failure'] or 'body_deadline')
        chunks.clear()
        raise AgentSystemError('Plan response timeout, cancellation, truncation or overflow')
    raw = b''.join(chunks)
    chunks.clear()
    return raw


# Provider prose and arbitrary machine identifiers are never telemetry. Unknown
# values get fixed markers; expanding these lists requires source admission.
_ERROR_TYPES = frozenset(('invalid_request_error', 'authentication_error', 'permission_error',
    'rate_limit_error', 'server_error', 'api_error', 'insufficient_quota'))
_ERROR_CODES = frozenset(('invalid_value', 'invalid_type', 'invalid_json', 'invalid_json_schema',
    'invalid_function_parameters', 'missing_required_parameter', 'unknown_parameter',
    'unsupported_parameter', 'unsupported_value', 'model_not_found', 'model_not_available',
    'invalid_api_key', 'invalid_token', 'token_expired', 'permission_denied', 'rate_limit_exceeded',
    'insufficient_quota', 'usage_limit_reached', 'billing_hard_limit_reached', 'server_error',
    'subscription_sharing_user_not_eligible', 'subscription_sharing_usage_limit_exceeded',
    'subscription_sharing_usage_unavailable', 'subscription_sharing_unsupported_capability',
    'subscription_sharing_route_not_supported', 'subscription_sharing_invalid_user',
    'subscription_sharing_user_unavailable', 'chatpass_v2_scope_not_authorized',
    'chatpass_v2_invalid_authorization_context'))
_PARAM_WORDS = frozenset(('model', 'input', 'instructions', 'store', 'stream', 'tools', 'tool_choice',
    'parallel_tool_calls', 'reasoning', 'effort', 'context', 'mode', 'summary', 'generate_summary',
    'text', 'format', 'verbosity', 'include', 'type', 'name', 'namespace', 'description', 'strict',
    'parameters', 'properties', 'required', 'additionalProperties', 'const', 'enum', 'items',
    'minItems', 'maxItems', 'minLength', 'maxLength', 'minimum', 'maximum', 'execution_id',
    'task_id', 'role', 'phase', 'contract_version', 'workspace_id', 'tool_type', 'argv', 'stdin',
    'timeout_seconds', 'output_bytes', 'read_only', 'content', 'id', 'status', 'input_text',
    'previous_response_id', 'client_metadata', 'prompt_cache_key', 'additional_tools',
    'background', 'conversation', 'max_output_tokens', 'max_tool_calls', 'metadata', 'moderation',
    'multi_agent', 'prompt', 'prompt_cache_retention', 'safety_identifier', 'temperature',
    'top_logprobs', 'top_p', 'truncation', 'user', 'service_tier'))


def error_metadata(raw, status, secret_filter):
    """Finite vocabulary only. No message, body, header, URL, ID or body hash."""
    from .agent_transport import strict_json
    record = {'status': status if type(status) is int and 300 <= status <= 599 else None,
              'type': None, 'code': None, 'param': None, 'message_category': 'unavailable'}
    try:
        if not isinstance(raw, bytes) or len(raw) > 16384: return record
        text = raw.decode('utf-8')
        secret_filter.reject(text)
        body = strict_json(text)
        # Detect escaped secrets, including in ignored envelope members.
        secret_filter.reject(json.dumps(body, ensure_ascii=False))
        error = body.get('error') if isinstance(body, dict) else None
        if not isinstance(error, dict): return record
        for key, allowed in (('type', _ERROR_TYPES), ('code', _ERROR_CODES)):
            value = error.get(key)
            record[key] = value if isinstance(value, str) and value in allowed else ('unrecognized' if value is not None else None)
        param = error.get('param')
        if isinstance(param, str) and 0 < len(param) <= 256:
            # Grammar cannot carry arbitrary property names or account IDs.
            tokens = re.findall(r'[A-Za-z_][A-Za-z_0-9]*|\[[0-9]{1,3}\]|\.', param)
            if (''.join(tokens) == param and re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*(?:\[[0-9]{1,3}\]|\.[A-Za-z_][A-Za-z_0-9]*)*', param)
                    and all(t in _PARAM_WORDS or t == '.' or t.startswith('[') for t in tokens)):
                record['param'] = param
        message = error.get('message')
        text = message.lower() if isinstance(message, str) else ''
        rules = (('unsupported_capability', ('subscription_sharing_unsupported_capability',)),
                 ('plan_eligibility', ('subscription_sharing_user_not_eligible',)),
                 ('usage_limit', ('subscription_sharing_usage_limit_exceeded',)),
                 ('plan_availability', ('subscription_sharing_usage_unavailable', 'subscription_sharing_user_unavailable')),
                 ('unsupported_route', ('subscription_sharing_route_not_supported',)),
                 ('authentication', ('subscription_sharing_invalid_user',)),
                 ('permission', ('chatpass_v2_scope_not_authorized', 'chatpass_v2_invalid_authorization_context')),
                 ('invalid_schema', ('invalid schema', 'invalid_json_schema', 'invalid_function_parameters')),
                 ('missing_parameter', ('missing required', 'required parameter')),
                 ('unknown_parameter', ('unknown parameter', 'unrecognized request argument')),
                 ('unsupported_parameter', ('unsupported parameter',)),
                 ('unsupported_value', ('unsupported value', 'invalid value', 'invalid_type')),
                 ('model_unavailable', ('model_not_found', 'model_not_available', 'model does not exist', 'model is not available')),
                 ('authentication', ('invalid_token', 'token_expired', 'invalid_api_key')),
                 ('permission', ('permission_denied',)),
                 ('usage_limit', ('usage_limit_reached', 'insufficient_quota', 'billing_hard_limit_reached')),
                 ('rate_limit', ('rate_limit_exceeded',)))
        evidence = text + ' ' + (record['code'] or '')
        record['message_category'] = next((category for category, markers in rules if any(m in evidence for m in markers)), 'other' if text else 'unavailable')
    except (UnicodeDecodeError, AgentSystemError, ValueError, RecursionError, TypeError):
        # Even the failure class is fixed; no offending fragment is retained.
        return {'status': record['status'], 'type': None, 'code': None, 'param': None, 'message_category': 'suppressed_or_malformed'}
    return record


def capture_http_error(error, policy, secret_filter, cancel_event=None):
    """Read only an owned HTTPError socket, at most 16KiB/2s/64 reads, then close.

    Already closed errors produce status-only metadata. Never authorize a tool,
    return error bytes to Codex, refresh credentials, or retry inference.
    """
    record = error_metadata(b'', error.code, secret_filter)
    raw = None
    try:
        response = error.fp
        if (not isinstance(response, http.client.HTTPResponse) or response.status != error.code
                or type(error.code) is not int or not 300 <= error.code <= 599): return record
        bounds = SimpleNamespace(deadline=min(policy.deadline, time.monotonic() + 2), max_response_bytes=16384)
        raw = _read_owned_body(response, bounds, cancel_event, seconds=2, reads=64)
        return error_metadata(raw, error.code, secret_filter)
    except (AgentSystemError, OSError, ValueError, http.client.HTTPException, AttributeError):
        return record
    finally:
        raw = None
        error.close()
