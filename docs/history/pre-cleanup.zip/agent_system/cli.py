import argparse
import json
from pathlib import Path

from .errors import AgentSystemError
from .controller import Controller as Orchestrator


def main(argv=None):
    parser = argparse.ArgumentParser(description="Local engineering workflow with telemetry and opt-in live pilots")
    parser.add_argument("--project", type=Path, default=Path.cwd())
    commands = parser.add_subparsers(dest="command", required=True)
    isolation = commands.add_parser('isolation-validate', help='Run real offline OS probes; no model calls')
    isolation.add_argument('--allow-containers', action='store_true')
    commands.add_parser('isolation-status')
    stale = commands.add_parser('isolation-cleanup-stale')
    stale.add_argument('execution_id')
    stale.add_argument('--allow-containers', action='store_true')
    for name in ("plan", "run"):
        commands.add_parser(name).add_argument("task", type=Path)
    for name in ("status", "resume", "inspect", "cleanup"):
        commands.add_parser(name).add_argument("task_id")
    commands.add_parser("architecture").add_argument("task_id")
    approval = commands.add_parser("approve-architecture")
    approval.add_argument("task_id")
    approval.add_argument("decision_id")
    approval.add_argument("--option", required=True)
    approval.add_argument("--approved-by", required=True)
    completion = commands.add_parser("approve-completion")
    completion.add_argument("task_id")
    completion.add_argument("--approved-by", required=True)
    contract = commands.add_parser('approve-contract')
    contract.add_argument('task_id')
    contract.add_argument('--package-sha256', required=True)
    contract.add_argument('--approved-by', required=True)
    dispute = commands.add_parser('resolve-test-dispute')
    dispute.add_argument('task_id')
    dispute.add_argument('--approved-by', required=True)
    dispute.add_argument('--changes-semantics', action='store_true')
    for name in ("telemetry", "metrics", "evaluate", "pilot-report"):
        command = commands.add_parser(name)
        command.add_argument("task_id")
        command.add_argument("--json", action="store_true", dest="json_output")
    comparison = commands.add_parser("compare")
    comparison.add_argument("task_ids", nargs="+")
    experiment = commands.add_parser("experiment-plan")
    experiment.add_argument("source_id")
    experiment.add_argument("new_id")
    experiment.add_argument("--models", type=Path, required=True)
    live = commands.add_parser("live-smoke")
    live.add_argument("--allow-live", action="store_true")
    live.add_argument("--workflow", action="store_true")
    live.add_argument("--runner-report", type=Path)
    pilot = commands.add_parser("pilot")
    pilot.add_argument("task", type=Path)
    pilot.add_argument("--allow-live", action="store_true")
    preflight = commands.add_parser("pilot-preflight")
    preflight.add_argument("task", type=Path)
    v1 = commands.add_parser("v1-status")
    v1.add_argument("--report", type=Path)
    args = parser.parse_args(argv)
    try:
        if args.command.startswith('isolation-'):
            from .config import Configuration
            from .runners import create_runner
            runner = create_runner(Configuration.load(args.project))
            if not hasattr(runner, 'validate_isolation'):
                raise AgentSystemError('Selected runner has no real OS validation backend')
            if args.command != 'isolation-status' and not args.allow_containers:
                raise AgentSystemError('Explicit --allow-containers is required for isolation execution/cleanup')
            if args.command == 'isolation-validate':
                result = runner.validate_isolation()
            elif args.command == 'isolation-cleanup-stale':
                runner.cleanup_stale(args.execution_id)
                result = {'cleanup': 'confirmed', 'execution_id': args.execution_id}
            else:
                result = runner.isolation_capabilities().manifest()
            print(json.dumps(result, indent=2))
            return 1 if result.get('admitted') is False else 0
        if args.command == "v1-status":
            from .storage import read_json
            from .task import validate
            result = validate(read_json(args.report or args.project / "docs/FRAMEWORK_V1_ACCEPTANCE.json"), "framework_acceptance")
            print(json.dumps(result, indent=2))
            return 1 if result["classification"] == "FRAMEWORK_V1_NOT_ACCEPTED" else 0
        if args.command in ("live-smoke", "pilot", "pilot-preflight"):
            from .config import Configuration
            from .live import live_smoke, pilot as run_pilot, project_preflight, backend_preflight
            from .task import load_task
            config = Configuration.load(args.project)
            if args.command == "pilot-preflight":
                result = {"project": project_preflight(config, load_task(args.task)), "backend": backend_preflight(config)}
            else:
                if not args.allow_live:
                    raise AgentSystemError("Explicit --allow-live is required; this command uses real model quota")
                print("This command performs real Codex role invocations after preflight; model quota may be consumed.",
                      file=__import__('sys').stderr, flush=True)
                result = live_smoke(config, args.workflow, True, args.runner_report) if args.command == "live-smoke" else run_pilot(config, args.task, True)
            print(json.dumps(result, indent=2))
            return 0 if (result["backend"]["ready"] if args.command == "pilot-preflight" else result["status"] == "PASSED") else 1
        if args.command == "experiment-plan":
            from .experiments import plan_experiment
            result = plan_experiment(args.project, args.source_id, args.new_id, args.models)
            print(json.dumps(result, indent=2))
            return 0
        orchestrator = Orchestrator(args.project)
        if args.command in ('approve-contract', 'approve-architecture', 'approve-completion', 'resolve-test-dispute'):
            if orchestrator.status(args.task_id)['version'] == 3:
                import sys
                if not sys.stdin.isatty():
                    raise AgentSystemError('Hardened approval requires an interactive controller CLI session')
                if input('Approve the reviewed package/resolution? Type approve: ').strip() != 'approve':
                    raise AgentSystemError('Explicit interactive approval not given')
        if args.command in ("telemetry", "metrics", "evaluate", "compare", "pilot-report"):
            from .evaluation import build_reports, compare_runs, pilot_report
            if args.command == "compare":
                result = compare_runs([orchestrator.run_dir(task_id) for task_id in args.task_ids])
            else:
                metrics, evaluation = build_reports(orchestrator.run_dir(args.task_id))
                result = pilot_report(orchestrator.run_dir(args.task_id), metrics, evaluation) if args.command == "pilot-report" else evaluation if args.command == "evaluate" else metrics
                if not args.json_output:
                    print(f"Task: {metrics['task_id']}\nOutcome: {metrics['outcome']}\nInvocations: {metrics['invocation_count']}\nFix cycles: {metrics['fix_cycles']}")
                    if args.command == "evaluate":
                        print(f"Findings: {len(evaluation['findings'])}\nUnique confirmed: {evaluation['unique_confirmed_findings']}")
                    else:
                        for role in metrics['roles']:
                            print(f"{role['role']}: {role['model']} / {role['reasoning']}, {role['invocations']} invocations, {role['duration_seconds']:.2f}s")
                        print("Measured usage: " + json.dumps(metrics['usage']))
                    return 0
        elif args.command in ("plan", "run"):
            result = orchestrator.plan(args.task)
            if args.command == "run":
                result = orchestrator.resume(result["task_id"])
        elif args.command == "cleanup":
            orchestrator.cleanup(args.task_id)
            result = {"task_id": args.task_id, "worktrees_removed": True, "branches_preserved": True}
        elif args.command == "resume":
            result = orchestrator.resume(args.task_id)
        elif args.command == "architecture":
            result = orchestrator.architecture(args.task_id)
        elif args.command == "approve-architecture":
            result = orchestrator.approve_architecture(args.task_id, args.decision_id, args.option, args.approved_by)
        elif args.command == "approve-completion":
            result = orchestrator.approve_completion(args.task_id, args.approved_by)
        elif args.command == 'approve-contract':
            result = orchestrator.approve_contract(args.task_id, args.approved_by, args.package_sha256)
        elif args.command == 'resolve-test-dispute':
            result = orchestrator.resolve_dispute(args.task_id, args.approved_by, args.changes_semantics)
        else:
            result = orchestrator.status(args.task_id)
            if args.command == "inspect":
                result = orchestrator.inspect(args.task_id)
        print(json.dumps(result, indent=2))
        return 1 if result.get("state") in ("FAILED", "ESCALATION_REQUIRED") else 0
    except (AgentSystemError, OSError, ValueError, KeyError) as exc:
        print(f"agentctl: {exc}", file=__import__("sys").stderr)
        return 1
