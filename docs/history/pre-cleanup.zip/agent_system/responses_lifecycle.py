"""Bounded Responses parsing with capability checks and nonblocking observations."""
import json

from .agent_transport import strict_json
from .errors import AgentSystemError


def canonical_arguments(value):
    if not isinstance(value, str): raise AgentSystemError('Malformed function arguments')
    parsed = strict_json(value)
    if not isinstance(parsed, dict): raise AgentSystemError('Function arguments must be an object')
    return json.dumps(parsed, sort_keys=True)


def record_anomaly(metadata, reason, executable=False, block=False, scope='response', project_mutation=None):
    """Fixed local reason codes only; no payloads, arguments or provider IDs."""
    record = {'classification': 'BLOCKING_VIOLATION' if block else 'ANOMALY',
              'category': 'SECURITY_CAPABILITY' if block else 'PROTOCOL_OBSERVATION',
              'anomaly_type': reason, 'scope': scope, 'executable_content': executable,
              'project_mutation': project_mutation, 'action': 'block' if block else 'continue', 'reason': reason}
    records = metadata.setdefault('anomalies', [])
    if record not in records and len(records) < 32: records.append(record)


def validate_response(gate, raw, metadata):
    try:
        return _validate_response(gate, raw, metadata)
    except AgentSystemError as error:
        # Export only known local literals, never arguments or provider prose.
        if 'denial_reason' not in metadata:
            fixed = {'Malformed function arguments', 'Function arguments must be an object',
                     'Invalid Controller function arguments', 'Tool execution identity mismatch',
                     'Invalid tool bounds', 'Read-only role mutation forbidden',
                     'Unsupported model output item', 'Unsupported model message content',
                     'Built-in or unknown model tool denied', 'Unsupported function execution context',
                     'Malformed model tool identity', 'Model output overflow',
                     'Invalid model output encoding', 'Partial model SSE frame',
                     'Unsupported SSE framing', 'Invalid model event type',
                     'Malformed model response output', 'Expired or closed model execution'}
            metadata['denial_reason'] = str(error) if str(error) in fixed else 'Unclassified local validation failure'
        # A body that cannot safely identify authority must never reach Codex.
        if not any(r['action'] == 'block' for r in metadata.get('anomalies', [])):
            record_anomaly(metadata, 'unsafe_or_unparseable_response', block=True,
                           executable=metadata.get('executable_content_seen', False))
        raise


def _validate_response(gate, raw, metadata):
    """Return private candidates. Never modify authorization or replay state."""
    gate.alive()
    if len(raw) > gate.policy.max_response_bytes: raise AgentSystemError('Model output overflow')
    try: text = raw.decode('utf-8').replace('\r\n', '\n')
    except UnicodeDecodeError: raise AgentSystemError('Invalid model output encoding') from None
    gate.secrets.reject(text)
    if not text.endswith('\n\n'): raise AgentSystemError('Partial model SSE frame')
    items, ids, calls, candidates = {}, set(), set(), {}
    nonexecutables, nonexecutables_done = [], []
    response_id, completed, previous_sequence = None, False, -1
    metadata.update(secret_checked=True, item_ids_stable=True, call_ids_stable=True,
                    output_indices_stable=True, arguments_equal=True)

    def deny(reason, flag=None):
        if flag: metadata[flag] = False
        metadata['denial_reason'] = reason  # All callers supply fixed source literals.
        record_anomaly(metadata, 'unsafe_executable_authority' if metadata.get('executable_content_seen') else 'unsafe_response_boundary',
                       executable=metadata.get('executable_content_seen', False), block=True)
        raise AgentSystemError(reason)

    def check_item(item):
        if isinstance(item, dict) and item.get('type') not in ('message', 'reasoning'):
            metadata['executable_content_seen'] = True
        gate._item(item)

    def identity(original, item):
        if item.get('id') != original['id']: deny('Model item identity mutation', 'item_ids_stable')
        if item.get('call_id') != original['call_id']: deny('Model call identity mutation', 'call_ids_stable')
        if any(item.get(k) != original.get(k) for k in ('type', 'name', 'namespace')):
            deny('Model function identity mutation')

    for frame in text.split('\n\n')[:-1]:
        if not frame: continue
        gate.alive()
        data, event = [], None
        for line in frame.split('\n'):
            if line.startswith('data:'): data.append(line[5:].lstrip(' '))
            elif line.startswith('event:') and event is None: event = line[6:].strip()
            elif line.startswith(':') or line.startswith(('id:', 'retry:')): continue
            else: raise AgentSystemError('Unsupported SSE framing')
        if not data: continue
        value = strict_json('\n'.join(data))
        gate.secrets.reject(json.dumps(value))
        if not isinstance(value, dict): deny('Invalid model event')
        kind = value.get('type')
        if not isinstance(kind, str): raise AgentSystemError('Invalid model event type')
        if 'function_call' in kind: metadata['executable_content_seen'] = True
        if kind not in gate.EVENTS:
            # Unknown metadata never grants authority. Explicit output still needs
            # the allowlist, and executable content needs a supported call event.
            unknown_output = value.get('response', {}).get('output', []) if isinstance(value.get('response'), dict) else []
            if not isinstance(unknown_output, list): raise AgentSystemError('Malformed model response output')
            for unknown_item in unknown_output + ([value['item']] if 'item' in value else []):
                check_item(unknown_item)
                if unknown_item['type'] == 'function_call': deny('Executable content on unknown event')
            if 'arguments' in value or 'function_call' in kind: deny('Unsupported executable event')
            record_anomaly(metadata, 'unknown_nonexecutable_event')
            continue
        if event not in (None, kind): record_anomaly(metadata, 'sse_event_label_mismatch')
        if completed:
            item = value.get('item')
            if kind.startswith('response.function_call_arguments.') or (isinstance(item, dict) and item.get('type') == 'function_call'):
                deny('Executable event after completion')
            if kind in ('response.created', 'response.in_progress', 'response.completed'):
                response = value.get('response')
                if not isinstance(response, dict) or response.get('id') != response_id:
                    deny('Model response identity mismatch')
                output = response.get('output', [])
                if not isinstance(output, list): raise AgentSystemError('Malformed model response output')
                repeated = {}
                for entry in output:
                    check_item(entry)
                    if entry['type'] == 'function_call':
                        cid = entry['call_id']
                        if cid in repeated: deny('Duplicate executable after completion')
                        repeated[cid] = canonical_arguments(entry.get('arguments'))
                if (any(candidates.get(cid) != args for cid, args in repeated.items())
                        or (kind == 'response.completed' and repeated != candidates)):
                    deny('Executable authority changed after completion')
                record_anomaly(metadata, 'duplicate_terminal_or_late_progress')
                continue
            if item is not None: check_item(item)
            record_anomaly(metadata, 'late_nonexecutable_event')
            continue
        metadata['event_counts'][kind] = metadata['event_counts'].get(kind, 0) + 1
        if 'sequence_number' in value:
            seq = value['sequence_number']
            if type(seq) is not int or seq < 0 or seq <= previous_sequence:
                record_anomaly(metadata, 'sequence_anomaly')
            else: previous_sequence = seq
        if 'item' in value:
            check_item(value['item'])
            if value['item']['type'] == 'function_call' and kind not in ('response.output_item.added', 'response.output_item.done'):
                deny('Unexpected executable item on model event')
        if kind in ('response.created', 'response.in_progress', 'response.completed'):
            response = value.get('response')
            if not isinstance(response, dict) or not isinstance(response.get('id'), str) or not response['id']:
                deny('Missing model response identity')
            if response_id is None:
                if response['id'] in gate.seen_responses:
                    deny('Replayed model response')
                if kind != 'response.created': record_anomaly(metadata, 'missing_creation')
                response_id = response['id']
            elif response['id'] != response_id:
                deny('Model response identity mismatch')
            output = response.get('output')
            if not isinstance(output, list): deny('Malformed model response output')
            if kind != 'response.completed':
                if response.get('status') != 'in_progress': record_anomaly(metadata, 'progress_status_anomaly')
                for index, item in enumerate(output):
                    check_item(item)
                    if item['type'] == 'function_call':
                        if index not in items: deny('Unregistered executable progress output')
                        identity(items[index]['item'], item)
                        if item.get('arguments'):
                            canonical = canonical_arguments(item['arguments'])
                            if items[index].get('canonical') != canonical:
                                deny('Conflicting executable progress arguments', 'arguments_equal')
                continue
            metadata['terminal_status'] = 'completed' if response.get('status') == 'completed' else 'invalid'
            if response.get('status') != 'completed': deny('Unsuccessful model completion')
            final_nonexecutables = [item for item in output if isinstance(item, dict) and item.get('type') in ('message', 'reasoning')]
            if nonexecutables_done != final_nonexecutables or len(nonexecutables) != len(final_nonexecutables):
                metadata['stream_final_bijection'] = False
                record_anomaly(metadata, 'nonexecutable_stream_final_mismatch')
            final_calls = set()
            metadata['streamed_function_count'] = len(calls)
            metadata['completed_function_snapshots'] = sum('canonical' in r for r in items.values())
            metadata['final_function_count'] = sum(isinstance(i, dict) and i.get('type') == 'function_call' for i in output)
            for index, item in enumerate(output):
                check_item(item)
                if item['type'] == 'function_call':
                    if item['call_id'] in final_calls: deny('Duplicate final executable call')
                    record = next((r for r in items.values() if r['item']['call_id'] == item['call_id']), None)
                    if record is None:
                        # A complete final call needs no optional stream history.
                        iid, cid = item.get('id'), item['call_id']
                        if not isinstance(iid, str) or not iid or iid in ids or iid in gate.seen_items or cid in gate.seen_calls:
                            deny('Duplicate or replayed final executable call')
                        record = {'item': item, 'arguments': item.get('arguments'), 'deltas': 0}
                        ids.add(iid)
                        calls.add(cid)
                        metadata['function_call_count'] += 1
                        if len(calls) > gate.policy.max_tool_calls: deny('Model tool count exceeded')
                    identity(record['item'], item)
                    if item.get('status') not in (None, 'completed'): deny('Incomplete final function')
                    if item.get('status') is None:
                        record_anomaly(metadata, 'function_status_omitted', executable=True)
                    canonical = canonical_arguments(item.get('arguments'))
                    gate.validate_arguments(canonical)
                    if record.get('canonical') is not None and canonical != record['canonical']:
                        deny('Conflicting final function arguments', 'arguments_equal')
                    if (record['deltas'] or record['item'].get('arguments')) and canonical_arguments(record['arguments']) != canonical:
                        deny('Conflicting streamed function arguments', 'arguments_equal')
                    final_calls.add(item['call_id'])
                    candidates[item['call_id']] = canonical
            # A validated output_item.done is itself a completed executable
            # snapshot. A summary that omits it cannot broaden its authority.
            # Contradictory snapshots above still block before publication.
            for record in items.values():
                cid = record['item']['call_id']
                if cid in final_calls: continue
                if not record.get('completed_item'): deny('Conflicting final function inventory', 'stream_final_bijection')
                gate.validate_arguments(record['canonical'])
                candidates[cid] = record['canonical']
                final_calls.add(cid)
                metadata['stream_final_bijection'] = False
                metadata['completed_calls_omitted_from_final'] = metadata.get('completed_calls_omitted_from_final', 0) + 1
                record_anomaly(metadata, 'completed_function_omitted_from_final', executable=True)
            if final_calls != calls: deny('Conflicting final function inventory', 'stream_final_bijection')
            usage = response.get('usage')
            if isinstance(usage, dict):
                # Only recognized numeric usage; arbitrary nested provider fields never exported.
                metadata['usage'] = {k: usage[k] for k in ('input_tokens', 'output_tokens', 'total_tokens')
                                     if type(usage.get(k)) is int and usage[k] >= 0}
            if metadata['stream_final_bijection'] is None: metadata['stream_final_bijection'] = True
            completed = True
            continue
        if response_id is None:
            if kind.startswith('response.function_call_arguments.') or (isinstance(value.get('item'), dict) and value['item']['type'] == 'function_call'):
                deny('Executable event before response identity')
            record_anomaly(metadata, 'nonexecutable_before_creation')
        if 'response_id' in value and value['response_id'] != response_id: deny('Model response identity mismatch')
        # Non-executable history is observation only. It cannot create authority.
        if kind in ('response.output_item.added', 'response.output_item.done') and value.get('item', {}).get('type') in ('message', 'reasoning'):
            item = value['item']
            (nonexecutables if kind.endswith('.added') else nonexecutables_done).append(item)
            metadata['transitions']['item_added' if kind.endswith('.added') else 'item_done'] += 1
            continue
        if kind.startswith(('response.content_part.', 'response.output_text.', 'response.reasoning_')):
            if any(value.get('item_id') == r['item']['id'] for r in items.values()):
                deny('Non-function event on function item')
            if kind.endswith('.delta') and not isinstance(value.get('delta'), str):
                record_anomaly(metadata, 'malformed_nonexecutable_delta')
            continue
        index = value.get('output_index')
        if type(index) is not int or index < 0: deny('Invalid model output index', 'output_indices_stable')
        if kind == 'response.output_item.added':
            item = value.get('item')
            check_item(item)
            iid = item.get('id')
            if not isinstance(iid, str) or not iid or iid in ids or iid in gate.seen_items:
                deny('Duplicate or replayed model item', 'item_ids_stable')
            if index in items: deny('Duplicate model output index', 'output_indices_stable')
            record = {'item': item,
                      'arguments': item.get('arguments', ''), 'deltas': 0}
            if not isinstance(record['arguments'], str): deny('Invalid function creation')
            cid = item['call_id']
            if cid in calls or cid in gate.seen_calls: deny('Duplicate or replayed model tool call', 'call_ids_stable')
            calls.add(cid)
            if len(calls) > gate.policy.max_tool_calls: deny('Model tool count exceeded')
            metadata['function_call_count'] += 1
            ids.add(iid)
            items[index] = record
            metadata['transitions']['item_added'] += 1
            continue
        record = items.get(index)
        if record is None: deny('Orphan executable item event', 'output_indices_stable')
        original = record['item']
        if kind == 'response.output_item.done':
            item = value.get('item')
            check_item(item)
            identity(original, item)
            if item.get('status') not in (None, 'completed'): deny('Incomplete function lifecycle')
            if item.get('status') is None:
                record_anomaly(metadata, 'function_status_omitted', executable=True)
            canonical = canonical_arguments(item.get('arguments'))
            gate.validate_arguments(canonical)
            if record.get('canonical') is not None and canonical != record['canonical']:
                deny('Conflicting completed function arguments', 'arguments_equal')
            if (record['deltas'] or original.get('arguments')) and canonical_arguments(record['arguments']) != canonical:
                deny('Conflicting streamed function arguments', 'arguments_equal')
            record['canonical'] = canonical
            record['completed_item'] = True
            metadata['transitions']['item_done'] += 1
            continue
        if value.get('item_id') != original['id']: deny('Model argument/item identity mismatch', 'item_ids_stable')
        if kind.startswith('response.function_call_arguments.'):
            # Undocumented alternate identities cannot override registered authority.
            if any(k in value and value[k] != original.get(k) for k in ('call_id', 'name', 'namespace')):
                deny('Conflicting argument identity fields')
            if kind.endswith('.delta'):
                if record.get('canonical') is not None: deny('Arguments changed after completed snapshot', 'arguments_equal')
                if not isinstance(value.get('delta'), str): deny('Malformed argument delta')
                record['arguments'] += value['delta']
                record['deltas'] += 1
                metadata['transitions']['arguments_delta'] += 1
            else:
                arguments = value.get('arguments')
                canonical = canonical_arguments(arguments)
                if (record['deltas'] or original.get('arguments')) and canonical_arguments(record['arguments']) != canonical:
                    deny('Arguments differ from streamed fragments', 'arguments_equal')
                gate.validate_arguments(canonical)
                if record.get('canonical') is not None and record['canonical'] != canonical:
                    deny('Conflicting argument snapshots', 'arguments_equal')
                record.update(arguments=arguments, canonical=canonical)
                metadata['transitions']['arguments_done'] += 1
        else: deny('Unexpected event on function item')
    if not completed: deny('Missing model completion')
    gate.alive()
    return candidates, ids, response_id


def structural_metadata(size):
    return {'response_bytes': size, 'secret_checked': False, 'event_counts': {}, 'anomalies': [],
            'function_call_count': 0, 'item_ids_stable': None, 'call_ids_stable': None,
            'output_indices_stable': None, 'arguments_equal': None, 'stream_final_bijection': None,
            'terminal_status': 'missing', 'validation_passed': False,
            'transitions': {'item_added': 0, 'arguments_delta': 0, 'arguments_done': 0, 'item_done': 0}}
