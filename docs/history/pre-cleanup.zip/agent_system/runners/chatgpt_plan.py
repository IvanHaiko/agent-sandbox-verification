"""Opt-in Controller factory integration. No API keys or automatic live calls."""
import hashlib
import json
from pathlib import Path
import shutil
import time

from .tool_docker import ToolDockerRunner
from .docker_isolated import regular_tree
from .base import AgentResult
from .isolated_session import IsolatedSessionRunner
from ..agent_transport import InvocationBinding
from ..codex_tool_session import CodexToolSession
from ..contexts import validate_context
from ..errors import AgentSystemError
from ..model_tool_boundary import (ExecutionPolicy, IsolatedExecutionBridge, ResponsesGate,
                                  LocalModelRelay, PlanUpstream, SecretFilter, UPSTREAM)
from ..evidence import Evidence
from ..chatgpt_oauth import PLAN_SCOPE
from ..storage import atomic_json, read_json, contained
from ..telemetry import enforce_limits, identity, finish_invocation
from ..state_machine import timestamp, validate_history
from ..git import git
from ..roles import Role, ROLES
from ..contexts import PHASE_ROLES
from ..task import validate
from ..approvals import ApprovalStore
from ..evidence import digest


class ChatGPTPlanRunner(ToolDockerRunner):
    """Construct only from a trusted operator-supplied runner factory.

    Existing backend selection remains unchanged. This factory requires explicit
    bound live approvals and no-credit attestations in Controller storage.
    """
    def __init__(self, config, credential_store, approval_store):
        super().__init__(config)
        if any(credential_store.directory.resolve().is_relative_to(p.resolve())
               for p in (config.root, config.worktrees_dir)):
            raise AgentSystemError('OAuth storage must stay outside repository and role roots')
        self.credential_store, self.live_approvals = credential_store, approval_store

    def run(self, role, model_config, context_bundle, workspace, task_metadata):
        self.require_transport_admission()
        role = Role(role)
        task, phase = validate(task_metadata, 'task'), context_bundle.get('phase')
        if 'hardening' not in task or not phase or model_config != self.config.model_for(role) or PHASE_ROLES.get(phase) != role:
            raise AgentSystemError('Explicit hardened role/routing/phase required')
        directory = contained(self.config.runs_dir, task['task_id'])
        state = validate_history(read_json(directory / 'state.json'))
        expected_states = {'architecture': 'ARCHITECTURE_CHECK', 'test_design': 'TEST_DESIGN',
            'test_implementation': 'TEST_DESIGN_FROZEN', 'implementation': 'IMPLEMENTING', 'fix': 'FIXING',
            'test_correction': 'TESTING', 'review': 'REVIEWING', 'review_blind': 'REVIEWING',
            'audit': 'AUDITING', 'test_correction_review': 'TESTING'}
        operation = f"c{state['fix_cycle']}-{phase}-r{state['architecture_round']}-t{state['test_version']}"
        if (state['version'] != 3 or state['state'] != expected_states.get(phase)
                or task != read_json(directory / 'task.json')
                or state['configuration_digest'] != digest({'project': self.config.project, 'routing': self.config.routing})
                or context_bundle['operation_id'] != operation):
            raise AgentSystemError('Invocation does not match persisted hardened lifecycle')
        control = ApprovalStore(directory / 'controller', {'task_id': task['task_id'],
            'task_digest': state['task_digest'], 'configuration_digest': state['configuration_digest'],
            'base_commit': state['base_commit']})
        from ..hardened_workflow import TestVersionEvidence
        evidence = TestVersionEvidence(directory, state)
        control.verify('interface', evidence.read('contract/package'))
        if task['major_phase'] and control.verify('contract')['package_sha256'] != digest(evidence.read('contract/package')):
            raise AgentSystemError('Contract approval mismatch')
        selections = []
        for number in range(state['architecture_round'] + 1):
            key = f'architecture/{number}'
            if evidence.exists(key + '/selection'):
                selection, decision = evidence.read(key + '/selection'), evidence.read(key + '/decision')
                control.verify('architecture/' + decision['decision_id'], selection)
                selections.append({'decision': decision, 'selection': selection})
        inputs = context_bundle.get('inputs', {})
        if inputs.get('architecture_selection', []) != selections:
            raise AgentSystemError('Unrecorded architecture selection')
        if phase in ('test_implementation', 'test_correction', 'review', 'audit') and inputs.get('test_design') != evidence.read('tester/frozen_design'):
            raise AgentSystemError('Unrecorded frozen independent design')
        if phase in ('review', 'audit') and inputs.get('test_results') != evidence.read(f"cycles/{state['fix_cycle']}/tests/result"):
            raise AgentSystemError('Unrecorded validation results')
        if phase == 'audit' and inputs.get('audit_validation') != evidence.read(f"cycles/{state['fix_cycle']}/auditor/regenerated"):
            raise AgentSystemError('Unrecorded Auditor regeneration')
        workspace = self._workspace(workspace, task)
        name = ROLES[role].workspace_name or 'orchestrator'
        if workspace != contained(self.config.worktrees_dir, f"{task['task_id']}/{name}"):
            raise AgentSystemError('Role checkout mismatch')
        if git(workspace, 'rev-parse', 'HEAD') != state['commits'][name] or git(workspace, 'status', '--porcelain', '--untracked-files=all'):
            raise AgentSystemError('Role candidate differs from persisted clean checkpoint')
        validate_context(context_bundle, role, workspace, task)
        enforce_limits(directory, task, {'project': self.config.project, 'routing': self.config.routing}, state['fix_cycle'])
        # The workflow's operation ID is Controller-created and present in the
        # frozen context. Operator approvals must target this exact execution.
        execution_id = context_bundle['operation_id']
        bound = InvocationBinding(execution_id, str(role), task['task_id'], task['hardening']['contract_version'],
                                  model_config.model, model_config.reasoning)
        policy = ExecutionPolicy(bound, phase, hashlib.sha256(str(workspace).encode()).hexdigest(),
                                  time.monotonic() + self.settings['timeout_seconds'])
        values = self.credential_store.read('credentials.json')
        if not values or PLAN_SCOPE not in values.get('scopes', []) or time.time() >= values['expires_at']:
            raise AgentSystemError('Explicit, unexpired ChatGPT plan connection required')
        filter_ = SecretFilter([values['access_token'], values['refresh_token'], values['id_token']])
        upstream = PlanUpstream(self.credential_store, policy, self.live_approvals, self.require_transport_admission, self.cancel_event)
        # All preflight approvals are checked before starting a process, not only
        # when it makes its first HTTP request. This does not issue approvals.
        from ..model_tool_boundary import require_credit_attestation
        require_credit_attestation(self.live_approvals, bound, values['client_id'])
        approved = self.live_approvals.verify('live-smoke/' + execution_id)
        if approved != {'authorized': True, **policy.identity(), 'model': bound.model,
                        'reasoning': bound.reasoning, 'route': UPSTREAM}:
            raise AgentSystemError('Explicit Stage19 authorization required')
        invocation = contained(directory / 'invocations', execution_id)
        invocation.mkdir(parents=True, exist_ok=False)
        atomic_json(invocation / 'context_manifest.json', context_bundle)
        prompt = IsolatedSessionRunner(self.config)._prompt(role, context_bundle, workspace, task)
        filter_.reject(prompt)
        (invocation / 'prompt.md').write_text(prompt, encoding='utf-8')
        telemetry_binding = identity(task, self.config, context_bundle, git(workspace, 'rev-parse', 'HEAD'), 0, execution_id)
        started, start = timestamp(), time.monotonic()
        Evidence(invocation).write('telemetry_start', {**telemetry_binding, 'started_at': started})
        bridge = IsolatedExecutionBridge(self, workspace, task, policy, filter_)
        gate = ResponsesGate(policy, filter_)
        session = None
        status, message = 'execution_failed', 'Bound model transport failed'
        try:
            with LocalModelRelay(gate, upstream) as relay:
                executable = Path(shutil.which('codex'))
                session = CodexToolSession(executable, hashlib.sha256(executable.read_bytes()).hexdigest(),
                                          invocation / 'model-home', relay, bridge, policy)
                with session:
                    report = session.run(prompt)
                    message, status = json.dumps(report), 'success'
        except (AgentSystemError, OSError) as error:
            # Raw provider messages, captures and token-bearing diagnostics never
            # enter Controller exports. Runner command outputs are gated earlier.
            status, message = 'policy_violation', 'Bound model/tool execution rejected'
            if session and session.failure_receipt is None:
                session._preserve_failure(error)  # e.g. relay shutdown after handoff
        finally:
            bridge.close()
            if session and session.failure_receipt:
                atomic_json(invocation / 'failure_receipt.json', session.failure_receipt)
            # Session exit persisted diagnostics before this owned home disposal.
            home = invocation / 'model-home'
            if home.exists():
                if home.is_symlink() or home.resolve().parent != invocation.resolve():
                    raise AgentSystemError('Unsafe model home cleanup target')
                regular_tree(home)
                shutil.rmtree(home)
            try:
                atomic_json(invocation / 'response_structure.json', {
                    'gate': gate.response_metadata_history,
                    'transport': upstream.response_metadata_history,
                    'codex_observations': session.observation_metadata if session else {'anomalies': []}})
            except OSError:
                pass  # Optional observation storage cannot veto an otherwise valid result.
        result = AgentResult(execution_id, task['task_id'], str(role), status, bound.model, bound.reasoning,
                             0, 0 if status == 'success' else None, message, sorted(bridge.changed_paths))
        atomic_json(invocation / 'result.json', result.to_dict())
        finish_invocation(invocation, telemetry_binding, result.to_dict(), started, timestamp(),
                          time.monotonic() - start, time.monotonic() >= policy.deadline, events_required=False)
        return result
