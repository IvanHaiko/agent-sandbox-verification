import json
import subprocess
import time
from pathlib import Path
from uuid import uuid4

from ..errors import AgentSystemError
from ..contexts import OUTPUT_SCHEMAS, ROLE_INSTRUCTIONS, check_role_paths, validate_context
from ..git import git, registered_worktrees, repository_root
from ..policies import changed_paths, check_paths
from ..roles import ROLES, Role
from ..storage import atomic_json, contained
from ..storage import read_json
from ..evidence import Evidence, digest
from ..task import validate
from ..state_machine import timestamp
from ..telemetry import enforce_limits, finish_invocation, identity, parse_events
from .base import AgentResult, AgentRunner


class IsolatedSessionRunner(AgentRunner):
    """Fresh Codex CLI process per invocation. No role orchestration or native adapter."""

    def __init__(self, config):
        self.config = config

    def isolation_capabilities(self):
        from ..isolation import Capability, IsolationCapabilities
        # CLI flags are intent, not verification of real sandbox behavior.
        return IsolationCapabilities("isolated_session", {
            "fresh_context": Capability(True, True, "exec without resume; --ephemeral"),
            "isolated_checkout": Capability(False, True, "Backend workspace admission requires registered shared worktrees"),
            "filesystem_read": Capability(False, True, "No portable OS read barrier"),
            "controller_storage": Capability(False, True, "Common operating-system user"),
            "hidden_tests": Capability(False, True, "Common operating-system filesystem"),
        })

    def _workspace(self, workspace, role, task):
        workspace = workspace.resolve()
        if workspace == self.config.root or not workspace.is_relative_to(self.config.worktrees_dir):
            raise AgentSystemError("Agent workspace must be an isolated framework worktree")
        name = ROLES[role].workspace_name
        if name is not None and workspace != contained(self.config.worktrees_dir, f"{task['task_id']}/{name}"):
            raise AgentSystemError("Role/worktree mismatch")
        entry = registered_worktrees(self.config.root).get(str(workspace))
        if not entry or repository_root(workspace) != workspace:
            raise AgentSystemError("Workspace is not a registered worktree")
        if name and entry.get("branch") != f"refs/heads/agent/{task['task_id']}/{name}":
            raise AgentSystemError("Role branch mismatch")
        if git(workspace, "status", "--porcelain", "--untracked-files=all"):
            raise AgentSystemError("Runner requires a clean starting workspace")
        return workspace

    def _prompt(self, role, bundle, workspace, task):
        validate_context(bundle, role, workspace, task)
        sections = []
        for relative in bundle["files"]:
            path = contained(workspace, relative)
            if relative.split("/")[0] in (".git", ".agent_runs", ".agent_worktrees"):
                raise AgentSystemError("Private runtime and Git files cannot be context inputs")
            sections.append(f"FILE {relative}\n{path.read_text(encoding='utf-8')}")
        schema_instruction = ""
        if bundle.get("phase"):
            from importlib.resources import files
            schema = files("agent_system").joinpath("schemas", OUTPUT_SCHEMAS[bundle["phase"]] + ".schema.json").read_text()
            schema_instruction = ("Return only JSON matching this schema. Do not commit; the framework commits approved changes. "
                                  "Test design is read-only. Phase B must implement every frozen case and must not edit existing tests. "
                                  "Report architectural needs before making changes. Approved architecture selections authorize only "
                                  "the selected option within the frozen task scope.\n" + schema)
        prompt_task, project_context = task, self.config.project
        if 'hardening' in task and bundle.get('phase') in ('test_design', 'test_implementation', 'test_correction', 'review_blind'):
            from ..contracts import public_contract
            prompt_task = public_contract(task)
            if role == Role.TEST_ENGINEER:
                prompt_task = {**prompt_task, 'test_paths': task['workflow']['test_paths'],
                               'holdout_paths': task['hardening']['holdout_paths']}
            project_context = {'project': self.config.project['project']}
        return "\n\n".join([
            f"Role: {role}. Work only on this task and in this workspace.",
            "Do not push, rewrite history, reset --hard, clean, delete protected data, or change architecture. "
            "Stop and report if an architectural change is required. Do not access other worktrees or agent histories.",
            "Read-only role: " + str(ROLES[role].read_only),
            ROLE_INSTRUCTIONS.get(bundle.get("phase"), ""),
            schema_instruction,
            "Protected paths:\n" + json.dumps(self.config.project["protected_paths"]),
            "Frozen project configuration:\n" + json.dumps(project_context, indent=2),
            "Task contract:\n" + json.dumps(prompt_task, indent=2),
            "Context manifest:\n" + json.dumps(bundle, indent=2),
            *sections,
        ])

    def run(self, role, model_config, context_bundle, workspace, task_metadata):
        if "hardening" in task_metadata:
            self.isolation_capabilities().require()
        role = Role(role)
        task = validate(task_metadata, "task")
        # The routing configuration is authoritative. No per-invocation escalation.
        if model_config != self.config.model_for(role):
            raise AgentSystemError("Requested model differs from configured role routing")
        phase = context_bundle.get("phase")
        if phase:
            self._workflow_request(phase, context_bundle, task)
        else:
            state_path = contained(self.config.runs_dir, task["task_id"]) / "state.json"
            saved = read_json(state_path) if state_path.exists() else {}
            if "workflow" in task or saved.get("version") == 2:
                raise AgentSystemError("Version-2 role invocation requires an explicit workflow phase")
            if saved.get("state") == "ARCHITECTURE_DECISION_REQUIRED" and not ROLES[role].read_only:
                raise AgentSystemError("Architecture-blocked task cannot invoke a code-producing role")
        workspace = self._workspace(Path(workspace), role, task)
        base = git(workspace, "rev-parse", "HEAD")
        starting_branch = git(workspace, "symbolic-ref", "--short", "HEAD")
        if role == Role.TEST_ENGINEER and phase != "test_implementation":
            manifest = self.config.runs_dir / task["task_id"] / "worktrees.json"
            if not manifest.exists() or json.loads(manifest.read_text())["base_commit"] != base:
                raise AgentSystemError("Initial Test Engineer must start from the frozen task base")
        prompt = self._prompt(role, context_bundle, workspace, task)
        settings = self.config.project["runner"]
        for attempt in range(settings["max_infrastructure_retries"] + 1):
            snapshot = {"project": self.config.project, "routing": self.config.routing}
            task_directory = contained(self.config.runs_dir, task['task_id'])
            cycle = read_json(task_directory / "state.json").get("fix_cycle")
            enforce_limits(task_directory, task, snapshot, cycle, retry=attempt > 0)
            execution_id = str(uuid4())
            directory = contained(self.config.runs_dir, f"{task['task_id']}/invocations/{execution_id}")
            directory.mkdir(parents=True, exist_ok=False)
            atomic_json(directory / "context_manifest.json", context_bundle)
            (directory / "prompt.md").write_text(prompt, encoding="utf-8")
            output = directory / "last_message.txt"
            command = [settings["executable"], "exec", "--ignore-user-config", "--ephemeral",
                       "--json", "--color", "never", "--cd", str(workspace),
                       "--model", model_config.model,
                       "--config", f'model_reasoning_effort="{model_config.reasoning}"',
                       "--config", "sandbox_workspace_write.network_access=false",
                       "--sandbox", "read-only" if ROLES[role].read_only or phase == "test_design" else "workspace-write",
                       "--output-last-message", str(output), "-"]
            if phase:
                from importlib.resources import files
                schema_path = directory / "output_schema.json"
                schema_path.write_text(files("agent_system").joinpath("schemas", OUTPUT_SCHEMAS[phase] + ".schema.json").read_text(), encoding="utf-8")
                command[-1:-1] = ["--output-schema", str(schema_path)]
            atomic_json(directory / "command.json", command)
            binding = identity(task, self.config, context_bundle, base, attempt, execution_id)
            started_at, clock_start = timestamp(), time.monotonic()
            Evidence(directory).write("telemetry_start", {**binding, "started_at": started_at})
            code = None
            status = "execution_failed"
            message = ""
            timed_out, protocol_error = False, None
            try:
                # Files rather than PIPE prevent unbounded event buffering in memory.
                with (directory / "events.jsonl").open("w", encoding="utf-8") as stdout, \
                        (directory / "stderr.txt").open("w", encoding="utf-8") as stderr:
                    result = subprocess.run(command, input=prompt, encoding="utf-8", cwd=workspace,
                                            stdout=stdout, stderr=stderr, timeout=settings["timeout_seconds"])
                code = result.returncode
                if code == 0 and output.exists():
                    status = "success"
                    message = output.read_text(encoding="utf-8")
                elif code == 0:
                    message = "Backend exited without a final message"
                else:
                    message = f"Backend exited with code {code}; see stderr.txt"
            except subprocess.TimeoutExpired:
                status, message = "timeout", "Backend execution timed out"
                timed_out = True
            except OSError as exc:
                message = str(exc)
            finished_at, duration = timestamp(), time.monotonic() - clock_start
            try:
                parse_events(directory / "events.jsonl", status == "success")
            except AgentSystemError as exc:
                status, message, protocol_error = "execution_failed", str(exc), str(exc)
            paths = changed_paths(workspace, base)
            try:
                check_paths(role, paths, task, self.config.project)
                check_role_paths(role, phase, paths, task)
                if context_bundle.get("phase") and (ROLES[role].read_only or phase == "test_design"):
                    if git(workspace, "rev-parse", "HEAD") != base:
                        raise AgentSystemError("Read-only invocation changed Git history")
                    if git(workspace, "ls-files", "--others", "--ignored", "--exclude-standard"):
                        raise AgentSystemError("Read-only invocation created ignored project files")
                if git(workspace, "symbolic-ref", "--short", "HEAD") != starting_branch:
                    raise AgentSystemError("Workspace branch changed during execution")
            except AgentSystemError as exc:
                status, message = "policy_violation", str(exc)
            result = AgentResult(execution_id, task["task_id"], str(role), status,
                                 model_config.model, model_config.reasoning, attempt, code, message, paths)
            atomic_json(directory / "result.json", result.to_dict())
            finish_invocation(directory, binding, result.to_dict(), started_at, finished_at,
                              duration, timed_out, protocol_error)
            # Never repeat an invocation that changed project files or succeeded.
            if status in ("success", "policy_violation") or paths or protocol_error:
                return result
        return result

    def _workflow_request(self, phase, bundle, task):
        """Direct backend calls cannot bypass the persisted lifecycle or approvals."""
        from ..state_machine import validate_history
        directory = contained(self.config.runs_dir, task["task_id"])
        state = validate_history(read_json(directory / "state.json"))
        if state["version"] != 2 or task != read_json(directory / "task.json"):
            raise AgentSystemError("Workflow runner requires the exact frozen version-2 task")
        phases = {"architecture": "ARCHITECTURE_CHECK", "test_design": "TEST_DESIGN",
                  "implementation": "IMPLEMENTING", "fix": "FIXING", "test_implementation": "TESTING",
                  "review": "REVIEWING", "audit": "AUDITING"}
        if phases.get(phase) != state["state"]:
            raise AgentSystemError("Role invocation is not permitted in the persisted lifecycle state")
        if digest({"project": self.config.project, "routing": self.config.routing}) != state["configuration_digest"]:
            raise AgentSystemError("Workflow runner configuration differs from the frozen snapshot")
        if bundle.get("operation_id") != f"c{state['fix_cycle']}-{phase}-r{state['architecture_round']}":
            raise AgentSystemError("Workflow invocation operation/cycle identity mismatch")
        evidence = Evidence(directory)
        selections = []
        for number in range(state["architecture_round"] + 1):
            key = f"architecture/{number}"
            if evidence.exists(key + "/selection"):
                selections.append({"decision": evidence.read(key + "/decision"),
                                   "selection": evidence.read(key + "/selection")})
        inputs = bundle.get("inputs", {})
        if inputs.get("architecture_selection", []) != selections:
            raise AgentSystemError("Role context contains an unrecorded architecture selection")
        if phase in ("test_implementation", "review", "audit"):
            if inputs.get("test_design") != evidence.read("tester/frozen_design"):
                raise AgentSystemError("Role context does not contain the immutable frozen design")
        if phase in ("review", "audit") and inputs.get("test_results") != evidence.read(f"cycles/{state['fix_cycle']}/tests/result"):
            raise AgentSystemError("Validation context contains unrecorded test results")
