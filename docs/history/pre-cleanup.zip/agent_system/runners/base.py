from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass
from pathlib import Path

from ..config import ModelConfig
from ..roles import Role
from ..task import validate


@dataclass(frozen=True)
class AgentResult:
    execution_id: str
    task_id: str
    role: str
    status: str
    model: str
    reasoning: str
    attempt: int
    returncode: int | None
    message: str
    changed_paths: list[str]

    def to_dict(self):
        return validate(asdict(self), "agent_result")


class AgentRunner(ABC):
    def isolation_capabilities(self):
        from ..isolation import IsolationCapabilities
        return IsolationCapabilities(type(self).__name__)

    def run_command(self, argv, workspace, environment, timeout_seconds, task, read_only=True):
        """Execute generated tests/audit code under the same verified boundary.

        A controller must never bypass isolation by running agent-generated code
        as an ordinary unsandboxed host subprocess. No default fallback exists.
        """
        from ..errors import AgentSystemError
        raise AgentSystemError('Runner has no verified isolated command execution adapter')

    @abstractmethod
    def run(self, role: Role, model_config: ModelConfig, context_bundle: dict,
            workspace: Path, task_metadata: dict) -> AgentResult:
        """Execute a fresh invocation; never implicitly reuse conversation history."""
        raise NotImplementedError
