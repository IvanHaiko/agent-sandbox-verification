from .isolated_session import IsolatedSessionRunner


def create_runner(config):
    # No implicit fallback changes backend or isolation semantics.
    if config.project["runner"]["backend"] == "isolated_session":
        return IsolatedSessionRunner(config)
    if config.project["runner"]["backend"] == "docker_isolated":
        from .docker_isolated import DockerIsolatedRunner
        return DockerIsolatedRunner(config)
    raise ValueError("Unsupported runner backend")
