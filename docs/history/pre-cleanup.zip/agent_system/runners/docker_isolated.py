"""Offline OS boundary. Docker configuration alone never grants admission.

The operator supplies a reviewed, immutable Linux image and a JSON-stdin role
driver. Live model credentials/protocol adapters are deliberately out of scope.
"""
import hashlib
import json
import os
from pathlib import Path, PureWindowsPath
import re
import shutil
import stat
import subprocess
import sys
import threading
import time
from uuid import uuid4

from ..approvals import ApprovalStore
from ..contexts import PHASE_ROLES, check_role_paths, validate_context
from ..errors import AgentSystemError
from ..evidence import Evidence, digest
from ..git import git
from ..isolation import CAPABILITIES, Capability, IsolationCapabilities, IsolatedCheckout
from ..policies import check_paths, matches
from ..roles import ROLES, Role
from ..state_machine import timestamp, validate_history
from ..storage import atomic_json, contained, read_json
from ..task import validate
from ..telemetry import enforce_limits, finish_invocation, identity
from .base import AgentResult, AgentRunner
from .isolated_session import IsolatedSessionRunner


# The image is trusted; this launcher is Controller code, not project code.
LAUNCHER = r'''import json, os, pathlib, sys
request = json.loads(sys.stdin.readline())
payload = sys.stdin.read()
for name in ('home', 'cache', 'config', 'data', 'state', 'tmp'):
    pathlib.Path('/role/' + name).mkdir(mode=0o700, exist_ok=True)
os.environ.clear()
os.environ.update(request['environment'])
stdin_path = pathlib.Path('/role/tmp/role-stdin')
stdin_path.write_text(payload, encoding='utf-8')
stdin_path.chmod(0o600)
fd = os.open(str(stdin_path), os.O_RDONLY)
os.dup2(fd, 0)
os.close(fd)
os.chdir('/workspace')
os.execvpe(request['argv'][0], request['argv'], os.environ)
'''

CLEANUP = r'''import pathlib, shutil, stat, sys
target, parent = map(pathlib.Path, sys.argv[1:])
if target.name not in ('checkout', 'transfer') or target.parent.resolve() != parent.resolve() or target.is_symlink():
    raise RuntimeError('Unsafe cleanup root')
def clear_readonly(function, filename, exc_info):
    candidate = pathlib.Path(filename)
    if not candidate.resolve().is_relative_to(target.resolve()) or candidate.is_symlink():
        raise RuntimeError('Unsafe readonly cleanup target')
    if not isinstance(exc_info[1], PermissionError): raise exc_info[1]
    candidate.chmod(stat.S_IREAD | stat.S_IWRITE)
    function(filename)
shutil.rmtree(target, onerror=clear_readonly)
'''


def regular_tree(root):
    """Do not follow project links, Windows junctions, devices or special files."""
    root = Path(root)
    for directory, dirs, files in os.walk(root, followlinks=False):
        for name in [*dirs, *files]:
            path = Path(directory) / name
            info = path.lstat()
            if (path.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400
                    or not (stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode))):
                raise AgentSystemError('Unsupported link/reparse/special file: ' + str(path))


def file_map(root):
    regular_tree(root)
    result = {}
    for path in Path(root).rglob('*'):
        if path.is_file() and '.git' not in path.relative_to(root).parts:
            with path.open('rb') as stream:
                result[path.relative_to(root).as_posix()] = hashlib.file_digest(stream, 'sha256').hexdigest()
    return result


class DockerIsolatedRunner(AgentRunner):
    backend = 'docker_isolated'

    def __init__(self, config):
        self.config = config
        self.settings = config.project['runner']
        self.options = self.settings.get('container', {})
        if config.project['runtime'].get('version') != 2:
            raise AgentSystemError('docker_isolated requires external runtime v2')
        self.image = self.options.get('image', '')
        if not re.fullmatch(r'sha256:[0-9a-f]{64}', self.image):
            raise AgentSystemError('Container image must be a pinned local sha256 image ID')
        self.docker = self.options.get('docker_executable', 'docker')
        self.root = config.runtime_root / 'docker-runner'
        self.owner = digest(str(config.root.resolve()))[:24]
        self._binding = None

    def _docker(self, args, timeout=20):
        result = subprocess.run([self.docker, '--context', self.options.get('context', 'desktop-linux'), *args],
                                capture_output=True, encoding='utf-8', errors='replace', timeout=timeout)
        if result.returncode:
            raise AgentSystemError('Docker command failed: ' + result.stderr[:4000])
        return result

    def preflight(self):
        engine = json.loads(self._docker(['info', '--format', '{{json .}}']).stdout)
        image = json.loads(self._docker(['image', 'inspect', self.image]).stdout)[0]
        if engine['OSType'] != 'linux' or image['Os'] != 'linux' or image['Id'] != self.image:
            raise AgentSystemError('A matching local Linux image and Linux engine are required')
        code = b''.join(path.read_bytes() for path in [Path(__file__), *(
            Path(__file__).parents[1] / filename for filename in
            ('isolation_probes.py', 'isolation.py', 'contexts.py', 'gates.py', 'mechanical_gates.py'))])
        self._binding = {'backend': self.backend, 'image': self.image,
                         'engine': {key: engine.get(key) for key in ('ID', 'ServerVersion', 'KernelVersion', 'Driver', 'SecurityOptions')},
                         'settings': digest(self.settings), 'implementation': hashlib.sha256(code).hexdigest(),
                         'project': str(self.config.root.resolve())}
        return self._binding

    def _store(self):
        binding = self.preflight()
        return ApprovalStore(self.root / 'attestations' / digest(binding), binding)

    def isolation_capabilities(self):
        capabilities = {}
        try:
            store = self._store()
            report = store.verify('validation')
            # Evidence is Controller-created and HMAC bound to the exact engine,
            # image, implementation and settings. Unknown probes never admit.
            for name in CAPABILITIES:
                item = report['capabilities'].get(name, {})
                if item.get('passed') is True:
                    paths = item.get('evidence', [])
                    if paths and all((store.directory / p).is_file() and
                                     hashlib.sha256((store.directory / p).read_bytes()).hexdigest() == h
                                     for p, h in paths):
                        capabilities[name] = Capability(True, True, str(store.directory / 'validation.json') + '#' + name)
        except (AgentSystemError, OSError, ValueError, KeyError, subprocess.TimeoutExpired):
            pass
        return IsolationCapabilities(self.backend, capabilities)

    def _workspace(self, workspace, task):
        workspace = Path(workspace).resolve()
        directory = contained(self.config.runs_dir, task['task_id'])
        manifest = read_json(directory / 'worktrees.json')
        if manifest['task_id'] != task['task_id']:
            raise AgentSystemError('Checkout task identity mismatch')
        entries = [entry for entry in manifest['worktrees'].values() if Path(entry['path']).resolve() == workspace]
        if (len(entries) != 1 or not workspace.is_relative_to(self.config.worktrees_dir.resolve())
                or workspace == self.config.root.resolve()):
            raise AgentSystemError('Container command requires an owned task checkout')
        regular_tree(workspace)
        return workspace

    def command_environment(self):
        return {'PATH': '/usr/local/bin:/usr/bin:/bin', 'HOME': '/role/home', 'USERPROFILE': '/role/home',
                'XDG_CACHE_HOME': '/role/cache', 'XDG_CONFIG_HOME': '/role/config',
                'XDG_DATA_HOME': '/role/data', 'XDG_STATE_HOME': '/role/state',
                'TMPDIR': '/role/tmp', 'TEMP': '/role/tmp', 'TMP': '/role/tmp',
                'CODEX_HOME': '/role/config/codex', 'HISTFILE': '/role/state/history',
                'PIP_CACHE_DIR': '/role/cache/pip', 'UV_CACHE_DIR': '/role/cache/uv',
                'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1',
                'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null',
                'GIT_CONFIG_COUNT': '2', 'GIT_CONFIG_KEY_0': 'safe.directory', 'GIT_CONFIG_VALUE_0': '/workspace',
                'GIT_CONFIG_KEY_1': 'core.hooksPath', 'GIT_CONFIG_VALUE_1': '/nonexistent-hooks'}

    def prepare_command(self, argv, workspace):
        """Translate executable/path tokens only; never rewrite script contents."""
        command = list(argv)
        for index, value in enumerate(command):
            if not isinstance(value, str) or '\0' in value:
                raise AgentSystemError('Command arguments must be strings without NUL')
            executable_name = PureWindowsPath(value).name if '\\' in value else Path(value).name
            if index == 0 and re.fullmatch(r'python(?:3(?:\.\d+)?)?(?:\.exe)?', executable_name.lower()):
                command[index] = 'python'
                continue
            if value == '/workspace' or value.startswith(('/workspace/', '/role/', '/usr/bin/', '/usr/local/bin/', '/bin/')):
                continue
            # A token that is exactly a host checkout path can be mapped. Embedded
            # script strings, shell expressions and arbitrary host paths cannot.
            try:
                p = Path(value)
                if p.is_absolute():
                    resolved = p.resolve()
                    if resolved == Path(workspace).resolve() or resolved.is_relative_to(Path(workspace).resolve()):
                        command[index] = '/workspace' + ('/' + resolved.relative_to(Path(workspace).resolve()).as_posix()
                                                         if resolved != Path(workspace).resolve() else '')
                    elif not value.startswith(('/usr/bin/', '/usr/local/bin/', '/bin/', '/workspace/')):
                        raise AgentSystemError('Host path outside role checkout in command')
                elif PureWindowsPath(value).is_absolute():
                    raise AgentSystemError('Unmapped Windows host path')
            except ValueError as exc:
                raise AgentSystemError('Invalid command path') from exc
        if not command or not command[0] or command[0].startswith('-'):
            raise AgentSystemError('Missing role executable')
        return command, self.command_environment()

    def _snapshot(self, workspace, directory):
        regular_tree(workspace)
        snapshot = directory / 'checkout'
        head = git(workspace, 'rev-parse', 'HEAD')
        # An active commit bundle exposes its ancestors, but no sibling refs,
        # reflogs, loose objects or shared worktree metadata.
        IsolatedCheckout.create(workspace, snapshot, head, directory / 'transfer')
        for item in snapshot.iterdir():
            if item.name != '.git':
                if item.is_dir():
                    shutil.rmtree(item)
                else:
                    item.unlink()
        for item in Path(workspace).iterdir():
            if item.name in ('.git', '.venv', '__pycache__', '.pytest_cache', '.agent_runs', '.agent_worktrees'):
                continue
            target = snapshot / item.name
            if item.is_dir():
                shutil.copytree(item, target)
            else:
                shutil.copyfile(item, target)
        regular_tree(snapshot)
        return snapshot

    def _mount(self, source, destination, readonly=True):
        # Docker --mount parses commas even when shell quoting is correct.
        source = str(Path(source).resolve())
        if ',' in source or ',' in destination:
            raise AgentSystemError('Comma in Docker mount path is unsupported')
        return ['--mount', f'type=bind,source={source},target={destination}' + (',readonly' if readonly else '')]

    def _create_args(self, name, snapshot, read_only, protected=()):
        memory = self.options.get('memory_mb', 512)
        command = ['create', '--pull=never', '--name', name, '--label', 'agentctl.owner=' + self.owner,
                   '--label', 'agentctl.execution=' + name, '--network', 'none', '--read-only',
                   '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges', '--user', '50000:50000',
                   '--memory', f'{memory}m', '--memory-swap', f'{memory}m',
                   '--cpus', str(self.options.get('cpus', 1)), '--pids-limit', '64', '--log-driver', 'none',
                   '--tmpfs', '/role:rw,nosuid,nodev,size=128m,mode=1777', '-i', '--entrypoint', 'python']
        command += self._mount(snapshot, '/workspace', read_only)
        if not read_only:
            command += self._mount(snapshot / '.git', '/workspace/.git')
            for path in sorted(set(protected)):
                command += self._mount(contained(snapshot, path), '/workspace/' + path)
        return [*command, self.image, '-I', '-c', LAUNCHER]

    def _verify_container(self, value, snapshot, read_only):
        host, config = value['HostConfig'], value['Config']
        mounts = value['Mounts']
        if (host['NetworkMode'] != 'none' or not host['ReadonlyRootfs'] or host.get('Privileged')
                or host['CapDrop'] != ['ALL'] or host.get('CapAdd')
                or not any(s.startswith('no-new-privileges') for s in host['SecurityOpt'])
                or config['User'] != '50000:50000' or value['Image'] != self.image
                or host.get('PortBindings') or host.get('Devices')
                or host['Memory'] != self.options.get('memory_mb', 512) * 1024 * 1024
                or host['MemorySwap'] != host['Memory']
                or host['NanoCpus'] != int(self.options.get('cpus', 1) * 1000000000)
                or host['Memory'] > 4096 * 1024 * 1024 or host['Memory'] <= 0
                or host['PidsLimit'] != 64 or host.get('PidMode') or host.get('IpcMode') == 'host'
                or config['Labels'].get('agentctl.owner') != self.owner):
            raise AgentSystemError('Docker enforcement configuration mismatch')
        workspace = next((m for m in mounts if m['Destination'] == '/workspace'), None)
        if workspace is None or bool(workspace['RW']) == bool(read_only):
            raise AgentSystemError('Docker workspace mount access mismatch')
        expected = self._expected_mounts
        actual = {(m['Destination'], bool(m['RW'])) for m in mounts}
        if actual != expected or host['Tmpfs'] != {'/role': 'rw,nosuid,nodev,size=128m,mode=1777'}:
            raise AgentSystemError('Unexpected Docker mount visibility')

    def _cleanup_container(self, container_id, name):
        value = json.loads(self._docker(['inspect', container_id]).stdout)[0]
        if (value['Id'] != container_id or value['Name'] != '/' + name or
                value['Config']['Labels'].get('agentctl.owner') != self.owner or
                value['Config']['Labels'].get('agentctl.execution') != name):
            raise AgentSystemError('Refusing cleanup of unrelated container')
        self._docker(['rm', '--force', container_id])
        remaining = self._docker(['ps', '-aq', '--no-trunc', '--filter', 'id=' + container_id]).stdout.strip()
        if remaining:
            raise AgentSystemError('Container cleanup not confirmed')

    def _attach(self, container_id, request, timeout):
        """Drain pipes with bounded memory; kill the container on timeout/overflow."""
        argv = [self.docker, '--context', self.options.get('context', 'desktop-linux'), 'start', '-ai', container_id]
        if len(request.encode('utf-8')) > 2 * 1024 * 1024:
            raise AgentSystemError('Role input limit exceeded')
        process = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        limit = self.options.get('output_limit_bytes', 1024 * 1024)
        output = [bytearray(), bytearray()]
        overflow = threading.Event()
        def drain(stream, index):
            while data := stream.read(4096):
                remaining = limit - len(output[index])
                output[index].extend(data[:max(0, remaining)])
                if len(data) > remaining:
                    overflow.set()
        threads = [threading.Thread(target=drain, args=(stream, index), daemon=True)
                   for index, stream in enumerate((process.stdout, process.stderr))]
        for thread in threads:
            thread.start()
        def feed():
            try:
                process.stdin.write(request.encode('utf-8'))
                process.stdin.close()
            except (OSError, ValueError):
                pass
        writer = threading.Thread(target=feed, daemon=True)
        writer.start()
        try:
            deadline = time.monotonic() + timeout
            while process.poll() is None:
                if overflow.is_set():
                    raise AgentSystemError('Role output limit exceeded')
                if time.monotonic() >= deadline:
                    raise subprocess.TimeoutExpired(argv, timeout)
                time.sleep(0.03)
        finally:
            if process.poll() is None:
                try:
                    self._docker(['kill', container_id])
                except AgentSystemError:
                    value = json.loads(self._docker(['inspect', container_id]).stdout)[0]
                    if value['State']['Running']:
                        raise
                finally:
                    process.kill()
            process.wait(timeout=10)
            writer.join(timeout=10)
            for thread in threads:
                thread.join(timeout=10)
            process.stdout.close()
            process.stderr.close()
        if overflow.is_set():
            raise AgentSystemError('Role output limit exceeded')
        status = json.loads(self._docker(['inspect', container_id]).stdout)[0]['State']
        if status['Running'] or status.get('Error'):
            raise AgentSystemError('Container did not finish normally')
        return subprocess.CompletedProcess(argv, status['ExitCode'], *(bytes(b).decode('utf-8', 'replace') for b in output))

    def _remove_owned_tree(self, path, directory):
        path, directory = Path(path), Path(directory)
        if not path.resolve().is_relative_to(directory.resolve()) or path.is_symlink():
            raise AgentSystemError('Unsafe execution cleanup target')
        try:
            result = subprocess.run([sys.executable, '-I', '-c', CLEANUP, str(path), str(directory)],
                capture_output=True, text=True, timeout=20,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
        except subprocess.TimeoutExpired as exc:
            raise AgentSystemError('Bounded execution storage cleanup timed out') from exc
        if result.returncode:
            raise AgentSystemError('Execution storage cleanup failed: ' + result.stderr[:4000])

    def _execute(self, argv, workspace, timeout, task, read_only=True, input_text='', directory=None):
        """Private bootstrap path used by independent probes before admission."""
        if self.stale_executions():
            raise AgentSystemError('Outstanding owned container blocks execution; inspect stale cleanup')
        workspace = Path(workspace).resolve()
        execution_id = uuid4().hex
        directory = directory or self.root / 'executions' / execution_id
        directory.mkdir(parents=True, exist_ok=False)
        name = 'agentctl-' + self.owner[:12] + '-' + execution_id
        container_id = None
        record = {'execution_id': execution_id, 'name': name, 'owner': self.owner,
                  'workspace': str(workspace), 'created_at': timestamp(), 'status': 'preparing'}
        atomic_json(directory / 'ownership.json', record)
        try:
            snapshot = self._snapshot(workspace, directory)
            record['input_commit'] = read_json(directory / 'transfer/checkout.json')['base']
            before = file_map(snapshot)
            protected = [p for p in before if any(matches(p, pattern) for pattern in self.config.project['protected_paths'])]
            if task.get('_role') == str(Role.IMPLEMENTER):
                protected += [p for p in before if any(matches(p, pattern) for pattern in task['workflow']['test_paths'])]
            command = self._create_args(name, snapshot, read_only, protected)
            self._expected_mounts = {('/workspace', not read_only)}
            if not read_only:
                self._expected_mounts |= {('/workspace/.git', False), *(('/workspace/' + p, False) for p in protected)}
            argv, environment = self.prepare_command(argv, workspace)
            atomic_json(directory / 'command.json', {'docker': command, 'argv': argv, 'environment': environment})
            container_id = self._docker(command).stdout.strip()
            if not re.fullmatch(r'[0-9a-f]{64}', container_id):
                raise AgentSystemError('Invalid container identity')
            record.update(container_id=container_id, status='created')
            atomic_json(directory / 'ownership.json', record)
            inspection = json.loads(self._docker(['inspect', container_id]).stdout)[0]
            self._verify_container(inspection, snapshot, read_only)
            atomic_json(directory / 'enforcement.json', inspection)
            request = json.dumps({'argv': argv, 'environment': environment}) + '\n' + input_text
            result = self._attach(container_id, request, timeout)
            (directory / 'stdout.txt').write_text(result.stdout, encoding='utf-8')
            (directory / 'stderr.txt').write_text(result.stderr, encoding='utf-8')
            after = file_map(snapshot)
            paths = sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))
            record['changed_paths'] = paths
            atomic_json(directory / 'mutations.json', {p: {'before': before.get(p), 'after': after.get(p)} for p in paths})
            # Directory-only side effects are real mutations too. Do not export
            # ambiguous empty directories that Git cannot account for.
            empty_directories = [p for p in snapshot.rglob('*') if p.is_dir()
                                 and '.git' not in p.relative_to(snapshot).parts
                                 and not any(p.iterdir())
                                 and not (workspace / p.relative_to(snapshot)).is_dir()]
            if empty_directories:
                record['new_empty_directories'] = [p.relative_to(snapshot).as_posix() for p in empty_directories]
                raise AgentSystemError('Untracked empty-directory mutation is unsupported')
            if read_only and paths:
                raise AgentSystemError('Read-only snapshot mutation')
            if any(p in protected for p in paths):
                raise AgentSystemError('Protected snapshot mutation')
            if paths:
                # Copy only regular project files after deterministic policy gates.
                # No Git metadata, hooks, symlinks or environment files are exported.
                role = Role(task['_role'])
                check_paths(role, paths, task, self.config.project)
                check_role_paths(role, task.get('_phase'), paths, task)
                regular_tree(workspace)
                for p in paths:
                    source, target = contained(snapshot, p), contained(workspace, p)
                    if source.is_file():
                        target.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copyfile(source, target)
                    elif target.is_file():
                        target.unlink()
            record.update(status='completed', returncode=result.returncode, changed_paths=paths)
            return result, directory, paths
        except BaseException as exc:
            record.update(status='failed', error=type(exc).__name__ + ': ' + str(exc)[:4000])
            raise
        finally:
            if container_id:
                try:
                    self._cleanup_container(container_id, name)
                    record['cleanup'] = 'confirmed'
                except BaseException as exc:
                    record['cleanup'] = 'failed: ' + str(exc)[:4000]
                    atomic_json(directory / 'ownership.json', record)
                    raise
            # Never delete a computed path outside the exact owned execution.
            try:
                for name in ('checkout', 'transfer'):
                    path = directory / name
                    if path.exists():
                        self._remove_owned_tree(path, directory)
                record['storage_cleanup'] = 'confirmed'
            except BaseException as exc:
                record['storage_cleanup'] = 'failed: ' + str(exc)[:4000]
                atomic_json(directory / 'ownership.json', record)
                raise
            atomic_json(directory / 'ownership.json', record)

    def run_command(self, argv, workspace, environment, timeout_seconds, task, read_only=True):
        self.isolation_capabilities().require()
        self._workspace(workspace, task)
        if not read_only:
            raise AgentSystemError('Generated command adapter is read-only; use the role invocation for mutations')
        # Host environment is intentionally not forwarded.
        return self._execute(argv, workspace, timeout_seconds, task, read_only=True)[0]

    def _role_argv(self, role, phase):
        return [self.settings['executable'], *self.options.get('role_args', [])]

    def run(self, role, model_config, context_bundle, workspace, task_metadata):
        self.isolation_capabilities().require()
        role = Role(role)
        task = validate(task_metadata, 'task')
        phase = context_bundle.get('phase')
        if 'hardening' not in task or not phase:
            raise AgentSystemError('docker_isolated supports explicit hardened phases only')
        if model_config != self.config.model_for(role) or PHASE_ROLES.get(phase) != role:
            raise AgentSystemError('Role/routing/phase mismatch')
        directory = contained(self.config.runs_dir, task['task_id'])
        state = validate_history(read_json(directory / 'state.json'))
        expected_states = {'architecture': 'ARCHITECTURE_CHECK', 'test_design': 'TEST_DESIGN',
                           'test_implementation': 'TEST_DESIGN_FROZEN', 'implementation': 'IMPLEMENTING',
                           'fix': 'FIXING', 'test_correction': 'TESTING', 'review': 'REVIEWING',
                           'review_blind': 'REVIEWING', 'audit': 'AUDITING', 'test_correction_review': 'TESTING'}
        operation = f"c{state['fix_cycle']}-{phase}-r{state['architecture_round']}-t{state['test_version']}"
        if (state['version'] != 3 or state['state'] != expected_states.get(phase)
                or task != read_json(directory / 'task.json')
                or state['configuration_digest'] != digest({'project': self.config.project, 'routing': self.config.routing})
                or context_bundle['operation_id'] != operation):
            raise AgentSystemError('Invocation does not match persisted hardened lifecycle')
        control = ApprovalStore(directory / 'controller', {
            'task_id': task['task_id'], 'task_digest': state['task_digest'],
            'configuration_digest': state['configuration_digest'], 'base_commit': state['base_commit']})
        from ..hardened_workflow import TestVersionEvidence
        evidence = TestVersionEvidence(directory, state)
        control.verify('interface', evidence.read('contract/package'))
        if task['major_phase']:
            if control.verify('contract')['package_sha256'] != digest(evidence.read('contract/package')):
                raise AgentSystemError('Contract approval mismatch')
        selections = []
        for number in range(state['architecture_round'] + 1):
            key = f'architecture/{number}'
            if evidence.exists(key + '/selection'):
                selection = evidence.read(key + '/selection')
                decision = evidence.read(key + '/decision')
                control.verify('architecture/' + decision['decision_id'], selection)
                selections.append({'decision': decision, 'selection': selection})
        if context_bundle.get('inputs', {}).get('architecture_selection', []) != selections:
            raise AgentSystemError('Unrecorded architecture selection')
        inputs = context_bundle.get('inputs', {})
        if phase in ('test_implementation', 'test_correction', 'review', 'audit'):
            if inputs.get('test_design') != evidence.read('tester/frozen_design'):
                raise AgentSystemError('Unrecorded frozen independent design')
        if phase in ('review', 'audit'):
            if inputs.get('test_results') != evidence.read(f"cycles/{state['fix_cycle']}/tests/result"):
                raise AgentSystemError('Unrecorded validation results')
        if phase == 'audit' and inputs.get('audit_validation') != evidence.read(f"cycles/{state['fix_cycle']}/auditor/regenerated"):
            raise AgentSystemError('Unrecorded Auditor regeneration')
        workspace = self._workspace(workspace, task)
        name = ROLES[role].workspace_name or 'orchestrator'
        if workspace != contained(self.config.worktrees_dir, f"{task['task_id']}/{name}"):
            raise AgentSystemError('Role checkout mismatch')
        if git(workspace, 'rev-parse', 'HEAD') != state['commits'][name]:
            raise AgentSystemError('Role candidate differs from persisted commit')
        if git(workspace, 'status', '--porcelain', '--untracked-files=all'):
            raise AgentSystemError('Role invocation requires a clean starting checkout')
        validate_context(context_bundle, role, workspace, task)
        # Reuse public-contract projection and approved context construction;
        # do not inherit the old shared-worktree execution backend.
        prompt = IsolatedSessionRunner(self.config)._prompt(role, context_bundle, workspace, task)
        readonly = ROLES[role].read_only or phase in ('architecture', 'test_design')
        snapshot = {'project': self.config.project, 'routing': self.config.routing}
        enforce_limits(directory, task, snapshot, state['fix_cycle'])
        execution_id = str(uuid4())
        invocation = directory / 'invocations' / execution_id
        invocation.mkdir(parents=True, exist_ok=False)
        atomic_json(invocation / 'context_manifest.json', context_bundle)
        (invocation / 'prompt.md').write_text(prompt, encoding='utf-8')
        binding = identity(task, self.config, context_bundle, git(workspace, 'rev-parse', 'HEAD'), 0, execution_id)
        started, clock_start = timestamp(), time.monotonic()
        Evidence(invocation).write('telemetry_start', {**binding, 'started_at': started})
        payload = json.dumps({'role': str(role), 'model': model_config.model, 'reasoning': model_config.reasoning,
                              'phase': phase, 'prompt': prompt, 'inputs': context_bundle.get('inputs', {}),
                              'task_id': task['task_id'], 'contract_version': task['hardening']['contract_version']})
        status, message, code, paths, timed_out = 'execution_failed', '', None, [], False
        try:
            argv = self._role_argv(role, phase)
            result, command_dir, paths = self._execute(argv, workspace, self.settings['timeout_seconds'],
                {**task, '_role': str(role), '_phase': phase}, readonly, payload)
            code, message = result.returncode, result.stdout
            if code == 0:
                status = 'success'
            else:
                message = result.stderr or f'Role exited with {code}'
            atomic_json(invocation / 'execution.json', {'directory': str(command_dir)})
        except subprocess.TimeoutExpired:
            status, message, timed_out = 'timeout', 'Isolated role timed out', True
        except AgentSystemError as exc:
            status, message = 'policy_violation', str(exc)
        except OSError as exc:
            message = str(exc)
        result = AgentResult(execution_id, task['task_id'], str(role), status, model_config.model,
                             model_config.reasoning, 0, code, message, paths)
        atomic_json(invocation / 'result.json', result.to_dict())
        finish_invocation(invocation, binding, result.to_dict(), started, timestamp(),
                          time.monotonic() - clock_start, timed_out, events_required=False)
        return result

    def stale_executions(self):
        rows = self._docker(['ps', '-a', '--no-trunc', '--filter', 'label=agentctl.owner=' + self.owner,
                             '--format', '{{.ID}}']).stdout.splitlines()
        return [json.loads(self._docker(['inspect', row]).stdout)[0] for row in rows]

    def cleanup_stale(self, execution_id):
        if not re.fullmatch(r'[0-9a-f]{32}', execution_id):
            raise AgentSystemError('Invalid stale execution identity')
        directory = self.root / 'executions' / execution_id
        record = read_json(directory / 'ownership.json')
        if record['owner'] != self.owner or record['execution_id'] != execution_id:
            raise AgentSystemError('Stale execution ownership mismatch')
        values = [v for v in self.stale_executions() if v['Name'] == '/' + record['name']]
        if len(values) > 1 or (values and values[0]['State']['Running']):
            raise AgentSystemError('Stale cleanup requires exactly one stopped owned container')
        if values:
            if values[0]['Id'] != record.get('container_id'):
                raise AgentSystemError('Stale container ID differs from recorded ownership')
            self._cleanup_container(values[0]['Id'], record['name'])
            record['cleanup'] = 'confirmed'
        elif record.get('cleanup') != 'confirmed':
            raise AgentSystemError('No recorded confirmed container disposal; refusing storage cleanup')
        for name in ('checkout', 'transfer'):
            path = directory / name
            if path.exists():
                self._remove_owned_tree(path, directory)
        record['cleanup'] = 'confirmed'
        record['storage_cleanup'] = 'confirmed'
        atomic_json(directory / 'ownership.json', record)

    def validate_isolation(self):
        from ..isolation_probes import validate_docker_isolation
        return validate_docker_isolation(self)
