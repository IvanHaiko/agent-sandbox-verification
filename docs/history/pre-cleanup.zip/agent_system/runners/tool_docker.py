"""Stage18c binding for dynamic tools; retains the Stage17 runner unchanged."""
import hashlib
from pathlib import Path
import shutil
import threading

from .docker_isolated import DockerIsolatedRunner
from ..contexts import PHASE_ROLES
from ..errors import AgentSystemError
from ..roles import Role, ROLES


class ToolDockerRunner(DockerIsolatedRunner):
    def __init__(self, config):
        super().__init__(config)
        self.cancel_event = threading.Event()
        self.output_filter = None
        self.active_output_limit = self.options.get('output_limit_bytes', 1048576)

    def _attach(self, container_id, request, timeout):
        stopped = threading.Event()
        def cancel():
            while not stopped.wait(0.05):
                if self.cancel_event.is_set():
                    try:
                        self._docker(['kill', container_id])
                    except AgentSystemError:
                        pass  # parent verifies stopped state and disposal
                    return
        watcher = threading.Thread(target=cancel, daemon=True)
        watcher.start()
        try:
            cp = super()._attach(container_id, request, timeout)
            if self.cancel_event.is_set():
                raise AgentSystemError('Isolated tool cancelled')
            if '\ufffd' in cp.stdout or '\ufffd' in cp.stderr:
                raise AgentSystemError('Invalid tool output encoding')
            if any(len(s.encode()) > self.active_output_limit for s in (cp.stdout, cp.stderr)):
                raise AgentSystemError('Requested tool output limit exceeded')
            if self.output_filter:
                self.output_filter.reject(cp.stdout + cp.stderr)
            return cp
        finally:
            stopped.set()
            watcher.join(timeout=20)
            if watcher.is_alive():
                raise AgentSystemError('Tool cancellation watcher shutdown unconfirmed')

    def preflight(self):
        binding = super().preflight()
        files = [Path(__file__), Path(__file__).parents[1] / 'model_tool_boundary.py',
                 Path(__file__).parents[1] / 'codex_tool_session.py']
        files += [Path(__file__).with_name('chatgpt_plan.py')]
        files += [Path(__file__).parents[1] / name for name in ('chatgpt_oauth.py', 'agent_transport.py', 'responses_lifecycle.py', 'responses_http.py', 'runtime_observability.py')]
        binding['stage18c'] = {'topology': 'trusted-codex-gated-responses-dynamic-docker-tools',
            'protocol': 1, 'implementation': hashlib.sha256(b''.join(p.read_bytes() for p in files)).hexdigest(),
            'model_route': 'https://api.openai.com/v1/responses', 'role_network': 'none',
            'ipc': 'trusted-loopback-model-relay; trusted-stdio-codex; docker-attach-tools'}
        executable = Path(shutil.which('codex') or '')
        if not executable.is_file():
            raise AgentSystemError('Pinned local Codex executable required')
        binding['stage18c']['codex'] = {'path': str(executable.resolve()),
                                      'sha256': hashlib.sha256(executable.read_bytes()).hexdigest()}
        return binding

    def run_tool(self, argv, workspace, task, role, phase, read_only, stdin, timeout):
        if self.cancel_event.is_set():
            raise AgentSystemError('Cancelled Docker tool execution')
        role = Role(role)
        if PHASE_ROLES.get(phase) != role or type(read_only) is not bool:
            raise AgentSystemError('Tool role/phase mismatch')
        if (ROLES[role].read_only or phase in ('architecture', 'test_design')) and not read_only:
            raise AgentSystemError('Read-only role mutation forbidden')
        self.isolation_capabilities().require()
        workspace = self._workspace(workspace, task)
        # Trusted snapshot preparation/export is inherited. Model-driven argv
        # is only exec'd by Docker's container launcher, never by host subprocess.
        cp, _, paths = self._execute(argv, workspace, timeout,
                                {**task, '_role': str(role), '_phase': phase}, read_only, stdin)
        cp.changed_paths = paths
        return cp

    def require_transport_admission(self):
        self.isolation_capabilities().require()
        proof = self._store().verify('stage18c-transport')
        required = ('codex_dynamic_roundtrip', 'docker_mutation', 'host_execution_trap',
                    'token_visibility', 'builtin_response_denied', 'timeout_cleanup',
                    'cancel_cleanup', 'overflow_cleanup', 'secret_output_rejected_before_export')
        if any(proof.get(name) is not True for name in required) or proof.get('real_model_calls') != 0:
            raise AgentSystemError('Complete Stage18c transport admission required')
        path = self._store().directory / 'stage18c-proof.json'
        if hashlib.sha256(path.read_bytes()).hexdigest() != proof.get('evidence_sha256'):
            raise AgentSystemError('Stage18c transport evidence changed')
