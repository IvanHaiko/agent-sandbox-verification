"""Codex dynamic tools behind a credential-owning, model-only Responses gate.

No agent loop is implemented here. Codex owns it. Full SSE responses are checked
before release so built-in tool calls can never reach its local tool dispatcher.
"""
from dataclasses import dataclass
import hashlib
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import math
import secrets
import threading
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, build_opener, ProxyHandler

from .agent_transport import CredentialLease, InvocationBinding, strict_json
from .chatgpt_oauth import NoRedirect, PLAN_SCOPE
from .contexts import PHASE_ROLES
from .errors import AgentSystemError
from .roles import Role, ROLES
from .runtime_observability import safe_failure

TOOL = 'agentctl_execute'
NAMESPACE = 'agentctl'
UPSTREAM = 'https://api.openai.com/v1/responses'


@dataclass(frozen=True)
class ExecutionPolicy:
    binding: InvocationBinding
    phase: str
    workspace_id: str
    deadline: float
    max_requests: int = 4
    max_request_bytes: int = 1048576
    max_response_bytes: int = 1048576
    max_tool_calls: int = 8
    max_tool_seconds: int = 30
    output_bytes: int = 1048576

    def __post_init__(self):
        if (PHASE_ROLES.get(self.phase) != Role(self.binding.role) or not self.workspace_id
                or not math.isfinite(self.deadline)
                or any(type(n) is not int or n < 1 for n in (self.max_requests, self.max_request_bytes,
                    self.max_response_bytes, self.max_tool_calls, self.max_tool_seconds, self.output_bytes))
                or self.max_tool_seconds > 60 or max(self.max_request_bytes, self.max_response_bytes, self.output_bytes) > 16 * 1048576):
            raise AgentSystemError('Invalid execution policy')

    def identity(self):
        b = self.binding
        return {'execution_id': b.execution_id, 'task_id': b.task_id, 'role': b.role,
                'phase': self.phase, 'contract_version': b.contract_version, 'workspace_id': self.workspace_id}


def tool_spec(policy):
    properties = {k: {'const': v, 'type': 'integer' if type(v) is int else 'string'}
                  for k, v in policy.identity().items()}
    properties.update(tool_type={'const': 'argv', 'type': 'string'}, argv={'type': 'array', 'minItems': 1, 'maxItems': 64,
        'items': {'type': 'string', 'minLength': 1}}, stdin={'type': 'string', 'maxLength': 65536},
        timeout_seconds={'type': 'integer', 'minimum': 1, 'maximum': policy.max_tool_seconds},
        output_bytes={'type': 'integer', 'minimum': 1, 'maximum': policy.output_bytes},
        read_only={'type': 'boolean'})
    return {'type': 'function', 'name': TOOL, 'description': 'Execute argv inside the owned isolated Docker role workspace. '
        'Use for all repository inspection, file operations, edits, tests and imports. No host paths or host executor.',
        'inputSchema': {'type': 'object', 'properties': properties, 'required': list(properties), 'additionalProperties': False}}


class SecretFilter:
    def __init__(self, values=()):
        self.leases = [CredentialLease('trusted', 'transport', value) for value in values if value]
    def __repr__(self):
        return 'SecretFilter(<private>)'
    def redact(self, text):
        for lease in self.leases:
            text = lease.redact(text)
        return text
    def reject(self, text):
        if self.redact(text) != text:
            raise AgentSystemError('Credential-bearing output rejected')


class ResponsesGate:
    # Explicitly supported HTTP subset; no metadata, service tier, custom URL,
    # compaction, websocket continuation, hosted tool or billing fallback.
    FIELDS = {'model', 'input', 'instructions', 'store', 'stream', 'tools', 'tool_choice',
              'parallel_tool_calls', 'text', 'reasoning', 'include'}
    LOCAL_ONLY = {'client_metadata', 'prompt_cache_key'}
    EVENTS = {'response.created', 'response.in_progress', 'response.output_item.added',
        'response.output_item.done', 'response.content_part.added', 'response.content_part.done',
        'response.output_text.delta', 'response.output_text.done', 'response.function_call_arguments.delta',
        'response.function_call_arguments.done', 'response.reasoning_summary_part.added',
        'response.reasoning_summary_part.done', 'response.reasoning_summary_text.delta',
        'response.reasoning_summary_text.done', 'response.reasoning_text.delta',
        'response.reasoning_text.done', 'response.completed'}

    def __init__(self, policy, secret_filter=None):
        self.policy, self.secrets = policy, secret_filter or SecretFilter()
        self.requests, self.closed, self.seen_calls = 0, False, set()
        self.seen_items, self.seen_responses = set(), set()
        self.last_response_metadata = {}
        self.response_metadata_history = []
        self.request_fields = []
        self.authorized_arguments = {}
        self.lock = threading.Lock()

    def alive(self):
        if self.closed or time.monotonic() >= self.policy.deadline:
            raise AgentSystemError('Expired or closed model execution')

    def request(self, raw):
        with self.lock:
            self.alive()
            p = self.policy
            if self.requests >= p.max_requests or len(raw) > p.max_request_bytes:
                raise AgentSystemError('Model request limit exceeded')
            try:
                body = strict_json(raw.decode('utf-8'))
            except (UnicodeDecodeError, AgentSystemError):
                raise AgentSystemError('Malformed model request') from None
            if isinstance(body, dict):
                self.request_fields = sorted(body)
                # Measured Codex 0.159.2 adds these client-local fields. They are
                # discarded, never granted as upstream capabilities or authority.
                for key in self.LOCAL_ONLY:
                    body.pop(key, None)
            if (not isinstance(body, dict) or set(body) - self.FIELDS or body.get('model') != p.binding.model
                    or body.get('store') is not False or body.get('stream') is not True
                    or not isinstance(body.get('input'), list)
                    or any(isinstance(i, dict) and (i.get('role') == 'system' or i.get('type') in ('tool_search_output', 'tool_search_call')) for i in body['input'])):
                raise AgentSystemError('Unsupported model route or request')
            # Current Codex may put inventories in additional_tools input items.
            # Remove every such item; the only provider inventory is authored below.
            body['input'] = [i for i in body['input'] if not (isinstance(i, dict) and i.get('type') == 'additional_tools')]
            reasoning = body.get('reasoning', {})
            if not isinstance(reasoning, dict) or reasoning.get('effort') != p.binding.reasoning:
                raise AgentSystemError('Reasoning binding mismatch')
            allowed = tool_spec(p)
            # Codex can advertise built-ins. Replace the whole inventory with
            # one Controller-authored function schema, never forward built-ins.
            body['tools'] = [{'type': 'namespace', 'name': NAMESPACE, 'description': 'Controller-owned isolated execution',
                'tools': [{'type': 'function', 'name': TOOL, 'description': allowed['description'],
                           'strict': True, 'parameters': allowed['inputSchema']}]}]
            body['tool_choice'] = 'auto'
            self.requests += 1
            return body

    def inspect_response(self, raw):
        from .responses_lifecycle import validate_response, structural_metadata
        metadata = structural_metadata(len(raw))
        try:
            candidates, ids, response_id = validate_response(self, raw, metadata)
            metadata['validation_passed'] = True
            return candidates, ids, response_id, metadata
        except AgentSystemError as error:
            if str(error) == 'Credential-bearing output rejected':
                metadata = {'secret_checked': False, 'validation_passed': False}
            raise
        finally:
            # Secret-bearing data yields only a fixed suppression marker.
            self.last_response_metadata = metadata if metadata['secret_checked'] else {'secret_checked': False, 'validation_passed': False}
            self.response_metadata_history = (self.response_metadata_history + [self.last_response_metadata])[-self.policy.max_requests:]

    def response(self, raw):
        with self.lock:
            candidates, ids, response_id, metadata = self.inspect_response(raw)
            # Publish only after executable capability, schema and replay checks.
            updated = {**self.authorized_arguments, **candidates}
            self.seen_calls = self.seen_calls | set(candidates)
            self.seen_items = self.seen_items | ids
            self.seen_responses = self.seen_responses | {response_id}
            self.authorized_arguments = updated
            return raw

    def validate_arguments(self, canonical):
        from jsonschema import Draft202012Validator
        request = strict_json(canonical)
        if not Draft202012Validator(tool_spec(self.policy)['inputSchema']).is_valid(request):
            raise AgentSystemError('Invalid Controller function arguments')
        if any(request[k] != v or type(request[k]) is not type(v) for k, v in self.policy.identity().items()):
            raise AgentSystemError('Tool execution identity mismatch')
        if (any('\0' in arg for arg in request['argv']) or len(json.dumps(request['argv']).encode()) > 16384
                or len(request['stdin'].encode()) > 65536):
            raise AgentSystemError('Invalid tool bounds')
        if (ROLES[Role(self.policy.binding.role)].read_only or self.policy.phase in ('architecture', 'test_design')) and not request['read_only']:
            raise AgentSystemError('Read-only role mutation forbidden')

    def _item(self, item):
        if not isinstance(item, dict) or item.get('type') not in ('message', 'reasoning', 'function_call'):
            raise AgentSystemError('Unsupported model output item')
        if item['type'] == 'message':
            content = item.get('content')
            if (item.get('role') != 'assistant' or not isinstance(content, list)
                    or any(not isinstance(c, dict) or c.get('type') != 'output_text'
                           or not isinstance(c.get('text'), str) for c in content)):
                raise AgentSystemError('Unsupported model message content')
        if item['type'] == 'function_call':
            if item.get('name') != TOOL or item.get('namespace') != NAMESPACE:
                raise AgentSystemError('Built-in or unknown model tool denied')
            if item.get('async') not in (None, False) or item.get('caller') not in (None, {'type': 'direct'}):
                raise AgentSystemError('Unsupported function execution context')
            cid = item.get('call_id')
            if not isinstance(cid, str) or not cid:
                raise AgentSystemError('Malformed model tool identity')

    def close(self):
        self.closed = True


class IsolatedExecutionBridge:
    def __init__(self, runner, workspace, task, policy, secret_filter=None):
        if getattr(runner, 'backend', None) != 'docker_isolated' or not hasattr(runner, 'run_tool'):
            raise AgentSystemError('Admitted Docker tool runner required')
        self.runner, self.workspace, self.task, self.policy = runner, workspace, task, policy
        self.secrets = secret_filter or SecretFilter()
        if hasattr(runner, 'output_filter'):
            runner.output_filter = self.secrets  # inspect before runner persists output
        self.closed, self.calls = False, 0
        self.changed_paths = set()
        self.completed_calls, self.successful_write_paths, self.failure_receipt = 0, set(), None
        self.execution_layer = 'tool_request_validation_failure'

    def execute(self, request):
        self.execution_layer = 'tool_request_validation_failure'
        try:
            return self._execute(request)
        except Exception as error:
            self.failure_receipt = safe_failure(error, self.execution_layer)
            raise

    def _execute(self, request):
        p = self.policy
        if self.closed or time.monotonic() >= p.deadline:
            raise AgentSystemError('Expired tool execution')
        if not isinstance(request, dict) or set(request) != set(tool_spec(p)['inputSchema']['required']):
            raise AgentSystemError('Malformed or unknown tool request')
        if any(request[k] != v or type(request[k]) is not type(v) for k, v in p.identity().items()):
            raise AgentSystemError('Tool execution identity mismatch')
        if request['tool_type'] != 'argv' or self.calls >= p.max_tool_calls:
            raise AgentSystemError('Unsupported tool or tool count exceeded')
        argv = request['argv']
        if (not isinstance(argv, list) or not 1 <= len(argv) <= 64
                or any(not isinstance(a, str) or not a or '\0' in a for a in argv)
                or len(json.dumps(argv).encode()) > 16384 or not isinstance(request['stdin'], str)
                or len(request['stdin'].encode()) > 65536 or type(request['read_only']) is not bool
                or type(request['timeout_seconds']) is not int or not 1 <= request['timeout_seconds'] <= p.max_tool_seconds
                or type(request['output_bytes']) is not int or not 1 <= request['output_bytes'] <= p.output_bytes):
            raise AgentSystemError('Invalid tool bounds')
        role_readonly = ROLES[Role(p.binding.role)].read_only or p.phase in ('architecture', 'test_design')
        if role_readonly and not request['read_only']:
            raise AgentSystemError('Role cannot request mutations')
        self.secrets.reject(json.dumps(request))
        self.runner.isolation_capabilities().require()
        self.calls += 1
        if hasattr(self.runner, 'active_output_limit'):
            self.runner.active_output_limit = request['output_bytes']
        timeout = min(request['timeout_seconds'], max(0.01, p.deadline - time.monotonic()))
        self.execution_layer = 'tool_execution_failure'
        cp = self.runner.run_tool(argv, self.workspace, self.task, p.binding.role, p.phase,
                                  request['read_only'], request['stdin'], timeout)
        self.changed_paths.update(getattr(cp, 'changed_paths', []))
        if any(len(s.encode()) > request['output_bytes'] for s in (cp.stdout, cp.stderr)):
            raise AgentSystemError('Tool output overflow')
        self.secrets.reject(cp.stdout + cp.stderr)
        self.completed_calls += 1
        if cp.returncode == 0 and not request['read_only']:
            self.successful_write_paths.update(getattr(cp, 'changed_paths', []))
        return {'returncode': cp.returncode, 'stdout': cp.stdout, 'stderr': cp.stderr}

    def close(self):
        self.closed = True


def require_credit_attestation(store, binding, client_id=None):
    """Operator attestation is a requirement, not account-setting enforcement."""
    value = store.verify('no-credits/' + binding.execution_id)
    if (value.get('credits_fallback_disabled') is not True or value.get('execution_id') != binding.execution_id
            or not isinstance(value.get('operator'), str) or not value['operator']
            or (client_id is not None and value.get('client_id') != client_id)
            or type(value.get('attested_at')) not in (float, int)
            or not 0 <= time.time() - value['attested_at'] <= 86400):
        raise AgentSystemError('Fresh operator no-credit attestation required')


class PlanUpstream:
    """Only fixed SIWC inference URL. Never used by local synthetic validation."""
    def __init__(self, credential_store, policy, live_approval_store, admission_check, cancel_event=None):
        self.store, self.policy, self.approvals, self.admission = credential_store, policy, live_approval_store, admission_check
        initial = self.store.read('credentials.json')
        self.generation = hashlib.sha256(initial['access_token'].encode()).hexdigest() if initial else None
        self.cancel_event, self.last_response_metadata = cancel_event, {}
        self.response_metadata_history = []
    def __repr__(self):
        return 'PlanUpstream(<trusted>)'
    def __call__(self, body):
        self.last_response_metadata = {}
        try:
            return self._call(body)
        finally:
            self.response_metadata_history = (self.response_metadata_history + [self.last_response_metadata])[-self.policy.max_requests:]

    def _call(self, body):
        # Explicit Stage19 authorization is independently required per execution.
        self.admission()
        value = self.store.read('credentials.json')
        if not value or PLAN_SCOPE not in value.get('scopes', []) or time.time() >= value['expires_at']:
            raise AgentSystemError('Connected, unexpired plan credentials required')
        require_credit_attestation(self.approvals, self.policy.binding, value['client_id'])
        approved = self.approvals.verify('live-smoke/' + self.policy.binding.execution_id)
        if approved != {'authorized': True, **self.policy.identity(), 'model': self.policy.binding.model,
                        'reasoning': self.policy.binding.reasoning, 'route': UPSTREAM}:
            raise AgentSystemError('Explicit live inference authorization required')
        generation = hashlib.sha256(value['access_token'].encode()).hexdigest()
        if self.generation is not None and generation != self.generation:
            raise AgentSystemError('OAuth changed: restart with a fresh bound Codex session')
        self.generation = generation
        request = Request(UPSTREAM, data=json.dumps(body).encode(), method='POST', headers={
            'Authorization': 'Bearer ' + value['access_token'], 'Content-Type': 'application/json', 'Accept': 'text/event-stream'})
        try:
            remaining = self.policy.deadline - time.monotonic()
            if remaining <= 0 or (self.cancel_event is not None and self.cancel_event.is_set()):
                raise AgentSystemError('Expired or cancelled model execution')
            with build_opener(ProxyHandler({}), NoRedirect()).open(request, timeout=min(15, remaining)) as response:
                from .responses_http import read_bounded_response, mime_category
                self.last_response_metadata = {'validation_passed': False, 'mime_category': 'rejected_headers'}
                category = mime_category(response.headers)
                self.last_response_metadata['mime_category'] = category
                raw, category = read_bounded_response(response, self.policy, self.cancel_event, self.last_response_metadata)
            filter_ = SecretFilter([value['access_token'], value['refresh_token'], value['id_token']])
            validator = ResponsesGate(self.policy, filter_)
            try:
                validator.inspect_response(raw)  # validates fully without publishing any authority
            finally:
                self.last_response_metadata = {**self.last_response_metadata, **validator.last_response_metadata, 'mime_category': category,
                    'missing_mime_tolerated': category != 'event_stream' and validator.last_response_metadata.get('validation_passed', False)}
                if category != 'event_stream' and validator.last_response_metadata.get('validation_passed'):
                    from .responses_lifecycle import record_anomaly
                    record_anomaly(self.last_response_metadata, 'nonstandard_or_absent_mime', scope='request',
                                   executable=bool(validator.last_response_metadata.get('function_call_count')))
            return raw
        except HTTPError as error:
            from .responses_http import capture_http_error
            filter_ = SecretFilter([value['access_token'], value['refresh_token'], value['id_token']])
            self.last_response_metadata = {'validation_passed': False,
                'http_error': capture_http_error(error, self.policy, filter_, self.cancel_event)}
            raise AgentSystemError('Plan request failed; no billing fallback') from None
        except (URLError, OSError, UnicodeDecodeError):
            raise AgentSystemError('Plan request failed; no billing fallback') from None


class LocalModelRelay:
    """Ephemeral loopback HTTP route for trusted Codex only; roles have no socket.

    Channel credential is not an OpenAI token. One serialized request at a time.
    Entire upstream SSE is gated before any output is released.
    """
    def __init__(self, gate, upstream):
        self.gate, self.upstream = gate, upstream
        self._channel = secrets.token_urlsafe(48)
        self.server, self.thread = None, None
        self.failures = []
        self.failure_receipts = []
    def __repr__(self):
        return 'LocalModelRelay(<private>)'
    def __enter__(self):
        relay = self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args): pass
            def do_POST(self):
                self.connection.settimeout(5)
                layer = 'relay_or_session_failure'
                try:
                    if (self.path != '/v1/responses' or self.headers.get_all('Authorization') != ['Bearer ' + relay._channel]
                            or self.headers.get('Transfer-Encoding') is not None
                            or len(self.headers.get_all('Content-Length', [])) != 1):
                        raise AgentSystemError('Unauthorized relay route')
                    length = int(self.headers['Content-Length'])
                    if not 1 <= length <= relay.gate.policy.max_request_bytes:
                        raise AgentSystemError('Relay input limit exceeded')
                    raw = self.rfile.read(length)
                    if len(raw) != length: raise AgentSystemError('Partial relay request')
                    layer = 'model_request_failure'
                    body = relay.gate.request(raw)
                    data = relay.upstream(body)
                    layer = 'response_validation_failure'
                    data = relay.gate.response(data)
                    layer = 'relay_or_session_failure'
                    self.send_response(200)
                    self.send_header('Content-Type', 'text/event-stream')
                    self.send_header('Content-Length', str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                except Exception as error:
                    # Do not serialize request, credential, upstream prose or capture.
                    receipt = safe_failure(error, layer, getattr(relay.upstream, 'last_response_metadata', {})
                        if layer == 'model_request_failure' else None)
                    relay.failure_receipts.append(receipt)
                    relay.failures.append(receipt['detail'])
                    relay.gate.close()
                    self.send_error(403, 'Model transport denied')
            def do_GET(self): self.send_error(405)
        self.server = HTTPServer(('127.0.0.1', 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        return self
    @property
    def url(self):
        return 'http://127.0.0.1:' + str(self.server.server_port) + '/v1'
    def child_channel(self):
        return self._channel
    def __exit__(self, *args):
        self.gate.close()
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=5)
        if self.thread.is_alive(): raise AgentSystemError('Relay shutdown unconfirmed')
        self._channel = ''
