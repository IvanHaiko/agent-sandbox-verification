"""Stage 18 protocol boundary. No host process or authentication fallback.

This module prepares/validates Codex exec traffic; it does not grant live
admission. Docker's measured offline boundary remains unchanged.
"""
from dataclasses import dataclass, field
from datetime import datetime
import json
import re

from jsonschema import Draft202012Validator

from .errors import AgentSystemError
from .telemetry import TOKEN_FIELDS
from .task import validate
from .runners.base import AgentResult


def strict_json(text):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('duplicate key')
            result[key] = value
        return result
    def invalid(value):
        raise ValueError('nonfinite number')
    try:
        return json.loads(text, object_pairs_hook=pairs, parse_constant=invalid)
    except (ValueError, TypeError, RecursionError) as exc:
        # Never echo untrusted JSON or validator messages containing secrets.
        raise AgentSystemError('Malformed transport JSON') from None


@dataclass(repr=False)
class CredentialLease:
    """Explicit invocation-private value, never discovered from host login state.

    A lease does not make a reusable API key scoped or protect it from a process
    running under the same UID. Live injection therefore remains unimplemented.
    """
    execution_id: str
    role: str
    _value: str = field(repr=False)
    _closed: bool = field(default=False, repr=False)

    def __post_init__(self):
        if not self.execution_id or not self.role or not isinstance(self._value, str) or len(self._value) < 16:
            raise AgentSystemError('Invalid credential lease')

    def __repr__(self):
        return 'CredentialLease(<redacted>)'

    def redact(self, text):
        if self._closed:
            raise AgentSystemError('Credential lease closed; cannot safely redact')
        # Include common serialized forms. This is not an arbitrary encoding DLP.
        values = {self._value, json.dumps(self._value)[1:-1]}
        for value in sorted(values, key=len, reverse=True):
            text = text.replace(value, '[REDACTED]')
        return text

    def require_owner(self, execution_id, role):
        if self._closed or (execution_id, role) != (self.execution_id, self.role):
            raise AgentSystemError('Credential lease owner mismatch or closed')

    def close(self):
        # Python strings cannot promise cryptographic memory erasure.
        self._value, self._closed = '', True


@dataclass(frozen=True)
class InvocationBinding:
    execution_id: str
    role: str
    task_id: str
    contract_version: int
    model: str
    reasoning: str

    def __post_init__(self):
        if any(not isinstance(value, str) or not value or '\0' in value
               for key, value in vars(self).items() if key != 'contract_version'):
            raise AgentSystemError('Invalid transport binding')
        if type(self.contract_version) is not int or self.contract_version < 1:
            raise AgentSystemError('Invalid contract version')
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,63}', self.task_id):
            raise AgentSystemError('Invalid transport task ID')


class BoundedStreams:
    """Incremental byte limits enforced before decoding/redaction.

    Feed arbitrary pipe chunks. A capture failure is terminal; callers must
    cancel the isolated process and confirm cleanup, not use partial output.
    """
    NAMES = ('protocol', 'stderr', 'tool_logs')

    def __init__(self, limit_bytes=1024 * 1024):
        if type(limit_bytes) is not int or not 1 <= limit_bytes <= 16 * 1024 * 1024:
            raise AgentSystemError('Invalid stream limit')
        self.limit = limit_bytes
        self.buffers = {name: bytearray() for name in self.NAMES}
        self.failure = None

    def feed(self, name, chunk):
        if self.failure or name not in self.buffers or not isinstance(chunk, bytes):
            self.failure = self.failure or 'invalid_stream'
            raise AgentSystemError('Transport capture failed')
        if len(self.buffers[name]) + len(chunk) > self.limit:
            self.failure = 'output_overflow'
            raise AgentSystemError('Transport stream limit exceeded')
        self.buffers[name].extend(chunk)

    def abort(self, kind):
        if kind not in ('timeout', 'cancelled', 'process_crash'):
            raise AgentSystemError('Invalid transport abort')
        self.failure = self.failure or kind

    def diagnostics(self, lease=None):
        # Redact after reassembly so split secrets cannot evade the filter.
        result = {name: bytes(value).decode('utf-8', 'replace')
                  for name, value in self.buffers.items()}
        if not lease:
            return result
        result = {name: lease.redact(value) for name, value in result.items()}
        # Normalize valid protocol JSON before redacting, so escaped characters
        # cannot leak a known value through otherwise ordinary JSON serialization.
        lines = []
        for line in result['protocol'].splitlines():
            try:
                line = json.dumps(strict_json(line), ensure_ascii=False)
            except AgentSystemError:
                pass
            lines.append(lease.redact(line))
        result['protocol'] = '\n'.join(lines)
        return result


class CodexCliAdapter:
    """Strict single-turn exec decoder; Controller remains authoritative.

    Events, stderr, tool logs and the final JSON artifact are distinct channels.
    The backend-reported model is unavailable unless explicitly reported.
    """
    version = 1

    def __init__(self, binding, result_schema):
        self.binding = binding
        Draft202012Validator.check_schema(result_schema)
        self.validator = Draft202012Validator(result_schema)

    def command(self, schema_path='/role/tmp/result.schema.json', writable=False):
        if schema_path != '/role/tmp/result.schema.json':
            raise AgentSystemError('Schema must be in private role tmpfs')
        return ['codex', 'exec', '--ignore-user-config', '--ignore-rules', '--ephemeral',
                '--json', '--color', 'never', '--model', self.binding.model,
                '--sandbox', 'workspace-write' if writable else 'read-only',
                '-c', 'model_reasoning_effort=' + json.dumps(self.binding.reasoning),
                '-c', 'cli_auth_credentials_store="ephemeral"',
                '-c', 'shell_environment_policy.inherit="none"',
                '--output-schema', schema_path, '--output-last-message', '/role/tmp/result.json', '-']

    def decode(self, capture, final_bytes, returncode, started_at, finished_at, lease=None):
        if lease:
            lease.require_owner(self.binding.execution_id, self.binding.role)
        diagnostics = capture.diagnostics(lease)
        if capture.failure:
            raise AgentSystemError('Transport failed: ' + capture.failure)
        if type(returncode) is not int or returncode != 0:
            raise AgentSystemError('Agent process did not exit successfully')
        if not isinstance(final_bytes, bytes) or len(final_bytes) > capture.limit:
            raise AgentSystemError('Final artifact missing or oversized')
        try:
            protocol = bytes(capture.buffers['protocol']).decode('utf-8', 'strict')
            final_text = final_bytes.decode('utf-8', 'strict')
        except UnicodeDecodeError:
            raise AgentSystemError('Invalid transport UTF-8') from None
        events = []
        for line in protocol.splitlines():
            if not line:
                raise AgentSystemError('Unexpected blank protocol line')
            event = strict_json(line)
            if not isinstance(event, dict) or not isinstance(event.get('type'), str):
                raise AgentSystemError('Event type missing')
            if event['type'] not in ('thread.started', 'turn.started', 'item.started',
                                     'item.updated', 'item.completed', 'turn.completed'):
                raise AgentSystemError('Unsupported or failure protocol event')
            events.append(event)
        kinds = [event['type'] for event in events]
        if (len(events) < 4 or kinds[:2] != ['thread.started', 'turn.started']
                or kinds[-1] != 'turn.completed' or kinds.count('thread.started') != 1
                or kinds.count('turn.started') != 1 or kinds.count('turn.completed') != 1):
            raise AgentSystemError('Incomplete or ambiguous single-turn protocol')
        messages = [event['item'].get('text') for event in events
                    if event['type'] == 'item.completed' and isinstance(event.get('item'), dict)
                    and event['item'].get('type') == 'agent_message']
        if not messages or not isinstance(messages[-1], str):
            raise AgentSystemError('Final agent message missing')
        result = strict_json(final_text)
        if strict_json(messages[-1]) != result:
            raise AgentSystemError('Final artifact differs from protocol result')
        if next(self.validator.iter_errors(result), None) is not None:
            raise AgentSystemError('Role result schema mismatch')
        if isinstance(result, dict) and any(result[key] != value for key, value in vars(self.binding).items()
                                          if key in result):
            raise AgentSystemError('Role result invocation identity mismatch')
        canonical = json.dumps(result, ensure_ascii=False)
        if lease and (lease.redact(final_text) != final_text or lease.redact(canonical) != canonical):
            raise AgentSystemError('Credential leakage in role result')
        usage = dict.fromkeys(TOKEN_FIELDS)
        raw = events[-1].get('usage')
        if raw is not None:
            if not isinstance(raw, dict):
                raise AgentSystemError('Invalid backend usage')
            for key in TOKEN_FIELDS:
                value = raw.get(key)
                if value is not None and (type(value) is not int or value < 0):
                    raise AgentSystemError('Invalid backend usage')
                usage[key] = value
        try:
            start, end = (datetime.fromisoformat(value.replace('Z', '+00:00'))
                          for value in (started_at, finished_at))
            if start.tzinfo is None or end.tzinfo is None or end < start:
                raise ValueError()
        except (ValueError, TypeError, AttributeError):
            raise AgentSystemError('Invalid transport timestamps') from None
        envelope = {'protocol_version': self.version, **vars(self.binding), 'backend': 'codex_cli',
                    'reported_model': None, 'status': 'success', 'result': result,
                    'process': {'exit_code': returncode, 'tool_exit_codes': [event['item']['exit_code']
                        for event in events if event['type'] == 'item.completed'
                        and isinstance(event.get('item'), dict)
                        and type(event['item'].get('exit_code')) is int]},
                    'started_at': started_at, 'finished_at': finished_at, 'usage': usage, 'errors': []}
        return validate(envelope, 'transport_result'), diagnostics

    def require_live_admission(self, runner):
        # No bool flag can turn offline measurements into live verification.
        runner.isolation_capabilities().require()
        raise AgentSystemError('Live transport blocked: credential isolation and restricted model egress unverified')

    def agent_result(self, envelope, changed_paths):
        """Bridge to existing AgentRunner without making prose authoritative.

        changed_paths must come from the runner's measured snapshot diff, not
        from a model assertion. This method does not export files or grant gates.
        """
        try:
            validate(envelope, 'transport_result')
        except AgentSystemError:
            raise AgentSystemError('Invalid transport envelope') from None
        if any(envelope.get(key) != value for key, value in vars(self.binding).items()):
            raise AgentSystemError('Transport envelope invocation identity mismatch')
        if next(self.validator.iter_errors(envelope['result']), None) is not None:
            raise AgentSystemError('Role result schema mismatch')
        if any(envelope['result'][key] != value for key, value in vars(self.binding).items()
               if key in envelope['result']):
            raise AgentSystemError('Role result invocation identity mismatch')
        result = AgentResult(self.binding.execution_id, self.binding.task_id, self.binding.role,
                             'success', self.binding.model, self.binding.reasoning, 0,
                             envelope['process']['exit_code'], json.dumps(envelope['result']), list(changed_paths))
        result.to_dict()
        return result
