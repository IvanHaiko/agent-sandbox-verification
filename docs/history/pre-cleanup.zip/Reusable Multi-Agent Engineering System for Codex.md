# Reusable Multi-Agent Engineering System for Codex

**Status:** Approved architecture / ready for implementation  
**Initial project:** Open Model Lifecycle  
**Design goal:** reusable framework with project-specific configuration  
**Primary priorities:** correctness, context isolation, independent verification, architectural control, reproducibility, bounded model usage

---

# 1. Purpose

Implement a reusable multi-agent software-engineering workflow in which independent agents perform implementation, testing, review and, where appropriate, data auditing.

The system must improve reliability by separating:

- problem decomposition;
- implementation;
- independent test design;
- code review;
- data-semantic validation;
- architectural approval.

The system must not rely on one long shared conversation context.

Persistent project state must live primarily in repository documents and machine-readable task contracts. Agent conversations are runtime artifacts only.

The first production pilot will be the **Open Model Lifecycle** repository, but the core system must be reusable for other software/data-engineering projects without redesigning the framework.

---

# 2. Core principles

The implementation MUST follow these principles.

## 2.1 Context isolation

Different agents must operate with separate working contexts.

An agent must receive only the information required for its role.

The system must explicitly prevent unnecessary reasoning/context leakage between Implementer and Independent Test Engineer.

## 2.2 Independent verification

The agent implementing production code must not be the sole author of the criteria used to verify its correctness.

The Implementer may and should write implementation-level unit tests.

Independent acceptance, regression and adversarial tests must be designed by a separate Test Engineer.

## 2.3 Architecture requires human approval

**STRICT RULE: no architectural change may be implemented without explicit user approval.**

When an architectural issue is encountered, work must stop before implementation of that change.

The Orchestrator must present the user with:

1. the problem;
2. at least two viable options whenever more than one reasonable option exists;
3. advantages of each option;
4. disadvantages and risks of each option;
5. impact on the existing system;
6. migration/backward-compatibility implications where relevant;
7. the Orchestrator's recommendation.

Implementation may resume only after an explicit user decision.

Agents must never interpret silence, previous unrelated approvals or test success as architectural approval.

## 2.4 Raw agent conversations are ephemeral

Agent prompts, scratch notes, reasoning summaries, logs, temporary reports and inter-agent communication must remain local.

They must be stored under a gitignored runtime directory.

They must not be committed merely to preserve agent conversation history.

Only durable project artifacts should enter Git, such as:

- source code;
- tests;
- contracts;
- architecture documents;
- ADRs for explicitly approved architecture decisions;
- project state;
- final validation artifacts when they are part of the project's permanent audit trail.

## 2.5 Bounded autonomy

The system may autonomously implement and accept ordinary scoped engineering tasks.

Major phases and all architectural decisions require user approval.

Automatic correction loops are bounded to **two fix cycles**.

After the second failed fix cycle, the task must be escalated.

## 2.6 No infrastructure inflation

The multi-agent framework must remain lightweight.

Do not introduce queues, distributed workers, databases, cloud orchestration or similar infrastructure unless a concrete requirement emerges and the user explicitly approves the architectural change.

---

# 3. Initial agent topology

The system has five roles.

Four are standard roles.

The fifth is conditional.

```text
                        ┌─────────────────────┐
                        │    ORCHESTRATOR     │
                        │    / ARCHITECT      │
                        └──────────┬──────────┘
                                   │
                              task contract
                                   │
                    ┌──────────────┴──────────────┐
                    │                             │
                    ▼                             ▼
          ┌──────────────────┐          ┌──────────────────┐
          │   IMPLEMENTER    │          │ INDEPENDENT TEST │
          │                  │          │    ENGINEER       │
          └────────┬─────────┘          └────────┬─────────┘
                   │                             │
                   └──────────────┬──────────────┘
                                  ▼
                         integration candidate
                                  │
                                  ▼
                        ┌──────────────────┐
                        │     REVIEWER     │
                        └────────┬─────────┘
                                 │
                      if data-critical task
                                 │
                                 ▼
                        ┌──────────────────┐
                        │   DATA AUDITOR   │
                        └────────┬─────────┘
                                 │
                                 ▼
                           ORCHESTRATOR
                                 │
                    accept / fix / escalate
```

---

# 4. Agent responsibilities

## 4.1 Orchestrator / Architect

The Orchestrator owns workflow coordination.

It SHOULD NOT normally implement production code.

Responsibilities:

- interpret the task;
- read project state and relevant contracts;
- classify task type;
- detect potential architectural changes;
- create the task manifest;
- determine whether Data Auditor is required;
- provision isolated worktrees;
- launch role-specific agents;
- enforce information boundaries;
- integrate results;
- execute workflow gates;
- coordinate fix cycles;
- determine whether user completion approval is required;
- maintain runtime state;
- summarize final outcome.

The Orchestrator must not override Reviewer or Test Engineer findings merely because implementation tests pass.

The Orchestrator must not make architectural decisions on behalf of the user.

---

# 5. Architecture-change classification

The following must be treated as architectural changes unless the repository already contains an explicit approved contract authorizing them.

Examples include:

- changing the source of truth;
- changing persistent storage architecture;
- adding or removing a database;
- adding a cloud service;
- adding Kafka, Spark, Airflow or another major runtime component;
- changing deployment topology;
- changing dependency direction between major components;
- changing a public schema or public API contract;
- changing canonical data-model semantics;
- changing temporal semantics;
- changing identity-resolution semantics;
- changing migration strategy;
- introducing destructive migration behavior;
- changing security or permission boundaries;
- changing the multi-agent role topology;
- changing context-isolation rules;
- changing who may modify code;
- changing approval gates;
- changing durable orchestration topology.

The following are normally **not** architectural changes:

- refactoring inside an already approved component boundary;
- implementing an approved interface;
- fixing a bug without changing contract semantics;
- adding tests;
- adding logging;
- improving error messages;
- replacing one configured model with another while preserving the same agent role and workflow semantics;
- changing reasoning effort through model routing configuration;
- formatting or documentation corrections.

When uncertain, classify conservatively and request user approval.

---

# 6. Architecture Decision Gate

When an architectural change is detected, workflow state becomes:

```text
ARCHITECTURE_DECISION_REQUIRED
```

No agent may implement the architectural change while this state is active.

The Orchestrator must generate a local decision package:

```text
.agent_runs/<task-id>/architecture/
    proposal.md
    decision.json
```

Required content:

```yaml
decision_id: ARCH-<task-id>-001

problem: >
  Description of the architectural issue.

why_existing_architecture_is_insufficient: >
  Evidence.

options:
  - id: A
    description: ...
    advantages:
      - ...
    disadvantages:
      - ...
    migration_impact: ...
    compatibility_impact: ...

  - id: B
    description: ...
    advantages:
      - ...
    disadvantages:
      - ...
    migration_impact: ...
    compatibility_impact: ...

recommended_option: B

implementation_blocked: true
```

The system resumes only after explicit user selection.

If the approved decision permanently changes project architecture, a durable ADR should then be created or updated.

---

# 7. Implementer

The Implementer writes production code.

The Implementer receives:

- task objective;
- task contract;
- relevant architecture/contracts;
- project state;
- explicitly allowed files/modules;
- required invariants;
- acceptance criteria;
- existing relevant tests.

The Implementer must NOT receive:

- Test Engineer private reasoning;
- future independent acceptance tests before its first implementation is complete;
- Reviewer findings before review occurs;
- unrelated historical agent conversations.

Responsibilities:

- implement within scope;
- preserve existing contracts;
- write normal implementation-level unit tests;
- run relevant local checks;
- document any discovered ambiguity;
- stop if an architectural change becomes necessary.

The Implementer must never silently expand task scope.

---

# 8. Independent Test Engineer

The Test Engineer is intentionally isolated from implementation during its first phase.

## 8.1 Initial information

Before independent test design is frozen, it may receive:

- task contract;
- relevant public interfaces;
- architecture/contracts;
- existing regression requirements;
- fixture/data contracts;
- existing behavior that must remain compatible.

It must NOT initially receive:

- implementation diff;
- Implementer's reasoning;
- Implementer's notes explaining the chosen implementation;
- Implementer's newly written tests unless they are part of a pre-existing public test interface.

## 8.2 Responsibilities

The Test Engineer independently derives:

- acceptance tests;
- regression tests;
- adversarial tests;
- boundary conditions;
- failure cases;
- determinism tests;
- idempotency tests where relevant;
- compatibility tests;
- negative tests;
- invariants.

The initial independent test design must be persisted locally and hashed before implementation visibility is granted.

Example:

```text
.agent_runs/<task-id>/tester/
    initial_test_plan.md
    initial_test_plan.sha256
```

After the initial test suite/design is frozen, the Test Engineer MAY inspect implementation code to add additional white-box tests.

It must never weaken or rewrite an independently derived test solely to make the implementation pass unless the original test is proven inconsistent with the approved contract.

Such a change must be documented.

---

# 9. Reviewer

The Reviewer is read-only.

It must never modify production code or tests.

The Reviewer receives:

- approved task contract;
- integrated diff;
- relevant project contracts;
- independent tests;
- test results;
- static-analysis results.

It does not need Implementer reasoning.

The Reviewer must inspect at least:

- contract compliance;
- correctness;
- hidden assumptions;
- error handling;
- compatibility;
- determinism;
- idempotency where required;
- maintainability;
- test quality;
- whether tests accidentally mirror implementation;
- scope creep;
- architectural drift;
- unsafe migrations;
- security-impacting changes where relevant.

For data systems it must additionally consider:

- NULL semantics;
- duplicate handling;
- source provenance;
- timestamp meaning;
- row grain;
- data loss;
- ordering dependence;
- implicit type coercion;
- false absence;
- false zero values;
- destructive transformations.

Findings use severity:

```text
BLOCKER
MAJOR
MINOR
NIT
```

BLOCKER and MAJOR findings prevent task acceptance.

Reviewer output is a report, not a patch.

---

# 10. Data Auditor

Data Auditor is conditional.

It is required when a task is classified as **data-critical**.

Examples:

- schema migrations;
- historical data migration;
- temporal model changes;
- identity resolution;
- lifecycle event derivation;
- deduplication changes;
- backfills;
- source-of-truth transformations;
- data-quality logic;
- data reconciliation;
- derived analytical datasets whose semantics materially affect conclusions.

It is normally unnecessary for tasks such as:

- README changes;
- CLI wording;
- ordinary UI changes;
- isolated utility refactors;
- formatting.

Data Auditor is read-only.

Its primary responsibility is not Python style.

It evaluates whether generated data makes sense.

Checks may include:

- before/after row counts;
- cardinality;
- distributions;
- duplicate rates;
- NULL rates;
- key uniqueness;
- unexpected spikes;
- event counts;
- historical preservation;
- temporal consistency;
- provenance completeness;
- reconciliation against previous versions;
- impossible transitions;
- unexplained changes.

Example:

```text
Input observations: 28,959
Derived deployments: 7,091
PRICE_CHANGED events: 48,320
```

Even if tests pass, the Auditor should flag the event count as suspicious and require investigation.

---

# 11. Model routing

Model selection must be configuration-driven.

No role implementation may hard-code a model.

Initial pilot configuration:

```yaml
models:
  orchestrator:
    model: astra
    reasoning: medium

  implementer:
    model: sol
    reasoning: high

  test_engineer:
    model: sol
    reasoning: high

  reviewer:
    model: astra
    reasoning: medium

  data_auditor:
    model: astra
    reasoning: medium

  utility:
    model: luna
    reasoning: medium
```

This is a **pilot routing configuration**, not a permanent architecture requirement.

Changing:

```text
reviewer: Astra Medium
```

to:

```text
reviewer: Sol High
```

is considered a configuration change rather than an architectural change, provided role behavior and information boundaries remain unchanged.

Automatic escalation to more expensive reasoning/model tiers is forbidden unless explicitly enabled in configuration.

The system must not silently upgrade Medium → High or Sol → Astra.

---

# 12. Agent Runner abstraction

The framework must not depend on one specific Codex agent execution mechanism.

Define an abstraction conceptually similar to:

```python
class AgentRunner:
    def run(
        self,
        role,
        model_config,
        context_bundle,
        workspace,
        task_metadata,
    ) -> AgentResult:
        ...
```

Supported execution strategies may include:

```text
NativeSubagentRunner
IsolatedSessionRunner
```

Selection is configuration-based.

Preferred behavior:

1. use true isolated subagents when the environment supports the required isolation;
2. otherwise use separate isolated Codex executions/sessions.

A change in backend must not change task semantics.

---

# 13. Git isolation

Every code-producing role works in an isolated Git worktree.

Recommended branch structure:

```text
agent/<task-id>/implementer
agent/<task-id>/tester
agent/<task-id>/integration
agent/<task-id>/reviewer
agent/<task-id>/auditor
```

Reviewer and Auditor branches/worktrees are read-only from the framework's permission perspective.

Typical structure:

```text
.agent_worktrees/
    <task-id>/
        implementer/
        tester/
        integration/
        reviewer/
        auditor/
```

`.agent_worktrees/` must be ignored by Git.

Agents must never operate directly on the user's primary working tree.

---

# 14. Branch creation semantics

Implementer and Test Engineer branches must originate from the same base commit.

Conceptually:

```text
BASE
 ├── implementer
 └── tester
```

This prevents the tester from implicitly seeing implementation changes.

After both initial passes:

```text
BASE
 ├── implementer ───┐
 │                  ├── integration
 └── tester ────────┘
```

Integration must preserve both independent tests and implementation changes.

Conflicts must be resolved explicitly.

Tests must never be discarded merely because they conflict with implementation assumptions.

---

# 15. Runtime artifacts

All agent communication and execution records are local.

Default directory:

```text
.agent_runs/
```

It must be in `.gitignore`.

Example:

```text
.agent_runs/
    OML-0051/
        task.json

        orchestrator/
            context_manifest.json
            report.md

        implementer/
            prompt.md
            result.md
            commands.jsonl

        tester/
            initial_test_plan.md
            initial_test_plan.sha256
            result.md

        reviewer/
            findings.json
            report.md

        auditor/
            report.md

        telemetry/
            agents.jsonl
            task_summary.json

        architecture/
            proposal.md
            decision.json

        state.json
```

Do not commit this directory.

---

# 16. Persistent project context

Agents must not depend on previous chats as the canonical description of the project.

Projects using the system should provide durable context such as:

```text
docs/
    PROJECT_STATE.md

    contracts/
        ...

    adr/
        ...
```

For Open Model Lifecycle, `PROJECT_STATE.md` should summarize at least:

```text
Current architecture

Completed phases

Current invariants

Current dataset cutoff

Current schemas/contracts

Known limitations

Deferred decisions

Next approved phase
```

The Orchestrator reads this at the beginning of a task.

---

# 17. Project-specific configuration

Reusable behavior belongs in the framework.

Project-specific policy belongs in configuration.

Example:

```yaml
project:
  id: open-model-lifecycle

state_document:
  path: docs/PROJECT_STATE.md

contracts:
  roots:
    - docs/contracts
    - docs

architecture:
  adr_root: docs/adr
  require_user_approval: true

testing:
  commands:
    - python -m pytest -q
    - ruff check .

protected_paths:
  - data/raw
  - data/backfill
  - data/enrichment

data_critical_patterns:
  - temporal/**
  - silver/**
  - gold/**
  - collector/**
  - schemas/**

runtime:
  runs_dir: .agent_runs
  worktrees_dir: .agent_worktrees

git:
  allow_remote_push: false
```

The reusable framework must not contain Open Model Lifecycle-specific assumptions in its core logic.

---

# 18. Task manifest

Every task must have an explicit task manifest.

Conceptual schema:

```yaml
task_id: OML-0051

title: Implement lifecycle event engine v1

objective: >
  Derive approved deterministic lifecycle events from temporal
  deployment observations and identity history.

task_type: feature

base_ref: main

major_phase: true
data_critical: true

scope:
  allowed_paths:
    - temporal/events.py
    - temporal/__main__.py
    - tests/test_temporal_events.py
    - docs/temporal_lifecycle_events.md

  forbidden_paths:
    - data/raw/**
    - data/backfill/**
    - data/enrichment/**

invariants:
  - historical raw bytes must not change
  - event IDs must be deterministic
  - recorded_at must not affect event identity
  - UNKNOWN must not become ABSENT_CONFIRMED
  - canonical_model_id may remain null

enabled_event_types:
  - PROVIDER_LISTED
  - PRICE_CHANGED
  - CONTEXT_CHANGED
  - CAPABILITY_CHANGED
  - HF_IDENTITY_LINKED
  - HF_IDENTITY_REVISED

explicitly_deferred:
  - PROVIDER_DELISTED
  - MODEL_REAPPEARED
  - PROVIDER_ID_CHANGED

acceptance_criteria:
  - identical replay produces identical event identities
  - unchanged observations produce no change event
  - one price transition produces exactly one event
  - implementation does not alter historical archive
  - all existing tests pass

required_checks:
  - pytest
  - ruff
  - independent_tests
  - reviewer
  - data_auditor

architecture_change_allowed: false

completion:
  requires_user_approval: true
```

The manifest becomes the primary shared contract between agents.

---

# 19. Path enforcement

Allowed and forbidden paths must be mechanically checked.

After each code-producing agent finishes:

```text
git diff --name-only <base>
```

must be compared against its path policy.

Unexpected production-file modification is a failure.

Test Engineer normally receives write permission only to approved test/fixture paths.

Reviewer and Auditor receive no write permission to tracked project files.

---

# 20. Task state machine

The orchestration state machine should approximately follow:

```text
NEW
 ↓
CLASSIFY
 ↓
CONTRACT_READY
 ↓
ARCHITECTURE_CHECK
 │
 ├── architectural issue
 │       ↓
 │   ARCHITECTURE_DECISION_REQUIRED
 │       ↓
 │   USER_APPROVED
 │
 ↓
WORKTREES_READY
 ↓
┌─────────────────────────────┐
│                             │
IMPLEMENTATION          INDEPENDENT_TEST_DESIGN
│                             │
└──────────────┬──────────────┘
               ↓
          INTEGRATION
               ↓
          TEST_GATES
               ↓
            REVIEW
               ↓
        DATA_AUDIT? ── no ──┐
               │             │
              yes            │
               ↓             │
          DATA_AUDIT         │
               └──────┬──────┘
                      ↓
                GATE_DECISION
                 │          │
                pass       fail
                 │          │
                 │       FIX_CYCLE
                 │          │
                 │       max 2
                 │          │
                 │       RETEST
                 │          │
                 │       REREVIEW
                 │
                 ↓
         COMPLETION_CANDIDATE
                 │
         major phase?
            │         │
           yes       no
            │         │
 USER_COMPLETION     AUTO_ACCEPT
      APPROVAL
```

---

# 21. Fix-cycle rules

Maximum autonomous fix cycles:

```text
2
```

A fix cycle consists of:

```text
findings
→ Implementer correction
→ independent tests
→ regression tests
→ Reviewer repeat
→ Auditor repeat when applicable
```

After two unsuccessful cycles:

```text
ESCALATED
```

The Orchestrator must stop attempting autonomous fixes.

Escalation report must summarize:

- unresolved issue;
- attempted fixes;
- current failing tests;
- Reviewer findings;
- Data Auditor findings where applicable;
- whether specification ambiguity exists;
- recommended next action.

---

# 22. Major-phase approval

Small tasks may be automatically accepted when all gates pass.

Major project phases require explicit user approval.

The task manifest contains:

```yaml
major_phase: true
```

or:

```yaml
completion:
  requires_user_approval: true
```

Examples likely to be major phases:

- new temporal model;
- identity layer;
- lifecycle event engine;
- migration framework;
- storage redesign;
- new provider integration architecture;
- major cloud deployment change.

A phase being green does not imply user approval.

---

# 23. Reviewer gate

Acceptance requires:

```text
BLOCKER = 0
MAJOR   = 0
```

MINOR findings may be:

- fixed;
- accepted as technical debt;
- deferred with documented rationale.

The Orchestrator may not downgrade Reviewer severity solely to pass the task.

Disagreement should be surfaced explicitly.

---

# 24. Test gate

At minimum:

```text
existing regression suite passes
+
Implementer unit tests pass
+
Independent Test Engineer tests pass
+
configured lint/static checks pass
```

No agent may delete or skip failing existing tests to achieve green status unless the approved specification explicitly requires updating that behavior.

---

# 25. Data audit gate

For data-critical changes the audit report must explicitly state:

```text
PASS
PASS_WITH_WARNINGS
FAIL
```

`FAIL` blocks acceptance.

Minimum audit content should include appropriate subsets of:

```text
source row count
output row count
key cardinality
duplicates
NULL counts
unexpected distributions
historical preservation
reconciliation
event counts
temporal anomalies
provenance coverage
```

Thresholds may be project-specific.

---

# 26. Information-flow restrictions

The framework must enforce these boundaries.

## Implementer cannot initially see

- independent test design;
- tester reasoning;
- reviewer future findings.

## Test Engineer cannot initially see

- implementation diff;
- implementer reasoning;
- implementer private notes.

## Reviewer sees

- final/integration diff;
- contract;
- all tests;
- test output;
- relevant architecture.

It does not need private agent conversations.

## Data Auditor sees

- contract;
- data semantics;
- generated validation artifacts;
- relevant before/after data;
- relevant implementation where necessary.

## Orchestrator sees

all reports necessary to coordinate the workflow.

---

# 27. Context bundles

Each invocation must receive an explicit context manifest.

Example:

```json
{
  "role": "test_engineer",
  "task_id": "OML-0051",
  "files": [
    "docs/PROJECT_STATE.md",
    "docs/temporal_identity_history.md",
    ".agent_runs/OML-0051/task.json"
  ],
  "implementation_visible": false,
  "agent_history_visible": false
}
```

This allows later auditing of what information an agent actually received.

Do not pass entire repositories or entire historical conversations when a narrower context is sufficient.

---

# 28. Usage telemetry

The pilot must measure cost/usage per task.

For every agent invocation record when available:

```text
role
model
reasoning effort
start time
finish time
wall-clock duration
input tokens
output tokens
cached tokens
tool calls
commands executed
result
retry number
```

Per-task summary:

```text
number of agent invocations
number of Astra invocations
number of Sol invocations
number of Luna invocations
total known tokens
number of fix cycles
test failures caught independently
review findings
data-audit findings
final status
```

If Codex exposes five-hour quota consumption programmatically, record it.

If not, support optional manually supplied:

```yaml
quota_before: ...
quota_after: ...
```

Do not fabricate quota consumption from token counts.

---

# 29. Pilot evaluation metrics

After approximately 5–10 representative tasks, evaluate:

```text
quality
quota consumption
latency
number of independent defects caught
number of Reviewer defects caught
number of Auditor anomalies caught
fix-cycle rate
false-positive findings
tasks requiring escalation
```

Model routing may then be tuned.

Possible later changes include:

```text
Reviewer:
Astra Medium → Sol High

Data Auditor:
Astra Medium → Sol High

Tester:
Sol High → Astra Medium
```

These are configuration changes, not architecture changes, unless role behavior also changes.

---

# 30. Command execution policy

Agents must not be given unrestricted destructive Git behavior.

At minimum prohibit autonomous use of:

```text
git push --force
git reset --hard on user branches
git clean -fd outside isolated worktrees
history rewriting
deleting protected data
overwriting protected baselines
```

Normal commands may include:

```text
git status
git diff
git log
pytest
ruff
project-specific validation commands
```

Remote push should be disabled by default.

The framework should produce a merge-ready result locally rather than autonomously publishing remote changes.

---

# 31. Failure handling

The system must handle at least:

## Agent execution failure

Retry according to runner policy.

Do not count infrastructure failure as a code fix cycle.

## Test failure

Route back to Implementer.

## Reviewer BLOCKER/MAJOR

Route back to Implementer.

## Data Auditor failure

Route back to Implementer unless it indicates an architectural/data-contract problem.

If architecture semantics are implicated, trigger architecture approval workflow.

## Worktree conflict

Stop integration and report conflict.

Do not discard one side automatically.

## Contract ambiguity

Escalate to Orchestrator.

If it affects architecture or semantics, escalate to user.

## Agent attempts forbidden modification

Reject the agent result and report policy violation.

---

# 32. Resume and reproducibility

A task run must have durable local state sufficient to resume after interruption.

Example:

```json
{
  "task_id": "OML-0051",
  "state": "REVIEW",
  "base_commit": "...",
  "implementation_commit": "...",
  "tester_commit": "...",
  "integration_commit": "...",
  "fix_cycle": 0
}
```

Re-running orchestration must not blindly duplicate branches/worktrees or overwrite previous runtime reports.

Each agent invocation should receive a unique execution ID.

---

# 33. Framework layout

Recommended initial structure:

```text
agent_system/
    __init__.py
    cli.py
    orchestrator.py
    state_machine.py
    task.py
    policies.py
    git.py
    telemetry.py

    runners/
        base.py
        isolated_session.py
        native_subagent.py

    roles/
        orchestrator.py
        implementer.py
        test_engineer.py
        reviewer.py
        data_auditor.py

    schemas/
        task.schema.json
        agent_result.schema.json
        review.schema.json
        architecture_decision.schema.json

    prompts/
        orchestrator.md
        implementer.md
        test_engineer.md
        reviewer.md
        data_auditor.md

.agent_system/
    project.yaml
    models.yaml

.agent_runs/          # gitignored
.agent_worktrees/     # gitignored
```

Exact filenames may vary without constituting an architecture change, provided responsibilities remain the same.

---

# 34. CLI

Initial CLI should support conceptually:

```text
agentctl plan <task>
agentctl run <task>
agentctl status <task-id>
agentctl resume <task-id>
agentctl inspect <task-id>
agentctl cleanup <task-id>
```

Architecture workflow should additionally support either interactive approval or an explicit command such as:

```text
agentctl approve-architecture <task-id> <decision-id> --option B
```

Approval must be explicit and recorded in local task state.

The system must never synthesize its own approval.

---

# 35. Utility model

Luna or equivalent lower-cost model may be used for non-gating mechanical work such as:

- log summarization;
- changed-file classification;
- test-output extraction;
- telemetry summarization;
- formatting local reports.

Utility-agent output may not:

- approve architecture;
- approve tests;
- replace Reviewer;
- replace Data Auditor;
- make final correctness decisions.

---

# 36. Open Model Lifecycle pilot

The first pilot must run against Open Model Lifecycle.

Do not begin with a destructive or architecture-heavy change.

Recommended pilot progression:

## Pilot 1 — low-risk task

Use a small bounded feature/refactor.

Purpose:

- test runner;
- test worktree isolation;
- branch integration;
- Reviewer loop;
- telemetry;
- two-cycle enforcement.

No Data Auditor required.

## Pilot 2 — data-critical bounded task

Use a small deterministic data transformation.

Purpose:

- activate Data Auditor;
- test data metrics;
- verify immutable/protected-path enforcement.

## Pilot 3 — real lifecycle task

Use an approved lifecycle-event implementation slice.

Example scope:

```text
PROVIDER_LISTED
PRICE_CHANGED
CONTEXT_CHANGED
CAPABILITY_CHANGED
```

Do not automatically include delisting/reappearance unless their evidence policy has separately been approved.

---

# 37. Framework self-tests

The multi-agent framework itself must have tests.

At minimum test:

1. Implementer and Tester start from same base commit.
2. Tester cannot access implementation during initial independent design.
3. Reviewer cannot modify tracked files.
4. Data Auditor cannot modify tracked files.
5. forbidden path modification rejects an agent result.
6. architectural change stops implementation.
7. architecture workflow cannot continue without explicit approval.
8. approved architecture decision can resume the task.
9. two failed fix cycles cause escalation.
10. third autonomous fix cycle is impossible.
11. major phase cannot auto-complete.
12. ordinary green task can auto-complete.
13. Data Auditor runs only when required.
14. model routing comes from configuration.
15. changing model routing requires no framework code change.
16. `.agent_runs` remains untracked.
17. `.agent_worktrees` remains untracked.
18. interruption can resume from saved state.
19. existing task artifacts are not silently overwritten.
20. Reviewer BLOCKER prevents acceptance.
21. failing independent tests prevent acceptance.
22. architecture approval cannot be inferred from another task.
23. utility agent cannot act as a gating role.
24. agent path permissions are enforced after execution.

---

# 38. Acceptance criteria for framework v1

Framework v1 is complete when all of the following are demonstrated:

### Isolation

Implementer and Independent Test Engineer run in separate contexts and worktrees.

Test Engineer produces its initial tests without access to implementation.

### Workflow

A complete task successfully traverses:

```text
contract
→ implementation
→ independent testing
→ integration
→ review
→ acceptance
```

### Fix loop

A deliberately broken implementation is returned to Implementer and retested.

Maximum automatic fix count is enforced.

### Architecture gate

A synthetic architectural change causes workflow suspension.

The system presents multiple options with pros/cons.

No implementation proceeds until explicit approval is supplied.

### Data gate

A data-critical task invokes Data Auditor.

A deliberately suspicious output causes the Auditor to block acceptance.

### Git safety

No agent operates directly in the user's main worktree.

No remote push is performed.

No forbidden files are modified.

### Runtime privacy

Agent chatter remains local and ignored by Git.

### Model configurability

Role models and reasoning levels can be changed solely through configuration.

### Telemetry

A final task summary contains per-role model usage and execution statistics.

### Project portability

At least one project-specific configuration exists for Open Model Lifecycle without embedding Open Model Lifecycle-specific semantics into framework core code.

---

# 39. Explicit non-goals for v1

Do NOT implement unless later approved:

- web dashboard;
- cloud-hosted orchestrator;
- persistent SQL database for agent state;
- Kafka;
- distributed worker pool;
- vector database;
- agent memory service;
- automatic architecture approval;
- autonomous remote merging;
- autonomous force pushing;
- unlimited fix loops;
- agent-to-agent free-form group chat;
- automatic model escalation to expensive tiers;
- storing private chain-of-thought;
- committing raw agent conversation transcripts.

---

# 40. Implementation sequence

Implement incrementally.

### Stage 1 — contracts and configuration

Implement:

```text
task schema
project config
model routing
role definitions
runtime directories
gitignore
```

### Stage 2 — Git/worktree manager

Implement isolated branches/worktrees and cleanup/resume behavior.

### Stage 3 — Agent Runner interface

Implement runner abstraction and at least one working execution backend.

### Stage 4 — Orchestrator/state machine

Implement task lifecycle and local persisted state.

### Stage 5 — Implementer + independent Tester

Verify context isolation before proceeding.

### Stage 6 — integration + Reviewer

Implement immutable Reviewer findings and acceptance gates.

### Stage 7 — architecture decision gate

Implement mandatory human approval path.

This must be validated before using the framework for architecture-sensitive real tasks.

### Stage 8 — Data Auditor

Implement conditional data-critical gate.

### Stage 9 — telemetry

Collect model/task usage data.

### Stage 10 — Open Model Lifecycle pilot

Run representative tasks and generate evaluation summary.

---

# 41. Rule hierarchy

When instructions conflict, apply this precedence:

```text
1. explicit user architecture decision
2. approved ADR / project architecture contract
3. task contract
4. project invariants
5. role policy
6. project configuration
7. agent suggestion
```

No agent may override a higher-level rule.

---

# 42. Fundamental invariant

The purpose of the system is not to create more agents.

The purpose is to create **independent engineering checks with controlled information flow**.

A workflow in which several agents all receive the same reasoning, implementation assumptions and full conversation history does not satisfy this design.

The system must preserve genuine separation between:

```text
what must be built
how it was built
how it should be tested
whether the implementation is acceptable
whether the resulting data is credible
```

That separation is a core correctness requirement, not an optimization.