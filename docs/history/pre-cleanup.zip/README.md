# Codex multi-agent engineering — Stages 1–17

Stage 16 adds the opt-in `docker_isolated` backend and independent real OS probes.
See [operation and validation](docs/STAGE16_17_RUNBOOK.md) and the
[architecture decision](docs/STAGE16_ISOLATION_DECISION.md). Existing backend
selection and historical assessments are preserved; Docker requires explicit
configuration and successful evidence-based admission.
Current OS isolation assessment: [Stages 16–17](docs/STAGE16_17_ASSESSMENT.md).
Live agent authentication/transport/protocol remain unverified; no model calls
were made for these stages.

Source of truth: [Reusable Multi-Agent Engineering System for Codex](Reusable%20Multi-Agent%20Engineering%20System%20for%20Codex.md), especially section 40. The local workflow now includes invocation telemetry, deterministic evaluation, routing experiments and opt-in live validation/pilot machinery. Actual live validation is blocked by CLI authentication; the actual OML repository is unavailable. See [framework v1 acceptance](docs/FRAMEWORK_V1_ACCEPTANCE.md) for the distinction between implementation and live acceptance.

The framework uses Python 3.11+, Git, strict JSON Schemas, local JSON evidence and fresh Codex CLI executions. It has no database, queue, cloud service, dashboard or background worker. The framework never pushes or merges into the user's primary branch. An accepted result is a local integration branch ready for human inspection.

## Install and test

```powershell
python -m pip install -e ".[dev]"
python -m pytest -q
python -m agent_system --help
```

Tests use real temporary Git repositories and fake model processes. They execute real project/independent test commands, and consume no real model quota. In restricted environments, use a new unused directory inside the workspace:

```powershell
New-Item -ItemType Directory -Path .agent_runs -Force | Out-Null
python -m pytest -q --basetemp=.agent_runs/tests-new
```

Pytest clears an existing `--basetemp`; never point it at a valuable task run. `pyproject.toml` declares setuptools as a build dependency. This host's system Python does not currently have setuptools, so a wheel build has not been verified here.

Real invocations additionally need an installed/authenticated Codex CLI. Model identifiers are passed literally from `.agent_system/models.yaml`; the architecture document's pilot aliases are retained. Configure identifiers your installation accepts. Every role's model and reasoning level comes from the frozen routing configuration, with no silent escalation or fallback. The backend uses [non-interactive Codex execution](https://learn.chatgpt.com/docs/non-interactive-mode), rather than native Codex subagents.

## Task contracts and compatibility

The target must be an existing Git repository with at least one commit. This folder originally contained only the architecture document; the framework does not initialize or commit a user's repository for them. Worktrees contain committed baseline content, so uncommitted primary-tree edits are not copied into agent branches.

Put `.agent_system/project.yaml` and `models.yaml` in the target repository and ignore `.agent_runs/` and `.agent_worktrees/`. See [examples/workflow-task.yaml](examples/workflow-task.yaml) for a complete executable task contract. The example requires a repository containing `src/example.py` and `docs/contracts/answer.md`; it is not an OML pilot.

An explicit `workflow` block supplies:

- `public_context`: exact committed public interface/contract files available during independent design.
- `implementation_context`: exact additional files available after design, and to the Implementer.
- `test_paths`: patterns reserved for independently authored acceptance/regression tests. The Implementer cannot change these paths.
- `independent_command`: argv prefix accepting executable test selectors, such as `python -m pytest -q`.
- `checks`: named argv commands mapping all non-role `required_checks` to actual execution.
- `test_timeout_seconds`: the limit for each local test command.

Every check is executed as an argument vector without a shell. Project-level `testing.commands` remain supported and are parsed with shell-style quoting; use quoted forward-slash paths on Windows. Their commands also run against the integrated candidate. `independent_tests`, `reviewer` and conditional `data_auditor` are mandatory workflow gates, regardless of omission from the optional check-name list. A missing command mapping fails closed.

Version-1 tasks without `workflow` preserve preparation-only behavior and stop at `WORKTREES_READY`. Their contracts and runtime artifacts are not silently upgraded. To execute the full lifecycle, create a new task ID with an explicit workflow contract. Version-2 runs have strict persisted state, task/configuration digests and cycle history. Unsupported versions or mismatched identities produce explicit compatibility errors. There are no heuristic migrations.

## Lifecycle

```text
NEW -> CLASSIFY -> CONTRACT_READY -> ARCHITECTURE_CHECK
                                      |
                                      +-> ARCHITECTURE_DECISION_REQUIRED
                                      |       -> explicit selection -> ARCHITECTURE_APPROVED
                                      v
WORKTREES_READY -> TEST_DESIGN -> TEST_DESIGN_FROZEN
     -> IMPLEMENTING -> IMPLEMENTATION_READY
     -> TESTING (Tester phase B) -> INTEGRATING -> INTEGRATED
     -> EXECUTING_TESTS -> TESTS_PASSED / TESTS_FAILED
     -> REVIEWING -> REVIEW_PASSED / REVIEW_FAILED
     -> AUDITING -> AUDIT_PASSED / AUDIT_FAILED  [data-critical only]
     -> GATE_DECISION
          +-> COMPLETION_CANDIDATE -> ACCEPTED
          |                       -> USER_COMPLETION_APPROVAL -> explicit approval -> ACCEPTED
          +-> FIX_REQUIRED -> FIXING -> implementation/testing/review/audit again
          +-> ESCALATION_REQUIRED  [two unsuccessful fix cycles]
```

Policy, infrastructure and integration failures stop in `FAILED` with distinct `failure_kind` and evidence. Tests may fail while review/audit still gather actionable findings; acceptance remains blocked. `status` is read-only and exposes the current state, last role, fix count, architecture blocking state and test/review/audit status.

## Independent Tester and role boundaries

Implementer and Tester branches originate at the same frozen base commit. Tester phase A runs first, read-only, at that base, before implementation artifacts exist. Its manifest permits only explicit `public_context` files and recorded architecture selections. Implementation diff/result/notes, review output, private runtime paths and extra context keys are mechanically rejected. The structured design covers every acceptance criterion and is stored once with a SHA-256 digest.

The Implementer gets the task, frozen project configuration, permitted source/public context, role instructions and any recorded human selections. It does not receive the independent design or Tester invocation logs. It can write normal unit tests outside the reserved independent test paths.

Only after the design is frozen does Tester phase B fast-forward its own branch to the implementation candidate. It receives the authoritative frozen design and candidate source, and may add files only inside `test_paths`. Each independent case maps to an executable test selector. Implementation-discovered regressions have separate identifiers and reasons, and are executed separately. Original regression tests and candidate files cannot be rewritten by Tester. Later fixes retain the frozen independent suite rather than regenerating or weakening it.

Reviewer and Auditor each use an owned candidate worktree with a read-only Codex sandbox. Tracked changes, untracked/ignored file creation and Git-history changes reject their results. Framework-level checks also detect modifications to the primary checkout, other roles' workspaces, and configured protected data even when ignored by Git. Violations are retained as evidence and are not silently rolled back or retried.

These are manifest, provenance, ordering, sandbox and post-execution integrity guarantees. Git worktrees share repository metadata and the backend does **not** provide OS-level read isolation. A manifest prevents accidental forwarding of forbidden inputs; it cannot prove that an arbitrary process never read another accessible directory. Public context contents and configured local commands are operator-controlled inputs. The framework does not claim native subagent isolation or record private chain-of-thought.

## Integration and acceptance

The framework validates frozen task/configuration identity, branch ownership, expected heads, base ancestry, clean producer worktrees, allowed/forbidden/protected paths and test traceability. It commits approved producer changes locally, using a framework identity and disabled Git hooks. Integration is fast-forward only: producer history and independently authored tests are preserved, and divergence/conflicts stop with diagnostics rather than model-driven conflict resolution.

Every candidate runs the project regression commands, configured named checks, every independent selector and separately marked additional regressions. Evidence contains exact argv, exit status, timeout status, stdout/stderr and extracted failing pytest identifiers where available. A gate cannot pass just because an agent claims tests passed. Test commands that mutate tracked/untracked candidate files or protected data are rejected; ignored test caches are allowed in the integration checkout.

Reviewer reports use `BLOCKER`, `MAJOR`, `MINOR`, `NIT` with location, problem, impact, evidence and recommended correction. `BLOCKER` and `MAJOR` block acceptance. `MINOR`/`NIT` are retained with an explicit nonblocking policy, never silently downgraded.

Acceptance requires completed implementation, frozen independent design, integrated candidate, actually successful mandatory tests, passing review, a passing required audit, no policy violation and no unresolved architecture decision. Gate evidence must refer to the same candidate commit. Major phases and tasks marked `completion.requires_user_approval` stop at `USER_COMPLETION_APPROVAL` even when green.

## Architecture decisions

Architecture-sensitive task categories, public API/schema/storage/security/deployment changes and configured sensitive paths trigger a human gate. Detection is deliberately conservative and rule-based; it is not a semantic proof that every possible architecture issue has been found. Agents must additionally report newly encountered issues before changing files.

Optional project configuration under `architecture` can add `sensitive_paths` and `sensitive_categories`. A task may include `architecture.categories` and a fully structured `architecture.proposal`. If a sensitive task has no supplied proposal, the configured Orchestrator/Architect prepares one in its own read-only worktree. No Implementer call occurs while the decision is blocked.

The immutable package contains the question, architectural rationale, constraints, at least two alternatives, advantages/disadvantages, risks, migration/compatibility implications and recommendation. CLI inspection exposes the actual structured package. Human approval binds task ID, decision ID, package digest, option ID, approver and timestamp; nonexistent options, cross-task selections and mutation of an existing choice are rejected. Direct workflow backend calls also validate the persisted lifecycle and recorded selections.

```powershell
agentctl --project C:/repo architecture ENGINEERING-001
agentctl --project C:/repo approve-architecture ENGINEERING-001 ARCH-ENGINEERING-001 --option A --approved-by "Your name"
agentctl --project C:/repo resume ENGINEERING-001
```

Approval itself records the selection and advances to `ARCHITECTURE_APPROVED`; `resume` continues at the recorded lifecycle point. Scope and acceptance criteria stay frozen. Changing the task contract or an existing selection requires a new explicit workflow/task. A permanent architectural change should receive a durable ADR in an explicitly allowed path; the framework does not silently write ADRs outside the approved scope.

## Data audit and bounded repairs

Data-critical classification is frozen before execution from the task flag and project data-critical patterns. Auditor is mandatory for those tasks and absent from ordinary tasks. The Auditor examines relevant data semantics and evidence, with explicit checks, blocking findings and `PASS` / `PASS_WITH_WARNINGS` / `FAIL`. A failed check, blocking finding, unresolved architecture issue or `FAIL` verdict blocks acceptance. Audit failure shares the same repair budget as test/review failures.

The initial implementation is cycle 0. A transition from `FIX_REQUIRED` to `FIXING` increments the persisted counter; only cycles 1 and 2 are possible. The Implementer receives actionable failing-test evidence and review/audit findings, not private Tester invocation material. Tests, Reviewer and required Auditor run again on each repaired candidate. After the second unsuccessful cycle, `ESCALATION_REQUIRED` persists the unresolved evidence and recommended human action. Resume cannot start a third autonomous fix. Infrastructure retries remain bounded by runner configuration and never consume code-fix budget; contaminated invocations are not retried.

## CLI, evidence and resume

```powershell
agentctl --project C:/repo plan C:/repo/task.yaml
agentctl --project C:/repo run C:/repo/task.yaml
agentctl --project C:/repo status ENGINEERING-001
agentctl --project C:/repo inspect ENGINEERING-001
agentctl --project C:/repo resume ENGINEERING-001
agentctl --project C:/repo approve-completion ENGINEERING-001 --approved-by "Your name"
agentctl --project C:/repo cleanup ENGINEERING-001
```

`run` plans and advances until completion, a human gate or a terminal failure. Failed/escalated runs return a nonzero exit code. `plan` reusing an ID with changed contract/configuration fails; `resume` uses the frozen snapshot even if current valid configuration changes.

```text
.agent_runs/<task-id>/
    task.json / configuration.json / state.json / worktrees.json
    invocations/<execution-id>/        # raw local process artifacts
    cycles/<cycle>/roles/<phase>-r<n>/  # intent, execution, immutable complete report
    cycles/<cycle>/integration.json
    cycles/<cycle>/tests/              # command evidence and aggregate result
    cycles/<cycle>/decision.json
    tester/frozen_design.json / test_mapping.json
    architecture/<round>/decision.json / selection.json
    completion/selection.json
    escalation/report.json / failures/
.agent_worktrees/<task-id>/<role>/
```

Durable gate evidence uses write-once JSON envelopes with content digests. Resume checks digests and identities, reuses completed role outputs and recorded test results, and finishes interrupted Git fast-forwards/commits from recorded intent. If a backend finished and its invocation result exists, it can be recovered without another model call. If an interrupted invocation has no authoritative completed result, the run fails as `ambiguous_execution` instead of silently duplicating a model action. Filesystem digests detect accidental corruption; they are not tamper-proof against an operator who controls the filesystem.

Atomic state writes and an exclusive `.lock` serialize mutations. A killed process can leave a stale lock: verify the PID is no longer executing before manually removing only that lock. `status` never acquires a write lock or rewrites runtime files.

Cleanup preflights all recorded worktrees, refuses dirty/untracked/ignored files, removes only clean owned checkouts, and preserves branches, commits and all runtime evidence. Manually inspect disposable ignored caches before removing them. Resume can recreate cleaned worktrees from preserved branches. There is no force cleanup, branch deletion, remote merge or push.

## Telemetry, evaluation and live pilots

Every process attempt saves measured invocation telemetry bound to its context, result, routing, task, cycle and input commit. Optional usage remains null when absent; there is no estimated billing. Immutable aggregate/evaluation snapshots are rebuilt from lower-level evidence and finalized once. Old runs without telemetry stay readable and are never replayed for metrics.

```powershell
agentctl --project C:/repo metrics ENGINEERING-001
agentctl --project C:/repo telemetry ENGINEERING-001 --json
agentctl --project C:/repo evaluate ENGINEERING-001 --json
agentctl --project C:/repo pilot-report ENGINEERING-001 --json
agentctl --project C:/repo compare ENGINEERING-001 EXPERIMENT-B
agentctl --project C:/repo experiment-plan ENGINEERING-001 EXPERIMENT-B --models C:/repo/alternative-models.yaml
agentctl --project C:/repo resume EXPERIMENT-B
```

Inspection/comparison commands are read-only and never use models. Experiment preparation also makes no model calls: it freezes a new ordinary task with the original committed base and explicit alternate routing. Finish existing runs first, and execute experiments sequentially. JSON output can be redirected to an operator-chosen comparison artifact.

```powershell
agentctl --project C:/repo live-smoke --allow-live
agentctl --project C:/repo live-smoke --workflow --allow-live --runner-report C:/repo/.agent_runs/validations/RETURNED-RUNNER-ID
agentctl --project C:/repo pilot-preflight C:/repo/pilot-task.yaml
agentctl --project C:/repo pilot C:/repo/pilot-task.yaml --allow-live
agentctl --project C:/repo v1-status
```

Live commands announce real quota use and require `--allow-live`. Runner smoke uses one read-only invocation in a disposable Git repository; workflow smoke requires a successful matching runner report, then allows four role calls and no autonomous repairs. Neither modifies this framework's source repository. Every attempt retains JSON/Markdown evidence, including blocked prerequisites. `pilot-preflight` makes no model call. See [observability details](docs/OBSERVABILITY.md) and [OML adaptation instructions](examples/open-model-lifecycle/README.md).

The framework folder currently has no Git metadata. This does not prevent offline tests, `live-smoke` or `v1-status`; ordinary workflow commands must target a committed Git repository. The `.agent_system/models.yaml` aliases remain unverified rather than silently replaced. Adapt identifiers explicitly after authentication; help/config validation cannot prove model entitlement.


## Post-v1 hardening

Stages 11–15 add opt-in state-v3 controller hardening: external runtime storage,
private baseline Git repositories, verified isolation admission, signed approvals
and executable-test freezes, bounded test disputes, contract/interface approval,
actual-diff architecture and data gates, independent audit regeneration, and
Reviewer passes A/B. Legacy tasks and historical v1 acceptance remain unchanged.

See [hardening mechanisms and migration](docs/HARDENING.md),
[state machine](docs/HARDENED_STATE_MACHINE.md),
[runner capability matrix](docs/ISOLATION_CAPABILITIES.md), and
[hardening assessment](docs/HARDENING_ASSESSMENT.md).

The built-in `isolated_session` backend cannot meet required filesystem/controller
isolation, so hardened role execution fails closed before any model invocation.
Passing offline controller tests does not constitute live acceptance or authorize
an OML production pilot.

Stages 16–17 verified the configured Docker boundary offline; see
[the preserved assessment](docs/STAGE16_17_ASSESSMENT.md). Stage 18 adds an
offline structured Codex transport adapter and focused protocol tests, with live
execution still blocked by unverified credential isolation and model egress.
See [the credential/transport checkpoint](docs/STAGE18_CREDENTIAL_TRANSPORT.md)
and [master progress](MASTER_PROGRESS_ASSESSMENT.md). No live model acceptance
or workflow-tier calibration is claimed.

## Stage 18 ChatGPT-plan checkpoint

See [STAGE18_CHATGPT_PLAN_TRANSPORT.md](STAGE18_CHATGPT_PLAN_TRANSPORT.md) and
[machine-readable assessment](STAGE18_CHATGPT_PLAN_TRANSPORT.json) for the separate
official Sign in with ChatGPT investigation and implementation checkpoint.
The live transport remains blocked; framework model invocations remain zero.

## Stage 18c checkpoint

The trusted Codex/model-to-Docker tool boundary is documented in
[STAGE18C_MODEL_TOOL_BOUNDARY.md](STAGE18C_MODEL_TOOL_BOUNDARY.md), with a
[machine-readable assessment](STAGE18C_MODEL_TOOL_BOUNDARY.json). Engineering is
ready for a separately authorized live smoke; Stage 19 is not admitted and real
model calls remain zero. Earlier checkpoint documents remain historical records.
