# Stage19 HTTP 400 — offline request audit

Новых Responses requests, OAuth/model-catalog requests и credential reads не было. Stage19 остаётся `FAIL_LIVE_TRANSPORT`; Stage19 passed = false, Stage20 technically admissible = false. Stage20 не запускался.

**Точная причина 400 не установлена. Минимальный подтверждённый исходниками кандидат delta — `strict`: omitted → true при семи неизменённых const-only property schemas без `type`.** Это гипотеза о strict-schema compilation, а не доказанный серверный диагноз. Namespace сам по себе соответствует текущему контракту.

## Что удалось снять

Исторический `stage19-final-conformance-2` сделал один POST, получил HTTP 400 и выполнил ноль tools. `execution.json` сохранил `transport_structure: [{}]`. Ни точный request body, ни его hash, ни HTTP error code/param/body не сохранялись. Временный Codex home удалён. Получить exact historical sanitized JSON теперь невозможно.

Выполнен один **synthetic localhost replay** с закреплённым бинарником SHA256 `3b8f6e33caa75f232558a3cf76ff9b87bb5ef6dbcf4996372f24e55c78b1b916`, исходным Stage19d source bundle `255284b0d5d9f8c8de584ba68f2a24ac79500fdc29ab529c6b7ada5df014a544`, исходным prompt expression и вызовом exact consumed driver's `ExactGate.request`. Проверка полного source bundle выполнена до изменения transport-кода. Старый live entrypoint и его latch не вызывались.

Полный JSON локального запроса после gate: [conformance-2-postgate.sanitized.json](C:/Users/4ivan/codex-multi-agent/docs/stage19-request-audit-evidence/conformance-2-postgate.sanitized.json). До gate: [conformance-2-native.sanitized.json](C:/Users/4ivan/codex-multi-agent/docs/stage19-request-audit-evidence/conformance-2-native.sanitized.json). [Provenance](C:/Users/4ivan/codex-multi-agent/docs/stage19-request-audit-evidence/replay-provenance.json) явно отличает replay от исторического wire capture. Заменены client message IDs, значения client_metadata, cache key и путь нового disposable home; известные Controller argument constants сохранены. Это семантический JSON после sanitization, не исходные wire bytes. Время и окружение replay могут менять входной контекст. Synthetic completion не означает выполнение smoke.

## Проверка полей

[Машинный аудит](C:/Users/4ivan/codex-multi-agent/docs/stage19-request-audit-evidence/schema-audit.json) содержит 59 проверок. Это явно ограниченный documentation profile, а не полный официальный OpenAPI validator и не результат серверного admission. Проверено against [SIWC preview limitations](https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations), [Responses create](https://developers.openai.com/api/reference/typescript/resources/responses/methods/create) и generated-from-OpenAPI SDK declarations OpenAI.

| Поле | Локальный post-gate JSON | Вывод |
| --- | --- | --- |
| model | `gpt-6-sol` | Точный human amendment; доступность для данного account офлайн неизвестна |
| store / stream | false / true | Соответствуют HTTP SIWC |
| namespace | `{type,name,description,tools}` | `agentctl`; ровно одна вложенная function; документированная форма |
| tools | namespace → `agentctl_execute`, parameters, strict true | Hosted tools/tool_search/async/defer_loading отсутствуют; строгая schema требует отдельной проверки |
| tool_choice | `auto` | Документированное значение |
| parallel_tool_calls | false | Boolean, принудительно выставлен exact smoke gate |
| reasoning | `{effort:low, context:all_turns}` | Оба поля документированы; context не является неизвестным полем |
| text | `{verbosity:low}` | Документировано; format отсутствует/default text; strict AgentResult проверяется локально после финального ответа |
| include | `[reasoning.encrypted_content]` | Документированный stateless reasoning include; в первом input нет encrypted content |
| input | 6 message items: developer ×4, user ×2; content input_text/string | Нет system, audio/video, response history или native/hosted tool calls; client message `id` требует review |
| instructions | отсутствует | Инструкции представлены developer messages |
| previous_response_id и запрещённые SIWC top-level fields | отсутствуют | Gate allowlist не пропускает их |

Namespace проверен против [NamespaceToolParam](https://github.com/openai/openai-python/blob/main/src/openai/types/responses/namespace_tool_param.py). `reasoning.context="all_turns"` допускается [Reasoning](https://github.com/openai/openai-python/blob/main/src/openai/types/shared_params/reasoning.py); он также измерен в прежнем synthetic Codex 0.160 replay. `verbosity` допускается [ResponseTextConfigParam](https://github.com/openai/openai-python/blob/main/src/openai/types/responses/response_text_config_param.py). `include` описан в [ResponseCreateParams](https://github.com/openai/openai-python/blob/main/src/openai/types/responses/response_create_params.py).

Current app-server добавил `client_metadata` с семью ключами, `prompt_cache_key` и один developer `additional_tools` item. Gate удалил оба верхних поля и inventory item; native top-level `tools` отсутствовал, upstream namespace inventory полностью сформирован Controller. Остальные добавленные `reasoning.context`, `text.verbosity`, `include` и message IDs прошли gate. Он проверяет effort/основные route constraints, но не является полным nested Responses create validator.

**Два нерешённых schema вопроса:**

1. `execution_id`, `task_id`, `role`, `phase`, `contract_version`, `workspace_id`, `tool_type` имеют только `const`, без явного `type`. Generic Draft202012 schema валиден, все properties required, additionalProperties=false. Но совместимость const-only форм с provider strict subset не доказана. [Function calling strict mode](https://developers.openai.com/api/docs/guides/function-calling) различает explicit strict=true и omitted strict, при котором возможен fallback. [Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs) описывает ограниченный subset с typed properties. Само отсутствие `const` в списке документации не доказывает его запрет. Числовые/array bounds не объявлены запрещёнными; fine-tuned-only ограничения не применены к обычному model slug.
2. У всех шести messages есть client-generated `id`. Ни `Message`, ни `EasyInputMessage` в [ResponseInputParam](https://github.com/openai/openai-python/blob/main/src/openai/types/responses/response_input_param.py) / [EasyInputMessageParam](https://github.com/openai/openai-python/blob/main/src/openai/types/responses/easy_input_message_param.py) не объявляют это поле. Это undocumented extra-field candidate; неизвестно, игнорирует ли его сервер. Историческое наличие таких IDs не зафиксировано. Поэтому removal of input message IDs — отдельный кандидат, не доказанный delta относительно HTTP 200.

## Сравнение с последним HTTP 200

Последний сохранённый HTTP 200 — `stage19b-full-response-1`, [result.json](C:/Users/4ivan/codex-multi-agent/docs/stage19b-full-response-evidence/result.json). Hash реально отправленного request: `6a1e2669dcc14c9d2e99acd43ec1fec2b35009889ec869082343d7895c64b184`. Тело не сохранялось; по hash восстановить его нельзя. Тогда был получен полный SSE body, но response gate отказал на `Partial tool completion`; HTTP 200 не является успешным end-to-end smoke.

Бинарник SHA256 `4b01d5920e6785614727443bbecf343f4dedbb7347052b72ba805aab6353ef01` (Codex 0.160.0) по прежнему pinned path уже отсутствует. Новый replay того бинарника не выполнен. [Исторический source reconstruction](C:/Users/4ivan/codex-multi-agent/docs/stage19b-evidence/request-reconstruction.json) относится к более раннему Stage19 execution: его execution/workspace constants **не** выдаются за exact последний HTTP 200. Для последнего 200 использованы отдельно frozen-request driver source, binding и SHA256; old optional values остаются UNKNOWN.

| Delta | Последний HTTP 200: источник/предел знания | Новый 400: source-guaranteed / replay |
| --- | --- | --- |
| model | `gpt-6-astra`, actual record | `gpt-6-sol`, actual record |
| tools | Legacy gate authored flat function; no explicit strict | Namespace/function; explicit strict true |
| schema identity properties | Const-only; timeout bound 30 | Const-only; timeout bound 20; execution/workspace constants изменены |
| input inventory | Legacy gate preserved additional_tools if supplied | Удалён каждый additional_tools item |
| parallel_tool_calls | Exact value UNKNOWN | false, exact driver override |
| reasoning.context | Exact HTTP200 value UNKNOWN; old synthetic 0.160 replay = all_turns | New synthetic replay = all_turns |
| text/include/input IDs | Exact old values UNKNOWN | Measured new replay as above |
| prompt/home/binary | Original minimal prompt / old binary | Exact two-command prompt / new binary / different ephemeral home |

Наиболее узкий подтверждённый schema delta — одно поле `strict: true`. Оно **может** перевести прежнюю совместимую/нестрогую обработку той же const-only schema в отказ strict compiler. Это достаточный механизм гипотезы 400, но причинность без machine error metadata не установлена. Другой подтверждённый одно-полевой delta — model. SIWC требует account-specific доступный model; [documented unsupported capability](https://developers.openai.com/siwc/token-sharing-open-source/errors-and-recovery) может вернуть 400 в том числе для model/tool/input. Каталог для smoke не запрашивался; смена модели не выполнялась.

Предложен только offline [typed-const candidate](C:/Users/4ivan/codex-multi-agent/docs/stage19-request-audit-evidence/candidate-typed-const.sanitized.json): семь добавлений `type`, без изменения const, bounds, required и strict=true. Typed singleton enum — альтернативное документированное encoding, если provider const support окажется причиной. Ни candidate, ни удаление IDs, ни выключение strict не применены в production и не отправлены модели. Не подготовлен автоматический перебор вариантов.

## Structured HTTP error capture

Изменены только production [responses_http.py](C:/Users/4ivan/codex-multi-agent/agent_system/responses_http.py) и [model_tool_boundary.py](C:/Users/4ivan/codex-multi-agent/agent_system/model_tool_boundary.py). PlanUpstream теперь сохраняет metadata в существующий bounded `response_metadata_history` при HTTPError, затем возвращает прежний fixed failure. Success MIME/lifecycle/Controller authorization остаются строгими.

Сохраняемый record имеет только пять полей: `status`, `type`, `code`, `param`, `message_category`. Машинные type/code проходят finite allowlists, включая документированные SIWC subscription_sharing/chatpass codes; неизвестные заменяются `unrecognized`. Param допускает только известные request/schema names и ограниченные numeric indices; произвольные имена подавляются. Prose классифицируется в fixed category после проверки SecretFilter и JSON-decoded escaped secrets. При malformed/secret-bearing JSON machine поля подавляются; known HTTP status сохраняется. Envelope `detail` не превращается в machine code.

Читается только owned HTTPError/HTTPResponse socket: JSON ceiling 16 KiB с одним extra byte для обнаружения overflow, 2 секунды, 64 read iterations и текущий execution deadline/cancellation. Framing, encoding, EOF и reader shutdown проверяются; overflow/truncation/stall дают status-only metadata. Сокет закрывается. Нет raw body/header dump, request ID, provider/account identifiers, message text, body hash, credential read/refresh/reconnect, forwarding error bytes в Codex, retry или новых tool permissions.

Исторический retry driver закрывал HTTPError до rethrow; он сохранён неизменным. **Будущий отдельно authorized driver обязан не закрывать error раньше централизованного capture.** Уже закрытая ошибка корректно даёт только status; нельзя выдать это за successful error-code capture.

Production source bundle изменился; прошлый signed Stage19d admission теперь stale. Изменённые файлы входят в существующий ToolDockerRunner transport binding. Перед новым отдельно разрешённым execution понадобятся fresh admission, execution/client-bound approvals и новый latch. Старые latches и human billing confirmation timestamps сохранены; новые live разрешения здесь не выпущены.

## Проверка и остановка

Итог: **266 offline tests passed**. Результаты и хэши: [tests.xml](C:/Users/4ivan/codex-multi-agent/docs/stage19-request-audit-evidence/tests.xml), [integrity-after.json](C:/Users/4ivan/codex-multi-agent/docs/stage19-request-audit-evidence/integrity-after.json). Тестируются synthetic owned sockets, секреты/escaped JSON, arbitrary type/code/param/prose, SIWC codes, framing/chunked overflow/truncation, timeout/cancellation, PlanUpstream single dispatch/no retry, прежний MIME/lifecycle/tool boundary и consumed driver constraints. Первый запуск тестов выявил короткий synthetic credential fixture и sandbox temp-dir permission; fixture исправлен, финальная suite использует новый workspace basetemp.

Текущий source bundle SHA256: `ccee1417fde05b674122421f7ee6f639ac8363e7e49bd08d95ed21b75d2551fd`. Полная default suite и fresh Docker admission в этом аудите не выполнялись.

Все 1281 файла исторического evidence/source ledger неизменны. Новый replay home удалён. OAuth, Docker/role execution, fresh live admission, новые authorizations и Stage20 не запускались. Полное historical exact body и definitive 400 root cause остаются UNKNOWN; diagnostic implementation готова для отдельно разрешённой попытки после нового admission.
