# Stage19e — Final live smoke

**FAIL_LIVE_TRANSPORT.** The explicitly authorized final smoke on `gpt-6-astra / low` sent one of at most three sequential Responses POSTs and received HTTP 200. Strict lifecycle reconciliation rejected the response before any tool execution. No retry or Stage20 execution occurred.

| Check | Result |
|---|---|
| Current plan credentials and fresh account catalog | Valid; gpt-6-astra / low confirmed |
| Current production source / Codex / image / engine / config / project | Revalidated against final signed admission |
| Fresh live and execution/client-bound no-credit signatures | Issued; actual original billing-confirmation timestamp retained |
| Pre-execution driver/boundary/lifecycle offline tests | 222 passed |
| Responses POSTs / HTTP statuses | 1 / 200 |
| SSE bytes / EOF / reader shutdown | 20,990 / confirmed / confirmed |
| Content-Type | Absent; compatibility not accepted because lifecycle validation failed |
| Terminal status / final stream-output bijection | completed / false |
| Function calls / executed tools | 0 / 0 |
| Retry / Stage20 | 0 / not started |

The strict typed-const schema was retained. No alternative model, tool, command, role, request mutation or weaker lifecycle policy was applied during the smoke. The first response was rejected by the upstream validator, so no bytes or authority reached the model tool dispatcher and no second POST was sent. The gate structure is empty because upstream validation failed first.

The precise provider output discrepancy remains unknown: raw SSE, model prose, arguments, provider request/item/call/account IDs and credentials were not persisted. Safe telemetry shows two registered items and completed events, but `stream_final_bijection=false`. This is a separate lifecycle blocker after request admission; HTTP 400 was not observed in this smoke.

The original execution record says `FAIL_CLEANUP`. The new driver accidentally excluded `stage19e-final-smoke-1-evidence` rather than its actual output directory, so its own telemetry changes failed the broad manifest equality check. The original record and exact executed driver snapshot are preserved. An independent hash audit, performed under the **same elevated filesystem view as execution**, confirmed all 7,934 files outside current smoke evidence unchanged. A comparison under the sandbox view was not comparable because the `.agent_runs` view differed; it is retained separately and not used as proof of changes.

Codex exited, the disposable model-home and role storage were removed, stale owned container count is zero, credentials are unchanged, and the disposable workspace is unchanged. The exclusion bug was repaired offline with `OUT.name`; 38 driver tests passed, including a regression that preserves historical evidence while excluding current telemetry. The repaired driver was **not run live**. Its previous execution admission is stale for the new driver hash; production source and its admission are unchanged.

Final verdict separates the actual transport rejection from the resolved cleanup measurement error. Stage19 remains `FAIL_LIVE_TRANSPORT`, Stage19 passed=false, Stage20 technically admissible=false. No automatic follow-up smoke is scheduled. The next work is offline lifecycle investigation, without weakening reconciliation.

Evidence: [original execution](docs/stage19e-final-smoke-evidence/execution.json), [independent integrity audit](docs/stage19e-final-smoke-evidence/independent-integrity-audit.json), [fresh catalog](docs/stage19e-final-smoke-evidence/catalog.json), [executed driver](docs/stage19e-final-smoke-evidence/executed-driver.py), [pre-execution tests](docs/stage19e-final-smoke-evidence/offline.xml), [instrumentation regression](docs/stage19e-final-smoke-evidence/manifest-repair-tests.xml).
