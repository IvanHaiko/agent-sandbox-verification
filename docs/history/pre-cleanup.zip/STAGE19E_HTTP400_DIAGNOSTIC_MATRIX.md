# Stage19e — Controlled HTTP 400 diagnostic matrix

**ROOT_CAUSE_IDENTIFIED_AND_REPAIRED**. Two sequential live POSTs: catalog model control returned 400; adding explicit types to seven strict const-bound function properties returned 200. No diagnostic tool executed. Strict mode remains enabled.

## Credentials, catalog and admission

Fresh browser login succeeded with signature, issuer/audience/time/nonce checks intact. Credentials stayed in the protected store. The previous expired-credential stop is preserved separately; it was followed by the requested new sign-in and complete re-admission. No credentials, callbacks, account IDs or provider IDs were exported.

`gpt-6-sol / low` is **not available** in the fresh account catalog. Available relevant pairs:

- `gpt-6-astra`: low, medium, high, xhigh, max, ultra.
- `gpt-5.6-sol`: low, medium, high, xhigh, max, ultra.
- `gpt-5.6-terra`: low, medium, high, xhigh, max, ultra.
- `gpt-5.6-luna`: low, medium, high, xhigh, max.

E used `gpt-6-astra / low`, the available same-generation reasoning model. Catalog entitlement/reasoning and [official Responses/function/streaming support](https://developers.openai.com/api/docs/models/gpt-6-astra) justify this explicit control. No A POST was sent on an unavailable model and no permanent model substitution was applied.

Real Docker/Codex admission was rebuilt after login, then rebuilt again after the correction. Both verified signed transport proof, current executable, pinned image, engine/config/project binding and isolation/cleanup. Role network remained denied; model tools were not executed by the matrix. Fresh execution/client-bound no-credit and live signatures used the actual original human-confirmation handling timestamp, without refreshing or fabricating it.

## Comparison

| Variant | Single changed factor | Catalog model | HTTP status | Error type | Code | Param | Category | SSE reached | Tool call reached | Interpretation |
|---|---|---|---:|---|---|---|---|---|---|---|
| A_BASELINE | None | — | — | — | — | — | — | No | No | Not dispatched: requested model absent from account-specific catalog |
| E_CATALOG_MODEL_CONTROL | Only model: gpt-6-sol to catalog-confirmed gpt-6-astra; low retained | gpt-6-astra | 400 | — | — | — | suppressed_or_malformed | No | No | 400 with const-only strict schema |
| B_TYPED_CONST | Only seven explicit function property types; compared against necessary E control | gpt-6-astra | 200 | — | — | — | — | Yes | No | 200 after adding types only; subsequent lifecycle reconciliation rejected final output |
| C_NO_MESSAGE_IDS | Input message IDs only | — | — | — | — | — | — | No | No | Not needed after E/B single-factor comparison |
| D_NON_STRICT_CONTROL | Function strict flag only | — | — | — | — | — | — | No | No | Not needed after E/B single-factor comparison |

B was compared against E, holding the catalog-required model correction fixed. Both requests came from the **same in-memory baseline**: identical messages and IDs, prompt, reasoning, text/include, namespace, strict flag, constants, bounds and tool choice. B added only seven property types. This is the permitted one-additional-variable experiment after independently establishing E as necessary from the catalog.

The 400 error went through centralized bounded capture. It produced status=400 and category=`suppressed_or_malformed`; type/code/param are unavailable. No raw error body or prose was persisted. The root-cause conclusion rests on the controlled 400→200 comparison, not an invented provider error.

Request shape fingerprints:

- `E_CATALOG_MODEL_CONTROL`: `c3c89c5f075031af171cc0b4e8c465c4b3f8ce7ecbed0340fd394afa52ba1524`.
- `B_TYPED_CONST`: `0af6d561ce8823ee87482a08d0cb52d5e1bd643a300982cb49c589106951a745`.

Fingerprints hash sanitized shape, with opaque IDs, prose and private string values replaced first. No raw request body is persisted. Exclusive consumed-variant files and the matrix latch prevent repeating E or B; the remaining three allowances were not consumed. C and D were not needed.

## Facts, inference and root-cause scope

**Observed:** E=400; B=200 after types only. **Controlled conclusion:** the current strict const-only function declaration has an admission incompatibility corrected by explicit types. **Inference:** strict schema compilation/handling is implicated. The exact provider compiler failure and historical `gpt-6-sol` rejection cannot be reconstructed from this comparison. Model absence is a separate current catalog fact.

B reached a bounded 26,667-byte SSE body with EOF and reader shutdown confirmed; MIME was absent. Lifecycle reconciliation ran and rejected `stream_final_bijection=false`, with zero function calls. Missing-MIME compatibility was not accepted because full validation failed. No response was released to a tool dispatcher. This **does not pass Stage19** and does not justify weakening lifecycle enforcement.

## Repair and validation

Only `agent_system/model_tool_boundary.py:tool_spec` changed in production: string/integer types were added to seven const-bound properties. All const values, strict mode, required fields, additionalProperties=false and bounds remain. The production schema is regression-checked against the admitted B candidate; wrong identity/type and extra-authority arguments remain rejected. Message IDs, non-strict controls and default model configuration were not adopted.

Post-repair relevant offline suite: **421 passed**, 0 skipped, zero failures/errors. Before dispatch, 283 focused tests passed. Final real admission: **1 passed**. A broader default suite was stopped during unrelated workflow tests; no full-suite pass is claimed.

First final admission failed because its cancellation assertion expected lowercase cancel while the fixed error began Cancelled. The new admission test matches cancellation case-insensitively; production enforcement is unchanged. The second admission passed; both results are retained.

Previous source bundle: `ccee1417fde05b674122421f7ee6f639ac8363e7e49bd08d95ed21b75d2551fd` (stale after repair). Final source bundle: `9d98deecfbb7e8d0ba4fdf0de227540c8c3a8a9fcf436ec03474ec71567c85a1`. Final signed admission and the unchanged-source check are in `docs/stage19e-final-admission-evidence/fresh-admission.json`.

A separate final Stage19 smoke remains required under the fresh repaired admission, a catalog-confirmed model, fresh execution-bound approvals, exact smoke commands and unchanged strict lifecycle checks. No additional live POST was sent after identifying the correction. Stage19 remains `FAIL_LIVE_TRANSPORT`; Stage20 is not admissible and was not started.

Evidence: [live observations](docs/stage19e-live-evidence/execution.json), [catalog](docs/stage19e-live-evidence/catalog.json), [consumed attempts](docs/stage19e-live-evidence/attempts/consumed-attempts.json), [post-repair tests](docs/stage19e-live-evidence/after-repair-focused.xml), [final admission](docs/stage19e-final-admission-evidence/fresh-admission.json), [reconnection](docs/stage19e-evidence/reconnection.json).

Final smoke scope is prepared, not dispatched: [prepared-final-smoke.json](docs/stage19e-final-admission-evidence/prepared-final-smoke.json). Historical admissions remain unchanged and are marked stale in [stale-admissions.json](docs/stage19e-final-admission-evidence/stale-admissions.json).
