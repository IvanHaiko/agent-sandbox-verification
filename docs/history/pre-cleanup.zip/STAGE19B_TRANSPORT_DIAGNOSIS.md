# Stage 19b — Transport Diagnosis & Safe Diagnostic Capture

Date: 2026-10-06. Verdict: **DIAGNOSIS_READY_FOR_AUTHORIZED_CAPTURE**.

The actual historical response format and its cause remain UNKNOWN. Two actionable offline findings are established: the recorded MIME was a library-parsed value, not a retained raw header; and the Controller's flat function declaration differs from current SIWC tool-format guidance. Neither establishes why the server returned the rejected response. No live inference, authenticated catalog, OAuth exchange or refresh occurred in Stage 19b. Stage 19 remains **FAIL_LIVE_TRANSPORT**. Stage 20 is inadmissible.

The separate [JSON assessment](STAGE19B_TRANSPORT_DIAGNOSIS.json) separates `observed`, `documented`, `inferred` and `unknown`. [Request reconstruction](docs/stage19b-evidence/request-reconstruction.json), [native synthetic replay](docs/stage19b-evidence/native-replay.json), [final tests](docs/stage19b-evidence/final.xml) and [historical hashes](docs/stage19b-evidence/historical-hashes.json) are supporting evidence. Historical assessments were not rewritten.

## 1. Stage 19 facts

Sign in with ChatGPT OAuth and account-specific discovery succeeded. No API key was used. Catalog availability confirmed; successful inference acceptance remains unproven. Historical `entitlement_proven` wording in the immutable assessment does not establish completed inference.

Two separately authorized executions each sent one POST to `https://api.openai.com/v1/responses`, using `gpt-6-astra`, reasoning `low`. Both reported HTTP 200. The second reported parsed `text/plain`, zero upstream body bytes read, and `Unexpected plan response content type`. The first lacks equivalent MIME instrumentation. There was no validated completion, dynamic tool call, model-selected Docker operation, model-selected host execution, or observed credential escape. Backend inference activity, reasoning, usage and billing remain UNKNOWN. HTTP 200 and catalog presence establish neither successful inference nor billing behavior.

## 2. Sanitized exact request reconstruction

There is no captured historical request body or wire-header record. The reconstruction is exact for source-enforced invariants; values not retained by history are UNKNOWN. It must not be mistaken for a wire capture.

| Part | Reconstruction | Evidence category |
|---|---|---|
| Method / route | POST, fixed `https://api.openai.com/v1/responses` | source; route request count observed |
| Content-Type | `application/json` | source |
| Accept | `text/event-stream` | source |
| Authorization | SIWC OAuth bearer; value never exported | source / historical OAuth success |
| Model | `gpt-6-astra` | historical binding + gate |
| Reasoning | object with `effort: low`; historical other subfields UNKNOWN | gate / source |
| Stream / store | JSON booleans `true` / `false` | strict identity checks before upstream |
| Input | array; historical items/text UNKNOWN | gate |
| Tools | one Controller-authored flat function `agentctl_execute` | source replaces entire top-level inventory |
| Tool choice | `auto` | source overwrite |
| Optional fields | actual `instructions`, `include`, `text`, `parallel_tool_calls` values UNKNOWN | allowlist is not evidence of field presence |
| Serialization | strict JSON input; `json.dumps(body).encode()` UTF-8 JSON bytes | source |

The machine-readable reconstruction contains the full sanitized dynamic schema with the second execution's identity and source-computed workspace digest. Required constants bind execution, task, role, phase, contract version and workspace. Required operation fields are `tool_type: argv`, nonempty argv with at most 64 items, stdin at most 65,536 characters, integer timeout 1–30 seconds, output limit 1–1,048,576 bytes, and boolean `read_only`; additional properties are forbidden. This schema authorizes nothing by itself: the bridge's independent identity/argument checks still apply.

The top-level allowlist is `model`, `input`, `instructions`, `store`, `stream`, `tools`, `tool_choice`, `parallel_tool_calls`, `text`, `reasoning`, `include`. `client_metadata` and `prompt_cache_key` are removed. Everything else is rejected; `previous_response_id`, service tier, URL overrides, hosted top-level inventory and unsupported top-level options cannot pass. Other reasoning subfields are preserved; nested input structures are not comprehensively validated against SIWC request schemas. This is a compatibility uncertainty, not evidence of a boundary bypass.

## 3. Official SIWC comparison

Official pages were checked on 2026-10-06. The SIWC preview contract is evaluated separately from the general API. [SIWC inference](https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference), [preview limitations](https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations), and [app-server integration](https://developers.openai.com/siwc/token-sharing-open-source/codex-app-server) are the primary references.

| Concern | Our Stage 19 request | Official contract | Match? | Evidence |
|---|---|---|---|---|
| Endpoint / auth | fixed Responses POST / OAuth bearer | same SIWC route and auth category | yes | source; SIWC inference |
| Stream / store | true / false | true / false | yes | gate; SIWC limitations |
| Input | array; exact items UNKNOWN | array for HTTP | shape yes | gate; SIWC limitations |
| System/developer | direct system items rejected; historical developer items UNKNOWN | explicit system roles rejected; developer/instructions supported | partial | source; SIWC limitations |
| Function tools | flat top-level function | namespace grouping or `additional_tools` input items | **documented format gap** | source; SIWC limitations |
| Discovery | account catalog, selected low | account-specific model availability | catalog yes; inference unproven | immutable catalog; SIWC inference |
| Reasoning | effort low; other historical values UNKNOWN | supported values depend on model | partial / UNKNOWN | historical catalog; official inference |
| Headers | JSON content type, OAuth bearer, explicit SSE Accept | example uses JSON content type and bearer; does not make our Accept mandatory | base yes; Accept causality UNKNOWN | source; official example |
| HTTP transport | expects SSE, buffers before release | HTTP/SSE provider flow | intended yes; actual UNKNOWN | app-server; source |
| Framing | strict event/data, bounded whole-stream validation | Responses event stream | expected yes | general [streaming guide](https://developers.openai.com/api/docs/guides/streaming-responses); SIWC inference |
| Completion | requires validated `response.completed` | completion event required | contract yes; never observed live | gate; SIWC inference |
| Errors after 200 | unknown MIME rejected; unsupported/error events fail closed | failure can arrive after HTTP200 | conservative failure | SIWC inference; source |
| Exact response MIME | gate requires parsed `text/event-stream` | retrieved SIWC text does not establish a normative raw-header rule or permission for `text/plain` | UNKNOWN | repository assumption, no alternate MIME admission found |

The tool-format gap warrants investigation before another smoke, but changing it now would change the experiment. No request-format fix or MIME relaxation was implemented. Documentation is current guidance; it does not prove the historical server's implementation or the cause of its response.

## 4. Actual HTTP stack and observation point

The general runner path is `ChatGPTPlanRunner -> bound Controller policy -> CodexToolSession -> LocalModelRelay -> ResponsesGate.request -> PlanUpstream -> urllib/http.client -> MIME check -> buffered SSE -> ResponsesGate.response -> Codex -> matched dynamic call -> IsolatedExecutionBridge -> ToolDockerRunner`.

Stage 19 used a minimal direct harness in `validation/stage19_run_live.py`, assembling those transport components rather than invoking the full runner lifecycle/factory. That difference is explicit; it did not create an alternate host tool path.

The second execution's temporary tracked opener recorded `response.headers.get_content_type()` immediately after the real opener returned. Its `read1` wrapper counted body reads. `PlanUpstream` consulted the same parsed MIME and rejected it before any `read1`. Therefore no historical body reached the SSE parser, response gate, Codex or dispatcher.

CPython 3.13.1 `email.message.Message.get_content_type()` lowercases the media value, strips parameters and defaults to `text/plain` for missing headers or certain malformed values. Synthetic tests reproduce this behavior. The observation is **not definitely the direct raw upstream header**. Raw header presence, value, parameters and duplicates are UNKNOWN. A missing/malformed header could produce the same evidence as an explicit plain header. HTTP parsing also cannot prove whether an external intermediary originated the response.

The client uses one urllib HTTP path; `stream:true` is a request field, not a different client API. HTTP transfer chunking is decoded by `http.client`; application decompression is not added. The relay buffers the complete bounded supported SSE before gate validation. No normalization of the body, content sniffing, redirect following, environment proxy use or exception-to-success conversion occurs in this path. HTTP errors are converted to a local failure without releasing provider text.

## 5. Headers and content negotiation

`Accept: text/event-stream` is explicitly supplied. It is not absent or synthesized. Source reconstruction of ordinary library defaults includes Host, Content-Length computed from bytes, `Python-urllib/3.13`, Connection close and Accept-Encoding identity. Their exact historical wire representation/order is UNKNOWN.

Official SIWC curl examples omit an explicit Accept. That omission does not demonstrate that our header is wrong, that omitting it would fix this response, or that arbitrary plain responses should be accepted. No header change was made. ProxyHandler has an empty proxy map; `NoRedirect` rejects redirects. TLS/DNS/intermediary wire details were not captured historically.

## 6. Body and offline native replay

Gate checks use `is True` and `is False`, preventing string/integer coercion of stream/store. There is no observed boolean serialization defect. Actual historical body bytes, exact optional fields and nested representations remain UNKNOWN.

An isolated localhost replay with the exact pinned 0.160.0 binary completed against synthetic SSE with no tools or OpenAI requests. Native fields included local metadata/cache key, input, model, parallel calls, reasoning, stream/store, text, include and tool choice. The gate removed local fields and inserted the flat Controller function. Replayed reasoning was `{"effort":"low","context":"all_turns"}` both before and after the gate. Synthetic input used developer and user roles, with no observed system role. Input text was not exported. The replay uses a synthetic prompt and does **not** prove the historical request had identical fields/content.

`reasoning.context` is a real general API parameter with model-dependent support, according to the [reasoning guide](https://developers.openai.com/api/docs/guides/reasoning). It is not inherently an accidental private field. Its support specifically for this SIWC model remains UNKNOWN. General API reasoning support cannot establish SIWC acceptance.

## 7. Hypotheses ranked by evidence

Ranking prioritizes established findings and diagnostic usefulness; it is not a probability estimate or causal verdict.

1. **Library normalization:** confirmed observation ambiguity, including missing/malformed-header defaults. It could explain the recorded label; actual raw header remains unknown.
2. **Request-shape difference:** confirmed gap between flat function and current SIWC tool guidance. Connection to a plain HTTP200 response is unproven.
3. **Account/plan/admission message:** plain or JSON failure is plausible. HTTP200 can precede a failure; unread body prevents identification.
4. **Valid SSE with wrong/missing MIME:** plausible and synthetically classifiable. No historical bytes establish it.
5. **Unsupported model/reasoning/request combination:** availability/low are confirmed in the historical catalog, but nested context and actual request acceptance are unproven.
6. **Header differences:** explicit SSE Accept is confirmed; causality is unsupported.
7. **Client behavior:** source and tests argue against stream:false, boolean coercion, local proxy or redirect explanations; external behavior remains unknown.
8. **Relay bug:** measurement precision is limited, but rejection followed its policy. No body-to-SDK leak or inappropriate acceptance was found.
9. **Another supported wire representation:** no retrieved SIWC documentation admits it; format is unknown.
10. **Undocumented upstream/intermediary behavior or version drift:** possible; there is insufficient measured evidence to assign origin or causality.

## 8. Unknown facts

Unknowns include raw historical MIME and headers; body bytes/framing/events; exact request bytes/input/optional fields; origin of the response; whether backend inference or reasoning started; completion, usage and cost; whether flat tools or context affected acceptance; exact old/new wire differences. No body contents or error message were invented to fill these gaps.

## 9. Quarantine architecture

New `agent_system/transport_diagnostics.py` is intentionally **unwired and disabled by default**. It adds no HTTP client, credentials, inference loop or tool executor. A future trusted entrypoint may wrap the existing fixed-route opener. An unknown response is observed only after independent diagnostic authorization and is then always rejected. Expected SSE returns unchanged to the existing strict path; classification never becomes an alternate production parser.

Constants: **8,192 body bytes, 2.0 seconds, 8 chunks, 1,024 bytes/chunk**. A 50 ms socket idle limit stops early; shutdown join is bounded by an additional 0.5 seconds. EOF, byte/chunk limit, timeout and cancellation stop observation. Only an owned standard-library HTTPResponse with an interruptible socket is supported. Reader shutdown must be confirmed; otherwise the result is failure without prefix evidence.

The limits cover observed decoded body bytes after HTTP headers, not raw TLS or transfer-framing bytes. `http.client` performs its own header/chunk parsing. The two-second body limit does not replace the existing request/socket timeout (up to 15 seconds) or overall deadline. Short idle capture may produce only a partial prefix; classification cannot prove full stream validity.

## 10. Security and evidence handling

Before delegated HTTP, enabled instrumentation checks fresh admission, exact signed live grant, a separately signed diagnostic grant binding identity/model/route/limits and observer source hash, and fresh client-bound no-credit attestation. An in-memory consumed latch prevents observer reuse; a future execution also requires its own persisted one-execution latch. No existing Stage19 grant authorizes another call.

Raw bytes stay in bounded Controller memory. There is no temporary body file, repository body, role mount, stdout/stderr output or JUnit body. Known-secret rejection runs on literal text, canonical JSON and independently decodable fragments, including escaped secrets preceding malformed data. Only fixed header enums, counts, presence, lengths, framing booleans/counts, UTF-8/classification, read/stop state and an approved prefix SHA256 are eligible for export. Arbitrary header text, identifiers, event contents and function arguments are never exported. Secret-containing prefix structure/hash are suppressed.

These mechanisms protect known credentials and avoid exporting sensitive prose; they are not universal detection of every possible encoded secret. Python memory disposal is not cryptographic zeroization. A prefix hash is a correlation artifact, not proof of authenticity, validity or completion. None of these outputs grants execution authority.

## 11. Synthetic adversarial tests

**40 diagnostic cases pass**, using synthetic socket peers and no OAuth/model traffic. They cover every requested category: expected SSE; mislabeled SSE; plain/JSON/JSONL; invalid UTF-8; huge/large-length responses; never-ending responses; timeout/cancellation; literal, escaped, fragment and header secrets; fake plain tool calls; early SSE calls followed by malformed data; duplicate/invalid events; misleading/missing/malformed/duplicate/case-varied headers; and chunked transfer decoding.

Additional cases verify disabled mode, missing/expired/wrong-client grants, fresh-admission failure, forbidden route before delegation, replay denial, authorization before HTTP and unknown rejection before relay response validation. Executor traps fail tests if Codex run, bridge execution, Docker tool execution or host subprocess execution is attempted. An SSE-like prefix inside `text/plain` is still rejected. The integration test proves captured unknown data cannot enter the relay's response gate or be forwarded to Codex.

## 12. Regression results

**190 fresh focused tests pass** in `final.xml`: 40 new diagnostic cases plus existing OAuth, transport, model boundary and native synthetic tool coverage. An independent pinned native replay also completed synthetically with no tools. Default collection has **415 tests**, all covered by the exact node-ID union of historical full regression, prior SIWC focused evidence and this fresh focused run. This is cumulative coverage, not a newly run full suite.

An earlier Stage19b run had a cancellation reader-shutdown race on Windows. The new observer's short idle timeout fixed it; final cancellation/shutdown tests pass. Earlier failed evidence remains in `focused.xml` and is excluded from passing coverage. No old checkpoint was edited to hide that failure. No fresh Docker capability probe was needed for this unwired observation module; prior measurements remain historical, not new live proof. A future live integration requires fresh admission including the new observer and pinned runtime.

## 13. Source, hashes and runtime drift

Added files: observer, diagnostic tests, offline native replay and separate assessment generator. All six accepted Stage18c production source hashes still match; the aggregate transport and six-file Docker boundary hashes also match historical admission. All **22** snapshotted Stage18c/Stage19 assessments and Stage19 evidence files still match byte-for-byte. New source SHA256 values and historical/runtime hashes are in the JSON. No runtime or existing Docker isolation source was changed.

Stage18c measured 0.159.2; Stage19 used 0.160.0 with fresh admission. The old pinned executable is now unavailable, preventing a direct binary comparison. The exact pinned 0.160.0 hash was verified before synthetic replay.

The [official changelog](https://learn.chatgpt.com/docs/changelog), reached from the Codex developer changelog, lists 0.160.0 provider/catalog changes and persistence of provider, reasoning-summary and verbosity settings. No response MIME, Accept or SSE change was identified in the listed notes. These changes make provider drift a topic for inspection, but do not establish the MIME failure's cause. Version correlation remains unproven.

## 14. Production acceptance semantics and MIME policies

Acceptance did not change: supported MIME -> complete bounded strict SSE validation; unexpected MIME -> reject. Optional future quarantine would add observation before the same rejection. It would never stream unknown bytes into Codex or dispatch inferred function calls.

**Policy A remains recommended:** enforce the current MIME boundary and seek a provider-conformant stream. It can reject mislabeled valid content but avoids new sniffing rules and protocol ambiguity.

**Policy B was analyzed, not implemented.** A future narrow framing override would require a separately reviewed change, authoritative compatibility evidence or strong complete-stream measurements, exact allowed media/framing rules, bounded buffering, strict events/schema/completion validation, credential filtering, canonical call identity/arguments, replay defenses, fresh admission and adversarial regression. A prefix resembling SSE or containing a completion-shaped event is insufficient. Such an override increases content-sniffing, fail-open and drift risks, especially when early tool-like events precede malformed data. It must never be added merely to make the smoke pass.

## 15. Is another diagnostic technically justified?

Yes, **exactly one separately authorized bounded diagnostic** is justified: historical body format cannot be recovered offline, and the tested observer can classify a prefix without accepting it. This is a recommendation and proposal only. No live request, retry or scheduled continuation was created.

## 16. Exact proposed future diagnostic scope

| Item | Proposed limit |
|---|---|
| Execution / HTTP attempts | one new diagnostic execution, at most one Responses POST, no retries |
| Model / reasoning | `gpt-6-astra` / `low` |
| Route | POST `https://api.openai.com/v1/responses`, existing proxy/redirect prohibition |
| Request preparation | offline pinned 0.160.0 preparation using original Stage19 minimal prompt and bound identity; Controller captures gated request in memory and freezes body hash before approval |
| Request variants | none; preserve stream:true, store:false, array input, original tool/header semantics; exact historical byte identity remains UNKNOWN |
| Live path | Controller sends frozen gated body once; no live Codex session, relay client, bridge or tool dispatcher |
| Capture | at most 8,192 decoded body bytes, 8 chunks, 2 seconds; 50 ms idle stop; at most 0.5 seconds shutdown join |
| Retain | safe status/header enums/presence/counts/length, byte/chunk counts, read/stop/shutdown state, UTF-8/framing classification, secret-checked prefix hash |
| Discard | raw text/body, payloads, function arguments, arbitrary headers, request/account identifiers; secret-bearing derived structure/hash |
| Stop | unknown MIME always ends in transport failure after bounded observation; expected MIME ends diagnostic without accepting inference or executing tools |
| Authorization | later explicit one-diagnostic approval; new signed diagnostic and live grants; new execution/latch; fresh runtime/observer/limits binding; frozen request hash reviewed before HTTP |
| No credits | new signed attestation, at most 24 hours old, bound to issued OAuth client and new execution; credits-fallback switch OFF and remaining OFF; balance alone insufficient |

The future request entrypoint is a proposal, not an enabled integration. Before execution it must bind the frozen request scope to approval, use current valid Controller credentials without exporting them, verify fresh admission, and preserve every existing Stage18c boundary. Any required account connection/refresh would also need to fall within that later authorized scope. Existing signed records are not reused or edited. This diagnostic cannot execute the original prompt's requested tool operations because no live tool dispatcher or Codex consumer exists.

## 17. Can Stage 19 be considered passed?

**No.** It remains `FAIL_LIVE_TRANSPORT`. Even a useful future classification would not establish a smoke pass. A separately authorized minimal smoke must still reach a validated completed response and the intended live Docker tool path.

## 18. Is Stage 20 admissible?

**No.** Stop at this offline assessment and capture proposal. No OML, multi-agent workflow, model benchmark, routing optimization, MIME relaxation or additional inference was performed.
