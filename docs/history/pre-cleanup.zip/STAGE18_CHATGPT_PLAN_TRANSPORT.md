# Stage 18 — official ChatGPT plan transport checkpoint

Date: 2026-10-05. Status: **CHATGPT_PLAN_TRANSPORT_BLOCKED**.

The official open-source Sign in with ChatGPT flow is applicable. A separate Controller-side OAuth implementation and deterministic boundary prototypes now exist. There is no working authenticated model relay or admitted app-server/Docker arrangement. Stage 18 remains `PARTIAL_BLOCKED`; highest completed stage is **17**. Stage 19 is neither technically ready nor authorized. Framework real model calls: **0**. No real OAuth login, token acquisition, inference, model-catalog query, or consumption of plan usage occurred.

This report and `STAGE18_CHATGPT_PLAN_TRANSPORT.json` are new checkpoints. Earlier acceptance, hardening, Stage 16/17, credential-transport and master assessments remain unchanged. Their byte hashes are recorded in the JSON; this records preservation, not new acceptance.

## Official capabilities verified

Sources were consulted on 2026-10-05. The guides do not expose a pinned protocol release/date. The official [SIWC cookbook article](https://developers.openai.com/cookbook/articles/sign-in-with-chatgpt) is dated September 28, 2026. Local Codex CLI inspected: **0.159.2**; that binary version is separate from the current web documentation.

| Required fact | Current official contract |
|---|---|
| 1. Open-source/local registration | Public-client dynamic registration is documented. [Quickstart](https://developers.openai.com/siwc/quickstart) |
| 2. Eligible users | Eligible Plus/Pro users may grant ChatGPT plan usage; eligibility restrictions apply. [Quickstart](https://developers.openai.com/siwc/quickstart) |
| 3. Secrets/API keys | This open-source flow requires no client secret, partner key or ordinary OpenAI API key. OAuth bearer credentials remain secrets. [Quickstart](https://developers.openai.com/siwc/quickstart) |
| 4. Returned artifacts | Access, refresh and ID tokens, token type, granted scope, expiry and `earliest_refresh_at`. Access tokens last one hour; refreshed renewable tokens have a fresh 30-day lifetime. [Token reference](https://developers.openai.com/siwc/token-sharing-open-source/token-reference) |
| 5. Plan permission | Request `openid profile email offline_access resource.invoke chatgpt.tokens.use.direct`; inspect granted scope separately from identity. [Sign-in](https://developers.openai.com/siwc/token-sharing-open-source/sign-in) |
| 6. Host identity | Persist stable, opaque `ext_agent_host_id` before login; a UUID URN is supported. Host identifier is distinct from issued client registration. [Overview](https://developers.openai.com/siwc/token-sharing-open-source) |
| 7. Authorization protections | Fresh state, nonce and S256 PKCE; exact loopback `/auth/callback`. Verify ID-token signature and claims. [Sign-in](https://developers.openai.com/siwc/token-sharing-open-source/sign-in) |
| 8. Refresh | Use issued client ID, refresh token and resource; serialize rotation and persist the replacement. Revocation endpoint comes from discovery. [Sessions](https://developers.openai.com/siwc/token-sharing-open-source/profiles-and-sessions) |
| 9. Responses/app-server | Plan OAuth supports documented Responses requests and an app-server custom provider. [Inference](https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference), [integration](https://developers.openai.com/siwc/token-sharing-open-source/codex-app-server) |
| 10. Provider configuration | Official example uses `ACCESS_TOKEN`, `https://api.openai.com/v1`, Responses wire format, no separate Codex login and disabled WebSockets. [Integration](https://developers.openai.com/siwc/token-sharing-open-source/codex-app-server) |
| 11. Models/entitlement | OAuth-authenticated `/models` exposes visible models. Catalog listing is not entitlement proof; actual eligible inference remains untested here. [Inference](https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference) |
| 12. Coding/tool semantics | Local function/custom tools and Codex coding behavior are supported. Where those tools execute is a separate security question. [Limitations](https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations) |
| 13. Preview restrictions | HTTP requires `store:false`, `stream:true`, input array; no system message items or HTTP `previous_response_id`. Numerous usual Responses fields and hosted tools are unsupported. [Limitations](https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations) |
| 14. Usage attribution | App use consumes the existing ChatGPT Work/Codex allowance; it provides no extra allowance. [User guide](https://learn.chatgpt.com/docs/sign-in-with-chatgpt) |
| 15. App limits | Users can configure a weekly percentage limit per app in Settings → Usage. [User guide](https://learn.chatgpt.com/docs/sign-in-with-chatgpt) |
| 16. Exhaustion | Structured usage-limit/eligibility errors must stop or recover explicitly; do not silently switch billing routes. [Recovery](https://developers.openai.com/siwc/token-sharing-open-source/errors-and-recovery) |
| 17. Credits | A user setting permits other apps to use credits after allowance exhaustion. This checkpoint has not verified that setting or a programmatic opt-out. [User guide](https://learn.chatgpt.com/docs/sign-in-with-chatgpt) |

Login, granted plan permission, model entitlement and remaining usage are four distinct states. The implementation reports entitlement as unverified and remaining usage as unknown. No model alias is promoted to an available model.

## Architecture comparison and decision

| Option | Credentials and tool boundary | Decision |
|---|---|---|
| A: direct token in role | Simple official provider integration; same-UID generated code can inspect environment/process state. Bearer leakage enables use outside local request ceilings until expiry/revocation. Refresh would be still more sensitive. Direct egress also changes admission. Redaction cannot fix this. | Rejected for this threat model. No token injection. |
| B: trusted OAuth/app-server/model transport | Keeps renewable credentials outside roles and preserves Codex agent semantics, provided **every** shell/file operation can be delegated into Docker. Normal server-side tools would execute in the trusted server's environment. | Preferred target; exact safe execution arrangement is unresolved and unadmitted. |
| C: minimal Responses broker with custom agent loop | Can retain credentials and restrict requests, but requires context history, tool loop, structured-result handling and termination logic. | No custom agent loop built. Do not choose it merely because the B integration is unfinished. |

The official [app-server reference](https://developers.openai.com/codex/app-server) documents server-side command/filesystem methods, experimental dynamic tools and experimental remote code-mode hosting. Approval acceptance allows execution; it is not a Docker delegation mechanism. **Inference from these contracts:** putting an ordinary app-server on the trusted host and approving its tools would breach this framework's boundary. Experimental delegation facilities require implementation-specific measurement before selection; the flow itself has not been proven unsuitable.

Candidate B arrangements include a separately isolated Codex runtime with a trusted model-only relay, or an explicitly supported remote execution host. Neither is selected/admitted here. A relay candidate could communicate over Controller-owned stdio rather than opening general role egress; that is a design proposal, not a measured network claim.

```mermaid
flowchart TB
  O[Operator browser consent] --> C[Trusted Controller OAuth lifecycle]
  C --> S[Protected external credential store]
  C -. future bounded authenticated channel .-> M[Codex model transport arrangement]
  M -. future tool delegation .-> R[Controller-authorized docker_isolated runner]
  R --> D[Untrusted role workspace and generated tools]
  C -. future fixed OpenAI model route .-> API[Official OpenAI endpoint]
```

Solid arrows describe implemented OAuth/runner building blocks. Dotted arrows remain unimplemented integration. The new OAuth code never launches Codex or dispatches model inference.

## Implemented OAuth and credential lifecycle

`agent_system/chatgpt_oauth.py` implements the public-client lifecycle as a library; no workflow automatically invokes it:

1. Initialize a protected Controller directory outside **all caller-supplied repository and role-mount roots**. Reject symlinks/reparse points. Persist a UUID host ID.
2. Start the loopback listener before handing the authorization URL to the caller's browser opener. Generate fresh state, nonce and PKCE verifier/challenge.
3. First login uses `dynamic_agent_client` and the real application name. Validate callback location, duplicate query fields, state, expiry, denial, code and issued registration.
4. Persist issued client ID before exchanging the one-use code. An expired code does not discard registration. Returning authorization retains the issued-client/account binding; workspace identity is represented by that registration, not inferred from email.
5. Verify ID token using maintained PyJWT, the exact issuer/JWKS path, RS256 signature, audience, expiry, subject, nonce and multi-audience authorized-party check. Unexpected key algorithms fail closed.
6. Persist credentials atomically; public status contains no tokens. Missing plan scope leaves identity connected but inference disabled.

Windows creation removes unrelated explicit DACL entries and verifies access is limited to current SID and SYSTEM. POSIX requires directory 0700 and writes files 0600. Windows PowerShell is launched with its own module search path to avoid inherited PowerShell 7 incompatibility. Storage is protected plaintext, not an OS credential vault; trusted same-user host processes remain trusted. The library relies on the Controller to supply the complete forbidden-root set and is not yet wired into the workflow CLI.

Refresh is serialized using an exclusive storage lock, submits the issued client and resource without changing scopes, validates the response and atomically replaces the renewable token. Terminal refresh errors clear unusable tokens; transient failures retain them. Stale locks fail closed for operator inspection. `earliest_refresh_at` is stored opaquely; automatic scheduling is not implemented.

Disconnect uses validated discovery for revocation, then deletes local tokens. On remote failure it explicitly reports unconfirmed revocation and directs the user to ChatGPT Settings. Local-only deletion makes no remote-revocation claim. Host/client identifiers remain for reauthorization. The [self-hosted guidance](https://developers.openai.com/siwc/token-sharing-open-source/self-hosted-vms) does not authorize importing this user's existing Codex cache; none was imported.

The auth HTTP client permits only documented issuer endpoints and validated issuer-side revocation, disables inherited proxies/redirects and bounds response size/time. Exceptions expose allowlisted machine codes, not upstream prose. No bearer value is passed in argv, a prompt, role environment or evidence export. Synthetic test captures are not real credentials. Existing `CredentialLease` redaction remains defense in depth; its raw/escaped-token and partial-protocol tests still pass.

## App-server integration contract and tool boundary

Official provider configuration, recorded for future trusted-side integration only:

```toml
model_provider = "openai_chatgpt_plan"
[model_providers.openai_chatgpt_plan]
name = "ChatGPT plan"
base_url = "https://api.openai.com/v1"
env_key = "ACCESS_TOKEN"
wire_api = "responses"
requires_openai_auth = false
supports_websockets = false
```

The documented server invocation is `codex app-server --listen stdio://`. Its JSONL protocol initializes the client, then starts a thread and turn with an explicit model. Agent-message deltas are intermediate; successful turn completion is authoritative. Refreshed child environment credentials require server restart and thread resume. This configuration was **not launched for an agent turn**. [Official integration](https://developers.openai.com/siwc/token-sharing-open-source/codex-app-server)

`agent_system/chatgpt_plan_transport.py` contains deliberately non-launching prototypes:

- `PlanModelBoundary`: binds role/task/execution/model, rejects arbitrary URL/unsupported request fields and hosted tools, enforces input bytes, request count and expiry. Identity fields alone are not channel authentication. No HTTP dispatch, token access or generic proxy exists.
- `IsolatedToolBridge`: accepts bounded argv with Controller-selected workspace and identity, calls `docker_isolated` capability admission and the existing read-only runner, supplies an empty environment, and has no host fallback. Mutations still require the established role lifecycle.
- `AppServerBoundary`: declines built-in shell/file approvals, rejects unknown dynamic requests and blocks `turn/start`. It does not pretend that an approval result reroutes a tool.

Tests with a runner double fail if generated-tool execution calls a host subprocess. They prove this helper's routing and denial behavior; they do not prove full app-server wiring, generated repository edits, remote code-mode execution, process cleanup or a kernel boundary for a new runtime.

## Network, usage and fresh admission

Existing active Docker network remains `none`; no HOME/`.codex` mount, image or isolation implementation changed. The Stage 17 pinned image still has no Codex binary. No new image was built because the live execution arrangement remains unresolved. A new relay/runtime/image/network binding must receive fresh filesystem read/write, HOME, Controller store, holdout, Git, instruction visibility, network, import/tool and cleanup probes. Historical Stage 17 evidence is **not** admission for it. New transport admission results: **NOT RUN / NOT ADMITTED**.

Local request count, input size, tool timeout and execution expiry are policy ceilings, not proof of remaining plan quota or monetary cost. Existing invocation ceilings must also be checked when a live launcher is integrated. No usage amount is fabricated. The framework never enables a credits setting and currently denies all inference. Until the credit policy is authoritatively verified, it cannot guarantee an allowed live request will avoid credits. There is no API-key or paid-route fallback.

Threat model includes generated-code access to same-UID secrets, broad broker abuse, identity replay, arbitrary host tools, credential-bearing error output, arbitrary endpoint forwarding and quota exhaustion. Current denial policies limit those surfaces by leaving the live integration disabled. They are not acceptance evidence for an implemented relay.

## Validation and regression

Final focused run: **102 passed**, no failures/errors/skips. Evidence: `docs/stage18-chatgpt-evidence/focused-final-pass.xml`. Covers registration, state/PKCE rejection, replay/expiry/denial, malformed callback/token response, rotation and refresh failures, disconnect, safe HTTP errors, actual Windows protected storage and a real loopback listener with a synthetic browser and mock token exchange.

Opt-in cryptographic run: **10 passed**, using PyJWT **2.15.1**, cryptography **50.0.2** and synthetic RSA keys. Covers valid signature plus wrong signature, expiry, nonce, audience, issuer, key ID, algorithm, missing subject and ambiguous multi-audience. Evidence: `docs/stage18-chatgpt-evidence/signatures-complete.xml`. No external requests.

Earlier failed test runs are retained as diagnostics. Final tests fix both inherited ACL grants and PowerShell module-loading behavior; failed runs are not counted as passes.

The recent full offline baseline finished with **266 passed**. Its exact node-ID union with the final 102-test focused rerun covers **all 328 current default tests**, with no missing nodes. This is cumulative coverage, not a claim that all 328 ran in one fresh full run. The 10 opt-in signature cases are additional. Historical real-Docker tests were not rerun; no new Docker acceptance is claimed. Reproducible coverage: `validation/stage18_chatgpt_assessment.py`; exact node lists: `docs/stage18-chatgpt-evidence/coverage.json`.

## Remaining work and completion decision

The applicable official auth flow has been researched and implemented as a testable library. Stage 18 is **not complete**. Remaining work is concrete:

1. Select and prove a supported Codex execution arrangement that routes every shell/file operation through `docker_isolated`.
2. Implement the authenticated bounded model channel with upstream bearer/refresh secrets retained on the trusted side.
3. Resolve the no-credits guarantee through an authoritative control or verified required operator setting.
4. Pin the required Linux runtime, bind all changed capabilities and obtain fresh isolation/network/cleanup evidence.
5. Integrate result/stream validation and existing invocation ceilings, then assess technical readiness. Separate explicit Stage 19 authorization is still required before any inference.

No documented incompatibility justifies abandoning ChatGPT-plan OAuth for an API key. No OAuth test proves model entitlement, real-agent behavior or available quota.
