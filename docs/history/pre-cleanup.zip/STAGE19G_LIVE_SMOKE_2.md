# Stage19g — Second authorized smoke

**FAIL_EXECUTABLE_RESPONSE_VALIDATION.** `stage19g-smoke-2` ran one Codex turn with `gpt-6-astra / low`. One bounded Responses request returned HTTP 200 and one function call. The independent upstream validator rejected the executable response before releasing it to Codex. No Docker mutation or verification ran; project acceptance was not reached. The allowance is consumed; no retry or Stage20 execution is scheduled.

Two smoke preparation defects were fixed: the Controller now sets `tool_choice` to `required`, `required`, then `none`, with parallel calls disabled; LF characters inside the prepared Python string literals are correctly escaped. The derived proposal preserves the intended two commands, file, expected bytes and stdout. The original proposal and first execution remain unchanged. The tool-choice behavior follows the [official OpenAI function-calling documentation](https://developers.openai.com/api/docs/guides/function-calling#tool-choice).

41 driver checks and one real Codex/Docker test with synthetic provider responses passed. That test completed both exact commands, both tool results and the structured final result. Its first local run exposed the invalid Python escaping; the failure is retained in `roundtrip-initial-invalid-argv.xml`. No live inference occurred during local tests.

Before live inference, current production sources matched the accepted Stage19g manifest; signed transport admission and current Codex/Docker image/engine/config/project bindings were verified. Valid protected OAuth credentials and the current account catalog confirmed the requested model/effort. A new exclusive latch and fresh execution/client-bound live/no-credit signatures were created. The original human billing-confirmation timestamp was retained unchanged.

| Live observation | Result |
|---|---|
| Responses / HTTP / response bytes | 1 / 200 / 63,326 |
| First request tool choice | required |
| Function calls seen / tools dispatched | 1 / 0 |
| Non-executable stream/final difference | Recorded; continued |
| Executable response validation | Rejected before dispatch |
| Body EOF / reader shutdown / secret scan | Confirmed |
| Primary, disposable workspace and credentials | Unchanged |
| Codex process/home, owned Docker/role resources | Cleaned up; zero stale containers |
| Automatic retries / Stage20 execution | 0 / none |

The compact metadata records `unsafe_executable_authority`, but does not retain the specific failed validation rule. It therefore supports rejection of the executable response, not a diagnosis of the exact provider discrepancy or proof that a dangerous command ran. No unauthorized capability was exercised. Raw provider payloads, model prose, arguments and identifiers were not saved. Strict non-executable lifecycle enforcement was not restored.

- Stage19 passed: **false**.
- Stage20 technically admissible: **false**.
- Stage20 started: **false**.

Evidence: [execution](docs/stage19g-live-smoke-2-evidence/execution.json), [assessment](docs/stage19g-live-smoke-2-evidence/assessment.json), [derived proposal](docs/stage19g-live-smoke-2-evidence/prepared-smoke.json), [driver checks](docs/stage19g-live-smoke-2-evidence/driver.xml), [real offline roundtrip](docs/stage19g-live-smoke-2-evidence/offline-roundtrip.json), [catalog](docs/stage19g-live-smoke-2-evidence/catalog.json).
