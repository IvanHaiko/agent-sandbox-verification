# Stage 19 — Authorized minimal live smoke

Date: 2026-10-05, Europe/Berlin. Final verdict: **FAIL_LIVE_TRANSPORT**.

OAuth is connected. Two separately authorized executions sent **two real Responses requests**, both receiving HTTP 200. Neither produced a completed gated response or a dynamic tool call. The second attempt established the denial: the provider returned **Content-Type: text/plain**, while the existing transport requires **text/event-stream**. It rejected the response before reading its body. No more live attempts were made; Stage 20 was not started.

[Machine-readable assessment](STAGE19_AUTHORIZED_LIVE_SMOKE.json) · [First execution](docs/stage19-evidence/live-observations.json) · [Separately authorized second execution](docs/stage19-evidence/second-live-observations.json).

## 1. OAuth connection

Real Sign in with ChatGPT connection succeeded after two initial failed OAuth attempts. The unchanged verifier checked RS256 signature, issuer/audience/time claims, subject, nonce and authorized party. Plan permission was obtained; protected Controller credentials are persisted with verified ACL. Account/client identity is represented by hashes in evidence. No refresh occurred during either execution. Earlier OAuth failures remain historical; their root cause is unestablished.

[OAuth observations](docs/stage19-evidence/oauth-reconnection.json). The existing public-client flow uses no API key. [Official sign-in contract](https://developers.openai.com/siwc/token-sharing-open-source/sign-in).

## 2. Inference observations

Two real inference requests were sent to the fixed `https://api.openai.com/v1/responses` route using Controller-owned OAuth. Both returned HTTP 200. Successful backend reasoning/completion is **unproven**: no completed model response was observed, and the second response body was deliberately not read after MIME rejection. HTTP 200 is not treated as evidence of a completed model execution.

## 3. Execution count and authorization

Two live role/session execution attempts, one Responses request each. The second followed the user's explicit “попробуй еще раз” instruction after the first failure. They used the same disposable task, model and reasoning, with separate execution IDs `c0-implementation-r0-t1` and `c0-implementation-r0-t2`. Each had exact signed live authorization and current signed no-credit attestation. No automatic retries, model changes, fix cycles or full permanent-role workflow ran.

## 4. Exact model/reasoning

Both requested **gpt-6-astra / low**. No fallback or rerouting occurred. One informational native Codex warning per attempt was counted; its prose is discarded by the existing session. The provider's completed-model identifier and actual reasoning behavior are unavailable.

## 5. Entitlement

One authenticated account-specific `/v1/models` request listed `gpt-6-astra` and its `low` reasoning option. Catalog entitlement is proven; successful inference acceptance remains unproven. [Catalog evidence](docs/stage19-evidence/account-catalog.json). The account catalog, not configured aliases or a cached native list, supplied this choice. [Official discovery/inference contract](https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference).

## 6. Dynamic Docker tool boundary

**Not reached live.** Both attempts had zero gated tool calls and zero bridge executions. No live model-selected shell/file action occurred. Fresh synthetic native Codex/Docker tests proved the routing and canonical call-ID/argument checks for the exact runtime binding, but are not relabeled as a successful live path.

## 7. Host execution

The host execution trap observed no model-selected host command. Trusted Git, Docker, native Codex and exact ACL/cleanup helpers were allowed. Roles retain `network none`; no generic proxy, host HOME/.codex mount, credential forwarding or host fallback was added. Stage 18c production sources remain hash-identical.

## 8. Credentials

Access/refresh/ID tokens remained in protected Controller storage and memory. Codex received only its ephemeral local channel credential. No credential escape was observed; known current token values were absent from the scoped scan of exported evidence, source files, owned checkout and invocation records. No raw body, stderr, JWT, token or provider error prose was exported. A real live-role token-visibility probe was not reached, so that live guarantee is not claimed from these failed attempts.

## 9. Disposable task

The disposable `STAGE19-SMOKE` repository supplies `src/example.py` with `value = 1`. The model was asked to inspect it, set the value to 2, verify with a standard-library Python assertion and return the existing strict implementation result. Both stopped before any tool. The source and owned checkout remain at value 1; owned Git status is clean. The task **did not complete**. The framework repository was not a model workspace.

## 10. Cleanup and telemetry

Both Codex processes exited; both ephemeral model-home directories were removed. No owned containers survived and no live role container was started. Persistent credentials are intentionally retained in the protected account store. Existing immutable start evidence was used to finalize failure AgentResult/telemetry offline; durations derive from start evidence and final-observation artifact timestamps. Usage is unavailable rather than fabricated. Original execution observations were preserved.

## 11. Usage

Observed: two executions attempted, two Responses requests, HTTP statuses `[200, 200]`, zero tool calls, zero completed model responses. No provider token/usage fields were received. Input/output/total tokens, remaining quota and monetary cost are **unknown**. No estimate or cost conversion is made; failed requests might still have affected plan usage.

## 12. Credits/billing

The operator explicitly confirmed the required app-credit-fallback setting disabled. Fresh client/execution-bound HMAC attestations and separate exact live authorizations were issued for both attempts. There was no API-key/paid-route fallback. Account-setting state is operator-attested, not programmatically controlled; actual quota/billing effects remain unknown. [Official account controls](https://learn.chatgpt.com/docs/sign-in-with-chatgpt).

## 13. Fresh admission and final security regression

Before the first request, **13 OS capabilities and 9 transport/security facts passed**, with signed admission for the exact disposable project, image, engine, source bundle and native binary. Actual native runtime was **codex-cli 0.160.0**, SHA256 `4b01d5920e6785614727443bbecf343f4dedbb7347052b72ba805aab6353ef01`. This differs from the historical 0.159.2 binary, so fresh admission was required and performed. The original Stage 18c checkpoint remains unchanged.

After the second request, **150 focused cases passed** and a comprehensive fresh real-Docker security case passed all 13 OS capabilities and 9 transport facts again. These tests use synthetic models, never a live account. They cover credential/path visibility, fixed endpoints, dispatch/host fallback, replay, role network, timeout/cancellation/overflow cleanup and secret rejection. No failures/errors/skips in final successful regression evidence.

[Live-target admission](docs/stage19-evidence/fresh-admission.json) · [Final focused tests](docs/stage19-evidence/final-focused.xml) · [Post-second Docker evidence](docs/stage19-evidence/post-second-live-security.json) · [JUnit](docs/stage19-evidence/post-second-live-security.xml).

## 14. Deviations and precise limitation

The provider response MIME type conflicts with the current transport's strict assumption. The exact body format and why it was labeled text/plain are **unknown**, since rejection occurred before reading. It might be a stream or a different response; neither is asserted. Official SIWC documentation requires a streaming response through completion, but this task did not establish that arbitrary text/plain bodies are safe compatible responses.

Initial live diagnostics were insufficient. The separately authorized second attempt added metadata-only diagnostics in the opt-in wrapper and identified the MIME rejection; no production verifier/gate was relaxed. The only extra live execution was explicitly authorized. Native runtime drift was handled through fresh admission. No full workflow or Stage 20 was started.

## 15. Verdict and next step

**FAIL_LIVE_TRANSPORT**. Stage 19 is evaluated but **not passed**; Stage 20 is **not technically admissible from this evidence**.

Next: offline review of MIME/stream compatibility and a bounded diagnostic design that retains strict SSE, identity, credential and tool validation. Do not simply allow text/plain or replay the requests. Any further live execution requires separate explicit authorization. A successful minimal smoke would still prove only the narrow path, not multi-agent correctness, performance, billing efficiency or framework v1 readiness.
