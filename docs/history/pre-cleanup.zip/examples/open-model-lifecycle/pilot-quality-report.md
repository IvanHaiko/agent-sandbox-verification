# Project-owned pilot contract — adaptation required

This is an inspection-only derived-partition diagnostic, not a historical-data migration.
Copy this contract to `docs/contracts/pilot-quality-report.md` in the actual OML
repository after resolving every item below from its existing public contracts.
The repository has not been supplied, so no current source layout or semantics are asserted.

Required decisions before running:

- Name the existing partition reader and its public callable/command interface.
- Reference the authoritative observation key, required fields and timestamp rules.
- Define the input manifest count (records, observations or unique keys) and null handling.
- Specify the bounded partition input format and synthetic fixture construction.
- Specify the report interface: counts, stable record locations, error categories,
  deterministic ordering, and zero/nonzero exit status. Keep version 1 additive.
- Specify exception behavior and verify every historical input remains read-only.

The diagnostic must surface duplicate keys, required-field failures and manifest
count mismatches. It must handle empty input and repeated inspection deterministically.
It must never repair or rewrite records, read credentials, dump the environment,
or access a remote service. Tests use synthetic samples rather than production data.

Changing entity identity, temporal meaning, source interpretation, partition format,
historical schemas or compatibility requires a new architecture-sensitive contract
and explicit human selection through the ordinary architecture gate.
