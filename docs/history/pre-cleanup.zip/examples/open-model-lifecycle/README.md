# Open Model Lifecycle pilot

Status: **BLOCKED_BY_ENVIRONMENT — actual OML repository unavailable**.
This portable configuration is a complete executable-contract template. Paths
containing `REPLACE_WITH_` must be replaced from the actual repository before use.
The existing `temporal`, `silver`, `gold`, `collector` and `schemas` patterns are
illustrative configuration from the earlier example; verify them against OML.
Do not treat this folder as evidence that an OML implementation exists here.

The first candidate adds a bounded, read-only partition reconciliation diagnostic.
This is useful production hardening: it detects count mismatches, duplicate keys
and required-field errors without changing historical data or redefining identity.
Independent Tester freezes synthetic acceptance cases before implementation;
Data Auditor checks lineage, idempotency, temporal compatibility and no-write
behavior. It is data-critical, while documentation paths alone do not trigger audit.

Adapt `project.yaml`, protected historical roots, context files and commands to the
actual repository. Resolve `pilot-quality-report.md` against its existing public
observation contract. Commit those files plus the task in OML, and ignore
`.agent_runs/` and `.agent_worktrees/`. Keep machine-local paths out of committed examples.
Explicitly configure literal CLI identifiers in `.agent_system/models.yaml`;
`models.yaml` preserves the agreed Astra Medium / Sol High role profile using
candidate identifiers, whose live availability has not been verified.

```powershell
agentctl --project C:/path/to/oml pilot-preflight C:/path/to/oml/pilot-task.yaml
agentctl --project C:/path/to/oml pilot C:/path/to/oml/pilot-task.yaml --allow-live
agentctl --project C:/path/to/oml status OML-QUALITY-PILOT-001
agentctl --project C:/path/to/oml evaluate OML-QUALITY-PILOT-001 --json
agentctl --project C:/path/to/oml pilot-report OML-QUALITY-PILOT-001 --json
```

Preflight makes no model call. It checks the clean committed baseline, contracts,
context, protected paths, routing syntax, local command/module availability,
usage limits, CLI flags and authentication. Model entitlement can only be verified
by successful inference; no fallback is permitted. The pilot uses the ordinary
workflow and stops at human gates. Use existing `approve-architecture`, `resume`
and `approve-completion` commands after inspecting their concrete evidence.

Task telemetry/evaluation snapshots survive every stop. After completion,
`telemetry/aggregate.json`, `evaluation/report.json` and `evaluation/pilot_report.json` contain measured routing,
usage, durations, test results, review/audit findings and conservative attribution.
The validation attempt also has a local JSON/Markdown report under
`.agent_runs/validations/`. A pending human gate is explicitly recorded and is
not a successful pilot; final task reports after approval are the authoritative outcome.

The invocation ceiling covers all attempts and retries. One repair cycle is
allowed here, subject to the framework's absolute two-cycle maximum. A budget
that prevents another mandatory call fails closed with `LIVE_USAGE_LIMIT_REACHED`.
It never bypasses tests, review, audit or completion approval.

No real pilot or routing benchmark has occurred. One future pilot cannot establish
model superiority, excessive testing duplication, subjective code quality or
justify removing a role. Inspect exact overlap/confirmed findings and preserve
unknown causal attribution. Further routing runs require separate explicit actions.
