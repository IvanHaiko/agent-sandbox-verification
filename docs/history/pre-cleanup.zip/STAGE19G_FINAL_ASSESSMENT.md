# Stage19g — Final smoke assessment

**Stage19 passed: true. Stage20 technically admissible: true. Stage20 started: false.**

`stage19g-smoke-8` completed the authorized live path using `gpt-6-astra / low`: three sequential Responses requests (all HTTP 200), one Codex turn and exactly two successful `agentctl.agentctl_execute` calls. No automatic retries or alternate model/reasoning were used.

The working variant gives the model two fixed selectors, `stage19-mutate` and `stage19-verify`. The Controller validates their complete execution-bound arguments and maps each to its unchanged prepared Python command. It runs neither extra arguments nor arbitrary replacement commands. This resolver is confined to the smoke driver; production runner capabilities were not expanded.

Only disposable `src/example.py` changed. Its bytes are exactly `value = 2\n`, and the verification confirmed the public Python value is 2. Mutation and verification each returned 0, with stdout exactly `stage19-mutated\n` and `stage19-verified\n`. The final structured result exactly matched the prepared contract. Project acceptance, unchanged primary workspace/credentials and cleanup all passed; zero owned containers remained.

The preceding `stage19g-smoke-7` tested direct argv copying with stronger instructions. Its `python` and `-c` matched, but the script was 31 characters shorter and did not parse as Python. It was blocked before Docker. The selector variant removes that reproduction problem. Direct raw-argv copying and the earlier HTTP 400 cause remain unresolved; they do not establish a capability failure in the successful fixed-action path.

Current source, Codex executable, Docker image/engine/config/project bindings and signed admission were verified before inference. Expired OAuth credentials were reconnected through official browser login before either live attempt; credentials stayed protected. Fresh execution/client-bound authorizations and exclusive latches were used, retaining the original human confirmation that credit fallback is OFF.

Harmless stream/final message variation, completed tool omission from the final summary, and absent MIME were recorded and tolerated. Exact executable authority, identity, replay, output and project checks remained enforced. The variants passed 43 and 49 distinct local checks respectively, including real Codex/Docker roundtrips with a synthetic provider.

Two of the five newly authorized live tests were used. Work stopped after success; three remain unused and none is scheduled. Stage20 was not started.

Evidence: [successful execution](docs/stage19g-smoke-8-evidence/execution.json), [assessment](docs/stage19g-smoke-8-evidence/assessment.json), [local checks](docs/stage19g-smoke-8-evidence/roundtrip.xml), [failed direct-copy variant](docs/stage19g-smoke-7-evidence/assessment.json). Previous assessments are preserved in `docs/stage19g-additional-tests-evidence`.
