# Stage19b — Completed authorized quarantine capture

Date: 2026-10-06. Result: **CAPTURE_COMPLETED_TRANSPORT_REJECTED**.

Exactly one authorized diagnostic POST was dispatched using `gpt-6-astra`, reasoning `low`, to the fixed Responses route. The restored OAuth session required no refresh. HTTP200 was received. There was no retry, live Codex consumer, model-selected tool execution or inference acceptance. Historical Stage19/19b assessments remain unchanged.

## Concrete finding

The standard-library parsed response-header collection contained **zero Content-Type headers**. CPython's `get_content_type()` therefore returned its default **`text/plain`**. This establishes the local rejection chain for this request:

`no recognized Content-Type -> library default text/plain -> existing strict MIME rejection`.

The captured body prefix was **SSE-like**, with an `event:` line, a `data:` line and a recognizable `response.` event prefix. It was UTF-8. This contradicts the assumption that a parsed plain MIME necessarily denotes ordinary prose. It does not prove that the complete body was a valid Responses stream.

The observer read **5,537 decoded body bytes across eight reads**, then stopped at its eight-chunk ceiling. The prefix ended inside a frame/data value: no complete data object or final frame suffix was established. `malformed_or_partial_data: true` therefore means incomplete/ambiguous captured data; it must not be interpreted as proof that the original complete upstream stream was malformed. Transfer-Encoding was chunked; no Content-Length or Content-Encoding was reported.

The body stayed in bounded Controller memory and was discarded. Only safe header enums/presence/counts, framing metadata, read bounds/stop/shutdown state and a secret-checked prefix hash were retained. No body text, event contents, function arguments, request/account identifiers or credentials were written to project evidence.

## What this resolves and leaves unknown

The immediate MIME refusal is now explained for this diagnostic request: the client default arose from an absent recognized MIME header. The old Stage19 evidence is consistent with this explanation, but did not retain raw header presence or body, so its two responses cannot be retroactively classified as identical.

Raw wire header bytes were not retained; ignored or malformed header lines cannot be excluded. The reason the provider/intermediary supplied no recognized Content-Type is UNKNOWN. Full event sequence, schema/completion validity, model acceptance/completion, usage and cost remain UNKNOWN. The previously identified flat-function versus SIWC namespace guidance gap has not been proven causal.

## Authorization, execution and cleanup

The renewed human request authorized this new diagnostic after reconnection. A new execution ID and exclusive persisted latch were used; the earlier auth-blocked attempt and its latch were preserved. Fresh signed live, diagnostic, frozen-body and client-bound no-credit grants were issued and subsequently reverified. The frozen request hash, pinned native executable, entrypoint, observer and existing transport/isolation binding matched.

Six entrypoint tests passed after adding the separately authorized second-attempt route. The existing 40 observer tests and fresh synthetic Docker/native admission supplied the unchanged capture/isolation evidence. Before sending the request, native Codex prepared its body against localhost synthetic responses and exited; no live response reached Codex, relay response validation or the tool bridge.

Post-execution checks confirmed reader shutdown, disposable native-home removal, no stale owned containers, unchanged owned baseline `value = 1`, and all 22 historical hashes. Production sources and MIME acceptance semantics were not relaxed. Across the task history, Stage19 dispatched two Responses requests and this diagnostic dispatched one; the earlier auth-blocked diagnostic dispatched zero.

## Consequence

Stage19 remains **FAIL_LIVE_TRANSPORT** and Stage20 remains inadmissible. A completed diagnostic is not a passed live smoke.

The next engineering decision can now focus on **missing MIME headers**, rather than blindly treating this response as ordinary text. A separate reviewed proposal should establish the provider's header contract, or narrowly allow missing MIME only after full existing bounded SSE/event/schema/completion and tool-call validation with fresh adversarial admission. Prefix sniffing alone is insufficient. No such acceptance change or additional request was executed here.

[Structured assessment](STAGE19B_CAPTURE_RESULT.json) · [Capture evidence](docs/stage19b-capture-evidence/attempt-2/capture.json).
