# Stage19g â€” Simplified enforcement

**PASS_OFFLINE; one live smoke proposed, not executed.** The contained synthetic path uses real Codex and Docker. No OpenAI inference, credential refresh, billing attestation, retry or Stage20 run was performed.

## What changed

Stage19e received HTTP 200 and completed SSE, but exact non-executable stream/final inventory reconciliation stopped the run before tools. Production now treats message/reasoning identity, index, count and snapshot differences as observations. Sequence and harmless metadata variations also continue. A normal completion and safely parsed, bounded body are still required.

`responses_lifecycle.py` keeps executable records only. Non-executable snapshots supply one compact mismatch observation; they never authorize tools. Exact non-executable added/done/final reconstruction and shared lifecycle enforcement were removed. Executable final indices are presentation: final calls match logical call IDs. Optional arguments-done/item-done events are unnecessary when complete final arguments satisfy the exact schema and all known snapshots agree. Complete final-only calls are supported. Known conflicting fragments or snapshots still block.

`codex_tool_session.py` observes message stream/final differences, malformed optional message deltas and unknown informational notifications. Server requests, execution identities and final result validation remain enforced. `chatgpt_plan.py` stores compact observations alongside existing transport telemetry; an optional observation-file write failure cannot veto the result. Missing/nonstandard MIME is recorded after safe parsing. Bounded HTTP error diagnostics are unchanged.

The previous production conformance matrix is archived at `docs/stage19g-evidence/test_stage19d_conformance.before.py`. Ten focused tests replace it in `tests/test_stage19g_enforcement.py`; historical reports and the frozen Stage19c tests remain. No second lifecycle state machine was introduced.

## Enforcement and observation

| Class | Action | Concrete reason |
|---|---|---|
| SECURITY_CAPABILITY | BLOCKING_VIOLATION / block | Unknown/hosted/wrong-namespace tools; identity/workspace/read-only escalation; mismatched executable arguments; logical-call replay; ambiguous executable fragments; credentials; unauthorized route; resource limits. |
| PROJECT_INTEGRITY | Do not accept result | Unexpected/protected diff, missing expected mutation, failed required verification, malformed/incorrect structured result, independent Tester/Reviewer failures. Existing Controller gates remain. |
| PROTOCOL_OBSERVATION | ANOMALY / continue | Non-executable lifecycle/snapshot differences, sequence anomalies, harmless metadata, absent Content-Type, optional events and Codex message differences. |

Retained parser/HTTP rejections prevent releasing opaque, truncated, unbounded or explicitly unsupported input to Codex. Missing/unsuccessful completion prevents obtaining a valid result. Identity checks prevent authorizing a call from another execution or response. Function inventory checks prevent executing an observed call omitted or contradicted by final authority. Unsupported non-executable categories remain outside the allowlist. These are capability/result boundaries, not requirements for ideal message history.

OAuth stays Controller-owned; generated commands only enter the measured Docker runner. There is no host fallback, role network, credential injection, model-selected workspace or authority escalation. Existing limits, output filtering, export checks, signed approvals and owned-resource cleanup remain unchanged. Anomalies contain fixed reason/category/action codes, scope and involvement flags; unknown mutation state is null. No provider IDs, arguments, reasoning, prose or credentials are added to telemetry.

## Focused evidence

| Check | Result | Evidence |
|---|---|---|
| Transport, safe HTTP errors, capability/working path | 112 passed (includes 10 replacement tests) | `docs/stage19g-evidence/focused.xml` |
| Existing boundary, Docker, isolation and hardened workflow checks | 149 passed; overlaps the transport set | `docs/stage19g-evidence/core.xml` |
| Intended acceptance, unexpected integration file, failed required tests | 3 passed | `docs/stage19g-evidence/acceptance.xml` |
| Existing real Docker capability, protected Controller key and timeout cleanup checks | 3 passed | `docs/stage19g-evidence/real.xml` |
| Real Codex â†’ two sequential Docker calls â†’ verification â†’ structured result, with harmless inventory anomalies | 1 passed | `docs/stage19g-evidence/contained.xml`, `contained-summary.json` |

There are 166 distinct passing test cases across these sets. The real smoke also confirms denied network, no generated host process, rejected unexpected export, unchanged primary project, stopped Codex, removed disposable Codex home and confirmed owned container/storage cleanup. Initial synthetic fixture mistakes (primary checkout selection and use of the role-storage helper for a Codex home) were corrected without weakening production gates. The first real XML contains that initial workspace-fixture failure alongside the three passing isolation tests; the final contained XML is green. A transient final-only-call fixture failure was corrected before the final focused run.

## Limits and exact next smoke

Live SIWC success is unproven. Synthetic provider responses exercise real Codex/Docker but cannot establish current provider behavior. The full historical regression suite was intentionally not required. Source-bound historical live admissions are stale after these edits; no signatures were fabricated. The proposal is concrete; a new single-use live entrypoint and current-source admission must be bound when the live execution is authorized.

Use `docs/stage19g-evidence/prepared-smoke.json` for **stage19g-smoke-1**, **gpt-6-astra / low**, one implementer turn, fixed Responses endpoint, at most three requests, exactly two sequential `agentctl.agentctl_execute` calls, zero retries, 180-second deadline and 1 MiB response/output ceilings. Check current credential/catalog eligibility; stop if unavailable. Obtain the existing required fresh execution/client-bound human no-credit attestation and live authorization; do not reuse Stage19e's consumed receipt.

Call 1 changes only disposable `src/example.py` from `value = 1` to `value = 2`, printing `stage19-mutated`. Call 2 verifies file content and Python public value with a read-only command, printing `stage19-verified`. Accept only both zero return codes, exact outputs, the exact structured result and measured diff `{src/example.py}`; independently confirm primary/credential integrity and cleanup. Harmless anomalies continue. Proceed directly to this one smoke after those execution prerequisites; no new diagnostic matrix or historical campaign. Stage20 remains unauthorized.
