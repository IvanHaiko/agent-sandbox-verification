# Финальная попытка Stage19 №2 — stage19-final-conformance-2

**`FAIL_LIVE_TRANSPORT`**. Первый запрос к публичному Responses endpoint получил **HTTP 400**. Выполнен один запрос из разрешённых трёх, tool calls — **0**. Повторных запросов не было. Execution allowance израсходован, latch сохранён.

**Stage19 passed: false. Stage19: `FAIL_LIVE_TRANSPORT`. Stage20 technically admissible: false.** Stage20 не запускался.

## Авторизация и подготовка

Новая явная авторизация пользователя разрешила один OAuth refresh, затем одну попытку `stage19-final-conformance-2` для `STAGE19-SMOKE`, implementer / implementation, строго `gpt-6-sol` / `low`. Остальные границы исходного proposal сохранены: одна execution/turn, максимум три Responses requests, две точные последовательные tool-команды, parallel calls выключены, без автоматических повторов, альтернативного model/reasoning, дополнительных role команд/файлов, role network, package installation, других ролей или Stage20.

Исправленный новый драйвер принимает LF/CRLF через `read_text()` в точности как утверждённая mutation argv. Его 37 офлайн-тестов прошли. Исходный неудачный драйвер, использованный latch первой попытки и её отчёты не изменены.

Однократный отдельно разрешённый `ChatGPTPlanOAuth.refresh()` прошёл: один token POST, один issuer-discovery GET и один JWKS GET. Использован исходный строгий verifier; client/account совпадают, plan scope присутствует, token действителен для smoke. Переподключения, повторного refresh, model catalog lookup и inference на этом этапе не было. Credentials остались в защищённом Controller storage.

Перед live запросом повторно совпали source bundle, Codex executable, Docker image/engine/config/project binding и подписанный transport proof нового runtime. Чистая исходная fixture с CRLF прошла проверку. Созданы новый exclusive execution latch и fresh signed live/no-credit разрешения. Время нового человеческого подтверждения — **6 октября 2026, 10:48:50 Europe/Berlin** (08:48:50 UTC, первое получение ответа); оно не обновлялось. Client/execution binding и подписи independently reverified после попытки. OFF credit fallback — человеческая аттестация; независимого доказательства billing enforcement нет.

## Фактически достигнутый путь и отказ

Ephemeral Codex app-server запущен, начат один turn. Gate подготовил один Controller-owned namespace `agentctl` с единственной strict function `agentctl_execute` и execution-bound schema, фиксированными model/reasoning и выключенными parallel calls. В публичный `https://api.openai.com/v1/responses` отправлен один POST. Провайдер ответил HTTP 400, после чего Codex остановлен с безопасной общей причиной `Codex/model protocol denied`.

Тело HTTP ошибки закрыто без захвата. Точная причина HTTP 400 **не установлена**, machine error code отсутствует в retained evidence. Нельзя приписать отказ недоступности модели, schema или lifecycle reconciliation. Валидация SSE не началась: нет событий, MIME/body/EOF/usage данных или частично авторизованных calls. HTTP статус и нулевые структурные счётчики сохранены. Произвольные IDs, arguments, model prose, credentials и provider payloads не сохранялись.

## Независимые проверки после попытки

- Tool dispatch, `IsolatedExecutionBridge` и Docker mutation/verification не выполнялись; validated executable calls — 0.
- Owned workspace Git-clean, изменённых файлов нет; public value остаётся 1. Требуемые `value = 2\n`, mutation/verification outputs и успешный strict AgentResult не получены.
- Model-selected host execution, неожиданных tool calls и credential escape не наблюдалось.
- Codex process завершён, ephemeral home удалён, role execution storage для smoke не создавался, stale owned containers — 0.
- Подписанные live/no-credit grants, их client/execution/timestamp bindings и transport proof проверены read-only без новой inference.
- Existing primary/framework и historical baseline совпали в драйвере. Отчёт дополнительно перепроверил **1256** historical files, **147** framework/test/config files и **12** files первой попытки. Production код и исторические отчёты/evidence сохранены; изменения credentials ограничены отдельно разрешённым refresh. Новые драйвер/tests/evidence и этот отдельный отчёт — разрешённые добавления.

## Хеши и evidence

Production bundle SHA256: `255284b0d5d9f8c8de584ba68f2a24ac79500fdc29ab529c6b7ada5df014a544`.

Codex SHA256: `3b8f6e33caa75f232558a3cf76ff9b87bb5ef6dbcf4996372f24e55c78b1b916`.

Executed driver SHA256: `6c56fc4495ee202c2caa37ce197f5bd5328bd5e03ece4bcee2adaa5fbd4e74b7`.

- [Execution record](docs/stage19-final-conformance-2-evidence/execution.json)
- [OAuth refresh result](docs/stage19-final-conformance-2-evidence/oauth-refresh-result.json)
- [Independent post-execution check](docs/stage19-final-conformance-2-evidence/post-execution-check.json)
- [Frozen scope](docs/stage19-final-conformance-2-evidence/prepared-scope.json)
- [New authorization receipt](docs/stage19-final-conformance-2-evidence/authorization.json)
- [Driver admission](docs/stage19-final-conformance-2-evidence/driver-admission.json)
- [37 passing offline tests](docs/stage19-final-conformance-2-evidence/driver-tests.xml)
- [Consumed execution latch](docs/stage19-final-conformance-2-evidence/one-shot-latch)
- [Consumed OAuth refresh latch](docs/stage19-final-conformance-2-evidence/oauth-refresh-latch)
- [Separate JSON assessment](STAGE19_FINAL_CONFORMANCE_SMOKE_2.json)

Live end-to-end успех не достигнут. Реальный function lifecycle не проверен этой попыткой; account availability модели не подтверждена. Повтор, альтернативная модель, переподключение, дальнейший refresh, multi-agent workflow, benchmark и Stage20 не выполнялись. Работа остановлена после этого отчёта.
