# Stage19b — Full response verification

Date: 2026-10-06. Verdict: **FULL_RESPONSE_CAPTURED_STRICT_GATE_REJECTED**.

Exactly one newly authorized Responses POST used `gpt-6-astra`, reasoning `low`. The complete response was read and inspected privately in Controller memory. No live Codex consumer, bridge execution, tool operation or retry occurred. Normal production MIME acceptance did not change.

## Complete HTTP body

HTTP200 again had no recognized Content-Type in the standard-library header collection, so `get_content_type()` returned its `text/plain` default. Transfer-Encoding was chunked.

The observer reached **EOF after 105,349 decoded body bytes in 197 reads**. UTF-8 and the final SSE frame suffix were valid. The configured ceilings were 1 MiB, 60 seconds of body reading, 4,096 reads, a five-second socket idle timeout and at most 5.5 seconds for forced reader shutdown. No ceiling caused truncation. Reader shutdown was confirmed.

Safe event counts were:

| Event | Count |
|---|---:|
| response.created | 1 |
| response.in_progress | 1 |
| response.output_item.added | 2 |
| response.content_part.added | 1 |
| response.output_text.delta | 27 |
| response.output_text.done | 1 |
| response.content_part.done | 1 |
| response.output_item.done | 2 |
| response.function_call_arguments.delta | 127 |
| response.function_call_arguments.done | 1 |
| response.completed | 1 |

This is now a complete captured SSE body, rather than the previous partial prefix. It contains a completion event and streamed tool-related events. That does **not** establish successful strict validation or a passed live engineering smoke.

## Strict gate result

The existing unmodified `ResponsesGate.response` inspected the complete buffered body and raised:

`Partial tool completion`

This exception is emitted when `set(calls) - set(final_calls)` is nonempty: at least one function-call ID gathered from the stream is absent from the final completed response's function-call inventory. It is a semantic reconciliation failure, not an EOF truncation, timeout or missing completion-event failure.

The exact differing call/item IDs, function arguments and response text were deliberately not exported. Consequently the evidence does not establish whether the provider omitted a snapshot item, changed identity, used different tool semantics, or exposed an incorrect assumption in the local gate. No parser or tool-call reconciliation rule was relaxed.

There are therefore **two separate observed barriers**: missing MIME and stream/final tool-call inconsistency. A MIME-only workaround would not make this response pass the existing gate.

## Authority, tests and preservation

The user's instruction to check the full response authorized this separate larger observation scope. New signed full-response and live grants bound one frozen request, the existing runtime, new observer/entrypoint source hashes and explicit limits. The earlier signed client-bound no-credit confirmation was reused with its original timestamp, rather than falsely refreshing the time of the human attestation. It remained valid within the existing 24-hour requirement.

Eleven synthetic tests passed, including complete supported and unsupported streams, invalid UTF-8, secret rejection, byte/timeout bounds, bodies larger than the prior capture ceiling, allowed function calls inspected without execution, and hosted-function rejection. Native request preparation ran only against localhost synthetic responses and finished before the real HTTP request.

Raw full-body bytes and payloads stayed in Controller memory, passed known-secret/canonical JSON checks, and were discarded. Only safe metadata, event counts, full-body hash and the static gate failure were persisted. Signed authority and source hashes were reverified in the separate assessment. Cleanup confirmed zero stale owned containers, disposable native-home removal and unchanged workspace baseline. All 22 historical artifact hashes still match.

Stage19 remains **FAIL_LIVE_TRANSPORT**; Stage20 is inadmissible. Four Responses requests have now been dispatched across the history: two original Stage19 attempts, one bounded-prefix diagnostic and this full-response diagnostic. The earlier auth-blocked attempt dispatched none.

The next useful work is offline analysis of SIWC stream/final-snapshot semantics and the call-reconciliation rule. This execution did not change production acceptance, perform a fix, or issue another request.

[JSON assessment](STAGE19B_FULL_RESPONSE.json) · [Safe execution evidence](docs/stage19b-full-response-evidence/result.json).
