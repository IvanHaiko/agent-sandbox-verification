"""Stage21A deterministic failure, candidate safety and cleanup regressions."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time
from types import SimpleNamespace
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import pytest

from agent_system.agent_transport import InvocationBinding
from agent_system.codex_tool_session import CodexToolSession
from agent_system.errors import AgentSystemError
from agent_system.model_tool_boundary import (ExecutionPolicy, IsolatedExecutionBridge,
    LocalModelRelay, ResponsesGate, SecretFilter)
from agent_system.runtime_observability import diagnostic_directory, safe_failure
from test_model_tool_boundary import body, sse, message, tool_request
from test_hardened_workflow import hardened


CANDIDATE = b'def utility(value):\r\n    return value + 1\r\n'
CANARY = 'synthetic-private-credential-stage21a'
SCHEMA = {'type': 'object', 'properties': {'answer': {'const': 'ok'}},
          'required': ['answer'], 'additionalProperties': False}


class LocalRunner:
    """Deterministic fixture provider; never executes model-supplied commands."""
    backend = 'docker_isolated'

    def __init__(self, root):
        self.config = SimpleNamespace(runtime_root=root / 'runtime' / 'project-id',
                                      project={'protected_paths': []})
        self.code, self.error = 0, None

    def isolation_capabilities(self): return self
    def require(self): pass

    def run_tool(self, argv, workspace, task, role, phase, read_only, stdin, timeout):
        if self.error: raise self.error
        paths = []
        if not read_only:
            path = workspace / 'src/utility.py'
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(CANDIDATE)
            paths = ['src/utility.py']
        cp = subprocess.CompletedProcess([], self.code, 'fixture-ok', '')
        cp.changed_paths = paths
        return cp


def fixture_session(root, monkeypatch):
    runner = LocalRunner(root)
    workspace = runner.config.runtime_root / 'worktrees/TASK/implementer'
    workspace.mkdir(parents=True)
    home = runner.config.runtime_root / 'model-homes/implementer'
    p = ExecutionPolicy(InvocationBinding('failure-fixture', 'implementer', 'TASK', 1,
                        'synthetic-local', 'low'), 'implementation', 'owned', time.monotonic() + 60)
    task = {'scope': {'allowed_paths': ['src/utility.py'], 'forbidden_paths': []},
            'workflow': {'test_paths': ['tests/**']}}
    bridge = IsolatedExecutionBridge(runner, workspace, task, p, SecretFilter([CANARY]))
    gate = ResponsesGate(p)
    upstream = SimpleNamespace(response_metadata_history=[])
    relay = SimpleNamespace(gate=gate, upstream=upstream, failures=[], failure_receipts=[])
    session = CodexToolSession('unused', 'unused', home, relay, bridge, p)

    def start():
        home.mkdir(parents=True)
        (home / 'private-fixture').write_text(CANARY)
        session.thread_id = 'thread'
        session.last_completed_phase = 'thread_started'
        return session
    monkeypatch.setattr(session, '_start', start)
    return session


def fail(session, error):
    with pytest.raises(type(error)):
        with session:
            raise error
    directory = diagnostic_directory(session.bridge)
    receipt = json.loads((directory / 'failure_receipt.json').read_text())
    assert CANARY not in json.dumps(receipt)
    assert receipt['accepted'] is False and receipt['role_status'] == 'failed'
    return directory, receipt


def cleanup(session):
    root = session.bridge.runner.config.runtime_root.resolve()
    assert root.name == 'project-id' and root.parent.name == 'runtime'
    shutil.rmtree(root)
    assert not session.home.exists() and not Path(session.bridge.workspace).exists()


def test_failure_before_any_write_and_cleanup(tmp_path, monkeypatch):
    session = fixture_session(tmp_path, monkeypatch)
    session.failure = 'Malformed, partial or overflowing Codex protocol'
    directory, r = fail(session, AgentSystemError('Codex/model protocol denied'))
    assert r['failure_category'] == 'model_protocol_failure'
    assert r['candidate_preserved'] is False and r['candidate_written'] is False
    cleanup(session)
    assert (directory / 'failure_receipt.json').exists()


def test_write_then_failed_handoff_preserves_exact_bytes_before_cleanup(tmp_path, monkeypatch):
    session = fixture_session(tmp_path, monkeypatch)
    request = {**tool_request(session.policy), 'read_only': False}
    session.bridge.execute(request)
    session.bridge.execute({**request, 'read_only': True})  # optional successful self-check
    directory, r = fail(session, AgentSystemError('Unsuccessful Codex completion'))
    assert r['failure_category'] == 'handoff_finalization_failure'
    assert r['completed_tool_call_count'] == 2
    assert r['candidate_written'] and r['candidate_preserved']
    item = r['candidates'][0]
    assert item['sha256'] == hashlib.sha256(CANDIDATE).hexdigest()
    assert item['status'] == 'unaccepted_diagnostic_candidate' and item['accepted'] is False
    assert (directory / item['archive_path']).read_bytes() == CANDIDATE
    cleanup(session)
    assert (directory / item['archive_path']).read_bytes() == CANDIDATE


def configure_handoff(session, monkeypatch, text):
    monkeypatch.setattr(session, 'rpc', lambda *args: {'turn': {'id': 'turn'}})
    frames = iter([{'method': 'item/completed', 'params': {'threadId': 'thread', 'turnId': 'turn',
        'item': {'id': 'final', 'type': 'agentMessage', 'text': text}}},
        {'method': 'turn/completed', 'params': {'turn': {'id': 'turn', 'status': 'completed'}}}])
    monkeypatch.setattr(session, 'read', lambda: next(frames))


def test_normal_completed_role_unchanged(tmp_path, monkeypatch):
    session = fixture_session(tmp_path, monkeypatch)
    configure_handoff(session, monkeypatch, '{"answer":"ok"}')
    with session:
        session.bridge.execute({**tool_request(session.policy), 'read_only': False})
        assert session.run('fixture', SCHEMA) == {'answer': 'ok'}
    assert session.completed and session.handoff_status == 'completed'
    assert not diagnostic_directory(session.bridge).exists()
    assert (session.bridge.workspace / 'src/utility.py').read_bytes() == CANDIDATE
    cleanup(session)


def test_shutdown_failure_after_handoff_still_preserves_candidate(tmp_path, monkeypatch):
    session = fixture_session(tmp_path, monkeypatch)
    configure_handoff(session, monkeypatch, '{"answer":"ok"}')
    with session:
        session.bridge.execute({**tool_request(session.policy), 'read_only': False})
        assert session.run('fixture', SCHEMA) == {'answer': 'ok'}
    session._preserve_failure(AgentSystemError('Relay shutdown unconfirmed'))
    assert session.failure_receipt['failure_category'] == 'relay_or_session_failure'
    assert session.failure_receipt['candidate_preserved']
    assert session.failure_receipt['accepted'] is False
    cleanup(session)


@pytest.mark.parametrize('text', ['{"answer":"bad"}', 'not-json', '{"answer":"ok","unexpected":1}'])
def test_final_schema_failure_receipt(tmp_path, monkeypatch, text):
    session = fixture_session(tmp_path, monkeypatch)
    configure_handoff(session, monkeypatch, text)
    with pytest.raises(AgentSystemError, match='schema mismatch'):
        with session: session.run('fixture', SCHEMA)
    assert session.failure_receipt['failure_category'] == 'handoff_schema_failure'
    assert session.failure_receipt['last_completed_phase'] == 'turn_completed'
    cleanup(session)


@pytest.mark.parametrize('relative', ['other/private.py', 'tests/test_private.py', '../outside', '.git/config'])
def test_out_of_scope_paths_never_archived(tmp_path, monkeypatch, relative):
    session = fixture_session(tmp_path, monkeypatch)
    # Simulate a bad changed-path record; the archive must independently recheck it.
    session.bridge.successful_write_paths.add(relative)
    directory, r = fail(session, AgentSystemError('Unsuccessful Codex completion'))
    assert not r['candidate_preserved'] and r['candidate_skipped_count'] == 1
    assert not (directory / 'candidates').exists()
    cleanup(session)


def test_untouched_file_or_failed_write_is_not_a_candidate(tmp_path, monkeypatch):
    session = fixture_session(tmp_path, monkeypatch)
    session.bridge.runner.code = 1
    session.bridge.execute({**tool_request(session.policy), 'read_only': False})
    directory, r = fail(session, AgentSystemError('Unsuccessful Codex completion'))
    assert not r['candidate_written'] and not r['candidate_preserved']
    cleanup(session)


def test_tool_execution_failure_retained_without_exception_prose(tmp_path, monkeypatch):
    session = fixture_session(tmp_path, monkeypatch)
    session.bridge.runner.error = OSError('Authorization: Bearer ' + CANARY)
    with pytest.raises(OSError):
        with session: session.bridge.execute(tool_request(session.policy))
    r = session.failure_receipt
    assert r['failure_category'] == 'tool_execution_failure'
    assert r['completed_tool_call_count'] == 0 and not r['candidate_preserved']
    assert CANARY not in json.dumps(r)
    cleanup(session)


def test_tool_request_failure_is_separate(tmp_path, monkeypatch):
    session = fixture_session(tmp_path, monkeypatch)
    with pytest.raises(AgentSystemError):
        with session: session.bridge.execute({**tool_request(session.policy), 'role': 'reviewer'})
    assert session.failure_receipt['failure_category'] == 'tool_request_validation_failure'
    assert session.bridge.calls == 0
    cleanup(session)


def test_unknown_failure_does_not_guess_socket_timeout(tmp_path, monkeypatch):
    session = fixture_session(tmp_path, monkeypatch)
    session.relay.upstream.response_metadata_history = [{'validation_passed': True, 'eof': True,
        'reader_shutdown_confirmed': True}]
    directory, r = fail(session, AgentSystemError('Codex/model protocol denied'))
    assert r['failure_category'] == 'unknown_runtime_failure'
    assert r['eof_observed'] is True and r['reader_shutdown_confirmed'] is True
    assert r['socket_idle_timeout_observed'] is False
    cleanup(session)


def test_secret_candidate_and_raw_error_are_suppressed(tmp_path, monkeypatch):
    session = fixture_session(tmp_path, monkeypatch)
    p = session.bridge.workspace / 'src/utility.py'
    p.parent.mkdir(); p.write_text(CANARY)
    session.bridge.successful_write_paths.add('src/utility.py')
    directory, r = fail(session, AgentSystemError(CANARY + ' socket_idle_timeout'))
    assert r['failure_category'] == 'unknown_runtime_failure' and not r['candidate_preserved']
    assert CANARY not in (directory / 'failure_receipt.json').read_text()
    cleanup(session)


def test_hardlink_candidate_is_not_archived(tmp_path, monkeypatch):
    import os
    session = fixture_session(tmp_path, monkeypatch)
    original = tmp_path / 'private'
    original.write_bytes(CANDIDATE)
    p = session.bridge.workspace / 'src/utility.py'; p.parent.mkdir()
    os.link(original, p)
    session.bridge.successful_write_paths.add('src/utility.py')
    _, r = fail(session, AgentSystemError('Unsuccessful Codex completion'))
    assert not r['candidate_preserved']
    cleanup(session)
    assert original.read_bytes() == CANDIDATE


@pytest.mark.parametrize('kind,expected', [('timeout', 'socket_idle_timeout'),
    ('response', 'response_validation_failure'), ('unknown', 'model_request_failure')])
def test_synthetic_relay_retains_failure_layer(tmp_path, monkeypatch, kind, expected):
    session = fixture_session(tmp_path, monkeypatch)
    class Provider:
        last_response_metadata = {}
        response_metadata_history = []
        def __call__(self, request):
            if kind == 'response': return b'data: {}\n\n'
            self.last_response_metadata = {'body_failure': 'socket_idle_timeout'} if kind == 'timeout' else {}
            self.response_metadata_history.append(self.last_response_metadata)
            raise AgentSystemError('raw-provider-message ' + CANARY)
    provider = Provider()
    with LocalModelRelay(session.relay.gate, provider) as relay:
        session.relay = relay
        request = Request(relay.url + '/responses', data=json.dumps(body(session.policy)).encode(),
                          headers={'Authorization': 'Bearer ' + relay.child_channel()})
        with pytest.raises(HTTPError): urlopen(request, timeout=5)
        directory, r = fail(session, AgentSystemError('Codex/model protocol denied'))
        assert r['failure_category'] == expected
        assert CANARY not in json.dumps(relay.failure_receipts)
    cleanup(session)


def test_startup_failure_also_has_receipt(tmp_path, monkeypatch):
    session = fixture_session(tmp_path, monkeypatch)
    def start(): raise OSError(CANARY)
    monkeypatch.setattr(session, '_start', start)
    with pytest.raises(OSError): session.__enter__()
    assert session.failure_receipt['failure_category'] == 'unknown_runtime_failure'
    assert not session.failure_receipt['candidate_preserved']
    cleanup(session)


def test_parser_denial_does_not_depend_on_harmless_anomalies(tmp_path, monkeypatch):
    session = fixture_session(tmp_path, monkeypatch)
    session.relay.gate.response_metadata_history = [{'validation_passed': True, 'anomalies': [
        {'anomaly_type': name} for name in ('completed_function_omitted_from_final',
            'nonexecutable_stream_final_mismatch', 'nonstandard_or_absent_mime')]}]
    session.failure = 'Malformed, partial or overflowing Codex protocol'
    _, r = fail(session, AgentSystemError('Codex/model protocol denied'))
    assert r['failure_category'] == 'model_protocol_failure'
    assert len(r['protocol_anomaly_counters']) == 3
    cleanup(session)


def test_failed_implementation_never_continues_or_integrates(hardened, monkeypatch):
    from dataclasses import replace
    task, make = hardened
    controller, runner = make()
    original = runner.run
    def failed(*args):
        result = original(*args)
        if args[2]['phase'] == 'implementation':
            return replace(result, status='execution_failed', returncode=None,
                           message='Synthetic failed handoff after successful write')
        return result
    monkeypatch.setattr(runner, 'run', failed)
    state = controller.resume(task['task_id'])
    assert state['state'] == 'FAILED'
    phases = [p for p, _, _ in runner.calls]
    assert phases[-1] == 'implementation' and 'review' not in phases
    wf = controller.workflow(task['task_id'])
    assert not wf.evidence.exists(wf.role_key('implementation') + '/complete')
    assert (wf.git.path('implementer') / 'src/example.py').read_text() == 'value = 2\n'
    assert 'integration' not in state['commits'] or state['commits']['integration'] == state['base_commit']
