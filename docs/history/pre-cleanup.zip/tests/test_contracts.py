from copy import deepcopy

import pytest

from agent_system.config import Configuration, ModelConfig
from agent_system.errors import AgentSystemError
from agent_system.roles import ROLES, Role
from agent_system.storage import contained
from agent_system.task import load_document, load_task, validate


def test_task_contract(task):
    path, expected = task
    assert load_task(path) == expected
    for update in ({"task_id": "../escape"}, {"major_phase": "false"},
                   {"architecture_change_allowed": True}, {"unknown": 1}):
        with pytest.raises(AgentSystemError):
            validate({**expected, **update}, "task")
    bad = deepcopy(expected)
    bad["scope"]["allowed_paths"] = ["../secret"]
    with pytest.raises(AgentSystemError):
        validate(bad, "task")


def test_configuration_driven_routing(project):
    config = Configuration.load(project)
    assert config.model_for(Role.IMPLEMENTER) == ModelConfig("sol", "high")
    config.routing["models"]["implementer"] = {"model": "custom-model", "reasoning": "low"}
    assert config.model_for(Role.IMPLEMENTER) == ModelConfig("custom-model", "low")
    assert ROLES[Role.REVIEWER].read_only
    assert ROLES[Role.DATA_AUDITOR].read_only
    assert not ROLES[Role.UTILITY].gating
    config.routing["automatic_escalation"] = True
    with pytest.raises(AgentSystemError):
        validate(config.routing, "models")


def test_runtime_privacy_config(project):
    value = load_document(project / ".agent_system/project.yaml")
    value["git"]["allow_remote_push"] = True
    with pytest.raises(AgentSystemError):
        validate(value, "project")


@pytest.mark.parametrize("path", ["../escape", "/absolute", "C:/secret", "a\\b", "."])
def test_path_escape_rejected(project, path):
    with pytest.raises(AgentSystemError):
        contained(project, path)

