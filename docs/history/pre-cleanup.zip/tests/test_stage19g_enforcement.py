"""Focused capability/working-path tests; historical protocol matrix is archived."""
import copy
import json
import http.client
import socket
import threading
import time
from types import SimpleNamespace

import pytest

import agent_system.model_tool_boundary as boundary
from agent_system.codex_tool_session import CodexToolSession
from agent_system.errors import AgentSystemError
from test_model_tool_boundary import body, function, message, sse, tool_request, policy
from test_transport_diagnostics import response


def decode(raw):
    return [json.loads(frame.split('data: ', 1)[1]) for frame in raw.decode().strip().split('\n\n')]


def encode(events):
    return ''.join('event: '+v['type']+'\ndata: '+json.dumps(v)+'\n\n' for v in events).encode()


def synthetic_upstream(p, monkeypatch, value, cancel=None):
    credentials = {'access_token': 'synthetic-access-token-123456', 'refresh_token': 'synthetic-refresh-token-123456', 'id_token': 'synthetic-id-token-123456',
                   'client_id': 'oaiapp_fixture', 'scopes': [boundary.PLAN_SCOPE], 'expires_at': time.time()+300}
    class Store:
        def read(self, name): return credentials
    class Approvals:
        def verify(self, name):
            if name.startswith('no-credits/'):
                return {'credits_fallback_disabled': True, 'execution_id': p.binding.execution_id,
                        'client_id': credentials['client_id'], 'operator': 'synthetic', 'attested_at': time.time()}
            return {'authorized': True, **p.identity(), 'model': p.binding.model, 'reasoning': p.binding.reasoning, 'route': boundary.UPSTREAM}
    class Opener:
        def open(self, request, **kwargs):
            assert request.full_url == boundary.UPSTREAM and request.method == 'POST'
            return value
    monkeypatch.setattr(boundary, 'build_opener', lambda *handlers: Opener())
    return boundary.PlanUpstream(Store(), p, Approvals(), lambda: None, cancel)


@pytest.mark.parametrize('mime', [None, 'text/event-stream'])
def test_bounded_http_working_path(policy, monkeypatch, mime):
    raw = sse([function(policy)])
    with response(raw, mime) as peer:
        upstream = synthetic_upstream(policy, monkeypatch, peer)
        gate = boundary.ResponsesGate(policy)
        assert gate.response(upstream(body(policy))) == raw
        assert upstream.last_response_metadata['validation_passed']
        assert upstream.last_response_metadata['missing_mime_tolerated'] == (mime is None)


def test_messages_reasoning_and_observations_do_not_grant_capabilities(policy):
    gate = boundary.ResponsesGate(policy)
    assert gate.response(sse([message()]))
    reasoning = {'type': 'reasoning', 'id': 'r1', 'summary': []}
    events = decode(sse([reasoning, message()], response_id='response-2'))
    events[1]['output_index'] = 99
    events[2]['item']['id'] = 'different'
    events[-1]['response']['output'] = [message('final representation')]
    events.insert(1, {'type': 'response.reasoning_text.delta', 'delta': 'private reasoning'})
    events.insert(1, {'type': 'response.harmless_metadata', 'private': 'never logged'})
    events[2]['sequence_number'] = -1
    gate.response(encode(events))
    assert not gate.authorized_arguments
    assert gate.last_response_metadata['validation_passed']
    observations = gate.last_response_metadata['anomalies']
    assert any(r['reason'] == 'nonexecutable_stream_final_mismatch' for r in observations)
    assert all(r['action'] == 'continue' for r in observations)
    assert 'private reasoning' not in json.dumps(gate.response_metadata_history)
    assert 'never logged' not in json.dumps(gate.response_metadata_history)
    duplicate = decode(sse([message()], response_id='duplicate-terminal'))
    duplicate.append(copy.deepcopy(duplicate[-1]))
    assert boundary.ResponsesGate(policy).response(encode(duplicate))


def test_valid_call_is_independent_of_nonexecutable_history(policy):
    reasoning = {'type': 'reasoning', 'id': 'r1', 'summary': []}
    events = decode(sse([reasoning, function(policy)]))
    events[-1]['response']['output'].pop(0)
    gate = boundary.ResponsesGate(policy)
    gate.response(encode(events))
    assert len(gate.authorized_arguments) == 1
    assert not gate.last_response_metadata['stream_final_bijection']
    assert gate.last_response_metadata['validation_passed']


def test_optional_call_events_and_final_index_are_not_authority(policy):
    events = decode(sse([function(policy)]))
    events = [e for e in events if e['type'] not in ('response.function_call_arguments.done', 'response.output_item.done')]
    assert boundary.ResponsesGate(policy).response(encode(events))
    # A complete schema-valid call can be authorized from the final response alone.
    assert boundary.ResponsesGate(policy).response(encode([events[0], events[-1]]))


def test_executable_argument_change_blocks_atomically(policy):
    gate = boundary.ResponsesGate(policy)
    events = decode(sse([function(policy)]))
    args = tool_request(policy)
    args['argv'] = ['python', '-c', 'print(2)']
    events[-1]['response']['output'][0]['arguments'] = json.dumps(args)
    with pytest.raises(AgentSystemError): gate.response(encode(events))
    assert not gate.authorized_arguments and not gate.seen_calls
    assert any(r['action'] == 'block' and r['executable_content'] for r in gate.last_response_metadata['anomalies'])


def session_for(policy, gate):
    bridge = SimpleNamespace(execute=lambda args: {'returncode': 0, 'stdout': '', 'stderr': ''})
    session = CodexToolSession('unused', 'unused', 'unused', SimpleNamespace(gate=gate), bridge, policy)
    session.thread_id, session.turn_id = 'thread', 'turn'
    session.send = lambda value: None
    return session


def test_two_sequential_calls_and_replay_execute_once(policy):
    gate = boundary.ResponsesGate(policy)
    session = session_for(policy, gate)
    executed = []
    session.bridge.execute = lambda args: (executed.append(args) or {'returncode': 0, 'stdout': '', 'stderr': ''})
    for i in range(2):
        item = function(policy, call_id='call-'+str(i))
        item['id'] = 'fc-'+str(i)
        gate.response(sse([item], response_id='response-'+str(i)))
        call = {'id': i, 'method': 'item/tool/call', 'params': {'threadId': 'thread', 'turnId': 'turn',
                'namespace': boundary.NAMESPACE, 'tool': boundary.TOOL, 'callId': item['call_id'], 'arguments': tool_request(policy)}}
        session.handle(call)
        with pytest.raises(AgentSystemError): session.handle({**call, 'id': 10+i})
    assert len(executed) == 2


def test_codex_message_mismatch_is_observed_but_result_schema_still_checked(policy):
    session = session_for(policy, boundary.ResponsesGate(policy))
    session.handle({'method': 'item/agentMessage/delta', 'params': {'itemId': 'msg', 'delta': 'stream'}})
    session.handle({'method': 'item/completed', 'params': {'item': {'id': 'msg', 'type': 'agentMessage', 'text': '{"bad":true}'}}})
    assert session.observation_metadata['anomalies'][0]['action'] == 'continue'
    session.completed = True
    session.rpc = lambda *args: {'turn': {'id': 'turn'}}
    session.turn_id = None
    session.completed = False
    session.read = lambda: {'method': 'turn/completed', 'params': {'turn': {'id': 'turn', 'status': 'completed'}}}
    session.bridge.secrets = boundary.SecretFilter()
    with pytest.raises(AgentSystemError, match='schema mismatch'): session.run('fixture')


def test_unknown_executable_event_never_becomes_authority(policy):
    events = decode(sse([message()]))
    events.insert(1, {'type': 'response.unknown_capability', 'item': function(policy)})
    gate = boundary.ResponsesGate(policy)
    with pytest.raises(AgentSystemError): gate.response(encode(events))
    assert not gate.authorized_arguments


def test_exact_namespace_and_readonly_authority_remain_enforced(policy):
    item = function(policy)
    item['namespace'] = 'functions'
    with pytest.raises(AgentSystemError): boundary.ResponsesGate(policy).response(sse([item]))
    from dataclasses import replace
    readonly = replace(policy, binding=replace(policy.binding, role='reviewer'), phase='review')
    item = function(readonly)
    args = tool_request(readonly)
    args['read_only'] = False
    item['arguments'] = json.dumps(args)
    with pytest.raises(AgentSystemError): boundary.ResponsesGate(readonly).response(sse([item]))


def test_completed_stream_call_survives_summary_omission_without_payload(policy):
    events = decode(sse([function(policy)]))
    events[-1]['response']['output'] = [message('private provider prose')]
    gate = boundary.ResponsesGate(policy)
    gate.response(encode(events))
    metadata = gate.last_response_metadata
    assert metadata['streamed_function_count'] == metadata['completed_function_snapshots'] == 1
    assert metadata['final_function_count'] == 0
    assert metadata['completed_calls_omitted_from_final'] == 1 and metadata['validation_passed']
    assert len(gate.authorized_arguments) == 1
    assert 'private provider prose' not in json.dumps(metadata)
    assert 'python' not in json.dumps(metadata)
    assert any(a['reason'] == 'completed_function_omitted_from_final' and a['action'] == 'continue' for a in metadata['anomalies'])
    with pytest.raises(AgentSystemError): gate.response(encode(events))  # Never dispatch a replay.


def test_partial_stream_call_omitted_from_final_cannot_authorize(policy):
    events = decode(sse([function(policy)]))
    events = [e for e in events if e['type'] != 'response.output_item.done']
    events[-1]['response']['output'] = [message()]
    gate = boundary.ResponsesGate(policy)
    with pytest.raises(AgentSystemError, match='Conflicting final function inventory'):
        gate.response(encode(events))
    assert not gate.authorized_arguments
    assert gate.last_response_metadata['denial_reason'] == 'Conflicting final function inventory'


def test_optional_function_status_is_observation_but_explicit_incomplete_blocks(policy):
    events = decode(sse([function(policy)]))
    for e in events:
        if isinstance(e.get('item'), dict): e['item'].pop('status', None)
    events[-1]['response']['output'][0].pop('status', None)
    gate = boundary.ResponsesGate(policy)
    gate.response(encode(events))
    assert len(gate.authorized_arguments) == 1
    events[-1]['response']['output'][0]['status'] = 'incomplete'
    rejected = boundary.ResponsesGate(policy)
    with pytest.raises(AgentSystemError, match='Incomplete final function'): rejected.response(encode(events))
    assert not rejected.authorized_arguments


def test_wrong_namespace_reason_is_local_literal_not_provider_text(policy):
    item = function(policy); item['namespace'] = 'secret-provider-string'
    gate = boundary.ResponsesGate(policy)
    with pytest.raises(AgentSystemError): gate.response(sse([item]))
    assert gate.last_response_metadata['denial_reason'] == 'Built-in or unknown model tool denied'
    assert 'secret-provider-string' not in json.dumps(gate.last_response_metadata)


def test_owned_reader_tolerates_provider_pause_over_five_seconds(policy):
    from agent_system.responses_http import read_bounded_response
    client, peer = socket.socketpair()
    stop = threading.Event()
    def send():
        try:
            peer.sendall(b'HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\na')
            if not stop.wait(5.2):
                peer.sendall(b'b'); peer.shutdown(socket.SHUT_WR)
        except OSError: pass
    worker = threading.Thread(target=send, daemon=True); worker.start()
    value = http.client.HTTPResponse(client); value.begin()
    metadata = {}
    try:
        assert read_bounded_response(value, policy, metadata=metadata)[0] == b'ab'
        assert metadata['eof'] and metadata['reader_shutdown_confirmed']
    finally:
        stop.set(); value.close(); client.close(); peer.close(); worker.join(1)
        assert not worker.is_alive()


def test_reader_records_finite_truncation_reason(policy):
    from agent_system.responses_http import read_bounded_response
    metadata = {}
    with response(b'private-body', None, extra=('Content-Length: 999',)) as peer:
        with pytest.raises(AgentSystemError): read_bounded_response(peer, policy, metadata=metadata)
    assert metadata['body_failure'] == 'truncated_content_length'
    assert 'private-body' not in json.dumps(metadata)
