import json
import subprocess
import sys
from pathlib import Path

import pytest
import yaml

from agent_system.config import ModelConfig
from agent_system.errors import AgentSystemError
from agent_system.git import git
from agent_system.orchestrator import Orchestrator
from agent_system.roles import Role
from agent_system.runners import create_runner


@pytest.fixture
def setup_runner(project, task, monkeypatch):
    path, contract = task
    contract["data_critical"] = True
    path.write_text(yaml.safe_dump(contract))
    orchestrator = Orchestrator(project)
    orchestrator.plan(path)
    orchestrator.resume(contract["task_id"])
    config = orchestrator.config
    config.project["runner"]["executable"] = "fake-codex"
    original = subprocess.run
    calls = []
    def launch(command, **kwargs):
        if command[0] == "fake-codex":
            calls.append(command)
            command = [sys.executable, str(Path(__file__).with_name("fake_codex.py")), *command[1:]]
        return original(command, **kwargs)
    monkeypatch.setattr(subprocess, "run", launch)
    return create_runner(config), contract, config, calls


def invoke(setup, role=Role.IMPLEMENTER, **updates):
    runner, task, config, calls = setup
    name = {Role.IMPLEMENTER: "implementer", Role.TEST_ENGINEER: "tester",
            Role.REVIEWER: "reviewer", Role.DATA_AUDITOR: "auditor"}[role]
    workspace = config.worktrees_dir / task["task_id"] / name
    bundle = {"task_id": task["task_id"], "role": str(role), "files": ["src/example.py"],
              "implementation_visible": False, "agent_history_visible": False, **updates}
    return runner.run(role, config.model_for(role), bundle, workspace, task)


def test_real_subprocess_adapter_and_unique_artifacts(setup_runner):
    runner, contract, config, calls = setup_runner
    result = invoke(setup_runner)
    assert result.status == "success"
    assert result.message == "offline backend completed"
    second = invoke(setup_runner)
    assert second.execution_id != result.execution_id
    assert calls[0][calls[0].index("--model") + 1] == "sol"
    assert '--ignore-user-config' in calls[0] and '--ephemeral' in calls[0]
    assert 'model_reasoning_effort="high"' in calls[0]
    directory = config.runs_dir / contract["task_id"] / "invocations" / result.execution_id
    assert json.loads((directory / "result.json").read_text()) == result.to_dict()
    assert (directory / "events.jsonl").read_text().strip()


@pytest.mark.parametrize("role", [Role.REVIEWER, Role.DATA_AUDITOR, Role.TEST_ENGINEER])
def test_role_sandbox(setup_runner, role):
    result = invoke(setup_runner, role)
    assert result.status == "success"
    calls = setup_runner[3]
    expected = "workspace-write" if role == Role.TEST_ENGINEER else "read-only"
    assert calls[0][calls[0].index("--sandbox") + 1] == expected


def test_forbidden_modification_is_rejected(setup_runner):
    setup_runner[1]["objective"] = "MODIFY_FORBIDDEN"
    result = invoke(setup_runner)
    assert result.status == "policy_violation"
    assert result.changed_paths == ["forbidden.txt"]
    assert len(setup_runner[3]) == 1


def test_allowed_modification_is_preserved(setup_runner):
    setup_runner[1]["objective"] = "MODIFY_ALLOWED"
    result = invoke(setup_runner)
    assert result.status == "success"
    assert result.changed_paths == ["src/example.py"]


@pytest.mark.parametrize("role", [Role.REVIEWER, Role.DATA_AUDITOR])
def test_readonly_violation_rejected_after_execution(setup_runner, role):
    setup_runner[1]["objective"] = "MODIFY_ALLOWED"
    assert invoke(setup_runner, role).status == "policy_violation"


def test_tester_visibility_refused_before_launch(setup_runner):
    with pytest.raises(AgentSystemError, match="visibility"):
        invoke(setup_runner, Role.TEST_ENGINEER, implementation_visible=True)
    assert not setup_runner[3]


def test_main_workspace_and_model_escalation_refused(setup_runner):
    runner, task, config, calls = setup_runner
    with pytest.raises(AgentSystemError, match="isolated"):
        runner.run(Role.IMPLEMENTER, config.model_for(Role.IMPLEMENTER), {}, config.root, task)
    with pytest.raises(AgentSystemError, match="routing"):
        runner.run(Role.IMPLEMENTER, ModelConfig("astra", "high"), {}, config.root, task)
    assert not calls


def test_bounded_infrastructure_retries_do_not_change_fix_cycles(setup_runner):
    runner, task, config, calls = setup_runner
    config.project["runner"]["max_infrastructure_retries"] = 2
    task["objective"] = "EXIT_FAILURE"
    result = invoke(setup_runner)
    assert result.status == "execution_failed"
    assert result.attempt == 2
    assert len(calls) == 3
    state = json.loads((config.runs_dir / task["task_id"] / "state.json").read_text())
    assert state["fix_cycle"] == 0


def test_modified_failure_not_retried(setup_runner):
    runner, task, config, calls = setup_runner
    config.project["runner"]["max_infrastructure_retries"] = 2
    task["objective"] = "MODIFY_ALLOWED EXIT_FAILURE"
    assert invoke(setup_runner).status == "execution_failed"
    assert len(calls) == 1


def test_timeout_is_persisted(setup_runner):
    runner, task, config, calls = setup_runner
    task["objective"] = "TIMEOUT"
    config.project["runner"]["timeout_seconds"] = 1
    result = invoke(setup_runner)
    assert result.status == "timeout"
    assert result.returncode is None
    directory = config.runs_dir / task["task_id"] / "invocations" / result.execution_id
    assert json.loads((directory / "result.json").read_text())["status"] == "timeout"


def test_missing_executable_returns_execution_failure(setup_runner):
    setup_runner[2].project["runner"]["executable"] = "definitely-missing-agent-executable"
    result = invoke(setup_runner)
    assert result.status == "execution_failed"
    assert result.returncode is None


@pytest.mark.parametrize("files", [["../outside"], [".git/HEAD"], [".agent_runs/private.md"]])
def test_private_or_escaping_context_refused(setup_runner, files):
    with pytest.raises(AgentSystemError):
        invoke(setup_runner, files=files)
    assert not setup_runner[3]


def test_tester_cannot_use_advanced_branch(setup_runner):
    runner, task, config, calls = setup_runner
    tree = config.worktrees_dir / task["task_id"] / "tester"
    (tree / "tests/test_example.py").write_text("assert 1 == 1\n")
    git(tree, "add", ".")
    git(tree, "commit", "-m", "Changed tester branch")
    with pytest.raises(AgentSystemError, match="frozen task base"):
        invoke(setup_runner, Role.TEST_ENGINEER)
    assert not calls
