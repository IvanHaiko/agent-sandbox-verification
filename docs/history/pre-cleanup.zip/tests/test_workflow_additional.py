from copy import deepcopy

import pytest
import yaml

from agent_system.architecture import architecture_reasons, validate_decision
from agent_system.evidence import digest
from agent_system.errors import AgentSystemError
from agent_system.git import git
from agent_system.orchestrator import Orchestrator
from agent_system.state_machine import State, transition
from agent_system.task import validate
from agent_system.workflow import Workflow
from agent_system.contexts import validate_context
from test_workflow import full_task, execute, Interrupted


def test_protected_ignored_primary_data_is_checked(project, full_task):
    config_path = project / ".agent_system/project.yaml"
    config = yaml.safe_load(config_path.read_text())
    config["protected_paths"] = ["data/raw"]
    config_path.write_text(yaml.safe_dump(config))
    ignore = project / ".gitignore"
    ignore.write_text(ignore.read_text() + "\ndata/raw/\n")
    data = project / "data/raw"
    data.mkdir(parents=True)
    (data / "raw.txt").write_text("protected bytes")
    git(project, "add", ".agent_system", ".gitignore")
    git(project, "commit", "-m", "Protected untracked data policy")
    _, state, _, _, _ = execute(project, full_task, "primary_protected")
    assert state["state"] == "FAILED"
    assert state["failure_kind"] == "policy"
    assert "protected" in state["detail"]


def test_reviewer_cannot_create_ignored_files(project, full_task):
    _, state, _, _, _ = execute(project, full_task, "reviewer_ignored")
    assert state["state"] == "FAILED"
    assert "ignored" in state["detail"]


def test_resume_at_fix_boundary_preserves_budget(project, full_task, monkeypatch):
    path, task, calls = full_task
    task["objective"] += " scenario=tests_first"
    path.write_text(yaml.safe_dump(task))
    orchestrator = Orchestrator(project)
    orchestrator.plan(path)
    original = Workflow.advance
    stopped = []
    def advance(self, target):
        original(self, target)
        if target == State.FIX_REQUIRED and not stopped:
            stopped.append(target)
            raise Interrupted()
    monkeypatch.setattr(Workflow, "advance", advance)
    with pytest.raises(Interrupted):
        orchestrator.resume(task["task_id"])
    assert orchestrator.status(task["task_id"])["fix_cycle"] == 0
    monkeypatch.setattr(Workflow, "advance", original)
    final = Orchestrator(project).resume(task["task_id"])
    assert final["state"] == "ACCEPTED", final["detail"]
    assert final["fix_cycle"] == 1


def test_ambiguous_role_interruption_does_not_reexecute(project, full_task, monkeypatch):
    path, task, calls = full_task
    path.write_text(yaml.safe_dump(task))
    orchestrator = Orchestrator(project)
    orchestrator.plan(path)
    from agent_system.runners.isolated_session import IsolatedSessionRunner
    original = IsolatedSessionRunner.run
    def stop_before_process(self, role, *args, **kwargs):
        if role == "implementer":
            raise Interrupted()
        return original(self, role, *args, **kwargs)
    monkeypatch.setattr(IsolatedSessionRunner, "run", stop_before_process)
    with pytest.raises(Interrupted):
        orchestrator.resume(task["task_id"])
    monkeypatch.setattr(IsolatedSessionRunner, "run", original)
    final = orchestrator.resume(task["task_id"])
    assert final["state"] == "FAILED"
    assert final["failure_kind"] == "ambiguous_execution"
    assert not any(call["context"]["phase"] == "implementation" for call in calls)


def test_completed_backend_execution_recovers_without_rerun(project, full_task, monkeypatch):
    path, task, calls = full_task
    path.write_text(yaml.safe_dump(task))
    orchestrator = Orchestrator(project)
    orchestrator.plan(path)
    from agent_system.runners.isolated_session import IsolatedSessionRunner
    original = IsolatedSessionRunner.run
    stopped = []
    def stop_after_backend(self, role, *args, **kwargs):
        result = original(self, role, *args, **kwargs)
        if role == "implementer" and not stopped:
            stopped.append(role)
            raise Interrupted()
        return result
    monkeypatch.setattr(IsolatedSessionRunner, "run", stop_after_backend)
    with pytest.raises(Interrupted):
        orchestrator.resume(task["task_id"])
    monkeypatch.setattr(IsolatedSessionRunner, "run", original)
    final = orchestrator.resume(task["task_id"])
    assert final["state"] == "ACCEPTED", final["detail"]
    assert sum(c["context"]["phase"] == "implementation" for c in calls) == 1


def test_required_check_must_have_executable_mapping(project, full_task):
    full_task[1]["required_checks"].append("unconfigured_check")
    _, state, _, _, _ = execute(project, full_task)
    assert state["state"] == "FAILED"
    assert "mapped" in state["detail"]


def test_architecture_path_and_category_classification(full_task, project):
    _, task, _ = full_task
    config = Orchestrator(project).config.project
    assert not architecture_reasons(task, config)
    config["architecture"]["sensitive_paths"] = ["src/**"]
    assert architecture_reasons(task, config)
    config["architecture"]["sensitive_paths"] = []
    config["architecture"]["sensitive_categories"] = ["custom_provider_boundary"]
    task["architecture"] = {"categories": ["custom_provider_boundary"], "proposal": None}
    assert architecture_reasons(task, config)


def test_status_does_not_mutate_runtime(project, full_task):
    path, task, calls = full_task
    path.write_text(yaml.safe_dump(task))
    orchestrator = Orchestrator(project)
    orchestrator.plan(path)
    directory = orchestrator.run_dir(task["task_id"])
    before = {p.name: p.read_bytes() for p in directory.iterdir() if p.is_file()}
    assert orchestrator.status(task["task_id"])["state"] == "NEW"
    after = {p.name: p.read_bytes() for p in directory.iterdir() if p.is_file()}
    assert before == after and not calls


def test_direct_backend_cannot_bypass_architecture_gate(project, full_task):
    path, task, calls = full_task
    task["architecture"] = {"categories": ["storage"], "proposal": None}
    path.write_text(yaml.safe_dump(task))
    orchestrator = Orchestrator(project)
    orchestrator.plan(path)
    blocked = orchestrator.resume(task["task_id"])
    assert blocked["state"] == "ARCHITECTURE_DECISION_REQUIRED"
    workflow = orchestrator.workflow(task["task_id"])
    bundle = {"task_id": task["task_id"], "role": "implementer", "phase": "implementation",
              "operation_id": "c0-implementation-r0", "files": ["src/example.py"],
              "implementation_visible": False, "agent_history_visible": False,
              "inputs": {"architecture_selection": []}}
    with pytest.raises(AgentSystemError, match="lifecycle"):
        workflow.runner.run("implementer", workflow.config.model_for("implementer"), bundle,
                            workflow.git.path("implementer"), task)
    without_phase = {k: v for k, v in bundle.items() if k not in ("phase", "operation_id", "inputs")}
    for supplied_task in (task, {k: v for k, v in task.items() if k != "workflow"}):
        with pytest.raises(AgentSystemError, match="phase"):
            workflow.runner.run("implementer", workflow.config.model_for("implementer"), without_phase,
                                workflow.git.path("implementer"), supplied_task)
    assert [c["context"]["phase"] for c in calls] == ["architecture"]


def test_phase_b_must_receive_authoritative_frozen_design(project, full_task, monkeypatch):
    original = Workflow.invoke
    def contaminate(self, phase, inputs=None):
        if phase == "test_implementation":
            inputs = deepcopy(inputs)
            inputs["test_design"]["cases"][0]["expected_result"] = "A weakened substitute"
        return original(self, phase, inputs)
    monkeypatch.setattr(Workflow, "invoke", contaminate)
    _, state, evidence, calls, _ = execute(project, full_task)
    assert state["state"] == "FAILED"
    assert "immutable frozen design" in state["detail"]
    assert not any(c["context"]["phase"] == "test_implementation" for c in calls)


@pytest.mark.parametrize("phase,role", [("test_implementation", "test_engineer"), ("review", "reviewer"), ("fix", "implementer")])
def test_context_artifacts_cannot_cross_task_identity(project, full_task, phase, role):
    _, task, _ = full_task
    design = {"task_id": "OTHER-TASK", "cases": [{"id": "CASE-1", "category": "acceptance",
              "priority": "high", "criterion": 0, "preconditions": [], "action": "Read public interface",
              "expected_result": "Expected contract value", "fixtures": []}]}
    tests = {"task_id": "OTHER-TASK", "cycle": 0, "candidate_commit": "a" * 40,
             "passed": True, "commands": [{"id": "pytest", "argv": ["python", "-m", "pytest"],
             "returncode": 0, "timed_out": False, "stdout": "passed", "stderr": "", "failing_test_ids": []}]}
    review = {"task_id": task["task_id"], "summary": "Valid current-task review", "findings": [], "architecture_decision": None}
    inputs = {"test_design": design} if phase == "test_implementation" else (
        {"test_results": tests} if phase == "review" else {"fix_feedback": {"tests": tests, "review": review, "audit": None}})
    bundle = {"task_id": task["task_id"], "role": role, "phase": phase, "operation_id": "cross-task-check",
              "files": [], "implementation_visible": True, "agent_history_visible": False, "inputs": inputs}
    with pytest.raises(AgentSystemError, match="different task"):
        validate_context(bundle, role, project, task)
