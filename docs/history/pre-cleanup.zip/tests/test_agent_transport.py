import json

import pytest

from agent_system.agent_transport import (BoundedStreams, CodexCliAdapter,
                                           CredentialLease, InvocationBinding, strict_json)
from agent_system.errors import AgentSystemError


SCHEMA = {'type': 'object', 'properties': {'answer': {'type': 'string'}},
          'required': ['answer'], 'additionalProperties': False}
START, END = '2026-10-05T12:00:00Z', '2026-10-05T12:00:01Z'


@pytest.fixture
def adapter():
    return CodexCliAdapter(InvocationBinding('execution-1', 'implementer', 'TASK-1',
                                            1, 'explicit-model', 'low'), SCHEMA)


def events(result=None, usage=None):
    result = result or {'answer': 'ok'}
    return [{'type': 'thread.started', 'thread_id': 'thread-1'}, {'type': 'turn.started'},
            {'type': 'item.completed', 'item': {'type': 'agent_message', 'text': json.dumps(result)}},
            {'type': 'turn.completed', 'usage': usage}]


def capture(values=None):
    stream = BoundedStreams()
    stream.feed('protocol', ('\n'.join(json.dumps(item) for item in (values or events())) + '\n').encode())
    return stream


def decode(adapter, stream=None, result=b'{"answer":"ok"}', code=0, lease=None):
    return adapter.decode(stream or capture(), result, code, START, END, lease)


def test_success_binds_controller_identity_and_unavailable_usage(adapter):
    envelope, diagnostics = decode(adapter)
    assert envelope['execution_id'] == 'execution-1'
    assert envelope['contract_version'] == 1
    assert envelope['model'] == 'explicit-model' and envelope['reported_model'] is None
    assert all(value is None for value in envelope['usage'].values())
    assert envelope['result'] == {'answer': 'ok'}
    assert diagnostics['stderr'] == ''


def test_actual_usage_only_no_inferred_totals(adapter):
    result, _ = decode(adapter, capture(events(usage={'input_tokens': 11, 'output_tokens': 4})))
    assert result['usage']['input_tokens'] == 11
    assert result['usage']['total_tokens'] is None


@pytest.mark.parametrize('text', ['{', '{"x":1} prose', '{"x":1,"x":2}',
                                  '{"x":NaN}', '[] trailing', 'ordinary stdout'])
def test_strict_json_rejects_ambiguous_input(text):
    with pytest.raises(AgentSystemError, match='Malformed'):
        strict_json(text)


@pytest.mark.parametrize('failure', ['timeout', 'cancelled', 'process_crash'])
def test_terminal_abort_rejects_even_valid_result(adapter, failure):
    stream = capture()
    stream.abort(failure)
    with pytest.raises(AgentSystemError, match=failure):
        decode(adapter, stream)


@pytest.mark.parametrize('name', BoundedStreams.NAMES)
def test_each_stream_bounded_and_overflow_terminal(name):
    stream = BoundedStreams(4)
    stream.feed(name, b'1234')
    with pytest.raises(AgentSystemError, match='limit'):
        stream.feed(name, b'5')
    assert bytes(stream.buffers[name]) == b'1234'
    with pytest.raises(AgentSystemError):
        stream.feed('stderr', b'')


@pytest.mark.parametrize('code', [1, -9, None, True])
def test_nonzero_or_unknown_process_state_rejected(adapter, code):
    with pytest.raises(AgentSystemError, match='exit'):
        decode(adapter, code=code)


@pytest.mark.parametrize('result', [b'{', b'{}', b'{"answer":3}', b'{"answer":"ok","extra":1}', b'\xff'])
def test_malformed_or_mismatched_final_result(adapter, result):
    with pytest.raises(AgentSystemError):
        decode(adapter, result=result)


@pytest.mark.parametrize('mutation', ['partial', 'extra', 'duplicate', 'failure', 'unknown', 'blank', 'no_message'])
def test_protocol_failure_modes(adapter, mutation):
    values = events()
    if mutation == 'partial':
        values.pop()
    elif mutation == 'extra':
        values.append({'type': 'item.completed'})
    elif mutation == 'duplicate':
        values.insert(2, {'type': 'turn.completed'})
    elif mutation == 'failure':
        values[-1]['type'] = 'turn.failed'
    elif mutation == 'unknown':
        values.insert(2, {'type': 'future.mandatory.event'})
    elif mutation == 'no_message':
        values[2]['item']['type'] = 'reasoning'
    stream = capture(values)
    if mutation == 'blank':
        stream.feed('protocol', b'\n')
    with pytest.raises(AgentSystemError):
        decode(adapter, stream)


@pytest.mark.parametrize('usage', [{'input_tokens': True}, {'output_tokens': -1}, 'unknown'])
def test_malformed_usage_rejected(adapter, usage):
    with pytest.raises(AgentSystemError, match='usage'):
        decode(adapter, capture(events(usage=usage)))


def test_redaction_after_split_chunks_and_lease_ownership(adapter):
    secret = 'synthetic-secret-value'
    lease = CredentialLease('execution-1', 'implementer', secret)
    stream = capture()
    stream.feed('stderr', b'synthetic-secret-')
    stream.feed('stderr', b'value')
    _, logs = decode(adapter, stream, lease=lease)
    assert secret not in repr(lease) and logs['stderr'] == '[REDACTED]'
    with pytest.raises(AgentSystemError, match='owner'):
        decode(adapter, lease=CredentialLease('other', 'implementer', secret))
    lease.close()
    with pytest.raises(AgentSystemError, match='closed'):
        lease.redact(secret)


def test_secret_result_rejected_without_echo(adapter):
    secret = 'synthetic-secret-value'
    stream = capture(events({'answer': secret}))
    with pytest.raises(AgentSystemError, match='Credential leakage') as error:
        decode(adapter, stream, json.dumps({'answer': secret}).encode(),
               lease=CredentialLease('execution-1', 'implementer', secret))
    assert secret not in str(error.value)


def test_json_escaped_secret_result_is_still_rejected(adapter):
    secret = 'synthetic-secret-value'
    encoded = ''.join('\\u%04x' % ord(character) for character in secret)
    final = ('{"answer":"' + encoded + '"}').encode()
    with pytest.raises(AgentSystemError, match='Credential leakage'):
        decode(adapter, capture(events({'answer': secret})), final,
               lease=CredentialLease('execution-1', 'implementer', secret))


def test_json_escaped_secret_protocol_diagnostic_is_redacted():
    secret = 'synthetic-secret-value'
    encoded = ''.join('\\u%04x' % ord(character) for character in secret)
    stream = BoundedStreams()
    stream.feed('protocol', ('{"text":"' + encoded + '"}\n').encode())
    log = stream.diagnostics(CredentialLease('one', 'reviewer', secret))['protocol']
    assert secret not in log and encoded not in log and '[REDACTED]' in log


def test_private_paths_fresh_exec_and_no_credentials_in_command(adapter):
    command = adapter.command()
    assert '--ephemeral' in command and '--ignore-user-config' in command
    assert '--ignore-rules' in command and 'shell_environment_policy.inherit="none"' in command
    assert command[-1] == '-' and '--output-schema' in command
    assert 'resume' not in command and '--dangerously-bypass-approvals-and-sandbox' not in command
    with pytest.raises(AgentSystemError, match='private'):
        adapter.command('/host/auth.json')


def test_cross_task_result_rejected():
    schema = {'type': 'object', 'required': ['task_id'], 'properties': {'task_id': {'type': 'string'}}}
    adapter = CodexCliAdapter(InvocationBinding('one', 'reviewer', 'TASK-1', 1, 'model', 'low'), schema)
    result = {'task_id': 'TASK-2'}
    with pytest.raises(AgentSystemError, match='identity'):
        decode(adapter, capture(events(result)), json.dumps(result).encode())


def test_existing_runner_result_bridge_and_envelope_mismatch(adapter):
    envelope, _ = decode(adapter)
    result = adapter.agent_result(envelope, ['src/example.py'])
    assert result.to_dict()['status'] == 'success'
    assert json.loads(result.message) == {'answer': 'ok'}
    assert result.changed_paths == ['src/example.py']
    envelope['execution_id'] = 'wrong'
    with pytest.raises(AgentSystemError, match='identity'):
        adapter.agent_result(envelope, [])


def test_tool_exit_codes_are_measured_and_do_not_override_role_result(adapter):
    values = events()
    values.insert(2, {'type': 'item.completed', 'item': {'type': 'command_execution', 'exit_code': 3}})
    envelope, _ = decode(adapter, capture(values))
    assert envelope['process']['tool_exit_codes'] == [3]
    assert envelope['process']['exit_code'] == 0


def test_live_admission_cannot_be_enabled_by_offline_probes(adapter):
    class Capabilities:
        def require(self):
            pass
    class Runner:
        def isolation_capabilities(self):
            return Capabilities()
    with pytest.raises(AgentSystemError, match='Live transport blocked'):
        adapter.require_live_admission(Runner())


@pytest.mark.parametrize('start,end', [('bad', END), (END, START),
                                      ('2026-10-05T12:00:00', END)])
def test_timestamps_require_order_and_timezone(adapter, start, end):
    with pytest.raises(AgentSystemError, match='timestamps'):
        adapter.decode(capture(), b'{"answer":"ok"}', 0, start, end)
