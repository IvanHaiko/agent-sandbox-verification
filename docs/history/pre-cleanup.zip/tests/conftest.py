import shutil
from pathlib import Path

import pytest
import yaml

from agent_system.git import git

SOURCE = Path(__file__).resolve().parents[1]


@pytest.fixture
def project(tmp_path):
    root = tmp_path / "project"
    root.mkdir()
    shutil.copytree(SOURCE / ".agent_system", root / ".agent_system")
    shutil.copy(SOURCE / ".gitignore", root / ".gitignore")
    (root / "src").mkdir()
    (root / "src/example.py").write_text("value = 1\n")
    (root / "tests").mkdir()
    (root / "tests/test_example.py").write_text("assert True\n")
    git(root, "init", "--initial-branch=main")
    git(root, "config", "user.name", "Framework Tests")
    git(root, "config", "user.email", "framework-tests@example.invalid")
    git(root, "add", ".")
    git(root, "commit", "-m", "Test baseline")
    yield root
    # Worktree registrations in test repositories must not outlive temporary fixtures.
    # No deletion is performed here; pytest owns the entire tmp_path lifecycle.


@pytest.fixture
def task(project):
    value = yaml.safe_load((SOURCE / "examples/foundation-task.yaml").read_text())
    value["scope"]["allowed_paths"] = ["src/**", "tests/**"]
    path = project / "task.yaml"
    path.write_text(yaml.safe_dump(value))
    return path, value

