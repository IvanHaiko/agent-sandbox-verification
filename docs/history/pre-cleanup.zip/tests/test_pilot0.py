"""Pilot 0 mechanisms only. No model backend or production data is invoked."""
import json
import subprocess
import sys
from uuid import uuid4

import pytest

from agent_system.config import Configuration
from agent_system.errors import AgentSystemError
from agent_system.git import git
from agent_system.isolation import IsolatedCheckout
from agent_system.runners import create_runner
from test_hardened_workflow import hardened
from test_hardened_workflow import (
    test_hidden_architecture_drift_blocks_before_testing as architecture_probe,
    test_incorrect_independent_test_enters_dispute_without_repairs as dispute_probe,
    test_actual_diff_mandates_auditor_and_regenerates_expectations as data_probe,
    test_hardened_repair_feedback_and_holdout_git_separation as feedback_probe,
)
from test_hardening_isolation import (
    test_role_local_import_resolution_and_shared_editable_rejection as import_probe,
    test_forged_approval_and_replayed_binding_rejected as approval_probe,
    test_gitignored_historical_data_mutation_detected as protected_probe,
)
from test_hardening_tests import test_frozen_assertion_mutation_detected as frozen_probe


def test_01_implementer_canary_leakage(project, tmp_path):
    baseline = git(project, 'rev-parse', 'HEAD')
    canary = 'IMPLEMENTER_ONLY_' + uuid4().hex
    git(project, 'checkout', '-b', 'implementer-canary')
    (project / 'secret.txt').write_text(canary)
    git(project, 'add', 'secret.txt'); git(project, 'commit', '-m', canary)
    checkout = tmp_path / 'tester'
    IsolatedCheckout.create(project, checkout, baseline, tmp_path / 'controller')
    records = []
    for command in (['branch', '-a'], ['log', '--all'], ['show', 'implementer-canary:secret.txt']):
        result = subprocess.run(['git', '-C', str(checkout), *command], capture_output=True, text=True)
        records.append({'command': command, 'stdout': result.stdout, 'stderr': result.stderr})
    artifact = checkout / 'tester-artifact.json'
    artifact.write_text(json.dumps(records))
    assert canary not in artifact.read_text()
    assert records[-1]['stderr'] and 'implementer-canary' not in records[0]['stdout']


def test_02_curious_tester_exposes_read_gap_and_required_mode_fails_closed(project, tmp_path):
    controller = tmp_path / 'controller'
    controller.mkdir()
    (controller / 'private.txt').write_text('controller-only')
    sibling = tmp_path / 'implementer'
    sibling.mkdir()
    (sibling / 'artifact.txt').write_text('implementer-only')
    history = tmp_path / 'sessions'
    history.mkdir()
    (history / 'history.txt').write_text('role-history')
    baseline = git(project, 'rev-parse', 'HEAD')
    tester = tmp_path / 'curious-tester'
    IsolatedCheckout.create(project, tester, baseline, tmp_path / 'bundle-controller')
    # An unmanaged local process demonstrably CAN inspect nearby filesystem state.
    # The framework must therefore reject this backend before running the agent.
    script = 'from pathlib import Path; import sys; [print(Path(p).read_text()) for p in sys.argv[1:]]'
    result = subprocess.run([sys.executable, '-c', script, str(controller / 'private.txt'),
                             str(sibling / 'artifact.txt'), str(history / 'history.txt')], cwd=tester, capture_output=True, text=True)
    assert result.returncode == 0 and 'controller-only' in result.stdout and 'role-history' in result.stdout
    runner = create_runner(Configuration.load(project))
    with pytest.raises(AgentSystemError, match='filesystem_read'):
        runner.run(None, None, {}, tester, {'hardening': {'version': 1}})


def test_03_import_resolution(tmp_path, monkeypatch):
    import_probe(tmp_path, monkeypatch)


def test_04_forged_approval(tmp_path):
    approval_probe(tmp_path)


def test_05_frozen_test_mutation(project, tmp_path):
    frozen_probe(project, tmp_path)


def test_06_gitignored_protected_path_write(project):
    protected_probe(project)


def test_07_hidden_architecture_drift(hardened):
    architecture_probe(hardened)


def test_08_incorrect_independent_test(hardened):
    dispute_probe(hardened)


def test_09_actual_diff_becomes_data_critical(project, hardened):
    data_probe(project, hardened)


def test_10_feedback_leakage(hardened):
    feedback_probe(hardened)
