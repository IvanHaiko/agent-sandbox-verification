import copy
import json
import subprocess
import time

import pytest

from agent_system.agent_transport import InvocationBinding
from agent_system.approvals import ApprovalStore
from agent_system.errors import AgentSystemError
from agent_system.model_tool_boundary import (ExecutionPolicy, ResponsesGate, SecretFilter,
    IsolatedExecutionBridge, LocalModelRelay, TOOL, NAMESPACE, require_credit_attestation)


@pytest.fixture
def policy():
    return ExecutionPolicy(InvocationBinding('exec-1', 'implementer', 'TASK', 1, 'offline-model', 'low'),
                           'implementation', 'owned-workspace', time.monotonic() + 30)


def body(policy):
    return {'model': policy.binding.model, 'reasoning': {'effort': 'low'}, 'input': [],
            'store': False, 'stream': True, 'tools': [{'type': 'custom', 'name': 'apply_patch'}]}


def tool_request(policy):
    return {**policy.identity(), 'tool_type': 'argv', 'argv': ['python', '-c', 'print(1)'],
            'stdin': '', 'read_only': True, 'timeout_seconds': 5, 'output_bytes': 1048576}


def sse(output, response_id='response-1'):
    response = {'id': response_id, 'object': 'response', 'status': 'completed', 'output': output,
                'usage': {'input_tokens': 0, 'output_tokens': 0, 'total_tokens': 0}}
    values = [{'type': 'response.created', 'response': {**response, 'status': 'in_progress', 'output': []}}]
    for index, item in enumerate(output):
        added = copy.deepcopy(item)
        added['status'] = 'in_progress'
        if item['type'] == 'function_call': added['arguments'] = ''
        values.append({'type': 'response.output_item.added', 'output_index': index, 'item': added})
        if item['type'] == 'function_call':
            args = item['arguments']
            for part in (args[:len(args)//2], args[len(args)//2:]):
                values.append({'type': 'response.function_call_arguments.delta', 'output_index': index,
                               'item_id': item['id'], 'delta': part})
            values.append({'type': 'response.function_call_arguments.done', 'output_index': index,
                           'item_id': item['id'], 'arguments': args})
        if item['type'] == 'message':
            values.append({'type': 'response.output_text.delta', 'item_id': item['id'],
                           'output_index': index, 'content_index': 0, 'delta': item['content'][0]['text']})
        values.append({'type': 'response.output_item.done', 'output_index': index, 'item': item})
    values.append({'type': 'response.completed', 'response': response})
    for seq, value in enumerate(values): value['sequence_number'] = seq
    return ''.join('event: ' + value['type'] + '\ndata: ' + json.dumps(value) + '\n\n' for value in values).encode()


def function(policy, name=TOOL, call_id='call-1'):
    return {'type': 'function_call', 'id': 'fc-1', 'call_id': call_id, 'name': name,
            'namespace': NAMESPACE, 'arguments': json.dumps(tool_request(policy)), 'status': 'completed'}


def message(text='{"answer":"ok"}'):
    return {'type': 'message', 'id': 'msg-1', 'role': 'assistant', 'status': 'completed',
            'content': [{'type': 'output_text', 'text': text, 'annotations': []}]}


def test_builtin_inventory_never_reaches_upstream(policy):
    gate = ResponsesGate(policy)
    approved = gate.request(json.dumps(body(policy)).encode())
    assert approved['tools'][0]['name'] == NAMESPACE
    assert [t['name'] for t in approved['tools'][0]['tools']] == [TOOL]
    assert approved['tools'][0]['tools'][0]['parameters']['properties']['execution_id']['const'] == 'exec-1'
    assert gate.response(sse([function(policy)]))


@pytest.mark.parametrize('change', [{'model': 'other'}, {'reasoning': {'effort': 'high'}},
    {'url': 'http://169.254.169.254'}, {'provider': 'other'}, {'metadata': {}}, {'store': True},
    {'stream': False}, {'input': [{'role': 'system'}]}, {'previous_response_id': 'old'}])
def test_unsupported_model_request_denied(policy, change):
    with pytest.raises(AgentSystemError):
        ResponsesGate(policy).request(json.dumps({**body(policy), **change}).encode())


@pytest.mark.parametrize('name', ['exec_command', 'shell', 'apply_patch', 'read_file', 'spawn_agent', 'agentctl_execute_other'])
def test_builtin_or_unknown_response_blocked_before_any_frame_released(policy, name):
    with pytest.raises(AgentSystemError, match='denied'):
        ResponsesGate(policy).response(sse([function(policy, name)]))


@pytest.mark.parametrize('raw', [b'\xff', b'data: {}', b'data: {"type":"unknown"}\n\n',
                               b'data: {"type":"response.completed","type":"response.created"}\n\n'])
def test_partial_invalid_encoding_unknown_duplicate_output_rejected(policy, raw):
    with pytest.raises(AgentSystemError): ResponsesGate(policy).response(raw)


def test_missing_completion_replay_and_limits(policy):
    gate = ResponsesGate(policy)
    first = sse([function(policy)])
    gate.response(first)
    with pytest.raises(AgentSystemError, match='[Rr]eplayed'): gate.response(first)
    with pytest.raises(AgentSystemError, match='Missing'):
        ResponsesGate(policy).response(first[:first.rfind(b'event: response.completed')])
    for _ in range(policy.max_requests): gate.request(json.dumps(body(policy)).encode())
    with pytest.raises(AgentSystemError, match='limit'): gate.request(json.dumps(body(policy)).encode())
    gate.close()
    with pytest.raises(AgentSystemError, match='closed'): gate.response(sse([message()]))


def test_model_and_tool_secret_exfiltration_rejected(policy):
    secret = 'synthetic-refresh-token-12345'
    gate = ResponsesGate(policy, SecretFilter([secret]))
    with pytest.raises(AgentSystemError, match='Credential'): gate.response(sse([message(secret)]))
    with pytest.raises(AgentSystemError, match='Credential'):
        gate.response(sse([message(json.dumps({'x': secret}))]))


class Runner:
    backend = 'docker_isolated'
    def __init__(self): self.calls = []
    def isolation_capabilities(self): return self
    def require(self): pass
    def run_tool(self, *args):
        self.calls.append(args)
        return subprocess.CompletedProcess([], 0, 'ok', '')


@pytest.mark.parametrize('field,value', [('execution_id', 'other'), ('task_id', 'other'), ('role', 'reviewer'),
    ('phase', 'fix'), ('contract_version', 2), ('workspace_id', 'other'), ('tool_type', 'read_host'),
    ('timeout_seconds', 90), ('output_bytes', 100000000), ('argv', ['python', '\0'])])
def test_tool_identity_confusion_and_bounds(policy, field, value):
    runner = Runner()
    bridge = IsolatedExecutionBridge(runner, 'trusted-selection', {}, policy)
    with pytest.raises(AgentSystemError): bridge.execute({**tool_request(policy), field: value})
    assert not runner.calls


def test_generated_command_has_no_host_subprocess_fallback(policy, monkeypatch):
    monkeypatch.setattr(subprocess, 'run', lambda *a, **k: pytest.fail('Untrusted host process'))
    runner = Runner()
    bridge = IsolatedExecutionBridge(runner, 'trusted-selection', {}, policy)
    assert bridge.execute(tool_request(policy))['stdout'] == 'ok'
    assert runner.calls[0][0] == tool_request(policy)['argv']
    bridge.close()
    with pytest.raises(AgentSystemError): bridge.execute(tool_request(policy))


def test_credit_attestation_missing_false_stale_and_execution_binding(tmp_path, policy):
    store = ApprovalStore(tmp_path / 'controller', {'execution': policy.identity()})
    with pytest.raises(AgentSystemError): require_credit_attestation(store, policy.binding)
    store.issue('no-credits/exec-1', {'execution_id': 'exec-1', 'credits_fallback_disabled': True,
                                    'operator': 'synthetic-operator', 'attested_at': time.time()})
    require_credit_attestation(store, policy.binding)
    other = ApprovalStore(store.directory, {'execution': 'different'})
    with pytest.raises(AgentSystemError): require_credit_attestation(other, policy.binding)


def test_arbitrary_url_and_wrong_channel_fail_closed(policy):
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError
    calls = []
    with LocalModelRelay(ResponsesGate(policy), lambda body: calls.append(body)) as relay:
        with pytest.raises(HTTPError):
            urlopen(Request(relay.url + '/responses', data=b'{}', headers={'Authorization': 'Bearer wrong'}), timeout=5)
    assert not calls


@pytest.mark.parametrize('changes', [{'credits_fallback_disabled': False}, {'attested_at': 0},
    {'execution_id': 'other'}, {'operator': ''}, {'client_id': 'other-account'}])
def test_false_stale_wrong_account_credit_attestation_denied(tmp_path, policy, changes):
    store = ApprovalStore(tmp_path / 'controller', {'execution': policy.identity()})
    store.issue('no-credits/exec-1', {'execution_id': 'exec-1', 'credits_fallback_disabled': True,
        'operator': 'synthetic-operator', 'attested_at': time.time(), 'client_id': 'oaiapp_current', **changes})
    with pytest.raises(AgentSystemError): require_credit_attestation(store, policy.binding, 'oaiapp_current')


def test_json_escaped_secret_and_file_message_rejected(policy):
    secret = 'synthetic-controller-secret-123456'
    raw = sse([message(secret)])
    escaped = ''.join('\\u%04x' % ord(c) for c in secret).encode()
    assert secret.encode() not in raw.replace(secret.encode(), escaped)
    with pytest.raises(AgentSystemError, match='Credential'):
        ResponsesGate(policy, SecretFilter([secret])).response(raw.replace(secret.encode(), escaped))
    item = message()
    item['content'] = [{'type': 'input_image', 'image_url': 'http://169.254.169.254'}]
    # Avoid using a text-only fixture builder for the deliberately bad item.
    raw = b'data: ' + json.dumps({'type': 'response.output_item.added', 'item': item}).encode() + b'\n\n'
    with pytest.raises(AgentSystemError): ResponsesGate(policy).response(raw)


@pytest.mark.parametrize('failure', ['missing_credit', 'missing_authorization', 'wrong_route',
                                    'expired_credentials', 'wrong_scope', 'rotated_token'])
def test_live_upstream_preflight_refuses_before_http(tmp_path, policy, monkeypatch, failure):
    import agent_system.model_tool_boundary as boundary
    from agent_system.chatgpt_oauth import PLAN_SCOPE
    value = {'access_token': 'synthetic-access-only', 'refresh_token': 'synthetic-refresh-only',
             'id_token': 'synthetic-id-only', 'client_id': 'oaiapp_fixture',
             'scopes': [PLAN_SCOPE], 'expires_at': time.time() + 300}
    class Store:
        def read(self, name): return value
    approvals = ApprovalStore(tmp_path / 'controller', {'execution': policy.identity()})
    if failure != 'missing_credit':
        approvals.issue('no-credits/exec-1', {'execution_id': 'exec-1', 'credits_fallback_disabled': True,
            'operator': 'offline-fixture-only', 'attested_at': time.time(), 'client_id': value['client_id']})
    if failure != 'missing_authorization':
        approvals.issue('live-smoke/exec-1', {'authorized': True, **policy.identity(),
            'model': policy.binding.model, 'reasoning': policy.binding.reasoning,
            'route': 'https://example.invalid' if failure == 'wrong_route' else boundary.UPSTREAM})
    upstream = boundary.PlanUpstream(Store(), policy, approvals, lambda: None)
    if failure == 'expired_credentials': value['expires_at'] = 0
    if failure == 'wrong_scope': value['scopes'] = []
    if failure == 'rotated_token': value['access_token'] = 'synthetic-rotated-only'
    monkeypatch.setattr(boundary, 'build_opener', lambda *args: pytest.fail('Unauthorized HTTP attempt'))
    with pytest.raises(AgentSystemError): upstream(body(policy))
