import subprocess
import sys
from pathlib import Path

import pytest
import yaml

from agent_system.cli import main
from agent_system.config import Configuration
from agent_system.errors import AgentSystemError
from agent_system.evidence import Evidence
from agent_system.git import git
from agent_system.live import backend_preflight, live_smoke, project_preflight, disposable_fixture
from agent_system.task import load_task


def test_live_requires_explicit_flag_before_preflight(project, monkeypatch):
    monkeypatch.setattr('agent_system.live.backend_preflight', lambda config: pytest.fail('unexpected preflight'))
    with pytest.raises(AgentSystemError, match='allow-live'):
        live_smoke(Configuration.load(project))
    assert main(['--project', str(project), 'live-smoke']) == 1
    assert not (project / '.agent_runs/validations').exists()


def test_blocked_auth_report_contains_no_secrets(project, monkeypatch):
    calls = []
    def run(argv, **kwargs):
        calls.append(argv)
        if argv[-1] == '--version':
            return subprocess.CompletedProcess(argv, 0, 'codex-cli 0.159.2', '')
        if argv[-1] == '--help':
            return subprocess.CompletedProcess(argv, 0, '--ignore-user-config --ephemeral --json --output-last-message --sandbox --model --output-schema', '')
        return subprocess.CompletedProcess(argv, 1, '', 'secret-auth-token-never-persist')
    monkeypatch.setattr(subprocess, 'run', run)
    result = live_smoke(Configuration.load(project), allow_live=True)
    assert result['status'] == 'BLOCKED_BY_ENVIRONMENT' and not result['executed']
    assert len(calls) == 3 and not any('exec' in c and '--json' in c for c in calls)
    content = (Path(result['report_directory']) / 'report.json').read_text()
    assert 'secret-auth-token' not in content
    assert 'authentication' in content


@pytest.mark.parametrize('failure', ['missing_executable', 'timeout', 'missing_flags'])
def test_preflight_environment_failures(project, monkeypatch, failure):
    def run(argv, **kwargs):
        if failure == 'missing_executable': raise FileNotFoundError()
        if failure == 'timeout': raise subprocess.TimeoutExpired(argv, 15)
        return subprocess.CompletedProcess(argv, 0, 'unsupported', '')
    monkeypatch.setattr(subprocess, 'run', run)
    assert not backend_preflight(Configuration.load(project))['ready']


def test_offline_live_commands_runner_then_workflow(project, monkeypatch):
    config = Configuration.load(project)
    config.project['runner']['executable'] = 'offline-live-fixture'
    monkeypatch.setattr('agent_system.live.backend_preflight', lambda config: {
        'ready': True, 'cli_version': 'offline-fixture', 'commands': [], 'diagnostic': None,
        'model_access': 'offline_fixture_only'})
    original = subprocess.run
    calls = []
    def launch(argv, **kwargs):
        if argv[0] == 'offline-live-fixture':
            calls.append(argv)
            argv = [sys.executable, str(Path(__file__).with_name('fake_live_codex.py')), *argv[1:]]
        elif argv[0] == 'codex':
            pytest.fail('Offline test attempted a real Codex invocation')
        return original(argv, **kwargs)
    monkeypatch.setattr(subprocess, 'run', launch)
    smoke = live_smoke(config, allow_live=True)
    assert smoke['status'] == 'PASSED', smoke['failures']
    assert len(calls) == 1 and smoke['executed'] and smoke['telemetry_available']
    assert calls[0][calls[0].index('--sandbox') + 1] == 'read-only'
    report = live_smoke(config, workflow=True, allow_live=True, runner_report=Path(smoke['report_directory']))
    assert report['status'] == 'PASSED', report['failures']
    assert report['task_outcome'] == 'ACCEPTED'
    assert len(calls) == 5
    assert report['telemetry']['invocation_count'] == 4
    assert report['telemetry']['usage']['total_tokens']['measured'] == 100
    assert report['evaluation']['tester']['executed_cases'] == 2
    assert all('--output-schema' in c for c in calls[1:])
    assert git(project, 'status', '--porcelain') == ''


def test_workflow_requires_successful_runner_report(project, monkeypatch):
    monkeypatch.setattr('agent_system.live.backend_preflight', lambda config: {
        'ready': True, 'cli_version': 'offline-fixture', 'commands': [], 'diagnostic': None})
    result = live_smoke(Configuration.load(project), workflow=True, allow_live=True)
    assert result['status'] == 'BLOCKED_BY_ENVIRONMENT' and not result['executed']
    assert 'runner-report' in result['failures'][0]


def test_project_preflight_stops_on_dirty_repository(project, monkeypatch):
    task = yaml.safe_load((Path(__file__).resolve().parents[1] / 'examples/workflow-task.yaml').read_text())
    (project / 'uncommitted.txt').write_text('dirty')
    monkeypatch.setattr('agent_system.live.backend_preflight', lambda config: pytest.fail('unexpected backend preflight'))
    with pytest.raises(AgentSystemError, match='clean committed'):
        project_preflight(Configuration.load(project), task)


def test_cli_help_never_calls_models(project, monkeypatch):
    monkeypatch.setattr('agent_system.live.backend_preflight', lambda config: pytest.fail('unexpected backend preflight'))
    with pytest.raises(SystemExit) as exc:
        main(['--help'])
    assert exc.value.code == 0


@pytest.mark.parametrize('missing', ['context', 'protected', 'command', 'module', 'budget'])
def test_complete_project_preflight_failures_are_offline(project, tmp_path, missing):
    root, task_path, task = disposable_fixture(tmp_path, Configuration.load(project), True)
    config = Configuration.load(root)
    if missing == 'context':
        task['workflow']['public_context'] = ['docs/missing.md']
    elif missing == 'protected':
        config.project['protected_paths'] = ['data/historical_missing']
    elif missing == 'command':
        task['workflow']['checks'][0]['argv'] = ['missing-required-executable']
    elif missing == 'module':
        task['workflow']['checks'][0]['argv'] = [sys.executable, '-m', 'missing_required_module_123']
    else:
        config.project.pop('live_limits')
    with pytest.raises(AgentSystemError):
        project_preflight(config, task)
