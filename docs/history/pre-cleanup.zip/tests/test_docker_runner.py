"""Controller/configuration checks only. These never attest OS enforcement."""
from pathlib import Path
import json

import pytest
import yaml

from agent_system.config import Configuration
from agent_system.errors import AgentSystemError
from agent_system.runners import create_runner
from agent_system.runners.docker_isolated import DockerIsolatedRunner, regular_tree
from agent_system.task import validate


@pytest.fixture
def docker_config(project, tmp_path):
    settings = yaml.safe_load((project / '.agent_system/project.yaml').read_text())
    settings['runtime'] = {'version': 2, 'root': str(tmp_path / 'runtime')}
    settings['runner'] = {'backend': 'docker_isolated', 'executable': 'python', 'timeout_seconds': 30,
                          'max_infrastructure_retries': 0, 'container': {'image': 'sha256:' + '1' * 64}}
    return Configuration(project, validate(settings, 'project'), Configuration.load(project).routing)


def test_container_requires_explicit_configuration(project):
    settings = Configuration.load(project).project
    settings['runner']['backend'] = 'docker_isolated'
    with pytest.raises(AgentSystemError):
        validate(settings, 'project')


@pytest.mark.parametrize('image', ['latest', 'python:3.12', 'sha256:abc', '--privileged'])
def test_mutable_or_invalid_image_rejected(docker_config, image):
    docker_config.project['runner']['container']['image'] = image
    with pytest.raises(AgentSystemError):
        validate(docker_config.project, 'project')
    with pytest.raises(AgentSystemError):
        DockerIsolatedRunner(docker_config)


@pytest.mark.parametrize('key,value', [('memory_mb', 4097), ('cpus', 5), ('output_limit_bytes', 0), ('privileged', True)])
def test_invalid_resource_or_escape_configuration_rejected(docker_config, key, value):
    docker_config.project['runner']['container'][key] = value
    with pytest.raises(AgentSystemError):
        validate(docker_config.project, 'project')


def test_no_evidence_no_admission(docker_config, monkeypatch):
    runner = create_runner(docker_config)
    def unavailable(*args, **kwargs):
        raise AgentSystemError('engine unavailable')
    monkeypatch.setattr(runner, '_docker', unavailable)
    manifest = runner.isolation_capabilities().manifest()
    assert all(not item['verified'] for item in manifest['capabilities'].values())
    with pytest.raises(AgentSystemError, match='filesystem_read'):
        runner.run(None, None, {}, Path('not-mounted'), {})


def test_plain_json_declaration_is_not_attestation(docker_config, monkeypatch):
    runner = create_runner(docker_config)
    from agent_system.approvals import ApprovalStore
    store = ApprovalStore(runner.root / 'unsigned', {'configuration': 'one'})
    store.directory.mkdir(parents=True)
    (store.directory / 'validation.json').write_text(json.dumps({'capabilities': {'filesystem_read': {'passed': True}}}))
    monkeypatch.setattr(runner, '_store', lambda: store)
    assert not runner.isolation_capabilities().capabilities


def test_host_environment_not_forwarded(docker_config, monkeypatch):
    runner = create_runner(docker_config)
    monkeypatch.setenv('SECRET_HOST_TOKEN', 'must-not-be-forwarded')
    argv, env = runner.prepare_command(['python.exe', '-c', 'print("C:/private/path")'], docker_config.root)
    assert argv == ['python', '-c', 'print("C:/private/path")']
    assert 'SECRET_HOST_TOKEN' not in env
    assert env['HOME'] == '/role/home' and env['CODEX_HOME'] == '/role/config/codex'
    assert 'PYTHONPATH' not in env and 'VIRTUAL_ENV' not in env


def test_exact_host_token_mapping_and_outside_path_rejection(docker_config, tmp_path):
    runner = create_runner(docker_config)
    argv, _ = runner.prepare_command(['python', str(docker_config.root / 'src/example.py')], docker_config.root)
    assert argv[1] == '/workspace/src/example.py'
    with pytest.raises(AgentSystemError, match='outside'):
        runner.prepare_command(['python', str(tmp_path / 'private.py')], docker_config.root)


def test_container_paths_survive_repeated_command_preparation(docker_config):
    runner = create_runner(docker_config)
    argv = ['python3.13.exe', '-c', 'print("literal script")', '/workspace', '/role/tmp/input']
    once, _ = runner.prepare_command(argv, docker_config.root)
    twice, _ = runner.prepare_command(once, docker_config.root)
    assert once == twice and twice[0] == 'python'


def test_python_prefix_executable_not_silently_replaced(docker_config):
    runner = create_runner(docker_config)
    assert runner.prepare_command(['python-helper', '--version'], docker_config.root)[0][0] == 'python-helper'


def test_container_imports_cannot_fall_back_without_task_metadata(docker_config, monkeypatch):
    from agent_system.isolation import verify_imports
    import subprocess
    def host_execution_forbidden(*args, **kwargs):
        pytest.fail('Container import escaped to a host subprocess')
    monkeypatch.setattr(subprocess, 'run', host_execution_forbidden)
    with pytest.raises(AgentSystemError, match='no host fallback'):
        verify_imports(docker_config.root, ['example'], create_runner(docker_config))


def test_container_tests_cannot_fall_back_without_task_metadata(docker_config, monkeypatch):
    from agent_system.gates import run_tests
    import subprocess
    def host_execution_forbidden(*args, **kwargs):
        pytest.fail('Container test escaped to a host subprocess')
    monkeypatch.setattr(subprocess, 'run', host_execution_forbidden)
    with pytest.raises(AgentSystemError, match='no host fallback'):
        run_tests(docker_config, {}, docker_config.root, {}, 0, None, create_runner(docker_config))


def test_comma_mount_rejected_and_spaces_preserved(docker_config, tmp_path):
    runner = create_runner(docker_config)
    with pytest.raises(AgentSystemError, match='Comma'):
        runner._mount(tmp_path / 'bad,path', '/workspace')
    assert 'source=' + str((tmp_path / 'space path').resolve()) in runner._mount(tmp_path / 'space path', '/workspace')[1]


def test_new_backend_does_not_change_old_backend(project):
    assert create_runner(Configuration.load(project)).isolation_capabilities().backend == 'isolated_session'


def test_stale_cleanup_rejects_unowned_identity(docker_config):
    runner = create_runner(docker_config)
    with pytest.raises(AgentSystemError, match='identity'):
        runner.cleanup_stale('../unrelated')


def test_storage_cleanup_cannot_delete_unrelated_tree(docker_config, tmp_path):
    runner = create_runner(docker_config)
    unrelated = tmp_path / 'unrelated'
    unrelated.mkdir()
    (unrelated / 'keep.txt').write_text('keep')
    with pytest.raises(AgentSystemError, match='Unsafe'):
        runner._remove_owned_tree(unrelated, tmp_path / 'owned-execution')
    assert (unrelated / 'keep.txt').read_text() == 'keep'


def test_stale_cleanup_rejects_reused_name_with_different_id(docker_config, monkeypatch):
    from agent_system.storage import atomic_json
    runner = create_runner(docker_config)
    execution_id = '3' * 32
    name = 'agentctl-' + runner.owner[:12] + '-' + execution_id
    directory = runner.root / 'executions' / execution_id
    atomic_json(directory / 'ownership.json', {'owner': runner.owner, 'execution_id': execution_id,
                'name': name, 'container_id': '1' * 64})
    monkeypatch.setattr(runner, 'stale_executions', lambda: [{'Name': '/' + name, 'Id': '2' * 64,
                                                           'State': {'Running': False}}])
    with pytest.raises(AgentSystemError, match='ID differs'):
        runner.cleanup_stale(execution_id)


def test_regular_tree_rejects_windows_reparse_point(tmp_path, monkeypatch):
    from types import SimpleNamespace
    path = tmp_path / 'file'
    path.write_text('regular')
    original = Path.lstat
    def fake_lstat(self, *args, **kwargs):
        result = original(self, *args, **kwargs)
        if self == path:
            return SimpleNamespace(st_mode=result.st_mode, st_file_attributes=0x400)
        return result
    monkeypatch.setattr(Path, 'lstat', fake_lstat)
    with pytest.raises(AgentSystemError, match='reparse'):
        regular_tree(tmp_path)
