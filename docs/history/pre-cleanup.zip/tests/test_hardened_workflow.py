"""Controller integration harness. Synthetic capabilities are not OS evidence."""
import json
from pathlib import Path
import sys
from uuid import uuid4

import pytest
import yaml

from agent_system.config import Configuration
from agent_system.errors import AgentSystemError
from agent_system.evidence import digest
from agent_system.git import git
from agent_system.isolation import CAPABILITIES, Capability, IsolationCapabilities
from agent_system.orchestrator import Orchestrator
from agent_system.runners.base import AgentRunner, AgentResult
from agent_system.state_machine import State


class HarnessRunner(AgentRunner):
    """Fixed deterministic actions; it does not execute arbitrary agent commands."""
    def __init__(self, config, broken=False, invalid_test=False, mutate=None):
        self.config, self.broken, self.invalid_test, self.mutate = config, broken, invalid_test, mutate
        self.calls = []

    def isolation_capabilities(self):
        return IsolationCapabilities('deterministic-harness', {k: Capability(True, True, 'Synthetic protocol fixture; not real OS isolation') for k in CAPABILITIES})

    def run_command(self, argv, workspace, environment, timeout_seconds, task, read_only=True):
        import subprocess
        assert read_only and task['hardening']['version'] == 1
        # These are fixed fixture programs, NOT a production sandbox adapter.
        return subprocess.run(argv, cwd=workspace, env=environment, capture_output=True, text=True, timeout=timeout_seconds)

    def run(self, role, model_config, context_bundle, workspace, task_metadata):
        task, bundle = task_metadata, context_bundle
        phase = bundle['phase']
        self.calls.append((phase, bundle, workspace))
        common = {'task_id': task['task_id'], 'contract_version': task['hardening']['contract_version']}
        if phase == 'test_design':
            report = {**common, 'cases': [{'id': name, 'category': 'acceptance', 'priority': 'critical',
                      'criterion': 0, 'preconditions': [], 'action': 'Read public value', 'expected_result': '2', 'fixtures': []}
                      for name in ('ACCEPT-0', 'ACCEPT-H')]}
        elif phase in ('test_implementation', 'test_correction'):
            folder = workspace / 'tests/acceptance'
            folder.mkdir(parents=True, exist_ok=True)
            value = 3 if self.invalid_test and phase != 'test_correction' else 2
            for name in ('visible', 'holdout'):
                (folder / f'test_{name}.py').write_text(f'from src.example import value\ndef test_{name}():\n    assert value == {value}\n')
            report = {**common, 'summary': 'Executable independent suite', 'independent': [
                {'case_id': 'ACCEPT-0', 'path': 'tests/acceptance/test_visible.py', 'test_id': 'tests/acceptance/test_visible.py::test_visible'},
                {'case_id': 'ACCEPT-H', 'path': 'tests/acceptance/test_holdout.py', 'test_id': 'tests/acceptance/test_holdout.py::test_holdout'}],
                'additional': []}
        elif phase in ('implementation', 'fix'):
            (workspace / 'src/example.py').write_text(f'value = {0 if self.broken and phase == "implementation" else 2}\n')
            report = {**common, 'outcome': 'completed', 'summary': 'Public behavior implemented', 'architecture_decision': None}
        elif phase in ('review', 'review_blind', 'test_correction_review'):
            report = {**common, 'summary': 'Reviewed', 'findings': [], 'architecture_decision': None}
        elif phase == 'audit':
            report = {**common, 'verdict': 'PASS', 'summary': 'Audited', 'checks': [{'name': 'data', 'evidence': 'Independent evidence', 'passed': True}], 'findings': [], 'architecture_decision': None}
        else:
            raise AssertionError(phase)
        if self.mutate:
            self.mutate(phase, workspace, report)
        return AgentResult(str(uuid4()), task['task_id'], str(role), 'success', model_config.model,
                           model_config.reasoning, 0, 0, json.dumps(report), [])


@pytest.fixture
def hardened(project, tmp_path):
    path = project / '.agent_system/project.yaml'
    config = yaml.safe_load(path.read_text())
    config['runtime'] = {'version': 2, 'root': str(tmp_path / 'runtime')}
    config['testing']['commands'] = []
    path.write_text(yaml.safe_dump(config))
    source = Path(__file__).resolve().parents[1]
    task = yaml.safe_load((source / 'examples/workflow-task.yaml').read_text())
    task['workflow']['public_context'] = []
    task['workflow']['implementation_context'] = []
    task['workflow']['checks'] = [{'id': 'baseline', 'argv': [sys.executable, '-c', 'import runpy; runpy.run_path("tests/test_example.py")']}]
    task['workflow']['independent_command'] = [sys.executable, '-c', 'import runpy,sys; [runpy.run_path(p.split("::")[0])[p.split("::")[1]]() for p in sys.argv[1:]]']
    task['objective'] = 'Set the public value to 2 while preserving its interface'
    task['required_checks'] = ['independent_tests', 'reviewer']
    task['hardening'] = {'version': 1, 'contract_version': 1, 'interface': {'description': 'Public value equals 2', 'files': [],
                         'assertions': [{'expression': 'value', 'expected': 2, 'criterion': 0}]},
                         'holdout_paths': ['tests/acceptance/test_holdout.py'], 'python_modules': ['src.example'], 'max_disputes': 2}
    task['acceptance_criteria'] = ['Public value equals 2']
    task['major_phase'] = False
    task['completion']['requires_user_approval'] = False
    task_path = project / 'hardened-task.yaml'
    def make(broken=False, invalid_test=False, mutate=None):
        task_path.write_text(yaml.safe_dump(task))
        runner = HarnessRunner(Configuration.load(project), broken, invalid_test, mutate)
        controller = Orchestrator(project, lambda config: runner)
        controller.plan(task_path)
        return controller, runner
    return task, make


def test_hardened_tests_frozen_before_implementation_and_holdouts_hidden(project, hardened):
    task, make = hardened
    controller, runner = make()
    state = controller.resume(task['task_id'])
    assert state['state'] == 'ACCEPTED', state['detail']
    phases = [p for p, _, _ in runner.calls]
    assert phases[:3] == ['test_design', 'test_implementation', 'implementation']
    assert phases[-2:] == ['review_blind', 'review']
    impl = next(w for p, _, w in runner.calls if p == 'implementation')
    assert not (impl / 'tests/acceptance/test_holdout.py').exists()
    assert 'test_holdout' not in git(impl, 'log', '--all', '--name-only')
    blind = next(b for p, b, _ in runner.calls if p == 'review_blind')
    assert 'test_results' not in blind['inputs']
    assert controller.resume(task['task_id'])['state'] == 'ACCEPTED'


def test_major_contract_gate_precedes_agent_work(hardened):
    task, make = hardened
    task['major_phase'] = True
    controller, runner = make()
    state = controller.resume(task['task_id'])
    assert state['state'] == 'CONTRACT_APPROVAL', state['detail']
    assert not runner.calls
    package = controller.workflow(task['task_id']).evidence.read('contract/package')
    with pytest.raises(AgentSystemError, match='identity'):
        controller.approve_contract(task['task_id'], 'human', 'wrong')
    controller.approve_contract(task['task_id'], 'human', digest(package))
    state = controller.resume(task['task_id'])
    assert state['state'] == 'USER_COMPLETION_APPROVAL', state['detail']
    controller.approve_completion(task['task_id'], 'human')
    assert controller.resume(task['task_id'])['state'] == 'ACCEPTED'
    approval = controller.workflow(task['task_id']).control.directory / 'contract.json'
    envelope = json.loads(approval.read_text())
    envelope['record']['payload']['approved_by'] = 'forged-role'
    approval.write_text(json.dumps(envelope))
    with pytest.raises(AgentSystemError, match='integrity'):
        controller.resume(task['task_id'])


def test_hardened_repair_feedback_and_holdout_git_separation(hardened):
    task, make = hardened
    controller, runner = make(broken=True)
    state = controller.resume(task['task_id'])
    assert state['state'] == 'ACCEPTED', state['detail']
    assert state['fix_cycle'] == 1
    feedback = next(b['inputs'] for p, b, _ in runner.calls if p == 'fix')
    assert 'test_holdout' not in str(feedback)
    assert 'assert value' not in str(feedback)
    assert 'fix_feedback' not in feedback


def test_contract_version_mismatch_fails_before_integration(hardened):
    task, make = hardened
    def mutate(phase, workspace, report):
        if phase == 'implementation': report['contract_version'] = 2
    controller, runner = make(mutate=mutate)
    state = controller.resume(task['task_id'])
    assert state['state'] == 'FAILED' and 'version mismatch' in state['detail']


def test_current_backend_isolation_rejection_runs_no_agent(project, hardened):
    task, make = hardened
    controller, _ = make()
    controller.runner_factory = None
    state = controller.resume(task['task_id'])
    assert state['state'] == 'FAILED' and 'Required isolation' in state['detail']
    assert not (controller.run_dir(task['task_id']) / 'invocations').exists()


def test_incorrect_independent_test_enters_dispute_without_repairs(hardened):
    task, make = hardened
    controller, runner = make(invalid_test=True)
    state = controller.resume(task['task_id'])
    assert state['state'] == 'TEST_DISPUTE', state['detail']
    assert state['fix_cycle'] == 0 and state['dispute_count'] == 1
    assert not any(p == 'fix' for p, _, _ in runner.calls)
    controller.resolve_dispute(task['task_id'], 'human')
    state = controller.resume(task['task_id'])
    assert state['state'] == 'ACCEPTED', state['detail']
    assert state['fix_cycle'] == 0 and state['test_version'] == 2
    assert any(p == 'test_correction' for p, _, _ in runner.calls)


def test_hidden_architecture_drift_blocks_before_testing(hardened):
    task, make = hardened
    task['scope']['allowed_paths'].append('pyproject.toml')
    def mutate(phase, workspace, report):
        if phase == 'implementation': (workspace / 'pyproject.toml').write_text('[project]\ndependencies=["new"]\n')
    controller, runner = make(mutate=mutate)
    state = controller.resume(task['task_id'])
    assert state['state'] == 'ARCHITECTURE_DECISION_REQUIRED', state['detail']
    package = controller.architecture(task['task_id'])
    assert 'pyproject.toml' in package['problem']
    controller.approve_architecture(task['task_id'], package['decision_id'], 'approve', 'human')
    state = controller.resume(task['task_id'])
    assert state['state'] == 'ACCEPTED', state['detail']


def test_actual_diff_mandates_auditor_and_regenerates_expectations(project, hardened):
    task, make = hardened
    path = project / '.agent_system/project.yaml'
    config = yaml.safe_load(path.read_text())
    config['data_critical_patterns'] = ['src/example.py']
    path.write_text(yaml.safe_dump(config))
    # Broad initial scope avoids the old classifier finding the exact path;
    # the actual file diff must trigger this gate.
    task['scope']['allowed_paths'] = ['src/**', 'tests/**']
    task['hardening']['audit_commands'] = [[sys.executable, '-c', 'import json; from src.example import value; print(json.dumps({"value":value}))']]
    task['hardening']['data_expectations'] = [{'metric': 'value', 'availability': 'registered', 'minimum': 2, 'maximum': 2}]
    controller, runner = make()
    state = controller.resume(task['task_id'])
    assert state['state'] == 'ACCEPTED', state['detail']
    assert state['data_critical'] and any(p == 'audit' for p, _, _ in runner.calls)
    wf = controller.workflow(task['task_id'])
    assert wf.evidence.read('auditor/escalation')['paths'] == ['src/example.py']
    regenerated = wf.evidence.read('cycles/0/auditor/regenerated')
    assert regenerated['metrics']['value'] == 2
    assert all(str(wf.git.path('auditor')) in origin for origin in regenerated['imports']['origins']['src.example'])
    assert regenerated['expectations']['results'][0]['status'] == 'validated'
    audit_bundle = next(bundle for phase, bundle, _ in runner.calls if phase == 'audit')
    assert audit_bundle['inputs']['audit_validation']['metrics']['value'] == 2


def test_resume_after_signed_executable_freeze_is_not_replayed(hardened, monkeypatch):
    from agent_system.hardened_workflow import HardenedWorkflow
    class Interrupted(BaseException): pass
    task, make = hardened
    controller, runner = make()
    def checkpoint(self, name):
        if name == 'frozen_tests': raise Interrupted()
    monkeypatch.setattr(HardenedWorkflow, 'checkpoint', checkpoint)
    with pytest.raises(Interrupted): controller.resume(task['task_id'])
    frozen = controller.workflow(task['task_id']).control.verify('tests/1')
    monkeypatch.setattr(HardenedWorkflow, 'checkpoint', lambda self, name: None)
    state = controller.resume(task['task_id'])
    assert state['state'] == 'ACCEPTED', state['detail']
    assert sum(p == 'test_implementation' for p, _, _ in runner.calls) == 1
    assert controller.workflow(task['task_id']).control.verify('tests/1') == frozen


def test_readonly_role_ignored_empty_directory_write_is_detected(hardened):
    task, make = hardened
    def mutate(phase, workspace, report):
        if phase == 'review_blind': (workspace / '__pycache__/empty').mkdir(parents=True, exist_ok=True)
    controller, _ = make(mutate=mutate)
    state = controller.resume(task['task_id'])
    assert state['state'] == 'FAILED' and 'Read-only role modified' in state['detail']


def test_final_integrated_diff_including_tester_files_can_require_audit(project, hardened):
    task, make = hardened
    path = project / '.agent_system/project.yaml'
    config = yaml.safe_load(path.read_text())
    config['data_critical_patterns'] = ['tests/acceptance/test_holdout.py']
    path.write_text(yaml.safe_dump(config))
    controller, runner = make()
    state = controller.resume(task['task_id'])
    assert state['state'] == 'ACCEPTED', state['detail']
    assert state['data_critical'] and any(phase == 'audit' for phase, _, _ in runner.calls)
    assert 'integrated paths' in controller.workflow(task['task_id']).evidence.read('auditor/escalation')['reason']


@pytest.mark.parametrize('dispute_phase', ['review', 'review_blind'])
def test_reviewer_can_resolve_contractual_dispute_without_human_or_repairs(hardened, dispute_phase):
    task, make = hardened
    task['hardening']['interface']['assertions'] = []
    once = []
    def mutate(phase, workspace, report):
        if phase == dispute_phase and not once:
            once.append(True)
            report['test_dispute'] = {'reason': 'unapproved_assumption', 'clause': 0,
                                      'evidence': 'The test assumes 3; the approved contract requires 2', 'changes_semantics': False}
    controller, runner = make(invalid_test=True, mutate=mutate)
    state = controller.resume(task['task_id'])
    assert state['state'] == 'ACCEPTED', state['detail']
    assert state['dispute_count'] == 1 and state['fix_cycle'] == 0
    assert any(entry['state'] == 'TEST_DISPUTE' for entry in state['history'])
    assert controller.workflow(task['task_id']).control.verify('disputes/1')['reviewer_resolution']
