"""Offline process/artifact tests; these are not native-model trial evidence."""
import json
import os
from pathlib import Path
import sys
import tomllib
import subprocess

import pytest

from agent_system.errors import AgentSystemError
from agent_system.native_codex import NativeCodexRunner, native_environment


def runner_with_script(monkeypatch, script):
    runner = NativeCodexRunner(sys.executable)
    monkeypatch.setattr(runner, 'command', lambda *args: [sys.executable, '-c', script])
    # The restricted host cannot use taskkill for even its own fixture. Model a
    # successful owned-tree stop via the Popen handle. This fixture has no
    # descendants; it is explicitly not proof of native Windows containment.
    actual_popen, actual_run = subprocess.Popen, subprocess.run
    handles = {}
    def popen(*args, **kwargs):
        process = actual_popen(*args, **kwargs)
        handles[process.pid] = process
        return process
    def stop(argv, *args, **kwargs):
        if argv[0] == 'taskkill':
            process = handles[int(argv[argv.index('/PID') + 1])]
            process.terminate()
            process.wait(timeout=5)
            return subprocess.CompletedProcess(argv, 0)
        return actual_run(argv, *args, **kwargs)
    monkeypatch.setattr(subprocess, 'Popen', popen)
    monkeypatch.setattr(subprocess, 'run', stop)
    return runner


def run(runner, tmp_path, **kwargs):
    (tmp_path / 'candidate.txt').write_text('baseline')
    return runner.run(trial_id='offline', role='implementer', workspace=tmp_path,
        prompt='bounded input', target='candidate.txt', model='gpt-6.1-sol', effort='low',
        verify=lambda b: {'valid': b == b'candidate'}, timeout_seconds=5, **kwargs)


SCRIPT = '''import json, pathlib, sys, time
sys.stdin.read()
print(json.dumps({'type':'thread.started','thread_id':'offline-thread'}),flush=True)
pathlib.Path('candidate.txt').write_text('candidate')
{extra}
print(json.dumps({{'type':'item.completed','item':{{'id':'write','type':'file_change','status':'completed'}}}}),flush=True)
time.sleep(30)
'''


def script(extra=''):
    # Replace only the interpolation marker; preserve JSON dictionary braces.
    return SCRIPT.replace('{extra}', extra).replace('{{', '{').replace('}}', '}')


def test_completed_tool_artifact_survives_controller_stop(monkeypatch, tmp_path):
    runner = runner_with_script(monkeypatch, script())
    result = run(runner, tmp_path)
    assert result['execution_status'] == 'abnormal_recoverable'
    assert result['artifact_boundary_observed'] and result['shutdown_confirmed']
    assert result['artifact_hashes']['candidate.txt']
    assert result['mutation_scope_valid']
    assert result['candidate_status'] == 'unaccepted'
    assert result['resolved_model'] is None  # fixture never proves native inference
    assert (tmp_path / 'candidate.txt').read_bytes() == b'candidate'


@pytest.mark.parametrize('extra', [
    "print(json.dumps({'type':'error','message':'401 unauthorized'}),flush=True)",
    "print(json.dumps({'type':'error','message':'unknown provider failure'}),flush=True)",
    "pathlib.Path('outside-scope.txt').write_text('mutation')",
])
def test_candidate_does_not_override_auth_unknown_failure_or_scope(monkeypatch, tmp_path, extra):
    result = run(runner_with_script(monkeypatch, script(extra)), tmp_path)
    assert result['execution_status'] == 'unrecoverable'


def test_normal_exit_without_artifact_is_unrecoverable(monkeypatch, tmp_path):
    executable = "import json,sys;sys.stdin.read();print(json.dumps({'type':'turn.completed'}))"
    result = run(runner_with_script(monkeypatch, executable), tmp_path)
    assert result['process_exit_code'] == 0
    assert result['execution_status'] == 'unrecoverable'
    assert result['candidate_status'] == 'missing'


def test_plain_write_without_completed_tool_is_not_recoverable(monkeypatch, tmp_path):
    source = "import pathlib,sys;sys.stdin.read();pathlib.Path('candidate.txt').write_text('candidate');sys.exit(1)"
    result = run(runner_with_script(monkeypatch, source), tmp_path)
    assert result['execution_status'] == 'unrecoverable'


def test_failed_tree_stop_blocks_artifact_recovery(monkeypatch, tmp_path):
    runner = runner_with_script(monkeypatch, script())
    previous_run = subprocess.run
    def failed_stop(argv, *args, **kwargs):
        if argv[0] == 'taskkill':
            return subprocess.CompletedProcess(argv, 1)
        return previous_run(argv, *args, **kwargs)
    monkeypatch.setattr(subprocess, 'run', failed_stop)
    if os.name != 'nt':
        pytest.skip('Windows owned-tree failure predicate')
    result = run(runner, tmp_path)
    assert result['artifact_boundary_observed']
    assert result['shutdown_confirmed'] is False
    assert result['execution_status'] == 'unrecoverable'


def test_command_sets_native_profile_fresh_context_and_exact_model(tmp_path):
    runner = NativeCodexRunner(sys.executable)
    command = runner.command(tmp_path, 'gpt-6.1-sol', 'low', 'candidate.txt')
    settings = {}
    for index, value in enumerate(command):
        if value == '-c':
            settings.update(tomllib.loads(command[index + 1]))
    assert '--ephemeral' in command and '--ignore-user-config' in command
    assert '--no-daemon' in command
    assert 'resume' not in command and 'fork' not in command
    assert command[command.index('--model') + 1] == 'gpt-6.1-sol'
    profile = settings['permissions']['stage23']
    assert profile['filesystem'][':workspace_roots'] == {'.': 'read', 'candidate.txt': 'write'}
    assert profile['filesystem'][':minimal'] == 'read'
    assert ':root' not in profile['filesystem']
    assert profile['network']['enabled'] is False


def test_native_environment_excludes_api_credentials_and_inherited_chat(monkeypatch):
    monkeypatch.setenv('OPENAI_API_KEY', 'fixture-secret')
    monkeypatch.setenv('CODEX_THREAD_ID', 'previous-role')
    monkeypatch.setenv('CODEX_SESSION_ID', 'previous-session')
    monkeypatch.setenv('CODEX_HOME', 'native-home-fixture')
    result = native_environment()
    assert 'OPENAI_API_KEY' not in result
    assert 'CODEX_THREAD_ID' not in result
    assert 'CODEX_SESSION_ID' not in result
    assert result['CODEX_HOME'] == 'native-home-fixture'


def test_artifact_cannot_traverse_workspace(tmp_path):
    runner = NativeCodexRunner(sys.executable)
    with pytest.raises(AgentSystemError, match='target'):
        runner.run(trial_id='offline', role='implementer', workspace=tmp_path, prompt='input',
            target='../escape', model='gpt-6.1-sol', effort='low', verify=lambda _: {'valid': True})
