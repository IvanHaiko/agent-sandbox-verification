import pytest

from agent_system.approvals import ApprovalStore
from agent_system.errors import AgentSystemError
from agent_system.git import git
from agent_system.independent_tests import freeze_tests, verify_frozen_tests, mutation_flags, repair_feedback, check_feedback, validate_correction


def test_frozen_assertion_mutation_detected(project, tmp_path):
    directory = project / 'tests/acceptance/task'
    directory.mkdir(parents=True)
    test = directory / 'test_behavior.py'
    test.write_text('def test_answer():\n    assert value == 42\n')
    git(project, 'add', 'tests')
    git(project, 'commit', '-m', 'Independent tests')
    commit = git(project, 'rev-parse', 'HEAD')
    store = ApprovalStore(tmp_path / 'controller', {'task': 'task'})
    freeze_tests(store, project, commit, ['tests/acceptance/task/**'], 1)
    verify_frozen_tests(store, project, commit, 1)
    test.write_text('def test_answer():\n    assert True\n')
    with pytest.raises(AgentSystemError, match='working file mutation'):
        verify_frozen_tests(store, project, commit, 1)
    git(project, 'add', 'tests'); git(project, 'commit', '-m', 'Weaken assertion')
    with pytest.raises(AgentSystemError, match='changed_assertion'):
        verify_frozen_tests(store, project, git(project, 'rev-parse', 'HEAD'), 1)


@pytest.mark.parametrize('after,flag', [
    ('def test_a():\n    pass\n', 'deleted_assertion'),
    ('import pytest\n@pytest.mark.skip\ndef test_a():\n    assert x == 2\n', 'introduced_skip'),
    ('import pytest\n@pytest.mark.xfail\ndef test_a():\n    assert x == 2\n', 'introduced_xfail'),
    ('def test_a():\n    assert x == 3\n', 'changed_assertion_or_expected_value_or_tolerance'),
    ('', 'removed_case'),
    ('def test_a():\n    assert abs(x) < 0.1\n', 'changed_assertion_or_expected_value_or_tolerance'),
])
def test_test_mutation_classification(after, flag):
    assert flag in mutation_flags('def test_a():\n    assert x == 2\n', after)


def test_feedback_leakage_is_not_forwarded():
    secret = 'assert result == "holdout-secret-e86b"'
    task = {'task_id': 'task', 'acceptance_criteria': ['Result follows public behavior']}
    feedback = repair_feedback(task, {'passed': False, 'commands': [{'stdout': secret}]},
                               {'findings': [{'severity': 'MAJOR', 'evidence': secret}]}, None)
    assert secret not in str(feedback) and 'holdout-secret' not in str(feedback)
    check_feedback(feedback, [secret])
    with pytest.raises(AgentSystemError, match='leaked'):
        check_feedback({'leak': secret}, [secret])


def test_test_dispute_cannot_authorize_assert_true_overfitting():
    before = 'def test_a():\n    assert value == 3\n'
    requirement = [{'expression': 'value', 'expected': 2, 'criterion': 0}]
    validate_correction(before, 'def test_a():\n    assert value == 2\n', requirement)
    with pytest.raises(AgentSystemError, match='Unjustified'):
        validate_correction(before, 'def test_a():\n    assert True\n', requirement)


def test_declared_holdout_cannot_silently_become_visible_only(project):
    from agent_system.gates import validate_test_mapping
    task = {'task_id': 'task', 'workflow': {'test_paths': ['tests/acceptance/**']},
            'hardening': {'holdout_paths': ['tests/acceptance/hidden/**']}}
    design = {'cases': [{'id': 'case'}]}
    report = {'task_id': 'task', 'summary': 'Only visible diagnostics', 'independent': [{
        'case_id': 'case', 'path': 'tests/acceptance/test_visible.py', 'test_id': 'tests/acceptance/test_visible.py::test_a'}], 'additional': []}
    with pytest.raises(AgentSystemError, match='Declared holdout'):
        validate_test_mapping(report, design, task, project)
