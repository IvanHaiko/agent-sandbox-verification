import pytest

from agent_system.contracts import lint_contract
from agent_system.errors import AgentSystemError
from agent_system.git import git
from agent_system.mechanical_gates import architecture_drift, actual_data_paths, evaluate_expectations


@pytest.mark.parametrize('path,content,reason', [
    ('pyproject.toml', '[project]\ndependencies=["surprise"]\n', 'sensitive_diff'),
    ('uv.lock', 'new lock contents', 'sensitive_diff'),
    ('src/new_package/__init__.py', '', 'new_top_level_module'),
    ('schemas/value.schema.json', '{}', 'sensitive_diff'),
    ('migrations/001.sql', 'ALTER TABLE historical ADD COLUMN value TEXT;', 'sensitive_diff'),
])
def test_mechanical_architecture_diff_detection(project, path, content, reason):
    base = git(project, 'rev-parse', 'HEAD')
    target = project / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content)
    git(project, 'add', path); git(project, 'commit', '-m', 'Unannounced architectural diff')
    report = architecture_drift(project, base, git(project, 'rev-parse', 'HEAD'), {})
    assert any(r.startswith(reason) for r in report['reasons'])


def test_public_api_and_import_boundary_detection(project):
    (project / 'src/example.py').write_text('def public(x: int):\n    return x\n')
    git(project, 'add', 'src'); git(project, 'commit', '-m', 'Public signature')
    base = git(project, 'rev-parse', 'HEAD')
    (project / 'src/example.py').write_text('import forbidden.storage\ndef public(x: str, y=None):\n    return x\n')
    git(project, 'add', 'src'); git(project, 'commit', '-m', 'Drift')
    report = architecture_drift(project, base, git(project, 'rev-parse', 'HEAD'), {'drift': {
        'public_api_paths': ['src/example.py'], 'import_boundaries': [{'from': 'src/**', 'deny': ['forbidden/**']}]}})
    assert 'public_interface_diff:src/example.py' in report['reasons']
    assert 'import_boundary:src/example.py' in report['reasons']


def test_actual_diff_data_escalation_has_path_evidence():
    assert actual_data_paths(['src/etl.py', 'docs/readme.md'], ['src/etl.py']) == ['src/etl.py']


def test_preregistered_expectations_distinguish_all_outcomes():
    expectations = [
        {'metric': 'rows', 'availability': 'registered', 'minimum': 10, 'maximum': 20},
        {'metric': 'duplicates', 'availability': 'registered', 'maximum': 0},
        {'metric': 'unknown', 'availability': 'unavailable', 'reason': 'No operator threshold supplied'},
        {'metric': 'missing', 'availability': 'registered', 'minimum': 1}]
    report = evaluate_expectations(expectations, {'rows': 15, 'duplicates': 1})
    assert [r['status'] for r in report['results']] == ['validated', 'violated', 'no_pre_registered_expectation', 'observation_requiring_human_judgment']
    assert not report['passed']
    with pytest.raises(AgentSystemError):
        evaluate_expectations([{'metric': 'rows', 'availability': 'registered'}], {})


def test_contract_linter_reports_private_context_without_guessing_semantics():
    warnings = lint_contract({'objective': 'First implement _private() with an internal cache in src/private.py'}, ['src/private.py'])
    assert {'private_symbol', 'prescriptive_steps', 'architecture_hint', 'implementer_path'} <= {w['code'] for w in warnings}
