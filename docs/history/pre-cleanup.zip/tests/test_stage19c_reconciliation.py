"""Offline semantic matrix and characterization of the unchanged production gate."""
import copy
import json
import socket
import subprocess
import time
from pathlib import Path

import pytest

from agent_system.agent_transport import InvocationBinding
from agent_system.codex_tool_session import CodexToolSession
from agent_system.errors import AgentSystemError
from agent_system.model_tool_boundary import ExecutionPolicy, IsolatedExecutionBridge, SecretFilter
from validation.stage19c_legacy_gate import ResponsesGate
from agent_system.runners.docker_isolated import DockerIsolatedRunner
from agent_system.runners.tool_docker import ToolDockerRunner
from validation.stage19c_reconciliation_model import OfflineReconciliationModel
from test_model_tool_boundary import function as current_function


def function(*args, **kwargs):
    item = current_function(*args, **kwargs)
    item.pop('namespace', None)
    return item


def policy():
    return ExecutionPolicy(InvocationBinding('exec-1', 'implementer', 'TASK', 1, 'offline-model', 'low'),
                           'implementation', 'owned-workspace', time.monotonic() + 300)


def stream(p, count=1, deltas=True):
    output = [dict(function(p, call_id=f'call-{i}'), id=f'fc-{i}') for i in range(count)]
    response = {'id': 'response-1', 'status': 'completed', 'output': output}
    events = [{'type': 'response.created', 'response': {**response, 'status': 'in_progress', 'output': []}}]
    for i, item in enumerate(output):
        events.append({'type': 'response.output_item.added', 'output_index': i,
                       'item': {**item, 'arguments': '', 'status': 'in_progress'}})
        if deltas:
            args = item['arguments']
            for part in (args[:len(args)//2], args[len(args)//2:]):
                events.append({'type': 'response.function_call_arguments.delta', 'output_index': i,
                               'item_id': item['id'], 'delta': part})
        events.append({'type': 'response.function_call_arguments.done', 'output_index': i,
                       'item_id': item['id'], 'arguments': item['arguments']})
        events.append({'type': 'response.output_item.done', 'output_index': i, 'item': copy.deepcopy(item)})
    events.append({'type': 'response.completed', 'response': copy.deepcopy(response)})
    return events


def encode(events, number=True):
    values = copy.deepcopy(events)
    if number:
        for seq, value in enumerate(values): value['sequence_number'] = seq
    return ''.join('event: ' + v['type'] + '\ndata: ' + json.dumps(v) + '\n\n' for v in values).encode()


# name, proposed-model acceptance, unchanged-gate acceptance
CASES = [
    ('one_valid', True, True), ('multiple_valid', True, True), ('item_differs_from_call', True, True),
    ('same_call_different_item', False, True), ('same_item_different_call', False, False),
    ('reordered_final', False, True), ('multiple_deltas', True, True), ('empty_arguments', False, False),
    ('done_without_deltas', True, True), ('duplicate_delta', False, True), ('duplicate_done', False, True),
    ('orphan_delta', False, True), ('orphan_done', False, True), ('duplicate_call_id', False, True),
    ('duplicate_item_id', False, True), ('function_name_mutation', False, False),
    ('call_id_mutation', False, False), ('conflicting_final_arguments', False, True),
    ('missing_final_call', False, False), ('extra_final_call', False, True),
    ('different_final_name', False, False), ('partial_stream', False, False),
    ('missing_completed', False, False), ('duplicate_completed', False, False),
    ('malformed_final_output', False, False), ('fake_hosted_tool', False, False),
    ('unknown_dynamic_tool', False, False), ('replayed_call', False, False),
    ('two_items_one_final', False, True), ('one_item_multiple_final', False, True),
    ('output_index_reuse', False, True), ('replayed_event', False, True),
    ('item_id_mutation', False, True), ('malformed_json_arguments', False, False),
    ('nested_output_schema', False, False), ('unsupported_event_as_call', False, True),
    ('arguments_done_creates_second_call', False, False), ('late_event_after_completion', False, False),
]


def case(p, name):
    events = stream(p, count=2 if name in ('multiple_valid', 'reordered_final', 'duplicate_call_id',
                                          'duplicate_item_id', 'two_items_one_final', 'output_index_reuse') else 1,
                    deltas=name != 'done_without_deltas')
    final = events[-1]['response']['output']
    if name in ('same_call_different_item', 'item_id_mutation'): final[0]['id'] = 'fc-other'
    elif name == 'same_item_different_call': final[0]['call_id'] = 'call-other'
    elif name == 'reordered_final': final.reverse()
    elif name in ('empty_arguments', 'malformed_json_arguments'):
        final[0]['arguments'] = '' if name == 'empty_arguments' else '{'
    elif name == 'duplicate_delta': events.insert(3, copy.deepcopy(events[2]))
    elif name == 'duplicate_done': events.insert(5, copy.deepcopy(events[4]))
    elif name in ('orphan_delta', 'orphan_done'):
        events[2 if name == 'orphan_delta' else 4]['item_id'] = 'orphan'
    elif name == 'duplicate_call_id':
        for event in events:
            if event.get('item', {}).get('type') == 'function_call': event['item']['call_id'] = 'same-call'
        for item in final: item['call_id'] = 'same-call'
    elif name == 'duplicate_item_id':
        for event in events:
            if 'item' in event: event['item']['id'] = 'same-item'
            if 'item_id' in event: event['item_id'] = 'same-item'
        for item in final: item['id'] = 'same-item'
    elif name == 'function_name_mutation': events[5]['item']['name'] = 'other'
    elif name == 'call_id_mutation': events[5]['item']['call_id'] = 'other'
    elif name == 'conflicting_final_arguments': final[0]['arguments'] = '{"different":true}'
    elif name == 'missing_final_call': final.clear()
    elif name == 'extra_final_call': final.append(dict(function(p, call_id='extra'), id='fc-extra'))
    elif name == 'different_final_name': final[0]['name'] = 'other'
    elif name == 'missing_completed': events.pop()
    elif name == 'duplicate_completed': events.append(copy.deepcopy(events[-1]))
    elif name == 'malformed_final_output': events[-1]['response']['output'] = {}
    elif name == 'fake_hosted_tool': final[0]['type'] = 'web_search_call'
    elif name == 'unknown_dynamic_tool': final[0]['name'] = 'agentctl_execute_unknown'
    elif name == 'two_items_one_final':
        for event in events:
            if 'item' in event: event['item']['call_id'] = 'same-call'
        for item in final: item['call_id'] = 'same-call'
        final.pop()
    elif name == 'one_item_multiple_final': final.append(dict(final[0], id='fc-other'))
    elif name == 'output_index_reuse':
        for event in events:
            if event.get('output_index') == 1: event['output_index'] = 0
    elif name == 'nested_output_schema': events[-1]['response']['output'] = [final]
    elif name == 'unsupported_event_as_call':
        events[2]['item'] = copy.deepcopy(final[0])  # known delta type carrying an undocumented item
    elif name == 'arguments_done_creates_second_call':
        events[4]['item'] = dict(final[0], call_id='phantom')
    elif name == 'late_event_after_completion': events.append(copy.deepcopy(events[2]))
    raw = encode(events)
    if name == 'partial_stream': raw = raw[:-1]
    if name == 'replayed_event':
        for seq, event in enumerate(events): event['sequence_number'] = seq
        events.insert(3, copy.deepcopy(events[2]))
        raw = encode(events, number=False)
    return raw


def replay_with_new_response_and_item(raw):
    # Isolate logical-call replay from replay of the response or item identity.
    events = [json.loads(frame.split('\ndata: ', 1)[1]) for frame in raw.decode().strip().split('\n\n')]
    for event in events:
        if 'response' in event:
            event['response']['id'] = 'response-2'
            for item in event['response']['output']: item['id'] = 'fresh-item'
        if 'item' in event: event['item']['id'] = 'fresh-item'
        if 'item_id' in event: event['item_id'] = 'fresh-item'
    return encode(events)


@pytest.fixture
def traps(monkeypatch):
    reached = []
    def trap(label):
        def fail(*args, **kwargs):
            reached.append(label)
            pytest.fail('Executor trap reached: ' + label)
        return fail
    for obj, name, label in [(CodexToolSession, 'handle', 'tool_dispatcher'),
                             (IsolatedExecutionBridge, 'execute', 'bridge'),
                             (DockerIsolatedRunner, '_docker', 'docker'),
                             (ToolDockerRunner, 'run_tool', 'docker_tool_runner'),
                             (subprocess, 'run', 'host_run'), (subprocess, 'Popen', 'host_popen'),
                             (socket, 'create_connection', 'network')]:
        monkeypatch.setattr(obj, name, trap(label))
    return reached, trap('codex_downstream_acceptance')


@pytest.mark.parametrize('name,accepted,old_accepted', CASES, ids=[c[0] for c in CASES])
def test_proposed_state_machine(name, accepted, old_accepted, traps):
    p = policy()
    model = OfflineReconciliationModel(p)
    raw = case(p, name)
    if name == 'replayed_call':
        model.response(raw)
        raw = replay_with_new_response_and_item(raw)
    reached, downstream = traps
    if accepted:
        assert model.response(raw) == raw
        assert model.authorized_arguments
    else:
        with pytest.raises(AgentSystemError):
            downstream(model.response(raw))
        assert not model.authorized_arguments
    assert reached == []


@pytest.mark.parametrize('name,accepted,old_accepted', CASES, ids=[c[0] for c in CASES])
def test_unchanged_gate_characterization(name, accepted, old_accepted, traps):
    gate = ResponsesGate(policy())
    raw = case(gate.policy, name)
    if name == 'replayed_call':
        gate.response(raw)
        raw = replay_with_new_response_and_item(raw)
    if old_accepted: assert gate.response(raw) == raw
    else:
        with pytest.raises(AgentSystemError): gate.response(raw)
    assert traps[0] == []  # Characterization never hands accepted attacks to any consumer.


def test_old_failure_has_same_namespace_and_no_delta_mapping():
    p = policy()
    events = stream(p)
    # Any number/identity of plain arguments events is ignored by the old gate.
    events[2]['item_id'] = 'call-not-item'
    assert ResponsesGate(p).response(encode(events))
    events[5]['item']['call_id'] = 'changed-call'
    with pytest.raises(AgentSystemError, match='Partial tool completion'):
        ResponsesGate(p).response(encode(events))


def test_old_gate_publishes_before_failed_completion_and_overwrites():
    p = policy()
    events = stream(p)
    events[-1]['response']['output'][0]['call_id'] = 'other-call'
    gate = ResponsesGate(p)
    with pytest.raises(AgentSystemError, match='Partial tool completion'): gate.response(encode(events))
    assert 'other-call' in gate.authorized_arguments  # Existing state bug; no consumer is called.
    events = stream(p)
    events[-1]['response']['output'].append(dict(events[-1]['response']['output'][0], arguments='{}'))
    gate = ResponsesGate(p)
    gate.response(encode(events))
    assert gate.authorized_arguments['call-0'] == '{}'


def test_model_secret_bounds_and_failed_response_atomicity(traps):
    p = policy()
    model = OfflineReconciliationModel(p, SecretFilter(['synthetic-private-value']))
    events = stream(p)
    events[2]['delta'] = 'synthetic-private-value'
    with pytest.raises(AgentSystemError): model.response(encode(events))
    assert not model.authorized_arguments and not model.gate.seen_calls
    with pytest.raises(AgentSystemError): model.response(b'x' * (p.max_response_bytes + 1))
    assert not model.authorized_arguments


def test_sequence_duplicate_vs_identical_distinct_fragments():
    # Equal fragment text is not intrinsically a replay: sequence numbers decide.
    p = policy()
    events = stream(p)
    argument = events[-1]['response']['output'][0]['arguments']
    pos = argument.index('exec-1')
    parts = [argument[:pos], 'e', 'x', 'e', argument[pos+3:]]
    deltas = [dict(events[2], delta=part) for part in parts]
    events[2:4] = deltas
    assert OfflineReconciliationModel(p).response(encode(events))


def test_historical_bytes_unchanged_and_legacy_algorithm_frozen():
    import hashlib
    root = Path(__file__).resolve().parents[1]
    baseline = json.loads((root/'docs/stage19c-evidence/baseline-hashes.json').read_text())
    assert all(hashlib.sha256((root/name).read_bytes()).hexdigest() == digest for name, digest in baseline.items()
               if not name.startswith('agent_system/'))
    # Stage19d intentionally changes production. Historical expectations run against frozen methods.
    import ast
    assert 'set(calls) - set(final_calls)' in ast.unparse(ast.parse((root/'validation/stage19c_legacy_gate.py').read_text()))
