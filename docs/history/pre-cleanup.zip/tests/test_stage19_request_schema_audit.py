"""Offline documentary audit must preserve uncertainty and proposed-only changes."""
import copy
import json
from pathlib import Path
from jsonschema import Draft202012Validator

from validation.stage19_request_schema_audit import audit, candidates

ROOT = Path(__file__).resolve().parents[1]


def fixture():
    directory = ROOT/'docs/stage19-request-audit-evidence'
    return [json.loads((directory/name).read_text()) for name in
            ('conformance-2-postgate.sanitized.json','conformance-2-native.sanitized.json')]


def test_documented_values_pass_and_unproven_fields_remain_review():
    body, native = fixture()
    rows = audit(body, native)
    checked = {r['path']:r['verdict'] for r in rows}
    for field in ('tools[0]','reasoning.context','text','include','tool_choice','parallel_tool_calls'):
        assert checked[field]=='MATCH'
    assert checked['parameters.properties.execution_id']=='REVIEW'
    assert checked['input[0].extra_fields']=='REVIEW'


def test_candidate_does_not_mutate_controller_schema_and_preserves_constants():
    body, _ = fixture()
    original = copy.deepcopy(body)
    typed, patch = candidates(body)
    assert body==original and len(patch)==7
    before = body['tools'][0]['tools'][0]['parameters']
    after = typed['tools'][0]['tools'][0]['parameters']
    Draft202012Validator.check_schema(after)
    assert after['required']==before['required'] and after['additionalProperties'] is False
    for name, value in before['properties'].items():
        if 'const' in value:
            assert after['properties'][name]['const']==value['const']
            assert Draft202012Validator(after['properties'][name]).is_valid(value['const'])
            assert not Draft202012Validator(after['properties'][name]).is_valid('wrong-identity')
    assert typed['tools'][0]['tools'][0]['strict'] is True


def test_forbidden_siwc_field_is_flagged():
    body, native = fixture()
    body['max_output_tokens'] = 100
    assert audit(body, native)[0]['verdict'] == 'REVIEW'
