import pytest

from agent_system.config import Configuration
from agent_system.errors import AgentSystemError
from agent_system.git import WorktreeManager, git


def test_same_base_resume_and_privacy(project):
    manager = WorktreeManager(Configuration.load(project))
    base = git(project, "rev-parse", "HEAD")
    first = manager.prepare("T-1", base, False)
    assert set(first["worktrees"]) == {"implementer", "tester", "integration", "reviewer"}
    assert manager.prepare("T-1", base, False) == first
    for entry in first["worktrees"].values():
        assert git(project, "rev-parse", entry["branch"]) == base
    assert not git(project, "ls-files", "--", ".agent_runs", ".agent_worktrees")
    assert ".agent_worktrees" not in git(project, "status", "--porcelain")


def test_auditor_only_for_data_critical(project):
    manager = WorktreeManager(Configuration.load(project))
    manifest = manager.prepare("T-data", git(project, "rev-parse", "HEAD"), True)
    assert "auditor" in manifest["worktrees"]


def test_cleanup_refuses_dirty_then_preserves_commits(project):
    manager = WorktreeManager(Configuration.load(project))
    base = git(project, "rev-parse", "HEAD")
    manifest = manager.prepare("T-1", base, False)
    from pathlib import Path
    implementation = Path(manifest["worktrees"]["implementer"]["path"])
    (implementation / "src/example.py").write_text("value = 2\n")
    with pytest.raises(AgentSystemError, match="dirty"):
        manager.cleanup("T-1")
    assert all(Path(entry["path"]).exists() for entry in manifest["worktrees"].values())
    git(implementation, "add", ".")
    git(implementation, "commit", "-m", "Implementation")
    commit = git(implementation, "rev-parse", "HEAD")
    manager.cleanup("T-1")
    manager.cleanup("T-1")
    assert not implementation.exists()
    manager.prepare("T-1", base, False)
    assert git(implementation, "rev-parse", "HEAD") == commit
    assert git(project, "rev-parse", "HEAD") == base


def test_cleanup_refuses_ignored_files(project):
    from pathlib import Path
    manager = WorktreeManager(Configuration.load(project))
    manifest = manager.prepare("T-1", git(project, "rev-parse", "HEAD"), False)
    tree = Path(manifest["worktrees"]["implementer"]["path"])
    (tree / "__pycache__").mkdir()
    (tree / "__pycache__/important.pyc").write_text("preserve")
    with pytest.raises(AgentSystemError, match="ignored"):
        manager.cleanup("T-1")


def test_unowned_branch_not_adopted(project):
    manager = WorktreeManager(Configuration.load(project))
    base = git(project, "rev-parse", "HEAD")
    git(project, "branch", "agent/T-1/tester", base)
    with pytest.raises(AgentSystemError, match="Unowned branch"):
        manager.prepare("T-1", base, False)
    assert not manager.manifest_path("T-1").exists()


def test_partial_creation_resumes(project, monkeypatch):
    manager = WorktreeManager(Configuration.load(project))
    base = git(project, "rev-parse", "HEAD")
    original = manager._ensure
    calls = []
    def interrupted(entry, base):
        calls.append(entry)
        if len(calls) == 2:
            raise AgentSystemError("Synthetic interruption")
        original(entry, base)
    monkeypatch.setattr(manager, "_ensure", interrupted)
    with pytest.raises(AgentSystemError, match="interruption"):
        manager.prepare("T-1", base, False)
    monkeypatch.setattr(manager, "_ensure", original)
    assert len(manager.prepare("T-1", base, False)["worktrees"]) == 4


def test_missing_gitignore_blocks_runtime(project):
    (project / ".gitignore").write_text("")
    with pytest.raises(AgentSystemError, match="gitignore"):
        WorktreeManager(Configuration.load(project))

