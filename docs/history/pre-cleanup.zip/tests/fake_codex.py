"""Offline executable fixture. It exercises process I/O without model calls."""
import json
import sys
from pathlib import Path

args = sys.argv[1:]
prompt = sys.stdin.read()
if "TIMEOUT" in prompt:
    import time
    time.sleep(5)
if "MODIFY_FORBIDDEN" in prompt:
    (Path.cwd() / "forbidden.txt").write_text("unexpected")
if "MODIFY_ALLOWED" in prompt:
    (Path.cwd() / "src/example.py").write_text("value = 2\n")
if "EXIT_FAILURE" in prompt:
    raise SystemExit(7)
Path(args[args.index("--output-last-message") + 1]).write_text("offline backend completed", encoding="utf-8")
print(json.dumps({"type": "turn.completed"}))
