import json
from pathlib import Path
import time

import pytest

from agent_system.agent_transport import InvocationBinding
from agent_system.chatgpt_plan_transport import AppServerBoundary, IsolatedToolBridge, ModelRequestPolicy, PlanModelBoundary
from agent_system.errors import AgentSystemError


@pytest.fixture
def boundary():
    return PlanModelBoundary(ModelRequestPolicy('execution', 'TASK', 'implementer', 'explicit-model', time.monotonic() + 60))


def request(**updates):
    return json.dumps({'model': 'explicit-model', 'input': [], 'stream': True, 'store': False, **updates}).encode()


def test_model_request_fixed_identity_and_ceiling(boundary):
    for _ in range(4):
        assert boundary.authorize('execution', 'TASK', 'implementer', request())['model'] == 'explicit-model'
    with pytest.raises(AgentSystemError, match='ceiling'):
        boundary.authorize('execution', 'TASK', 'implementer', request())


@pytest.mark.parametrize('ids', [('other', 'TASK', 'implementer'), ('execution', 'OTHER', 'implementer'), ('execution', 'TASK', 'reviewer')])
def test_wrong_execution_task_role_rejected(boundary, ids):
    with pytest.raises(AgentSystemError, match='identity'):
        boundary.authorize(*ids, request())
    assert boundary.requests == 0


@pytest.mark.parametrize('changes', [{'model': 'other'}, {'url': 'https://example.com'}, {'stream': False},
                                   {'store': True}, {'max_output_tokens': 5}, {'previous_response_id': 'old'},
                                   {'input': [{'role': 'system'}]}, {'tools': [{'type': 'tool_search'}]},
                                   {'tools': [{'type': 'namespace', 'tools': [{'type': 'file_search'}]}]}])
def test_wrong_model_arbitrary_url_or_unsupported_capability_rejected(boundary, changes):
    with pytest.raises(AgentSystemError):
        boundary.authorize('execution', 'TASK', 'implementer', request(**changes))


def test_stale_closed_and_oversized_requests_rejected(boundary):
    with pytest.raises(AgentSystemError, match='oversized'):
        boundary.authorize('execution', 'TASK', 'implementer', b'x' * 262145)
    boundary.close()
    with pytest.raises(AgentSystemError, match='Stale'):
        boundary.authorize('execution', 'TASK', 'implementer', request())
    expired = PlanModelBoundary(ModelRequestPolicy('execution', 'TASK', 'implementer', 'explicit-model', 0))
    with pytest.raises(AgentSystemError, match='Stale'):
        expired.authorize('execution', 'TASK', 'implementer', request())


def test_no_live_inference_method_or_upstream_credential(boundary):
    assert not hasattr(boundary, 'http') and not hasattr(boundary, 'access_token')
    with pytest.raises(AgentSystemError, match='not admitted'):
        boundary.require_live()


def test_generated_tools_only_call_isolated_runner(monkeypatch):
    import subprocess
    monkeypatch.setattr(subprocess, 'run', lambda *a, **k: pytest.fail('Untrusted host execution'))
    calls = []
    class Capabilities:
        def require(self): calls.append('admitted')
    class Runner:
        backend = 'docker_isolated'
        def isolation_capabilities(self): return Capabilities()
        def run_command(self, *args, **kwargs): calls.append((args, kwargs)); return 'isolated-result'
    bridge = IsolatedToolBridge(Runner(), Path('controller-selected'), {'task_id': 'TASK'}, 'execution', 'implementer')
    assert bridge.execute({'execution_id': 'execution', 'task_id': 'TASK', 'role': 'implementer',
                           'argv': ['python', '-c', 'print(1)']}) == 'isolated-result'
    assert calls[0] == 'admitted' and calls[1][1] == {'read_only': True}
    assert calls[1][0][2] == {}  # no inherited credential/environment
    with pytest.raises(AgentSystemError):
        bridge.execute({'execution_id': 'execution', 'task_id': 'TASK', 'role': 'implementer', 'argv': ['ls'], 'cwd': '/host'})
    bridge.close()
    with pytest.raises(AgentSystemError):
        bridge.execute({})


def test_unsupported_runner_never_falls_back_to_host():
    with pytest.raises(AgentSystemError, match='Docker'):
        IsolatedToolBridge(object(), Path('.'), {}, 'execution', 'implementer')


@pytest.mark.parametrize('method', ['item/commandExecution/requestApproval', 'item/fileChange/requestApproval'])
def test_host_builtin_tool_approvals_declined(method):
    server = AppServerBoundary(InvocationBinding('execution', 'implementer', 'TASK', 1, 'explicit-model', 'low'))
    assert server.handle_server_request({'id': 10, 'method': method}) == {'id': 10, 'result': {'decision': 'decline'}}
    with pytest.raises(AgentSystemError, match='isolated'):
        server.start_turn()


def test_unknown_server_tool_request_rejected():
    server = AppServerBoundary(None)
    with pytest.raises(AgentSystemError, match='not admitted'):
        server.handle_server_request({'id': 11, 'method': 'item/tool/call'})
