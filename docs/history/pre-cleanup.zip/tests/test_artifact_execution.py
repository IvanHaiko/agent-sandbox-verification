import hashlib
from pathlib import Path

import pytest

from agent_system.artifact_execution import implementation_handoff
from agent_system.errors import AgentSystemError
from agent_system.runners.docker_isolated import file_map


def setup_candidate(tmp_path):
    workspace=tmp_path/'workspace'; (workspace/'src').mkdir(parents=True)
    candidate=workspace/'src/normalize_labels.py'
    candidate.write_text('def normalize_labels(value: str) -> list[str]:\n    raise NotImplementedError\n')
    baseline={'hashes':file_map(workspace),'source':candidate.read_text()}
    candidate.write_text('def normalize_labels(value: str) -> list[str]:\n    return []\n')
    return workspace,baseline,candidate


def handoff(tmp_path, **overrides):
    workspace,baseline,candidate=setup_candidate(tmp_path)
    arguments=dict(successful_write_paths={'src/normalize_labels.py'},failure_category=None,
        security_violation=False,shutdown_confirmed=True,
        interface_check=lambda data:{'public_interface_verified':True})
    arguments.update(overrides)
    return implementation_handoff(workspace,baseline,'src/normalize_labels.py',
        tmp_path/'archive/candidate.py',**arguments)


def test_completed_write_without_model_handoff_remains_unaccepted(tmp_path):
    result=handoff(tmp_path)
    assert result['execution_status']=='completed'
    assert not result['model_handoff_received'] and not result['accepted']
    assert result['candidate_hashes']['src/normalize_labels.py']==hashlib.sha256((tmp_path/'archive/candidate.py').read_bytes()).hexdigest()
    assert '-    raise NotImplementedError' in result['diff_summary']


@pytest.mark.parametrize('failure',['socket_idle_timeout','stream_transport_failure','handoff_schema_failure','handoff_finalization_failure'])
def test_late_transport_or_narration_failure_recovers_artifact(tmp_path,failure):
    result=handoff(tmp_path,failure_category=failure)
    assert result['execution_status']=='abnormal_recoverable' and result['failure_category']==failure
    assert not result['accepted']


@pytest.mark.parametrize('change',[{'failure_category':'controller_rejection'},
    {'failure_category':'tool_request_validation_failure'}, {'failure_category':'response_validation_failure'},
    {'failure_category':'unknown_runtime_failure'}, {'security_violation':True},
    {'shutdown_confirmed':False}, {'successful_write_paths':set()},
    {'interface_check':lambda data:{'public_interface_verified':False}}])
def test_unsafe_or_incomplete_execution_never_recovers(tmp_path,change):
    with pytest.raises(AgentSystemError): handoff(tmp_path,**change)


def test_scope_violation_blocks_even_successful_write(tmp_path):
    workspace,baseline,candidate=setup_candidate(tmp_path)
    (workspace/'unexpected.py').write_text('bad=1')
    with pytest.raises(AgentSystemError,match='scope'):
        implementation_handoff(workspace,baseline,'src/normalize_labels.py',tmp_path/'archive.py',
            successful_write_paths={'src/normalize_labels.py'},failure_category='socket_idle_timeout',
            security_violation=False,shutdown_confirmed=True,interface_check=lambda data:{'public_interface_verified':True})


def test_mutation_during_interface_check_blocks_handoff(tmp_path):
    workspace,baseline,candidate=setup_candidate(tmp_path)
    def check(data):
        candidate.write_text('changed during check')
        return {'public_interface_verified':True}
    with pytest.raises(AgentSystemError,match='changed during'):
        implementation_handoff(workspace,baseline,'src/normalize_labels.py',tmp_path/'archive.py',
            successful_write_paths={'src/normalize_labels.py'},failure_category=None,
            security_violation=False,shutdown_confirmed=True,interface_check=check)
