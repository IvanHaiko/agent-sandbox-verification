import copy
import json
import time
import pytest
from agent_system.agent_transport import InvocationBinding
from agent_system.model_tool_boundary import ExecutionPolicy, ResponsesGate
from agent_system.errors import AgentSystemError
from validation.stage19e_matrix import variant_body, fingerprint, consume_variant, next_variant

def baseline():
    policy = ExecutionPolicy(InvocationBinding('e','implementer','STAGE19-SMOKE',1,'gpt-6-sol','low'),
        'implementation','owned',time.monotonic()+60)
    body = {'model':'gpt-6-sol','store':False,'stream':True,
        'reasoning':{'effort':'low','context':'all_turns'}, 'text':{'verbosity':'low'},
        'include':['reasoning.encrypted_content'], 'parallel_tool_calls':False,
        'input':[{'role':'user','id':'opaque-local-id','content':'private text'}]}
    result = ResponsesGate(policy).request(json.dumps(body).encode())
    # Reconstruct the frozen pre-correction baseline after production repair.
    for prop in result['tools'][0]['tools'][0]['parameters']['properties'].values():
        if 'const' in prop: prop.pop('type', None)
    return result

@pytest.mark.parametrize('variant', ['A_BASELINE','B_TYPED_CONST','C_NO_MESSAGE_IDS','D_NON_STRICT_CONTROL','E_CATALOG_MODEL_CONTROL'])
def test_only_authorized_factor_changes(variant):
    original = baseline()
    unchanged = copy.deepcopy(original)
    result = variant_body(original, variant, 'gpt-6-astra')
    assert original == unchanged
    if variant == 'B_TYPED_CONST':
        props = result['tools'][0]['tools'][0]['parameters']['properties']
        old = original['tools'][0]['tools'][0]['parameters']['properties']
        assert sum('type' not in p for p in old.values()) == 7
        for key in old:
            assert props[key] == (dict(old[key], type='integer' if key=='contract_version' else 'string')
                                 if set(old[key])=={'const'} else old[key])
        result['tools'] = original['tools']
    elif variant == 'C_NO_MESSAGE_IDS':
        assert result['input'] == [{'role':'user','content':'private text'}]
        result['input'] = original['input']
    elif variant == 'D_NON_STRICT_CONTROL':
        assert result['tools'][0]['tools'][0]['strict'] is False
        result['tools'][0]['tools'][0]['strict'] = True
    elif variant == 'E_CATALOG_MODEL_CONTROL':
        assert result['model'] == 'gpt-6-astra'
        result['model'] = original['model']
    assert result == original

def test_fingerprint_suppresses_ids_and_content_but_tracks_changes():
    original = baseline()
    other = copy.deepcopy(original)
    other['input'][0].update(id='different-id', content='credential-shaped-private-value')
    assert fingerprint(original) == fingerprint(other)
    for variant in ('B_TYPED_CONST','C_NO_MESSAGE_IDS','D_NON_STRICT_CONTROL','E_CATALOG_MODEL_CONTROL'):
        assert fingerprint(original) != fingerprint(variant_body(original,variant,'gpt-6-astra'))

def test_variant_consumed_before_dispatch_replay_denied_across_processes(tmp_path):
    ledger = []
    consume_variant(tmp_path,'E_CATALOG_MODEL_CONTROL',ledger)
    assert ledger == ['E_CATALOG_MODEL_CONTROL']
    with pytest.raises(AgentSystemError): consume_variant(tmp_path,'E_CATALOG_MODEL_CONTROL',ledger)
    with pytest.raises(FileExistsError): consume_variant(tmp_path,'E_CATALOG_MODEL_CONTROL',[])
    with pytest.raises(AgentSystemError): consume_variant(tmp_path,'UNAUTHORIZED',[])
    with pytest.raises(AgentSystemError): consume_variant(tmp_path,'A_BASELINE',['x']*5)

def test_evidence_driven_routing_stops_security_and_success():
    record = {'http_status':400,'http_error':{'message_category':'invalid_schema','param':'tools[0].tools[0].parameters'}}
    assert next_variant(record,['E_CATALOG_MODEL_CONTROL']) == 'B_TYPED_CONST'
    assert next_variant(record,['E_CATALOG_MODEL_CONTROL','B_TYPED_CONST']) == 'D_NON_STRICT_CONTROL'
    record['http_error'] = {'message_category':'unknown_parameter','param':'input[0].id'}
    assert next_variant(record,[]) == 'C_NO_MESSAGE_IDS'
    for category in ('authentication','permission','model_unavailable','usage_limit','plan_eligibility'):
        record['http_error'] = {'message_category':category}
        assert next_variant(record,[]) is None
    for status in (200,401,403,429,500):
        record['http_status'] = status
        assert next_variant(record,[]) is None

def test_production_schema_equals_admitted_typed_candidate_and_enforces_identity():
    from jsonschema import Draft202012Validator
    from agent_system.model_tool_boundary import tool_spec
    policy = ExecutionPolicy(InvocationBinding('e','implementer','STAGE19-SMOKE',1,'gpt-6-sol','low'),
        'implementation','owned',time.monotonic()+60)
    candidate = variant_body(baseline(),'B_TYPED_CONST')['tools'][0]['tools'][0]
    spec = tool_spec(policy)
    assert spec['inputSchema'] == candidate['parameters']
    assert candidate['strict'] is True
    request = {**policy.identity(),'tool_type':'argv','argv':['python','-c','print(1)'],
               'stdin':'','read_only':True,'timeout_seconds':5,'output_bytes':1048576}
    validator = Draft202012Validator(spec['inputSchema'])
    assert validator.is_valid(request)
    for key in (*policy.identity(), 'tool_type'):
        wrong = dict(request)
        wrong[key] = True if key=='contract_version' else 'other-authority'
        assert not validator.is_valid(wrong)
    assert not validator.is_valid(dict(request, arbitrary_permission=True))
