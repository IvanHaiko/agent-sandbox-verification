"""Structured offline role backend used through the real subprocess runner."""
import json
import re
import sys
from pathlib import Path

args = sys.argv[1:]
prompt = sys.stdin.read()
decoder = json.JSONDecoder()
task = decoder.raw_decode(prompt.split("Task contract:\n", 1)[1])[0]
context = decoder.raw_decode(prompt.split("Context manifest:\n", 1)[1])[0]
phase = context["phase"]
cycle = int(re.match(r"c(\d+)-", context["operation_id"])[1])
scenario = re.search(r"scenario=([a-z_]+)", task["objective"])
scenario = scenario[1] if scenario else "ordinary"
task_id = task["task_id"]
root = Path.cwd()
output = Path(args[args.index("--output-last-message") + 1])


def package():
    return {"task_id": task_id, "decision_id": "ARCH-" + task_id,
            "problem": "Choose approved persistence contract", "why_architectural": "Public storage contract changes",
            "constraints": ["Preserve existing raw observations"],
            "options": [{"id": "A", "description": "Keep the existing interface and add an approved adapter",
                         "advantages": ["Compatible consumers"], "disadvantages": ["Adapter maintenance"],
                         "risks": ["Conversion edge cases"], "migration_impact": "No destructive migration",
                         "compatibility_impact": "Existing interface retained"},
                        {"id": "B", "description": "Use an explicitly versioned new interface",
                         "advantages": ["Clearer contract"], "disadvantages": ["Consumer migration"],
                         "risks": ["Compatibility gaps"], "migration_impact": "Dual-read transition",
                         "compatibility_impact": "Old interface supported during transition"}], "recommended_option": "A"}


if scenario == "infra_always" and phase == "implementation":
    raise SystemExit(7)
if scenario == "infra_once" and phase == "implementation":
    marker = output.parents[2] / "fake-infra-once"
    if not marker.exists():
        marker.write_text("first failure")
        raise SystemExit(7)
if phase == "architecture":
    report = package()
elif phase == "test_design":
    report = {"task_id": task_id, "cases": [
        {"id": f"ACCEPT-{i}", "category": "acceptance", "priority": "critical", "criterion": i,
         "preconditions": [], "action": "Read value through the public module interface",
         "expected_result": criterion, "fixtures": []} for i, criterion in enumerate(task["acceptance_criteria"])]}
elif phase in ("implementation", "fix"):
    broken = scenario == "tests_always" or (scenario == "tests_first" and cycle == 0)
    (root / "src/example.py").write_text("value = " + ("0" if broken else "2") + "\n")
    report = {"task_id": task_id, "outcome": "completed", "summary": "Implemented public contract",
              "architecture_decision": None}
    if scenario == "primary_protected":
        (root.parents[2] / "data/raw/raw.txt").write_text("changed protected bytes")
elif phase == "test_implementation":
    target = root / "tests/acceptance"
    target.mkdir(parents=True, exist_ok=True)
    code = "from src.example import value\n\ndef test_contract():\n    assert value == 2\n"
    (target / "test_answer.py").write_text(code)
    report = {"task_id": task_id, "summary": "Frozen acceptance cases implemented", "independent": [
        {"case_id": "ACCEPT-0", "path": "tests/acceptance/test_answer.py",
         "test_id": "tests/acceptance/test_answer.py::test_contract"}], "additional": []}
    if scenario == "additional":
        (target / "test_additional.py").write_text("def test_new_boundary():\n    assert isinstance(2, int)\n")
        report["additional"].append({"path": "tests/acceptance/test_additional.py",
                                   "test_id": "tests/acceptance/test_additional.py::test_new_boundary",
                                   "reason": "Additional implementation-specific type regression"})
    if scenario == "tester_production":
        (root / "src/example.py").write_text("value = 3\n")
elif phase == "review":
    severity = None
    if scenario in ("review_blocker", "review_major", "review_minor", "review_nit"):
        severity = scenario.split("_")[1].upper()
    if scenario == "review_first" and cycle == 0:
        severity = "MAJOR"
    if scenario == "review_second" and cycle < 2:
        severity = "MAJOR"
    findings = [] if severity is None else [{"severity": severity, "location": "src/example.py:1",
         "problem": "Synthetic review finding", "impact": "Contract quality", "evidence": "Observed candidate",
         "recommended_correction": "Correct the scoped issue"}]
    report = {"task_id": task_id, "summary": "Reviewed implementation and tests", "findings": findings,
              "architecture_decision": package() if scenario == "review_architecture" and not context["inputs"]["architecture_selection"] else None}
    if scenario == "reviewer_tracked":
        (root / "src/example.py").write_text("value = 9\n")
    if scenario == "reviewer_untracked":
        (root / "unexpected.txt").write_text("mutation")
    if scenario == "reviewer_ignored":
        (root / "__pycache__").mkdir(exist_ok=True)
        (root / "__pycache__/unexpected.pyc").write_text("mutation")
elif phase == "audit":
    failed = scenario == "audit_always" or (scenario == "audit_first" and cycle == 0)
    report = {"task_id": task_id, "verdict": "FAIL" if failed else "PASS", "summary": "Audited relevant data invariant",
              "checks": [{"name": "Contract reconciliation", "evidence": "Scoped source/output contract", "passed": not failed}],
              "findings": [], "architecture_decision": None}
    if scenario == "auditor_tracked":
        (root / "src/example.py").write_text("value = 10\n")
else:
    raise SystemExit("Unknown phase")
output.write_text(json.dumps(report), encoding="utf-8")
print(json.dumps({"type": "turn.completed"}))
