"""Synthetic socket tests only: no OAuth or external request is permitted."""
import json
import time
from urllib.error import HTTPError
from types import SimpleNamespace
import threading

import pytest

from agent_system.errors import AgentSystemError
from agent_system.model_tool_boundary import SecretFilter
from agent_system.responses_http import error_metadata, capture_http_error
from test_transport_diagnostics import response


def payload(**kw):
    return json.dumps({'error': {'type': 'invalid_request_error', 'code': 'invalid_json_schema',
        'param': 'tools[0].tools[0].parameters', 'message': 'Invalid schema in private account context', **kw}}).encode()


def test_static_metadata_only():
    result = error_metadata(payload(), 400, SecretFilter())
    assert result == {'status': 400, 'type': 'invalid_request_error', 'code': 'invalid_json_schema',
        'param': 'tools[0].tools[0].parameters', 'message_category': 'invalid_schema'}
    assert 'private' not in json.dumps(result)


@pytest.mark.parametrize('field', ['type', 'code', 'param', 'message', 'ignored'])
@pytest.mark.parametrize('escaped', [False, True])
def test_secret_including_ignored_or_escaped_fields_suppresses_metadata(field, escaped):
    secret = 'synthetic-credential-sensitive-12345'
    raw = payload(**{field: secret})
    if escaped: raw = raw.replace(secret.encode(), ''.join('\\u%04x' % ord(c) for c in secret).encode())
    result = error_metadata(raw, 400, SecretFilter([secret]))
    assert result == {'status': 400, 'type': None, 'code': None, 'param': None,
                      'message_category': 'suppressed_or_malformed'}


@pytest.mark.parametrize('raw', [b'private text', b'\xff', b'[]', b'{}', b'{"error":"private"}',
    b'{"error":{"type":"a","type":"b"}}', b'{"error":{"code":NaN}}', b'x' * 16385,
    b'{"error":{"message":123}}'])
def test_invalid_envelope_never_dumps(raw):
    result = error_metadata(raw, 400, SecretFilter())
    assert set(result) == {'status', 'type', 'code', 'param', 'message_category'}
    assert 'private' not in json.dumps(result)


@pytest.mark.parametrize('param', ['tools[0].tools[0].parameters.properties.execution_id.type',
    'reasoning.context', 'input[12].content[0].type', 'text.verbosity', 'include'])
def test_known_request_parameter_paths(param):
    assert error_metadata(payload(param=param), 400, SecretFilter())['param'] == param


@pytest.mark.parametrize('param', ['account.secret-id', 'tools[123456789].name', 'api_key',
    'tools[0]private', 'tools..name', 'tools[0].message', 'x' * 257, 42])
def test_arbitrary_parameter_names_never_escape(param):
    assert error_metadata(payload(param=param), 400, SecretFilter())['param'] is None


@pytest.mark.parametrize('field', ['type', 'code'])
def test_unknown_machine_identifier_redacted(field):
    result = error_metadata(payload(**{field: 'account_arbitrary_private_token'}), 400, SecretFilter())
    assert result[field] == 'unrecognized'
    assert 'account_' not in json.dumps(result)


@pytest.mark.parametrize('code,category', [
    ('subscription_sharing_user_not_eligible','plan_eligibility'),
    ('subscription_sharing_usage_limit_exceeded','usage_limit'),
    ('subscription_sharing_usage_unavailable','plan_availability'),
    ('subscription_sharing_unsupported_capability','unsupported_capability'),
    ('subscription_sharing_route_not_supported','unsupported_route'),
    ('subscription_sharing_invalid_user','authentication'),
    ('subscription_sharing_user_unavailable','plan_availability'),
    ('chatpass_v2_scope_not_authorized','permission'),
    ('chatpass_v2_invalid_authorization_context','permission')])
def test_documented_siwc_codes_retained_without_prose(code, category):
    result = error_metadata(payload(code=code, message='arbitrary private prose'), 400, SecretFilter())
    assert result['code']==code and result['message_category']==category
    assert 'private' not in json.dumps(result)


def test_real_owned_http_error_socket_closed_after_capture():
    with response(payload()) as value:
        value.status = 400
        error = HTTPError('https://api.openai.com/v1/responses', 400, 'private reason', value.headers, value)
        result = capture_http_error(error, SimpleNamespace(deadline=time.monotonic()+5), SecretFilter())
        assert result['status'] == 400 and result['code'] == 'invalid_json_schema'
        assert value.isclosed()


@pytest.mark.parametrize('mode', ['oversized-length', 'truncated', 'bad-encoding', 'ambiguous-length', 'overflow'])
def test_unsafe_reader_suppresses_all_error_body_metadata(mode):
    extra = {'oversized-length': ('Content-Length: 16385',), 'truncated': ('Content-Length: 16000',),
             'bad-encoding': ('Content-Encoding: gzip',),
             'ambiguous-length': ('Content-Length: 12', 'Transfer-Encoding: chunked'),
             'overflow': ('Transfer-Encoding: chunked',)}[mode]
    data = b'x' * 16385 if mode == 'overflow' else payload()
    if mode == 'overflow': data = b'4001\r\n' + data + b'\r\n0\r\n\r\n'
    with response(data, extra=extra) as value:
        value.status = 400
        error = HTTPError('https://api.openai.com/v1/responses', 400, 'private', value.headers, value)
        result = capture_http_error(error, SimpleNamespace(deadline=time.monotonic()+5), SecretFilter())
        assert result['status'] == 400 and result['code'] is None
        assert value.isclosed()


@pytest.mark.parametrize('mode', ['deadline', 'cancelled', 'chunk-header'])
def test_pending_reader_bounded_and_shutdown(mode):
    cancel = threading.Event()
    timer = threading.Timer(.03, cancel.set) if mode == 'cancelled' else None
    extra = ('Transfer-Encoding: chunked',) if mode == 'chunk-header' else ()
    start = time.monotonic()
    with response(stuck=mode != 'chunk-header', trickle=mode == 'chunk-header', extra=extra) as value:
        value.status = 400
        error = HTTPError('https://api.openai.com/v1/responses', 400, 'private', value.headers, value)
        if timer: timer.start()
        try:
            result = capture_http_error(error, SimpleNamespace(deadline=time.monotonic()+.15), SecretFilter(), cancel)
        finally:
            if timer: timer.cancel()
        assert result['code'] is None and value.isclosed()
    assert time.monotonic() - start < 1


def test_planupstream_failure_keeps_metadata_never_returns_bytes_or_retries(monkeypatch):
    from agent_system.agent_transport import InvocationBinding
    from agent_system.model_tool_boundary import ExecutionPolicy, PlanUpstream, PLAN_SCOPE, UPSTREAM
    import agent_system.model_tool_boundary as boundary
    policy = ExecutionPolicy(InvocationBinding('offline', 'implementer', 'TASK', 1, 'offline-model', 'low'),
                             'implementation', 'owned', time.monotonic()+5)
    credentials = {'access_token': 'synthetic-access-token-123456789', 'refresh_token': 'synthetic-refresh-token-123456789',
                   'id_token': 'synthetic-id-token-123456789', 'client_id': 'synthetic-client',
                   'scopes': [PLAN_SCOPE], 'expires_at': time.time()+100}
    class Store:
        def read(self, name): return credentials
    class Approvals:
        def verify(self, name):
            if name.startswith('live-smoke/'):
                return {'authorized': True, **policy.identity(), 'model': policy.binding.model,
                        'reasoning': 'low', 'route': UPSTREAM}
            return {'credits_fallback_disabled': True, 'execution_id': 'offline',
                    'operator': 'synthetic', 'client_id': 'synthetic-client', 'attested_at': time.time()}
    calls = []
    with response(payload()) as value:
        value.status = 400
        error = HTTPError(UPSTREAM, 400, 'private', value.headers, value)
        class Opener:
            def open(self, *args, **kwargs):
                calls.append(1)
                raise error
        monkeypatch.setattr(boundary, 'build_opener', lambda *args: Opener())
        upstream = PlanUpstream(Store(), policy, Approvals(), lambda: None)
        with pytest.raises(AgentSystemError, match='no billing fallback'):
            upstream({})
        assert calls == [1] and value.isclosed()
        assert upstream.last_response_metadata['http_error']['code'] == 'invalid_json_schema'
        assert upstream.response_metadata_history == [upstream.last_response_metadata]
        assert upstream.last_response_metadata['validation_passed'] is False
        assert all(v not in json.dumps(upstream.last_response_metadata) for v in credentials.values() if isinstance(v, str))


def test_preclosed_error_does_not_obtain_another_reader():
    with response(payload()) as value:
        value.status = 400
        error = HTTPError('https://api.openai.com/v1/responses', 400, 'private', value.headers, value)
        error.close()
        result = capture_http_error(error, SimpleNamespace(deadline=time.monotonic()+5), SecretFilter())
        assert result['status'] == 400 and result['code'] is None
