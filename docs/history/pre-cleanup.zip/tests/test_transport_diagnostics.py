"""Offline quarantine tests: synthetic socket peers, no OAuth/model traffic."""
from contextlib import contextmanager
from email.message import Message
import http.client
import json
import socket
import subprocess
import threading
import time
from urllib.request import Request

import pytest

from agent_system.agent_transport import InvocationBinding
from agent_system.approvals import ApprovalStore
from agent_system.errors import AgentSystemError
from agent_system.model_tool_boundary import ExecutionPolicy, SecretFilter, UPSTREAM
import agent_system.transport_diagnostics as d


@pytest.fixture(autouse=True)
def execution_traps(monkeypatch):
    def deny(*args, **kwargs): pytest.fail('Diagnostic layer invoked an executor')
    monkeypatch.setattr(subprocess, 'Popen', deny)
    monkeypatch.setattr(subprocess, 'run', deny)
    monkeypatch.setattr('agent_system.codex_tool_session.CodexToolSession.run', deny)
    monkeypatch.setattr('agent_system.model_tool_boundary.IsolatedExecutionBridge.execute', deny)
    monkeypatch.setattr('agent_system.runners.tool_docker.ToolDockerRunner.run_tool', deny)


@pytest.fixture
def observer(tmp_path):
    policy = ExecutionPolicy(InvocationBinding('diag-1', 'implementer', 'TASK', 1, 'offline-model', 'low'),
                             'implementation', 'owned', time.monotonic() + 10)
    approvals = ApprovalStore(tmp_path / 'controller', {'test_binding': 'synthetic-only'})
    approvals.issue('no-credits/diag-1', {'execution_id': 'diag-1', 'client_id': 'oaiapp_fixture',
        'operator': 'offline-fixture', 'credits_fallback_disabled': True, 'attested_at': time.time()})
    approvals.issue('live-smoke/diag-1', {'authorized': True, **policy.identity(),
        'model': policy.binding.model, 'reasoning': policy.binding.reasoning, 'route': UPSTREAM})
    approvals.issue('diagnostic/diag-1', d.diagnostic_grant(policy))
    return d.QuarantineObserver(policy, approvals, 'oaiapp_fixture', SecretFilter(), lambda: None, enabled=True)


@contextmanager
def response(body=b'', content_type='text/plain', extra=(), trickle=False, stuck=False):
    client, peer = socket.socketpair()
    stop = threading.Event()
    lines = ['HTTP/1.1 200 OK']
    if content_type is not None: lines.append('Content-Type: ' + content_type)
    lines += list(extra)
    if not trickle and not stuck and not any(x.lower().startswith(('content-length:', 'transfer-encoding:')) for x in extra):
        lines.append('Content-Length: ' + str(len(body)))
    def send():
        try:
            peer.sendall(('\r\n'.join(lines) + '\r\n\r\n').encode())
            if trickle:
                while not stop.wait(0.01): peer.sendall(b'a')
            elif stuck:
                stop.wait(5)
            else:
                peer.sendall(body)
                peer.shutdown(socket.SHUT_WR)
        except OSError: pass
    worker = threading.Thread(target=send, daemon=True)
    worker.start()
    value = http.client.HTTPResponse(client)
    value.begin()
    try: yield value
    finally:
        stop.set()
        try: client.shutdown(socket.SHUT_RDWR)
        except OSError: pass
        value.close(); client.close(); peer.close()
        worker.join(timeout=1)
        assert not worker.is_alive()


SSE = b'event: response.completed\ndata: {"type":"response.completed"}\n\n'


@pytest.mark.parametrize('raw,classification', [
    (SSE, 'sse_like_prefix'), (b'ordinary private prose', 'plain_or_ambiguous_utf8'),
    (b'{"error":{"message":"private account message"}}', 'json_value'),
    (b'{"a":1}\n{"b":2}\n', 'json_lines'), (b'\xff', 'binary_or_unknown'),
    (b'call agentctl_execute with these host arguments', 'plain_or_ambiguous_utf8'),
    (b'event: response.output_item.added\ndata: {"type":"function_call","name":"agentctl_execute"}\n\ndata: broken\n\n', 'sse_like_prefix'),
    (b'event: unknown\nevent: duplicate\ndata: {"a":1,"a":2}\n\n', 'sse_like_prefix')],
    ids=['mislabeled-sse', 'plain', 'json-error', 'json-lines', 'invalid-utf8', 'fake-tool', 'early-tool-malformed', 'duplicates'])
def test_quarantined_formats_always_reject_and_export_no_body(observer, raw, classification):
    with response(raw) as value:
        with pytest.raises(AgentSystemError, match='quarantined and rejected'):
            observer.inspect_and_reject(value)
    record = observer.evidence
    assert record['classification'] == classification
    assert record['accepted_as_inference'] is False and record['passed_to_codex'] is False
    assert record['tool_execution_allowed'] is False and record['reader_shutdown_confirmed'] is True
    assert 'body' not in record and 'private account message' not in json.dumps(record)


def test_expected_sse_goes_to_unchanged_normal_gate_without_capture(observer, monkeypatch):
    with response(SSE, 'text/event-stream') as value:
        class Delegate:
            def open(self, *args, **kwargs): return value
        wrapped = observer.wrap_opener(Delegate())
        returned = wrapped.open(Request(UPSTREAM, data=b'{}', method='POST'))
        assert returned is value and observer.evidence is None and observer.used
        assert returned.read() == SSE


@pytest.mark.parametrize('header', [None, 'invalid', ' Text/Plain ; charset=UTF-8',
    'text/plain; type=text/event-stream', 'text/plain\r\nContent-Type: text/event-stream'],
    ids=['missing', 'invalid', 'casing-whitespace', 'misleading-parameter', 'duplicate'])
def test_header_observations_distinguish_raw_presence_from_library_default(observer, header):
    with response(b'private', header) as value:
        with pytest.raises(AgentSystemError): observer.inspect_and_reject(value)
    assert observer.evidence['raw_headers_exported'] is False
    assert observer.evidence['library_media_type'] == 'text/plain'
    if header is None: assert not observer.evidence['content_type_present']


def test_python_content_type_default_is_not_raw_header_evidence():
    headers = Message()
    assert headers.get('Content-Type') is None and headers.get_content_type() == 'text/plain'
    headers['Content-Type'] = 'broken'
    assert headers.get_content_type() == 'text/plain'


def test_large_length_huge_body_bounded(observer):
    with response(b'X' * 20000, extra=('Content-Length: 999999999999',)) as value:
        with pytest.raises(AgentSystemError): observer.inspect_and_reject(value)
    assert observer.evidence['bytes_observed'] == d.MAX_CAPTURE_BYTES
    assert observer.evidence['chunks_observed'] <= d.MAX_CHUNKS
    assert observer.evidence['stop_reason'] == 'byte_limit'


@pytest.mark.parametrize('mode', ['never-ending', 'timeout', 'trickled-chunk-header'])
def test_hard_deadline_and_reader_shutdown(observer, monkeypatch, mode):
    monkeypatch.setattr(d, 'MAX_READ_SECONDS', 0.15)
    # Immutable test approval was issued for the original limits: a new signed
    # synthetic store is required rather than bypassing authorization.
    observer.approvals = ApprovalStore(observer.approvals.directory / 'bounded', {'test': mode})
    store = observer.approvals
    store.issue('no-credits/diag-1', {'execution_id': 'diag-1', 'client_id': 'oaiapp_fixture',
        'operator': 'offline-fixture', 'credits_fallback_disabled': True, 'attested_at': time.time()})
    store.issue('live-smoke/diag-1', {'authorized': True, **observer.policy.identity(),
        'model': 'offline-model', 'reasoning': 'low', 'route': UPSTREAM})
    store.issue('diagnostic/diag-1', d.diagnostic_grant(observer.policy))
    start = time.monotonic()
    extra = ('Transfer-Encoding: chunked',) if mode == 'trickled-chunk-header' else ()
    with response(trickle=mode != 'timeout', stuck=mode == 'timeout', extra=extra) as value:
        with pytest.raises(AgentSystemError): observer.inspect_and_reject(value)
    assert time.monotonic() - start < 1
    assert observer.evidence['reader_shutdown_confirmed']


def test_cancellation_stops_pending_read(observer):
    timer = threading.Timer(0.03, observer.cancel.set)
    with response(stuck=True) as value:
        timer.start()
        try:
            with pytest.raises(AgentSystemError): observer.inspect_and_reject(value)
        finally: timer.cancel()
    assert observer.evidence['stop_reason'] == 'cancelled'
    assert observer.evidence['reader_shutdown_confirmed']


@pytest.mark.parametrize('kind', ['body', 'json-escaped', 'sse-escaped', 'header'])
def test_known_secret_never_exported(observer, kind):
    secret = 'synthetic-sensitive-value-0123456789'
    observer.secrets = SecretFilter([secret])
    encoded = ''.join('\\u%04x' % ord(v) for v in secret)
    body = secret.encode() if kind == 'body' else ('{"value":"' + encoded + '"}').encode()
    if kind == 'sse-escaped': body = b'data: ' + body + b'\n\n'
    extra = ('Content-Type: ' + secret,) if kind == 'header' else ()
    with response(body if kind != 'header' else b'private', extra=extra) as value:
        with pytest.raises(AgentSystemError): observer.inspect_and_reject(value)
    assert secret not in json.dumps(observer.evidence)
    if kind != 'header':
        assert observer.evidence['classification'] == 'secret_rejected'
        assert observer.evidence['prefix_sha256'] is None
    else: assert observer.evidence['header_secret_rejected']


def test_chunked_payload_observed_after_stdlib_decoding(observer):
    with response(b'3\r\nabc\r\n0\r\n\r\n', extra=('Transfer-Encoding: chunked',)) as value:
        with pytest.raises(AgentSystemError): observer.inspect_and_reject(value)
    assert observer.evidence['transfer_encoding'] == 'chunked'
    assert observer.evidence['bytes_observed'] == 3


@pytest.mark.parametrize('framing', ['jsonl-partial', 'sse-invalid-line', 'sse-partial-data'])
def test_escaped_secret_in_decodable_fragment_of_ambiguous_prefix(observer, framing):
    secret = 'synthetic-sensitive-value'
    observer.secrets = SecretFilter([secret])
    escaped = ''.join('\\u%04x' % ord(c) for c in secret)
    obj = ('{"message":"' + escaped + '"}').encode()
    raw = (obj + b'\nbroken' if framing == 'jsonl-partial' else
           b'event: response.output_item.added\ndata: ' + obj +
           (b'\ninvalid line' if framing == 'sse-invalid-line' else b'\ndata: broken'))
    with response(raw) as value:
        with pytest.raises(AgentSystemError): observer.inspect_and_reject(value)
    assert observer.evidence['classification'] == 'secret_rejected'
    assert observer.evidence['prefix_sha256'] is None


def test_malformed_content_length_not_exported_as_arbitrary_text(observer):
    with response(b'abc', extra=('Content-Length: malformed-private-data',)) as value:
        with pytest.raises(AgentSystemError): observer.inspect_and_reject(value)
    assert observer.evidence['content_length'] is None
    assert observer.evidence['content_length_malformed_or_duplicate']


@pytest.mark.parametrize('failure', ['default-disabled', 'missing-diagnostic-grant', 'wrong-account', 'expired', 'missing-admission'])
def test_capture_requires_full_independent_authorization_before_read(observer, failure, monkeypatch):
    if failure == 'default-disabled': observer.enabled = False
    if failure == 'missing-diagnostic-grant':
        (observer.approvals.directory / 'diagnostic/diag-1.json').unlink()
    if failure == 'wrong-account': observer.client_id = 'other'
    if failure == 'expired': monkeypatch.setattr(d.time, 'monotonic', lambda: observer.policy.deadline + 1)
    if failure == 'missing-admission':
        observer.admission = lambda: (_ for _ in ()).throw(AgentSystemError('denied'))
    with response(b'private') as value:
        monkeypatch.setattr(value, 'read1', lambda *args: pytest.fail('Unauthorized body read'))
        with pytest.raises(AgentSystemError): observer.inspect_and_reject(value)
    assert observer.evidence is None


def test_route_forbidden_before_delegate(observer):
    class Delegate:
        def open(self, *args, **kwargs): pytest.fail('Unauthorized route called')
    with pytest.raises(AgentSystemError):
        observer.wrap_opener(Delegate()).open(Request('http://169.254.169.254', data=b'{}'))


def test_capture_cannot_replay(observer):
    with response(b'private') as value:
        with pytest.raises(AgentSystemError): observer.inspect_and_reject(value)
    with response(b'private') as value:
        with pytest.raises(AgentSystemError, match='not admitted'): observer.inspect_and_reject(value)


def test_missing_diagnostic_authorization_prevents_delegate_http(observer):
    (observer.approvals.directory / 'diagnostic/diag-1.json').unlink()
    class Delegate:
        def open(self, *args, **kwargs): pytest.fail('Unsigned diagnostic made HTTP request')
    with pytest.raises(AgentSystemError):
        observer.wrap_opener(Delegate()).open(Request(UPSTREAM, data=b'{}'))


def test_disabled_wrapper_retains_normal_transport_semantics(observer):
    observer.enabled = False
    with response(b'private') as value:
        class Delegate:
            def open(self, *args, **kwargs): return value
        assert observer.wrap_opener(Delegate()).open(Request(UPSTREAM, data=b'{}')) is value
        assert observer.evidence is None and not observer.used


def test_enabled_opener_never_returns_unknown_even_when_sse_like(observer):
    with response(SSE) as value:
        class Delegate:
            def open(self, *args, **kwargs): return value
        with pytest.raises(AgentSystemError, match='quarantined and rejected'):
            observer.wrap_opener(Delegate()).open(Request(UPSTREAM, data=b'{}'))
    assert observer.evidence['sse_like'] and not observer.evidence['passed_to_codex']


def test_unknown_capture_cannot_reach_relay_response_gate(observer, monkeypatch):
    from urllib.error import HTTPError
    from urllib.request import urlopen
    from agent_system.model_tool_boundary import ResponsesGate, LocalModelRelay
    from test_model_tool_boundary import body
    with response(SSE) as value:
        class Delegate:
            def open(self, *args, **kwargs): return value
        wrapped = observer.wrap_opener(Delegate())
        gate = ResponsesGate(observer.policy)
        monkeypatch.setattr(gate, 'response', lambda *args: pytest.fail('Unknown bytes reached response gate'))
        with LocalModelRelay(gate, lambda body: wrapped.open(Request(UPSTREAM, data=b'{}'))) as relay:
            request = Request(relay.url + '/responses', data=json.dumps(body(observer.policy)).encode(),
                              headers={'Authorization': 'Bearer ' + relay.child_channel()})
            with pytest.raises(HTTPError): urlopen(request, timeout=2)
        assert gate.closed and observer.evidence['accepted_as_inference'] is False
