from contextlib import contextmanager
import copy
import json
import time
from urllib.parse import parse_qs, urlencode, urlsplit

import pytest

from agent_system import chatgpt_oauth as auth
from agent_system.errors import AgentSystemError


class MemoryStore:
    def __init__(self):
        self.values = {}
        self.locked = False
    def read(self, name):
        return copy.deepcopy(self.values.get(name))
    def write(self, name, value):
        self.values[name] = copy.deepcopy(value)
    def host_id(self):
        return 'urn:uuid:00000000-0000-4000-8000-000000000001'
    def clear_tokens(self):
        self.values.pop('credentials.json', None)
    @contextmanager
    def lock(self):
        if self.locked:
            raise AgentSystemError('session locked')
        self.locked = True
        try:
            yield
        finally:
            self.locked = False


class MockHttp:
    def __init__(self):
        self.calls, self.failure = [], None
        self.data = {'access_token': 'synthetic-access-token', 'refresh_token': 'synthetic-refresh-token',
                     'id_token': 'synthetic-id-token', 'token_type': 'Bearer', 'expires_in': 3600, 'scope': auth.SCOPES}
    def request(self, method, url, form=None):
        self.calls.append((method, url, copy.deepcopy(form)))
        if self.failure:
            raise self.failure
        return copy.deepcopy(self.data)
    def revocation_endpoint(self):
        return auth.ISSUER + '/synthetic-test-revocation'


@pytest.fixture
def oauth(monkeypatch):
    monkeypatch.setattr(auth, 'verify_identity', lambda *args: {'sub': 'account-1'})
    return auth.ChatGPTPlanOAuth(MemoryStore(), MockHttp())


def callback(oauth, **updates):
    values = {'code': 'synthetic-code', 'state': oauth.pending.state, 'client_id': 'oaiapp_registration1'}
    values.update(updates)
    return oauth.pending.redirect_uri + '?' + urlencode(values)


def connected(oauth):
    oauth.begin('http://127.0.0.1:1455/auth/callback')
    return oauth.callback(callback(oauth))


def test_first_registration_exact_public_client_contract(oauth):
    query = parse_qs(urlsplit(oauth.begin('http://127.0.0.1:1455/auth/callback')).query)
    assert query['client_id'] == ['dynamic_agent_client']
    from agent_system.chatgpt_plan_transport import AppServerBoundary
    assert query['agent_name_hint'] == [AppServerBoundary(None).initialize()['params']['clientInfo']['name']]
    assert query['resource'] == [auth.RESOURCE] and query['scope'] == [auth.SCOPES]
    assert query['code_challenge_method'] == ['S256']
    assert query['ext_agent_host_id'] == [oauth.store.host_id()]
    assert 'client_secret' not in query and 'api_key' not in query
    status = oauth.callback(callback(oauth))
    form = oauth.http.calls[-1][2]
    assert form['client_id'] == 'oaiapp_registration1'
    assert form['code_verifier'] == oauth.pending.verifier
    assert form['redirect_uri'] == oauth.pending.redirect_uri
    assert status['connected'] and status['plan_permission']
    assert status['model_entitlement'] == 'unverified' and not status['inference_enabled']


def test_state_nonce_pkce_fresh_on_reauthorization(oauth):
    connected(oauth)
    before = (oauth.pending.state, oauth.pending.nonce, oauth.pending.verifier)
    query = parse_qs(urlsplit(oauth.begin('http://127.0.0.1:54321/auth/callback')).query)
    assert query['client_id'] == ['oaiapp_registration1']
    assert 'agent_name_hint' not in query
    assert all(a != b for a, b in zip(before, (oauth.pending.state, oauth.pending.nonce, oauth.pending.verifier)))


@pytest.mark.parametrize('uri', ['http://localhost:1455/auth/callback', 'https://127.0.0.1:1455/auth/callback',
                                 'http://127.0.0.1:1455/callback', 'http://example.com/auth/callback'])
def test_invalid_loopback_callback_rejected(oauth, uri):
    with pytest.raises(AgentSystemError):
        oauth.begin(uri)


@pytest.mark.parametrize('mutation', ['state', 'client', 'missing_client', 'duplicate', 'path', 'code'])
def test_callback_mismatch_never_exchanges_code(oauth, mutation):
    oauth.begin('http://127.0.0.1:1455/auth/callback')
    uri = callback(oauth)
    if mutation == 'state': uri = callback(oauth, state='wrong')
    if mutation == 'client':
        oauth.pending.client_id = 'oaiapp_original'
    if mutation == 'missing_client': uri = callback(oauth, client_id='dynamic_agent_client')
    if mutation == 'duplicate': uri += '&state=extra'
    if mutation == 'path': uri = uri.replace('/auth/callback', '/different')
    if mutation == 'code': uri = callback(oauth, code='')
    with pytest.raises(AgentSystemError):
        oauth.callback(uri)
    assert not oauth.http.calls


def test_denial_checks_state_and_never_stores_credentials(oauth):
    oauth.begin('http://127.0.0.1:1455/auth/callback')
    with pytest.raises(AgentSystemError, match='denied'):
        oauth.callback(callback(oauth, error='access_denied'))
    assert not oauth.status()['connected'] and not oauth.http.calls


def test_expired_and_replayed_authorizations_rejected(oauth):
    connected(oauth)
    with pytest.raises(AgentSystemError, match='consumed'):
        oauth.callback(callback(oauth))
    oauth.begin('http://127.0.0.1:1455/auth/callback')
    oauth.pending.deadline = time.monotonic() - 1
    with pytest.raises(AgentSystemError, match='expired'):
        oauth.callback(callback(oauth))


def test_login_without_plan_permission_does_not_enable_inference(oauth):
    oauth.http.data['scope'] = 'openid profile email offline_access'
    status = connected(oauth)
    assert status['connected'] and not status['plan_permission'] and not status['inference_enabled']


def test_registration_retained_after_expired_code(oauth):
    oauth.http.failure = auth.AuthError('invalid_grant', 400)
    oauth.begin('http://127.0.0.1:1455/auth/callback')
    with pytest.raises(auth.AuthError):
        oauth.callback(callback(oauth))
    assert oauth.store.read('registration.json')['client_id'] == 'oaiapp_registration1'
    assert not oauth.store.read('credentials.json')


def test_refresh_rotation_uses_correct_registration_without_scope(oauth):
    connected(oauth)
    oauth.http.data['refresh_token'] = 'synthetic-replacement-refresh-token'
    oauth.refresh()
    form = oauth.http.calls[-1][2]
    assert form['grant_type'] == 'refresh_token' and form['refresh_token'] == 'synthetic-refresh-token'
    assert form['client_id'] == 'oaiapp_registration1' and 'scope' not in form
    assert oauth.store.read('credentials.json')['refresh_token'] == 'synthetic-replacement-refresh-token'


@pytest.mark.parametrize('code,clears', [('invalid_grant', True), ('refresh_token_reused', True),
                                       ('network_error', False), ('invalid_client', False)])
def test_refresh_errors_differentiate_terminal_and_transient(oauth, code, clears):
    connected(oauth)
    oauth.http.failure = auth.AuthError(code)
    with pytest.raises(auth.AuthError):
        oauth.refresh()
    assert oauth.status()['connected'] is not clears
    assert oauth.store.read('registration.json')


def test_identity_cannot_change_during_refresh(oauth, monkeypatch):
    connected(oauth)
    monkeypatch.setattr(auth, 'verify_identity', lambda *args: {'sub': 'other-account'})
    with pytest.raises(AgentSystemError, match='identity'):
        oauth.refresh()
    assert oauth.store.read('credentials.json')['subject'] == 'account-1'


def test_token_expiry_disconnected_and_public_status_redacted(oauth):
    connected(oauth)
    oauth.store.values['credentials.json']['expires_at'] = 0
    status = oauth.status()
    assert status['access_token_expired']
    assert 'synthetic' not in json.dumps(status)
    assert 'synthetic' not in repr(oauth.pending)
    result = oauth.disconnect_local()
    assert not result['remote_revocation_confirmed'] and not oauth.status()['connected']
    with pytest.raises(AgentSystemError, match='disconnected'):
        oauth.refresh()


@pytest.mark.parametrize('failure', [False, True])
def test_remote_disconnect_honest_and_clears_local_tokens(oauth, failure):
    connected(oauth)
    if failure: oauth.http.failure = auth.AuthError('network_error')
    result = oauth.disconnect()
    assert result['remote_revocation_confirmed'] is not failure
    assert not oauth.status()['connected']
    assert oauth.store.read('registration.json')


def test_error_serialization_never_uses_upstream_secret_prose():
    for raw in ['synthetic-refresh-token', {'error': 'synthetic-access-token'}, ['token']]:
        error = auth.AuthError(raw, 401)
        assert 'synthetic' not in str(error) and 'synthetic' not in repr(error)
        assert error.code == 'http_error'


def test_external_protected_store_actual_permissions_and_lifecycle(tmp_path):
    repo = tmp_path / 'repository'
    repo.mkdir()
    store = auth.CredentialStore(tmp_path / 'controller-auth', [repo])
    host = store.host_id()
    assert auth.CredentialStore(store.directory, [repo]).host_id() == host
    with store.lock():
        with pytest.raises(AgentSystemError, match='locked'):
            with store.lock():
                pass
        store.write('credentials.json', {'access_token': 'synthetic-private-token'})
    assert not list(repo.rglob('*'))
    store.clear_tokens()
    assert not store.read('credentials.json') and store.read('host.json')
    with pytest.raises(AgentSystemError, match='outside'):
        auth.CredentialStore(repo / 'auth', [repo])


def test_oauth_http_cannot_call_model_or_arbitrary_url():
    http = auth.OAuthHttp()
    for url in ['https://api.openai.com/v1/responses', 'https://example.com', auth.TOKEN + '?token=secret']:
        with pytest.raises(AgentSystemError, match='endpoint'):
            http.request('POST', url, {})


@pytest.mark.parametrize('field,value', [('token_type', None), ('expires_in', True),
                                        ('refresh_token', []), ('scope', ''), ('id_token', '')])
def test_malformed_token_response_safe_and_never_persisted(oauth, field, value):
    oauth.http.data[field] = value
    oauth.begin('http://127.0.0.1:1455/auth/callback')
    with pytest.raises(AgentSystemError, match='Malformed') as error:
        oauth.callback(callback(oauth))
    assert 'synthetic' not in str(error.value)
    assert not oauth.store.read('credentials.json')


def test_wrong_pkce_verifier_upstream_rejection_does_not_persist(oauth):
    expected = None
    def exchange(method, url, form):
        assert method == 'POST' and url == auth.TOKEN
        if form['code_verifier'] != expected:
            raise auth.AuthError('invalid_grant', 400)
        return oauth.http.data
    oauth.http.request = exchange
    oauth.begin('http://127.0.0.1:1455/auth/callback')
    expected = oauth.pending.verifier
    oauth.pending.verifier = 'synthetic-wrong-verifier'
    with pytest.raises(auth.AuthError):
        oauth.callback(callback(oauth))
    assert not oauth.store.read('credentials.json')


def test_store_rejects_record_links_and_unsafe_permissions(tmp_path):
    # Rejection of caller-selected records happens without opening any path.
    store = object.__new__(auth.CredentialStore)
    store.directory = tmp_path
    with pytest.raises(AgentSystemError, match='record'):
        store._path('../outside')
    with pytest.raises(AgentSystemError, match='permissions|DACL'):
        auth.CredentialStore(tmp_path, [tmp_path / 'repository'])


def test_http_auth_error_never_echoes_token_body(monkeypatch):
    import io
    from urllib.error import HTTPError
    class Opener:
        def open(self, *args, **kwargs):
            raise HTTPError(auth.TOKEN, 400, 'synthetic-secret-in-prose', {},
                            io.BytesIO(b'{"error":"invalid_grant","error_description":"synthetic-refresh-token"}'))
    monkeypatch.setattr(auth, 'build_opener', lambda *args: Opener())
    with pytest.raises(auth.AuthError) as error:
        auth.OAuthHttp().request('POST', auth.TOKEN, {'refresh_token': 'synthetic-refresh-token'})
    assert error.value.code == 'invalid_grant'
    assert 'synthetic' not in str(error.value) and 'synthetic' not in repr(error.value)


def test_real_loopback_listener_with_synthetic_browser_and_mock_exchange(oauth):
    import threading
    from urllib.request import build_opener, ProxyHandler
    threads, errors = [], []
    def browser(authorize_url):
        query = parse_qs(urlsplit(authorize_url).query)
        uri = query['redirect_uri'][0] + '?' + urlencode({'code': 'synthetic-code',
            'state': query['state'][0], 'client_id': 'oaiapp_registration1'})
        def send():
            try:
                with build_opener(ProxyHandler({})).open(uri, timeout=5) as response:
                    assert response.status == 200
            except Exception as error:
                errors.append(type(error).__name__)
        thread = threading.Thread(target=send, daemon=True)
        threads.append(thread)
        thread.start()
    assert oauth.sign_in(browser)['connected']
    for thread in threads:
        thread.join(timeout=5)
    assert not errors and all(not thread.is_alive() for thread in threads)
