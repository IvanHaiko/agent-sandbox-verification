from pathlib import Path
import json

import pytest
import yaml

from agent_system.approvals import ApprovalStore
from agent_system.config import Configuration
from agent_system.errors import AgentSystemError
from agent_system.git import git
from agent_system.isolation import Capability, IsolationCapabilities, IsolatedCheckout, verify_imports
from agent_system.policies import protected_snapshot
from agent_system.runners import create_runner
from agent_system.storage import atomic_json


def test_external_runtime_config_and_nested_rejection(project, tmp_path):
    path = project / '.agent_system/project.yaml'
    value = yaml.safe_load(path.read_text())
    value['runtime'] = {'version': 2, 'root': str(tmp_path / 'runtime')}
    path.write_text(yaml.safe_dump(value))
    config = Configuration.load(project)
    assert not config.runs_dir.is_relative_to(project)
    assert config.runs_dir.parent == config.worktrees_dir.parent
    value['runtime']['root'] = str(project / 'private')
    path.write_text(yaml.safe_dump(value))
    with pytest.raises(AgentSystemError, match='outside'):
        Configuration.load(project)


def test_curiosity_git_canary_is_absent(project, tmp_path):
    base = git(project, 'rev-parse', 'HEAD')
    git(project, 'checkout', '-b', 'implementer-secret')
    secret = 'implementer-canary-e9da6f4b'
    (project / 'secret.txt').write_text(secret)
    git(project, 'add', 'secret.txt')
    git(project, 'commit', '-m', secret)
    secret_commit = git(project, 'rev-parse', 'HEAD')
    checkout = tmp_path / 'tester'
    IsolatedCheckout.create(project, checkout, base, tmp_path / 'control')
    output = git(checkout, 'branch', '-a') + git(checkout, 'log', '--all')
    assert secret not in output and 'implementer-secret' not in output
    with pytest.raises(AgentSystemError):
        git(checkout, 'show', 'implementer-secret:secret.txt')
    with pytest.raises(AgentSystemError):
        git(checkout, 'show', secret_commit + ':secret.txt')
    assert not (checkout / 'secret.txt').exists()
    assert not git(checkout, 'remote')
    assert IsolatedCheckout.create(project, checkout, base, tmp_path / 'control') == checkout


def test_unknown_or_unverified_capability_cannot_admit():
    with pytest.raises(AgentSystemError, match='filesystem_read'):
        IsolationCapabilities('fake').require({'filesystem_read'})
    with pytest.raises(AgentSystemError):
        IsolationCapabilities('fake', {'filesystem_read': Capability(True)}).require({'filesystem_read'})
    IsolationCapabilities('verified', {'filesystem_read': Capability(True, True, 'probe')}).require({'filesystem_read'})


def test_current_backend_fails_closed_before_canary_probe(project):
    runner = create_runner(Configuration.load(project))
    with pytest.raises(AgentSystemError, match='filesystem_read'):
        runner.isolation_capabilities().require()
    manifest = runner.isolation_capabilities().manifest()
    assert manifest['capabilities']['private_home']['available'] is None
    assert manifest['capabilities']['hidden_tests']['available'] is False


def test_forged_approval_and_replayed_binding_rejected(tmp_path):
    store = ApprovalStore(tmp_path / 'controller', {'task': 'one', 'contract': 'hash'})
    payload = {'approved_by': 'human', 'option': 'A'}
    # Every role-accessible location contains convincing but non-authoritative JSON.
    for directory in ('tester', 'implementer', 'runtime'):
        atomic_json(tmp_path / directory / 'decision.json', payload)
    with pytest.raises(AgentSystemError, match='Missing controller'):
        store.verify('architecture/0')
    store.issue('architecture/0', payload)
    store.verify('architecture/0', payload)
    with pytest.raises(AgentSystemError, match='integrity'):
        ApprovalStore(store.directory, {'task': 'two'}).verify('architecture/0')
    path = store.directory / 'architecture/0.json'
    envelope = json.loads(path.read_text())
    envelope['record']['payload']['option'] = 'B'
    atomic_json(path, envelope)
    with pytest.raises(AgentSystemError, match='integrity'):
        store.verify('architecture/0')


def test_role_local_import_resolution_and_shared_editable_rejection(tmp_path, monkeypatch):
    checkout = tmp_path / 'tester'
    checkout.mkdir()
    (checkout / 'example.py').write_text('value = 2\n')
    monkeypatch.setenv('PYTHONPATH', str(tmp_path / 'implementer'))
    evidence = verify_imports(checkout, ['example'])
    assert evidence['origins']['example'] == [str((checkout / 'example.py').resolve())]
    # Stdlib imports also demonstrate that non-project origins fail closed.
    with pytest.raises(AgentSystemError, match='escaped'):
        verify_imports(checkout, ['json'])


def test_gitignored_historical_data_mutation_detected(project):
    (project / '.gitignore').write_text('raw/\n')
    (project / 'raw').mkdir()
    path = project / 'raw/history.csv'
    path.write_text('historical\n')
    before = protected_snapshot(project, {'protected_paths': ['raw/**']})
    assert 'raw/history.csv' in before
    path.write_text('mutated\n')
    assert protected_snapshot(project, {'protected_paths': ['raw/**']}) != before


def test_runtime_v2_keeps_legacy_run_readable_and_resumable(project, task, tmp_path):
    from agent_system.orchestrator import Orchestrator
    task_path, value = task
    controller = Orchestrator(project)
    controller.plan(task_path)
    old_directory = controller.run_dir(value['task_id'])
    controller.resume(value['task_id'])
    path = project / '.agent_system/project.yaml'
    config = yaml.safe_load(path.read_text())
    config['runtime'] = {'version': 2, 'root': str(tmp_path / 'runtime')}
    path.write_text(yaml.safe_dump(config))
    upgraded = Orchestrator(project)
    assert upgraded.run_dir(value['task_id']) == old_directory
    assert upgraded.resume(value['task_id'])['state'] == 'WORKTREES_READY'


def test_no_unsandboxed_generated_command_or_import_fallback(project, tmp_path):
    from agent_system.runners.base import AgentRunner
    runner = create_runner(Configuration.load(project))
    with pytest.raises(AgentSystemError, match='command execution adapter'):
        AgentRunner.run_command(runner, ['python', '-c', 'raise AssertionError()'], project, {}, 1, {})
    checkout = tmp_path / 'isolated'
    checkout.mkdir()
    (checkout / 'module.py').write_text('raise AssertionError("must not execute on host")')
    with pytest.raises(AgentSystemError, match='isolated command execution'):
        verify_imports(checkout, ['module'], task={'hardening': {}, 'workflow': {'test_timeout_seconds': 1}})


def test_external_runtime_needs_no_repository_local_runtime_ignore_entries(project, tmp_path):
    from agent_system.git import WorktreeManager
    path = project / '.agent_system/project.yaml'
    config = yaml.safe_load(path.read_text())
    config['runtime'] = {'version': 2, 'root': str(tmp_path / 'runtime')}
    path.write_text(yaml.safe_dump(config))
    (project / '.gitignore').write_text('.venv/\n__pycache__/\n')
    manager = WorktreeManager(Configuration.load(project))
    assert manager.config.runs_dir.is_relative_to(tmp_path / 'runtime')


def test_tester_prompt_projects_public_contract_and_test_ownership(project):
    from agent_system.roles import Role
    source = Path(__file__).resolve().parents[1]
    task = yaml.safe_load((source / 'examples/workflow-task.yaml').read_text())
    task['workflow']['public_context'] = []
    task['workflow']['implementation_context'] = ['private/implementer-strategy.md']
    task['hardening'] = {'contract_version': 1, 'interface': {'description': 'Public value is 2', 'files': []},
                         'holdout_paths': ['tests/acceptance/hidden/**']}
    task['objective'] = 'Public value is 2'
    bundle = {'task_id': task['task_id'], 'role': 'test_engineer', 'phase': 'test_design', 'operation_id': 'c0-test_design-r0-t1',
              'files': [], 'implementation_visible': False, 'agent_history_visible': False, 'inputs': {}}
    prompt = create_runner(Configuration.load(project))._prompt(Role.TEST_ENGINEER, bundle, project, task)
    assert 'private/implementer-strategy.md' not in prompt
    assert 'allowed_paths' not in prompt and 'test_paths' in prompt and 'holdout_paths' in prompt
