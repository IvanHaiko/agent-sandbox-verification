import json
from pathlib import Path

import pytest
import yaml

from agent_system.errors import AgentSystemError
from agent_system.evaluation import evaluate_records, normalized_test_id, build_reports, sources
from agent_system.evidence import Evidence
from agent_system.orchestrator import Orchestrator
from agent_system.runners.base import AgentResult
from agent_system.storage import atomic_json
from agent_system.task import validate
from agent_system.telemetry import invocations
from test_workflow import full_task, execute


def test_exact_duplicates_and_possible_relations_are_distinct():
    item = {'severity': 'MAJOR', 'location': 'src/data.py:10', 'problem': 'Wrong key',
            'evidence': 'Observed wrong key', 'impact': 'Bad identity', 'recommended_correction': 'Use existing key'}
    review = {'task_id': 'T', 'findings': [item, {**item, 'problem': 'Other risk'}], 'architecture_decision': None}
    audit = {'task_id': 'T', 'findings': [{k: v for k, v in item.items() if k not in ('severity', 'impact')} | {'blocking': True}],
             'checks': [{'name': 'lineage', 'passed': True}], 'architecture_decision': None}
    records = {
        'cycles/0/roles/review-r0/complete': {'role': 'reviewer', 'cycle': 0, 'input_commit': 'a'*40, 'report': review},
        'cycles/0/roles/audit-r0/complete': {'role': 'data_auditor', 'cycle': 0, 'input_commit': 'a'*40, 'report': audit}}
    task = {'task_id': 'T'}
    state = {'state': 'ACCEPTED', 'fix_cycle': 0, 'data_critical': True, 'history': []}
    first = evaluate_records(task, state, records, 'a'*64)
    assert first == evaluate_records(task, state, records, 'a'*64)
    findings = first['findings']
    assert findings[0]['duplicates'] == [findings[2]['finding_id']]
    assert findings[1]['duplicates'] == []
    assert set(findings[1]['possibly_related']) == {findings[0]['finding_id'], findings[2]['finding_id']}
    assert all(f['confirmed'] is None for f in findings)
    assert first['unique_confirmed_findings']['reviewer'] == 0
    assert first['unique_confirmed_findings']['data_auditor'] == 0


def test_windows_test_parameters_are_not_rewritten():
    assert normalized_test_id(r'tests\test_data.py::test_value[a\b]') == r'tests/test_data.py::test_value[a\b]'


def test_custom_runner_invocations_receive_actual_measurements(project, full_task):
    path, task, _ = full_task
    task['architecture'] = {'categories': ['storage'], 'proposal': None}
    path.write_text(yaml.safe_dump(task))
    package = {'task_id': task['task_id'], 'decision_id': 'ARCH-CUSTOM', 'problem': 'Choose interface',
        'why_architectural': 'Storage contract', 'constraints': [], 'recommended_option': 'A',
        'options': [{'id': i, 'description': 'Compatible option '+i, 'advantages': [], 'disadvantages': [],
                    'risks': [], 'migration_impact': 'No migration', 'compatibility_impact': 'Compatible'} for i in ('A', 'B')]}
    class CustomRunner:
        def __init__(self, config): self.config = config
        def run(self, role, model, bundle, workspace, task):
            return AgentResult('custom-execution', task['task_id'], str(role), 'success', model.model,
                               model.reasoning, 0, 0, json.dumps(package), [])
    orchestrator = Orchestrator(project, runner_factory=CustomRunner)
    orchestrator.plan(path)
    state = orchestrator.resume(task['task_id'])
    assert state['state'] == 'ARCHITECTURE_DECISION_REQUIRED'
    aggregate, _ = build_reports(orchestrator.run_dir(task['task_id']))
    assert aggregate['invocation_count'] == 1
    record = aggregate['invocations'][0]
    assert record['duration_seconds'] >= 0
    assert record['result_status'] == 'success' and record['failure_kind'] is None
    assert record['usage']['total_tokens'] is None
    assert record['events_digest'] is None


def test_completed_legacy_invocation_not_replayed_to_fill_telemetry(project, full_task):
    task = full_task[1]
    task['architecture'] = {'categories': ['storage'], 'proposal': None}
    orchestrator, state, evidence, calls, _ = execute(project, full_task)
    folder = next((evidence.root / 'invocations').iterdir())
    (folder / 'telemetry.json').unlink()
    (evidence.root / 'observability.json').unlink()
    before = len(calls)
    assert orchestrator.resume(state['task_id'])['state'] == 'ARCHITECTURE_DECISION_REQUIRED'
    assert len(calls) == before
    assert build_reports(evidence.root)[0]['telemetry_unavailable'] == [folder.name]


def test_malformed_envelope_cannot_disappear_from_report_sources(tmp_path):
    evidence = Evidence(tmp_path)
    evidence.write('cycles/0/example', {'value': 1})
    atomic_json(tmp_path / 'cycles/0/example.json', {'data': {'value': 1}, 'sha256': 'a'*64, 'extra': True})
    with pytest.raises(AgentSystemError, match='digest mismatch'):
        sources(tmp_path)


def test_final_telemetry_requires_authoritative_result(tmp_path):
    folder = tmp_path / 'invocations/example'
    Evidence(folder).write('telemetry', {})
    with pytest.raises(AgentSystemError, match='authoritative invocation result'):
        invocations(tmp_path, {}, {})


def test_full_v1_acceptance_cannot_be_inferred_from_offline_tests():
    source = Path(__file__).resolve().parents[1]
    report = json.loads((source / 'docs/FRAMEWORK_V1_ACCEPTANCE.json').read_text())
    report['offline_tests']['status'] = 'PASSED'
    report['live_runner_smoke']['status'] = 'BLOCKED_BY_ENVIRONMENT'
    report['live_runner_smoke']['executed'] = False
    report['classification'] = 'FRAMEWORK_V1_ACCEPTED'
    with pytest.raises(AgentSystemError):
        validate(report, 'framework_acceptance')
    report['classification'] = 'FRAMEWORK_V1_ACCEPTED_WITH_LIMITATIONS'
    validate(report, 'framework_acceptance')
