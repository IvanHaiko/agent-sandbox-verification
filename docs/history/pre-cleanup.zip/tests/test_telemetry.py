import json
import shutil
from copy import deepcopy
from pathlib import Path

import pytest
import yaml
from jsonschema import Draft202012Validator

from agent_system.cli import main
from agent_system.errors import AgentSystemError
from agent_system.evaluation import build_reports, compare_runs
from agent_system.evidence import Evidence, digest
from agent_system.experiments import plan_experiment
from agent_system.storage import atomic_json, read_json
from agent_system.task import validate
from agent_system.telemetry import parse_events, usage_summary
from test_workflow import full_task, execute
from test_runner import setup_runner, invoke


@pytest.mark.parametrize('usage,expected', [
    ({'input_tokens': 20, 'output_tokens': 5, 'cached_input_tokens': 10,
      'reasoning_tokens': 2, 'total_tokens': 25}, (20, 5, 10, 2, 25)),
    ({'input_tokens': 20, 'output_tokens': 5}, (20, 5, None, None, None)),
    ({'reasoning_output_tokens': 2}, (None, None, None, 2, None)),
    (None, (None, None, None, None, None)),
    ({'future_metric': 42}, (None, None, None, None, None)),
])
def test_usage_protocol(tmp_path, usage, expected):
    path = tmp_path / 'events.jsonl'
    path.write_text(json.dumps({'type': 'turn.completed', 'usage': usage, 'future': 'allowed'}) + '\n')
    assert tuple(parse_events(path, True).values()) == expected


@pytest.mark.parametrize('event', ['not-json', '[]', '{}', '{"type":null}',
    '{"type":"turn.completed","usage":[]}',
    '{"type":"turn.completed","usage":{"input_tokens":true}}',
    '{"type":"turn.completed","usage":{"output_tokens":-1}}',
    '{"type":"turn.completed","usage":{"total_tokens":"25"}}',
    '{"type":"turn.completed"}\n{"type":"turn.completed"}'])
def test_malformed_events_fail(tmp_path, event):
    path = tmp_path / 'events.jsonl'
    path.write_text(event)
    with pytest.raises(AgentSystemError):
        parse_events(path, True)


def test_missing_completion_and_unknown_events(tmp_path):
    path = tmp_path / 'events.jsonl'
    path.write_text('{"type":"future.event","usage":{"input_tokens":999}}\n')
    assert all(v is None for v in parse_events(path).values())
    with pytest.raises(AgentSystemError, match='missing turn.completed'):
        parse_events(path, True)


def test_partial_aggregate_reports_unknown():
    records = [{'usage': {'input_tokens': 4, 'output_tokens': None, 'cached_input_tokens': None,
                          'reasoning_tokens': None, 'total_tokens': None}}]
    report = usage_summary(records, 1)
    assert report['input_tokens'] == {'measured': 4, 'unavailable_invocations': 1}
    assert report['total_tokens'] == {'measured': None, 'unavailable_invocations': 2}


def test_end_to_end_immutable_reporting_and_readonly_cli(project, full_task, capsys):
    orchestrator, state, evidence, calls, _ = execute(project, full_task, 'tests_first', data=True)
    assert state['state'] == 'ACCEPTED', state['detail']
    aggregate, evaluation = build_reports(evidence.root)
    assert aggregate['invocation_count'] == len(calls) == 8
    assert aggregate['fix_cycles'] == 1 and aggregate['monetary_cost'] is None
    assert aggregate['usage']['input_tokens']['measured'] is None
    assert aggregate == evidence.read('telemetry/aggregate')
    assert evaluation == evidence.read('evaluation/report')
    assert evaluation['tester']['frozen_cases'] == 1
    assert evaluation['tester']['executed_cases'] == 1
    assert evaluation['tester']['resolved_by_test'] >= 1
    assert evaluation['auditor']['checks_performed'] == 2
    assert all(f['confirmed'] is True for f in evaluation['findings'] if f['category'] == 'test_failure')
    before = {p: p.read_bytes() for p in evidence.root.rglob('*') if p.is_file()}
    for command in ('telemetry', 'metrics', 'evaluate'):
        assert main(['--project', str(project), command, state['task_id'], '--json']) == 0
        assert state['task_id'] in capsys.readouterr().out
    assert main(['--project', str(project), 'metrics', state['task_id']]) == 0
    capsys.readouterr()
    assert orchestrator.resume(state['task_id'])['state'] == 'ACCEPTED'
    assert before == {p: p.read_bytes() for p in evidence.root.rglob('*') if p.is_file()}
    assert len(calls) == 8


@pytest.mark.parametrize('mutation', ['task_id', 'cycle', 'role', 'candidate_commit', 'execution_id', 'result', 'events', 'aggregate'])
def test_telemetry_integrity_rejections(project, full_task, mutation):
    # Stop at architecture-free first design invocation to keep this integrity
    # matrix small. Full resume correctness is covered separately.
    path, task, _ = full_task
    task['architecture'] = {'categories': ['storage'], 'proposal': None}
    _, state, evidence, _, _ = execute(project, full_task)
    assert state['state'] == 'ARCHITECTURE_DECISION_REQUIRED'
    folder = next((evidence.root / 'invocations').iterdir())
    if mutation == 'result':
        value = read_json(folder / 'result.json'); value['message'] = 'substituted'
        atomic_json(folder / 'result.json', value)
    elif mutation == 'events':
        with (folder / 'events.jsonl').open('a') as stream:
            stream.write('{"type":"unknown"}\n')
    elif mutation == 'aggregate':
        aggregate, _ = build_reports(evidence.root)
        evidence.write('telemetry/aggregate', {**aggregate, 'invocation_count': 99})
    else:
        value = Evidence(folder).read('telemetry')
        value[mutation] = {'task_id': 'OTHER', 'cycle': 1, 'role': 'reviewer',
                           'candidate_commit': 'a' * 40, 'execution_id': 'other'}[mutation]
        atomic_json(folder / 'telemetry.json', {'sha256': digest(value), 'data': value})
    with pytest.raises(AgentSystemError):
        build_reports(evidence.root)


def test_historical_telemetry_is_not_invented(project, full_task):
    full_task[1]['architecture'] = {'categories': ['storage'], 'proposal': None}
    _, _, evidence, calls, _ = execute(project, full_task)
    folder = next((evidence.root / 'invocations').iterdir())
    (folder / 'telemetry.json').unlink()
    aggregate, _ = build_reports(evidence.root)
    assert aggregate['invocation_count'] == 1
    assert aggregate['telemetry_unavailable'] == [folder.name]
    assert aggregate['roles'] == [] and len(calls) == 1
    assert not (folder / 'telemetry.json').exists()


@pytest.mark.parametrize('limit,value,scenario,expected_calls', [
    ('max_role_invocations', 1, 'ordinary', 1),
    ('max_autonomous_fix_cycles', 0, 'tests_first', 4),
    ('max_infrastructure_retries', 0, 'infra_always', 2),
    ('max_measured_tokens', 1, 'ordinary', 1),
])
def test_usage_guardrails_fail_closed(project, full_task, limit, value, scenario, expected_calls):
    config_path = project / '.agent_system/project.yaml'
    config = yaml.safe_load(config_path.read_text())
    config['live_limits'] = {'max_role_invocations': 20, 'max_infrastructure_retries': 2,
                            'max_autonomous_fix_cycles': 2, limit: value}
    config['runner']['max_infrastructure_retries'] = 2
    config_path.write_text(yaml.safe_dump(config))
    orchestrator, state, evidence, calls, _ = execute(project, full_task, scenario)
    assert state['state'] == 'FAILED', state['detail']
    assert state['failure_kind'] == 'usage_limit'
    assert 'LIVE_USAGE_LIMIT_REACHED' in state['detail']
    assert len(calls) == expected_calls
    assert evidence.read('telemetry/aggregate')['outcome'] == 'FAILED'
    before = len(calls)
    orchestrator.resume(state['task_id'])
    assert len(calls) == before


def test_retry_attribution_and_role_disappearance_unknown(project, full_task):
    config_path = project / '.agent_system/project.yaml'
    config = yaml.safe_load(config_path.read_text())
    config['runner']['max_infrastructure_retries'] = 1
    config_path.write_text(yaml.safe_dump(config))
    _, state, evidence, calls, _ = execute(project, full_task, 'infra_once')
    aggregate, _ = build_reports(evidence.root)
    assert state['state'] == 'ACCEPTED'
    assert aggregate['invocation_count'] == len(calls) == 5
    assert aggregate['infrastructure_retries'] == 1
    assert aggregate['infrastructure_failures'] == 1
    assert aggregate['fix_cycles'] == 0


def test_review_absence_does_not_confirm_fix(project, full_task):
    _, state, evidence, _, _ = execute(project, full_task, 'review_first')
    _, report = build_reports(evidence.root)
    assert state['state'] == 'ACCEPTED'
    finding = report['findings'][0]
    assert finding['confirmed'] is None and finding['resolved_in_cycle'] is None
    assert finding['resolution_status'] == 'no_longer_reported'
    assert report['reviewer']['confirmed_fixes'] == 0


def test_sequential_routing_experiment_and_comparison(project, full_task):
    orchestrator, state, evidence, calls, _ = execute(project, full_task)
    routing = yaml.safe_load((project / '.agent_system/models.yaml').read_text())
    routing['models']['reviewer'] = {'model': 'explicit-other-model', 'reasoning': 'high'}
    path = project / '.agent_runs/routing.yaml'
    path.write_text(yaml.safe_dump(routing))
    count = len(calls)
    planned = plan_experiment(project, state['task_id'], 'EXPERIMENT-B', path)
    assert planned['state'] == 'NEW' and len(calls) == count
    assert planned['base_commit'] == state['base_commit']
    final = orchestrator.resume('EXPERIMENT-B')
    assert final['state'] == 'ACCEPTED', final['detail']
    dirs = [evidence.root, orchestrator.run_dir('EXPERIMENT-B')]
    comparison = compare_runs(dirs)
    validate(comparison, 'comparison')
    assert len(comparison['runs']) == 2
    with pytest.raises(AgentSystemError, match='distinct'):
        compare_runs([dirs[0], dirs[0]])
    contract_path = dirs[1] / 'task.json'
    contract = read_json(contract_path)
    contract['objective'] = 'A different task'
    atomic_json(contract_path, contract)
    with pytest.raises(AgentSystemError):
        compare_runs(dirs)


def test_all_schemas_and_portable_pilot_validate():
    source = Path(__file__).resolve().parents[1]
    for path in (source / 'agent_system/schemas').glob('*.json'):
        Draft202012Validator.check_schema(read_json(path))
    for name, schema in [('project.yaml', 'project'), ('models.yaml', 'models'), ('pilot-task.yaml', 'task')]:
        validate(yaml.safe_load((source / 'examples/open-model-lifecycle' / name).read_text()), schema)


def test_fix_limit_cannot_exceed_two(project):
    config = yaml.safe_load((project / '.agent_system/project.yaml').read_text())
    config['live_limits'] = {'max_role_invocations': 10, 'max_infrastructure_retries': 0,
                            'max_autonomous_fix_cycles': 3}
    with pytest.raises(AgentSystemError):
        validate(config, 'project')


def test_timeout_telemetry_is_measured_without_usage(setup_runner):
    runner, task, config, calls = setup_runner
    task['objective'] = 'TIMEOUT'
    config.project['runner']['timeout_seconds'] = 1
    result = invoke(setup_runner)
    record = Evidence(config.runs_dir / task['task_id'] / 'invocations' / result.execution_id).read('telemetry')
    assert record['timeout'] and record['exit_code'] is None
    assert record['duration_seconds'] >= 1
    assert record['failure_kind'] == 'infrastructure'
    assert all(v is None for v in record['usage'].values())


def test_required_protocol_failure_is_not_retried(setup_runner, monkeypatch):
    import subprocess
    runner, task, config, calls = setup_runner
    config.project['runner']['max_infrastructure_retries'] = 2
    original = subprocess.run
    def corrupt(command, **kwargs):
        result = original(command, **kwargs)
        if command[0] == 'fake-codex':
            kwargs['stdout'].write('{"optional":"malformed required protocol"}\n')
        return result
    monkeypatch.setattr(subprocess, 'run', corrupt)
    result = invoke(setup_runner)
    assert result.status == 'execution_failed' and len(calls) == 1
    record = Evidence(config.runs_dir / task['task_id'] / 'invocations' / result.execution_id).read('telemetry')
    assert record['failure_kind'] == 'protocol'
    assert 'required type' in record['protocol_error']


def test_duplicate_execution_directory_rejected(project, full_task):
    full_task[1]['architecture'] = {'categories': ['storage'], 'proposal': None}
    _, _, evidence, _, _ = execute(project, full_task)
    folder = next((evidence.root / 'invocations').iterdir())
    shutil.copytree(folder, folder.parent / 'duplicated-id')
    with pytest.raises(AgentSystemError, match='execution ID'):
        build_reports(evidence.root)
