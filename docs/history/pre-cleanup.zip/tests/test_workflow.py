import json
import subprocess
import sys
from copy import deepcopy
from pathlib import Path

import pytest
import yaml

from agent_system.contexts import validate_context
from agent_system.errors import AgentSystemError
from agent_system.evidence import Evidence
from agent_system.git import git
from agent_system.orchestrator import Orchestrator
from agent_system.roles import Role
from agent_system.state_machine import State, transition
from agent_system.storage import atomic_json, read_json
from agent_system.workflow import Workflow


@pytest.fixture
def full_task(project, monkeypatch):
    source = Path(__file__).resolve().parents[1]
    contract = yaml.safe_load((source / "examples/workflow-task.yaml").read_text())
    docs = project / "docs/contracts"
    docs.mkdir(parents=True)
    (docs / "answer.md").write_text("Public interface: src.example.value must equal 2.\n")
    git(project, "add", "docs")
    git(project, "commit", "-m", "Public contract")
    config_path = project / ".agent_system/project.yaml"
    config = yaml.safe_load(config_path.read_text())
    config["runner"]["executable"] = "fake-workflow-codex"
    config_path.write_text(yaml.safe_dump(config))
    # Freeze explicit configuration in the primary repository; role worktrees use it.
    git(project, "add", ".agent_system")
    git(project, "commit", "-m", "Offline backend configuration")
    path = project / "workflow-task.yaml"
    original = subprocess.run
    calls = []
    def launch(command, **kwargs):
        if command[0] == "fake-workflow-codex":
            prompt = kwargs["input"]
            context = json.JSONDecoder().raw_decode(prompt.split("Context manifest:\n", 1)[1])[0]
            calls.append({"command": command, "context": context, "workspace": str(kwargs["cwd"])})
            command = [sys.executable, str(source / "tests/fake_workflow_codex.py"), *command[1:]]
        return original(command, **kwargs)
    monkeypatch.setattr(subprocess, "run", launch)
    return path, contract, calls


def execute(project, full_task, scenario="ordinary", data=False, major=False):
    path, task, calls = full_task
    task["objective"] += " scenario=" + scenario
    task["data_critical"] = data
    task["major_phase"] = major
    path.write_text(yaml.safe_dump(task))
    orchestrator = Orchestrator(project)
    initial = orchestrator.plan(path)
    state = orchestrator.resume(task["task_id"])
    return orchestrator, state, Evidence(orchestrator.run_dir(task["task_id"])), calls, initial


@pytest.mark.parametrize("data", [False, True])
def test_end_to_end_ordinary_and_data(project, full_task, data):
    orchestrator, state, evidence, calls, initial = execute(project, full_task, data=data)
    assert state["state"] == "ACCEPTED", state["detail"]
    assert state["fix_cycle"] == 0
    phases = [call["context"]["phase"] for call in calls]
    assert phases == ["test_design", "implementation", "test_implementation", "review"] + (["audit"] if data else [])
    assert "implementation_context" not in calls[0]["context"]["inputs"]
    assert calls[0]["context"]["files"] == ["docs/contracts/answer.md"]
    assert not calls[0]["context"]["implementation_visible"]
    assert calls[2]["context"]["implementation_visible"]
    assert calls[0]["command"][calls[0]["command"].index("--sandbox") + 1] == "read-only"
    assert evidence.read("tester/frozen_design")["cases"][0]["criterion"] == 0
    tests = evidence.read("cycles/0/tests/result")
    assert tests["passed"] and all(item["returncode"] == 0 for item in tests["commands"])
    assert any(item["id"] == "independent_tests" for item in tests["commands"])
    assert git(project, "rev-parse", "HEAD") == initial["base_commit"]
    assert (project / "src/example.py").read_text() == "value = 1\n"
    old_calls = len(calls)
    assert orchestrator.resume(state["task_id"])["state"] == "ACCEPTED"
    assert len(calls) == old_calls


@pytest.mark.parametrize("scenario, expected_cycle", [("tests_first", 1), ("review_first", 1), ("review_second", 2), ("audit_first", 1)])
def test_bounded_fixes_can_succeed(project, full_task, scenario, expected_cycle):
    orchestrator, state, evidence, calls, _ = execute(project, full_task, scenario, data=scenario.startswith("audit"))
    assert state["state"] == "ACCEPTED", state["detail"]
    assert state["fix_cycle"] == expected_cycle
    assert sum(call["context"]["phase"] == "test_design" for call in calls) == 1
    assert sum(call["context"]["phase"] == "test_implementation" for call in calls) == 1
    for call in calls:
        if call["context"]["phase"] == "fix":
            assert "test_design" not in call["context"]["inputs"]


@pytest.mark.parametrize("scenario,data", [("tests_always", False), ("review_blocker", False),
                                           ("review_major", False), ("audit_always", True)])
def test_exhaustion_stops_third_fix(project, full_task, scenario, data):
    orchestrator, state, evidence, calls, _ = execute(project, full_task, scenario, data=data)
    assert state["state"] == "ESCALATION_REQUIRED", state["detail"]
    assert state["fix_cycle"] == 2
    assert sum(call["context"]["phase"] == "fix" for call in calls) == 2
    assert evidence.read("escalation/report")["attempted_fix_cycles"] == 2
    assert [fix["cycle"] for fix in evidence.read("escalation/report")["attempted_fixes"]] == [1, 2]
    before = len(calls)
    assert orchestrator.resume(state["task_id"])["state"] == "ESCALATION_REQUIRED"
    assert len(calls) == before
    with pytest.raises(AgentSystemError):
        transition(state, State.FIXING)


@pytest.mark.parametrize("scenario", ["review_minor", "review_nit"])
def test_nonblocking_review(project, full_task, scenario):
    _, state, _, _, _ = execute(project, full_task, scenario)
    assert state["state"] == "ACCEPTED", state["detail"]


def test_additional_regressions_distinguished(project, full_task):
    _, state, evidence, _, _ = execute(project, full_task, "additional")
    assert state["state"] == "ACCEPTED", state["detail"]
    mapping = evidence.read("tester/test_mapping")
    assert len(mapping["independent"]) == 1 and len(mapping["additional"]) == 1
    assert "additional_regressions" in {c["id"] for c in evidence.read("cycles/0/tests/result")["commands"]}


@pytest.mark.parametrize("scenario,data", [("reviewer_tracked", False), ("reviewer_untracked", False),
                                           ("auditor_tracked", True), ("tester_production", False)])
def test_role_violations_fail_closed(project, full_task, scenario, data):
    _, state, _, calls, _ = execute(project, full_task, scenario, data=data)
    assert state["state"] == "FAILED", state["detail"]
    assert state["failure_kind"] == "policy"
    assert not any(call["context"]["phase"] == "fix" for call in calls)


def test_architecture_gate_explicit_selection_and_frozen_resume(project, full_task):
    path, task, calls = full_task
    task["architecture"] = {"categories": ["storage"], "proposal": None}
    path.write_text(yaml.safe_dump(task))
    orchestrator = Orchestrator(project)
    initial = orchestrator.plan(path)
    blocked = orchestrator.resume(task["task_id"])
    assert blocked["state"] == "ARCHITECTURE_DECISION_REQUIRED", blocked["detail"]
    assert [c["context"]["phase"] for c in calls] == ["architecture"]
    package = orchestrator.architecture(task["task_id"])
    with pytest.raises(AgentSystemError):
        orchestrator.approve_architecture(task["task_id"], package["decision_id"], "missing", "user")
    assert orchestrator.resume(task["task_id"])["state"] == "ARCHITECTURE_DECISION_REQUIRED"
    assert len(calls) == 1
    approved = orchestrator.approve_architecture(task["task_id"], package["decision_id"], "A", "user")
    assert approved["state"] == "ARCHITECTURE_APPROVED"
    # Change current routing; the frozen run still uses the original models.
    model_path = project / ".agent_system/models.yaml"
    routing = yaml.safe_load(model_path.read_text())
    routing["models"]["implementer"]["model"] = "different-model"
    model_path.write_text(yaml.safe_dump(routing))
    final = Orchestrator(project).resume(task["task_id"])
    assert final["state"] == "ACCEPTED", final["detail"]
    assert final["base_commit"] == initial["base_commit"]
    for call in calls[1:]:
        assert call["context"]["inputs"]["architecture_selection"][0]["selection"]["option"] == "A"
    implementation = next(call for call in calls if call["context"]["phase"] == "implementation")
    assert implementation["command"][implementation["command"].index("--model") + 1] == "sol"
    with pytest.raises(AgentSystemError):
        Orchestrator(project).approve_architecture(task["task_id"], package["decision_id"], "B", "user")


def test_midworkflow_architecture_gate(project, full_task):
    orchestrator, state, evidence, calls, _ = execute(project, full_task, "review_architecture")
    assert state["state"] == "ARCHITECTURE_DECISION_REQUIRED", state["detail"]
    package = orchestrator.architecture(state["task_id"])
    orchestrator.approve_architecture(state["task_id"], package["decision_id"], "A", "user")
    final = orchestrator.resume(state["task_id"])
    assert final["state"] == "ACCEPTED", final["detail"]
    assert sum(c["context"]["phase"] == "implementation" for c in calls) == 1


def test_major_phase_requires_completion_approval(project, full_task):
    orchestrator, state, _, calls, _ = execute(project, full_task, major=True)
    assert state["state"] == "USER_COMPLETION_APPROVAL", state["detail"]
    assert orchestrator.resume(state["task_id"])["state"] == "USER_COMPLETION_APPROVAL"
    assert orchestrator.approve_completion(state["task_id"], "human")["state"] == "ACCEPTED"


@pytest.mark.parametrize("scenario,retries,expected", [("infra_once", 1, "ACCEPTED"), ("infra_always", 2, "FAILED")])
def test_infrastructure_budget_separate(project, full_task, scenario, retries, expected):
    path = project / ".agent_system/project.yaml"
    config = yaml.safe_load(path.read_text())
    config["runner"]["max_infrastructure_retries"] = retries
    path.write_text(yaml.safe_dump(config))
    _, state, _, calls, _ = execute(project, full_task, scenario)
    assert state["state"] == expected, state["detail"]
    assert state["fix_cycle"] == 0
    assert sum(c["context"]["phase"] == "implementation" for c in calls) == retries + 1


class Interrupted(BaseException):
    pass


@pytest.mark.parametrize("point,data", [("frozen_design", False), ("implementation", False),
                                       ("test_results", False), ("review", False), ("audit", True), ("fix", False)])
def test_resume_after_durable_evidence(project, full_task, monkeypatch, point, data):
    path, task, calls = full_task
    task["data_critical"] = data
    if point == "fix":
        task["objective"] += " scenario=review_first"
    path.write_text(yaml.safe_dump(task))
    orchestrator = Orchestrator(project)
    orchestrator.plan(path)
    interrupted = []
    def checkpoint(self, name):
        if name == point and not interrupted:
            interrupted.append(name)
            raise Interrupted()
    monkeypatch.setattr(Workflow, "checkpoint", checkpoint)
    with pytest.raises(Interrupted):
        orchestrator.resume(task["task_id"])
    count = len(calls)
    last = calls[-1]["context"]["operation_id"]
    monkeypatch.setattr(Workflow, "checkpoint", lambda self, name: None)
    final = Orchestrator(project).resume(task["task_id"])
    assert final["state"] == "ACCEPTED", final["detail"]
    assert sum(c["context"]["operation_id"] == last for c in calls) == 1
    assert len(calls) >= count


def test_frozen_design_cannot_be_overwritten(project, full_task):
    _, state, evidence, _, _ = execute(project, full_task)
    assert state["state"] == "ACCEPTED", state["detail"]
    design = evidence.read("tester/frozen_design")
    with pytest.raises(AgentSystemError, match="overwrite"):
        evidence.write("tester/frozen_design", {**design, "cases": []})
    path = evidence.root / "tester/frozen_design.json"
    envelope = read_json(path)
    envelope["data"]["cases"] = []
    atomic_json(path, envelope)
    with pytest.raises(AgentSystemError, match="digest"):
        evidence.read("tester/frozen_design")


@pytest.mark.parametrize("changes", [
    {"implementation_visible": True},
    {"files": ["src/example.py"]},
    {"files": ["../private"]},
    {"files": [".agent_runs/implementation/result.json"]},
    {"inputs": {"candidate_diff": "implementation diff"}},
    {"inputs": {"review": {}}},
])
def test_phase_a_context_rejects_contamination(project, full_task, changes):
    _, task, _ = full_task
    bundle = {"task_id": task["task_id"], "role": "test_engineer", "phase": "test_design",
              "operation_id": "phase-a", "files": ["docs/contracts/answer.md"],
              "implementation_visible": False, "agent_history_visible": False, "inputs": {}, **changes}
    with pytest.raises(AgentSystemError):
        validate_context(bundle, Role.TEST_ENGINEER, project, task)


def test_unexpected_integration_source_fails(project, full_task, monkeypatch):
    path, task, calls = full_task
    path.write_text(yaml.safe_dump(task))
    orchestrator = Orchestrator(project)
    orchestrator.plan(path)
    def checkpoint(self, name):
        if name == "test_implementation":
            git(self.git.path("tester"), "checkout", "-b", "unexpected-source")
    monkeypatch.setattr(Workflow, "checkpoint", checkpoint)
    state = orchestrator.resume(task["task_id"])
    assert state["state"] == "FAILED"
    assert "branch" in state["detail"]


def test_unsupported_state_version_explicit(project, full_task):
    path, task, _ = full_task
    path.write_text(yaml.safe_dump(task))
    orchestrator = Orchestrator(project)
    state = orchestrator.plan(path)
    state["version"] = 99
    atomic_json(orchestrator.run_dir(task["task_id"]) / "state.json", state)
    with pytest.raises(AgentSystemError, match="version"):
        orchestrator.resume(task["task_id"])
