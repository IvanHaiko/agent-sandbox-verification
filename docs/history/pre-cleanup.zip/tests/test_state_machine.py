import pytest
import yaml

from agent_system.cli import main
from agent_system.errors import AgentSystemError
from agent_system.git import git
from agent_system.orchestrator import Orchestrator
from agent_system.state_machine import State, transition
from agent_system.storage import atomic_json, lock, read_json


def test_lifecycle_resume_frozen_base(project, task):
    path, contract = task
    orchestrator = Orchestrator(project)
    initial = orchestrator.plan(path)
    assert initial["state"] == "NEW"
    (project / "later.txt").write_text("later")
    git(project, "add", "later.txt")
    git(project, "commit", "-m", "User change after plan")
    final = orchestrator.resume(contract["task_id"])
    assert final["state"] == "WORKTREES_READY"
    assert final["base_commit"] == initial["base_commit"]
    assert [entry["state"] for entry in final["history"]] == [
        "NEW", "CLASSIFY", "CONTRACT_READY", "ARCHITECTURE_CHECK", "WORKTREES_READY"]
    assert Orchestrator(project).resume(contract["task_id"]) == final
    with pytest.raises(AgentSystemError):
        transition(final, "IMPLEMENTATION")


def test_contract_not_overwritten(project, task):
    path, contract = task
    orchestrator = Orchestrator(project)
    original = orchestrator.plan(path)
    path.write_text(yaml.safe_dump({**contract, "objective": "different"}))
    with pytest.raises(AgentSystemError, match="different contract"):
        orchestrator.plan(path)
    assert orchestrator.status(contract["task_id"]) == original


def test_architecture_block_cannot_self_approve(project, task):
    path, contract = task
    orchestrator = Orchestrator(project)
    state = orchestrator.plan(path)
    for target in (State.CLASSIFY, State.CONTRACT_READY, State.ARCHITECTURE_CHECK):
        state = transition(state, target)
    directory = orchestrator.run_dir(contract["task_id"])
    atomic_json(directory / "state.json", state)
    blocked = orchestrator.block_architecture(contract["task_id"])
    assert orchestrator.resume(contract["task_id"]) == blocked
    assert not (directory / "worktrees.json").exists()
    with pytest.raises(AgentSystemError):
        transition(blocked, State.WORKTREES_READY)


def test_major_phase_is_retained_not_accepted(project, task):
    path, contract = task
    contract["major_phase"] = True
    path.write_text(yaml.safe_dump(contract))
    orchestrator = Orchestrator(project)
    state = orchestrator.plan(path)
    assert state["requires_user_approval"]
    assert orchestrator.resume(contract["task_id"])["state"] == "WORKTREES_READY"


def test_concurrent_mutation_blocked(project, task):
    path, contract = task
    orchestrator = Orchestrator(project)
    orchestrator.plan(path)
    with lock(orchestrator.run_dir(contract["task_id"])):
        with pytest.raises(AgentSystemError, match="locked"):
            orchestrator.resume(contract["task_id"])


def test_cli_preparation(project, task, capsys):
    path, contract = task
    assert main(["--project", str(project), "run", str(path)]) == 0
    assert '"state": "WORKTREES_READY"' in capsys.readouterr().out
    assert main(["--project", str(project), "status", contract["task_id"]]) == 0


def test_resume_uses_frozen_config(project, task):
    path, contract = task
    orchestrator = Orchestrator(project)
    orchestrator.plan(path)
    cfgpath = project / ".agent_system/project.yaml"
    current = yaml.safe_load(cfgpath.read_text())
    current["data_critical_patterns"] = ["src/**"]
    cfgpath.write_text(yaml.safe_dump(current))
    assert not Orchestrator(project).resume(contract["task_id"])["data_critical"]


def test_corrupt_history_rejected(project, task):
    path, contract = task
    orchestrator = Orchestrator(project)
    state = orchestrator.plan(path)
    state["state"] = "WORKTREES_READY"
    state["history"].append({"state": "WORKTREES_READY", "at": "synthetic"})
    atomic_json(orchestrator.run_dir(contract["task_id"]) / "state.json", state)
    with pytest.raises(AgentSystemError, match="illegal transition"):
        orchestrator.resume(contract["task_id"])
