"""Disposable live-command fixture. Offline only, no network or model invocation."""
import json
import sys
from pathlib import Path

prompt = sys.stdin.read()
args = sys.argv[1:]
decoder = json.JSONDecoder()
task = decoder.raw_decode(prompt.split('Task contract:\n', 1)[1])[0]
context = decoder.raw_decode(prompt.split('Context manifest:\n', 1)[1])[0]
phase = context.get('phase')
task_id = task['task_id']
root = Path.cwd()
if phase is None:
    message = 'LIVE_SMOKE_OK'
elif phase == 'test_design':
    report = {'task_id': task_id, 'cases': [{'id': f'CASE-{i}', 'category': 'acceptance',
        'priority': 'high', 'criterion': i, 'preconditions': [], 'action': 'Call public interface',
        'expected_result': criterion, 'fixtures': []} for i, criterion in enumerate(task['acceptance_criteria'])]}
elif phase == 'implementation':
    (root / 'src/labels.py').write_text('def normalize_label(value: str) -> str:\n    return "-".join(value.lower().split())\n')
    report = {'task_id': task_id, 'outcome': 'completed', 'summary': 'Implemented contract', 'architecture_decision': None}
elif phase == 'test_implementation':
    tests = root / 'tests/acceptance'; tests.mkdir(parents=True)
    (tests / 'test_labels.py').write_text('from src.labels import normalize_label\n'
        'def test_0():\n    assert normalize_label("  A   B!  ") == "a-b!"\n'
        'def test_1():\n    assert normalize_label("  ") == ""\n')
    report = {'task_id': task_id, 'summary': 'Acceptance tests', 'independent': [
        {'case_id': f'CASE-{i}', 'path': 'tests/acceptance/test_labels.py',
         'test_id': f'tests/acceptance/test_labels.py::test_{i}'} for i in range(2)], 'additional': []}
elif phase == 'review':
    report = {'task_id': task_id, 'summary': 'Reviewed', 'findings': [], 'architecture_decision': None}
else:
    raise SystemExit('Unsupported fixture phase')
if phase:
    message = json.dumps(report)
Path(args[args.index('--output-last-message') + 1]).write_text(message, encoding='utf-8')
print(json.dumps({'type': 'turn.completed', 'usage': {'input_tokens': 20, 'output_tokens': 5,
                  'cached_input_tokens': 10, 'reasoning_output_tokens': 2, 'total_tokens': 25}}))
