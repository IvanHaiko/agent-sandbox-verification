# Stage 19b — Authorized diagnostic attempt

Date: 2026-10-06. Outcome: **BLOCKED_AUTH_BEFORE_INFERENCE**.

The operator authorized one proposed diagnostic execution and freshly confirmed that the app credits-fallback switch is OFF and will remain OFF. The attempt stopped at OAuth ID-token validation during a necessary refresh. **No Responses POST was dispatched**, no unknown model body was captured, and no model-selected tool ran. The historical transport mismatch therefore remains unexplained.

## Preparation and checks

- Fresh real Docker isolation and pinned Codex transport admission passed using synthetic localhost model responses: 13 isolation capabilities and 9 transport/security properties. No full framework workflow was run.
- 40 quarantine observer tests and 6 frozen-request entrypoint tests passed. Together with the fresh admission test, 47 tests passed.
- The exact pinned Stage19 Codex 0.160.0 prepared one gated request offline using the original Stage19 minimal prompt. The prepared body stayed in Controller memory; its SHA256 and field names were retained. Native Codex exited and its disposable home was removed before credential access.
- Model/reasoning remained `gpt-6-astra` / `low`; fixed route, stream/store/input/tool/header semantics were preserved. No alternative request was tried.
- The trusted entrypoint enforces a frozen body hash, new signed authority and at most one underlying dispatch. Supported SSE would be closed without body forwarding; unknown MIME would undergo bounded observation and mandatory rejection.

## Actual authorized attempt

The saved session required refresh. One refresh was attempted. The existing strict verifier raised the static error `ChatGPT ID token verification failed` while building the replacement credential record. The inference path was never reached.

The exact signature/claim/discovery failure was not instrumented by the existing verifier, so its cause is UNKNOWN. No arbitrary OAuth response or exception text was printed, persisted in project evidence or used as authority. No verifier was weakened, refresh retried or new sign-in attempted.

On this error, the refresh implementation does not write a replacement credential record, because persistence follows successful identity verification. Server-side refresh-token rotation is UNKNOWN; it is unsafe to assume that another use of the old token would work. This is an authentication blocker, not new evidence about the Responses transport.

Diagnostic/live/frozen-request/no-credit grants were not issued: execution stopped before that step. The fresh human no-credit confirmation exists in the chat, but this report does not claim that a new signed execution attestation was created or verified.

## Cleanup and historical integrity

The one-execution latch is preserved and was not reset. All 22 snapshotted historical files retain their hashes. The production MIME gate and accepted Stage18c sources were unchanged. Final checks found no stale owned containers, no remaining native preparation home, and the owned workspace at its original `value = 1` baseline. Initial sandbox-denied Docker admission evidence was retained separately; the later permitted admission passed.

Stage19 remains **FAIL_LIVE_TRANSPORT**; Stage20 remains inadmissible. Before another inference attempt, a separately authorized reconnection or authentication diagnosis is required. The failed diagnostic is not silently retried.

Supporting artifacts: [machine-readable assessment](STAGE19B_AUTHORIZED_CAPTURE.json), [attempt evidence](docs/stage19b-capture-evidence/capture.json), [fresh admission](docs/stage19b-capture-evidence/fresh-admission.json), [observer tests](docs/stage19b-capture-evidence/observer.xml), [entrypoint tests](docs/stage19b-capture-evidence/entrypoint.xml), [admission test](docs/stage19b-capture-evidence/admission-final.xml).
