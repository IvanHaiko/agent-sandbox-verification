# Stage 19d — SIWC Conformance Repair

`READY_FOR_FINAL_STAGE19_SMOKE` — the three production repairs, offline adversarial regression and fresh source-bound admission passed. Exactly one future smoke is proposed, awaiting separate user authorization after this assessment is reviewed. No live inference, OAuth refresh, OML, benchmark or real multi-agent workflow occurred.

**Stage19 remains `FAIL_LIVE_TRANSPORT`; Stage19 passed: false; Stage20 admissible: false.** Stage18c remains historical evidence for the architectural boundary, not admission of changed production bytes.

## Production changes and authorization invariant

The old gate merged accepted item/snapshot calls by `call_id`, then checked that earlier keys were a subset of final keys. Duplicate IDs collapsed, argument deltas/done were ignored, and canonical authorization could become visible before a later inventory/replay rejection. It did not confuse `item_id` with `call_id`.

The new production validator in `agent_system/responses_lifecycle.py` privately tracks response ID, supplied sequence ordering, output position, output item ID, separate logical call ID, function name, namespace, streamed arguments, arguments-done and item-done. Each final array position must match its registered completed item; functions must match all identities and canonical JSON. Missing/extra/duplicate/mutated/unfinished calls fail closed. Interleaved calls are accepted; supplied sequences must increase but need not be contiguous. Argument events use documented `item_id`, `output_index`, `delta`/`arguments`; they cannot invent alternate call/name/namespace authority. See the [Responses streaming event reference](https://developers.openai.com/api/reference/resources/responses/streaming-events).

`ResponsesGate.response` serializes full validation and replay checks under its existing lock. It builds private candidates, then replaces a copied authorization map exactly once on success. Rejection preserves the previous map object and seen-call/item/response sets; safe diagnostic metadata may change. `inspect_response` never publishes authority. `PlanUpstream` validates the complete body before returning it; the actual relay gate revalidates against session replay state before Codex receives it. Existing Controller and bridge checks independently validate exact identity, canonical arguments, schema, role/workspace/read-only bounds and Docker confinement.

`model_tool_boundary.py` declares one Controller-owned `agentctl` namespace containing one strict `agentctl_execute` function with the unchanged execution-bound schema, `additionalProperties: false`, argv-only execution and existing timeout/output limits. Top-level provider inventories are overwritten; Codex input `additional_tools` inventories are removed entirely; tool-search items are rejected. `codex_tool_session.py` emits the matching namespace `dynamicTools` wrapper and requires that namespace at dispatch. This follows the [function namespace format](https://developers.openai.com/api/docs/guides/function-calling) and [SIWC preview tool restrictions](https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations). The installed Codex's generated `DynamicToolSpec` schema was checked independently, and the real local app-server synthetic roundtrip passed; see [SIWC Codex app-server guidance](https://developers.openai.com/siwc/token-sharing-open-source/codex-app-server).

`responses_http.py` inspects actual Content-Type fields before library defaults. It buffers only an HTTP200 response from the fixed route on an owned socket, within byte/time/read/idle limits, with validated framing, EOF and confirmed reader shutdown. Cancellation, timeout, overflow and truncation discard bytes. Only after UTF-8, complete SSE framing, supported events/items, identity/lifecycle/final reconciliation, schema, secret and session replay validation pass can absent/unrecognized MIME be tolerated. No prefix sniffing or partial dispatch is used.

| MIME/body case | Decision |
|---|---|
| `text/event-stream`, optional UTF-8 charset | Eligible after full validation |
| Header absent | Tolerated after full validation |
| Empty malformed media token or unrecognized token with no valid media type | Tolerated after full validation |
| Explicit `text/plain`, `application/json`, or another valid incompatible media type | Reject |
| Damaged leading explicit media type, duplicate/unsafe header, non-UTF-8 charset | Reject |
| Invalid UTF-8, malformed/partial SSE, unknown event/tool, secret, replay, incomplete lifecycle | Reject for every MIME |

`runners/chatgpt_plan.py` passes cancellation and saves bounded structural metadata in invocation cleanup: known event counts, function/transition counts, stability/equality/bijection flags, byte count, MIME category/tolerance, EOF/shutdown, terminal status and recognized numeric usage. It retains no raw IDs, arguments, prose, account data or arbitrary provider fields. Known secret rejection suppresses metadata to fixed validation/secret flags. `runners/tool_docker.py` adds both new validators to admission source binding; Docker execution architecture, OAuth ownership, bearer storage, route/proxy/redirect policy and signed live/no-credit requirements remain unchanged.

## Measured offline results

**438 unique final-source tests passed:** 235 focused protocol/history/transport tests, 202 selected security/adapter/runner regressions and one fresh real Docker/Codex admission test. Zero final failures/errors/skips. The 84 Stage19d tests include all 38 Stage19c matrix cases: five valid accepted, 33 invalid rejected, including all 16 previously accepted attacks. Twenty extra lifecycle/security cases and twenty actual synthetic HTTP reader cases passed. Other tests cover interleaving, reasoning/message output, optional sequences, canonical whitespace, independent namespace/schema checks, atomic publication and bounded safe telemetry. Every rejected Stage19d case uses downstream/execution/host-write traps and must leave authorization/replay state unchanged; trap hits were zero.

`{}` is valid JSON and canonicalizes successfully; it cannot authorize `agentctl_execute` because the exact schema requires execution-bound fields. This explicitly preserves JSON validity without weakening the executable schema. Historical Stage19c characterization now uses a frozen legacy algorithm only in validation; production never imports it. Historical reports/evidence are byte-preserved.

| Final test module | Passed |
|---|---:|
| `tests.test_model_tool_boundary` | 47 |
| `tests.test_stage19c_reconciliation` | 81 |
| `tests.test_stage19d_conformance` | 84 |
| `validation.test_full_response_observer` | 11 |
| `validation.test_stage19_reconnect` | 6 |
| `validation.test_stage19b_capture_entrypoint` | 6 |
| `tests.test_agent_transport` | 45 |
| `tests.test_chatgpt_oauth` | 37 |
| `tests.test_chatgpt_plan_transport` | 20 |
| `tests.test_contracts` | 8 |
| `tests.test_docker_runner` | 23 |
| `tests.test_hardening_isolation` | 11 |
| `tests.test_runner` | 18 |
| `tests.test_transport_diagnostics` | 40 |
| `validation.test_stage19d_admission` | 1 |

The default collection contains **580** node IDs. **414** passed freshly; **166** remain uncompleted in this stage, with **24** additional validation nodes outside default collection. The full default attempt was stopped after slow unrelated deterministic workflow fixtures and produced no final XML; partial progress is excluded. This is selected fresh regression, not a fresh full-suite pass. The [coverage ledger](docs/stage19d-evidence/coverage.json) lists every completed and uncompleted node ID and each XML SHA256. Earlier failed attempts and fixes are recorded in the JSON assessment; superseded passing runs are not double-counted.

## Exact source and fresh admission

Current production bundle SHA256: **`255284b0d5d9f8c8de584ba68f2a24ac79500fdc29ab529c6b7ada5df014a544`**. The bundle is SHA256 of the sorted compact JSON mapping all `agent_system/**/*.py` paths to their byte SHA256. The complete mapping is in the JSON assessment and measured admission evidence.

| Changed baseline file | Before SHA256 | After SHA256 |
|---|---|---|
| `agent_system/codex_tool_session.py` | b6fd75be1be630fcbe11cb01436b83f9071d6bd1c2002adcf18f3c9121541d72 | 47027747dcad94340437a34ab7740f27d68b1d65d68f4ffec9b87789ca198623 |
| `agent_system/model_tool_boundary.py` | dbf72c3a41a9923ac31fbb5abc7e68028227cea220f98aabaa11cf5c2b61ee5d | b0448fffea5fa1eb15e2d1806b5fcd3e6e496b11568c0ae651bd83c9ce7b3b1b |
| `agent_system/runners/chatgpt_plan.py` | a0264c1a0321052a5f1fffeba070c62608dc51ef1d188d9f2a187c947dd4a097 | eb5b6b7b9f9e4b57c9d7a217923f2da29568a883acd260f89d6bcf770d6d0a10 |
| `agent_system/runners/tool_docker.py` | 1c9a492a868e53e05eeabcc75cb9acf3cb229ce73201291936f2e924f14a2076 | bed4e547ea585604aae156ecf4ad96416ade2bbc6d7a235773695b3fc6d2c807 |

| New production file | SHA256 |
|---|---|
| `agent_system/responses_lifecycle.py` | 6f31870fea83358930849c611367ba606d9b84a97d226541f64d52246881938a |
| `agent_system/responses_http.py` | 0596a4187033719c9fc1cf5262a0bc02802850d42aa963ca158221a0e3aa72c3 |

The final admission test reused the existing Stage18c deterministic admission prefix, stopping before Controller workflow. It measured the installed Codex app-server with synthetic localhost Responses, real Docker mutation, host execution traps, token/environment visibility, network/storage isolation, native tool rejection, timeout/cancel/overflow cleanup and secret-output rejection. It signed new transport admission for the changed source. Nine deterministic tool executions occurred, zero real model calls; the disposable workspace was reset to `value = 1`, bridges closed and stale owned containers checked absent.

The assessment independently reverified the HMAC-bound transport proof and evidence SHA256, current production byte hashes and Codex executable SHA256. Pinned image: `sha256:6c07868196d1880d956f4b5ddf50244bc281faab39704a8940b1c1f3159a145e`; Docker `29.7.2`, context `desktop-linux`; Codex SHA256 `3b8f6e33caa75f232558a3cf76ff9b87bb5ef6dbcf4996372f24e55c78b1b916`. Full engine/settings/project binding is retained in [fresh admission evidence](docs/stage19d-evidence/fresh-admission.json). No live-smoke grant was issued. Source, executable, image, engine, settings or project changes require fresh matching admission before live use. The signed local proof relies on protected Controller storage, not protection from the machine's administrator.

## One final smoke proposal

The exact [proposal JSON](docs/stage19d-evidence/final-smoke-proposal.json) is reviewable and contains the exact argv templates and structured result. It proposes the existing disposable Stage19 fixture under one fresh execution identity `stage19-final-conformance-1`, task `STAGE19-SMOKE`, one implementer/implementation role, `gpt-6-astra`, reasoning `low`, one turn/execution, no retries, at most three fixed-route Responses requests and exactly two sequential `agentctl.agentctl_execute` calls. Parallel calls are disabled.

The first command checks `src/example.py` equals `value = 1\n`, changes only that file to `value = 2\n`, and prints `stage19-mutated`. The second reads the same file, loads its public value, checks both equal 2 and prints `stage19-verified`. Each tool is bounded to 20 seconds/1MiB output; the mutation uses `read_only=false`, verification `true`, stdin empty. Controller supplies all six exact identity constants and independently restricts the bridge to those two templates. Total deadline 180 seconds; response ceiling 1MiB; body ceiling 60 seconds/4096 reads/5-second idle. The final role result must exactly match the task/version/completed outcome and fixed summary in the proposal.

A future driver must be created and independently source-bound after separate review/authorization. Historical live entrypoints/grants cannot authorize this scope. It must reverify matching admission, valid existing OAuth and a genuine fresh execution/client-bound human no-credit-fallback attestation (at most 24 hours old), obtain the separately authorized signed live grant, persist an exclusive one-shot latch before inference, and consume the allowance on failure. Expired credentials stop before inference; no automatic refresh. Capture safe structural metadata for every request, independently verify the exact file diff/public value/tool outputs/strict result, and confirm owned container, Codex home and role-storage cleanup plus unchanged primary workspace and historical evidence. No driver, live grant, scheduling or execution was performed here.

## Remaining uncertainty and stop state

Offline fixtures cannot prove success on real SIWC traffic. Cross-event stability and terminal bijection are conservative local authorization rules based on documented event identities; unseen provider variation may safely reject. Missing-MIME tolerance is the explicit narrow policy requested for observed SIWC behavior, not a general documented `text/plain` allowance. Without supplied sequence numbers, identical legitimate fragments are appended and checked by full argument reconciliation rather than inferred duplicate detection. Message/reasoning remain nonexecutable under the accepted policy; no new general text transcript completeness guarantee is claimed.

The destroyed historical response and its `Partial tool completion` cause remain unknown. Current account credentials were neither inspected nor refreshed. Exact default regression omissions are retained. Admission fixture/storage must remain available and protected, and all environment bindings must be checked again for any future smoke. Production is ready to propose exactly one separately authorized smoke; Stage19 has no live success and Stage20 remains inadmissible. Work stops here.
