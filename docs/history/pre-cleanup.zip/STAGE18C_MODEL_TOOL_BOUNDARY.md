# Stage 18c: model/tool boundary

Date: 2026-10-05. Status: **READY_FOR_AUTHORIZED_LIVE_SMOKE**.

Stage 18 engineering is complete under the measured, pinned topology below. Stage 19 is **not technically admitted, authorized or executed**. Real model calls: **0**. No real OAuth login, token acquisition or model-catalog request occurred. Earlier checkpoints retain their historical conclusions and were not overwritten.

Machine-readable assessment: [STAGE18C_MODEL_TOOL_BOUNDARY.json](STAGE18C_MODEL_TOOL_BOUNDARY.json). Reproducible assessment builder: [validation/stage18c_assessment.py](validation/stage18c_assessment.py).

## 1. Selected topology

Topology A: trusted Windows Codex app-server, Controller-owned model-only Responses relay, and external dynamic tool delegation into existing per-role Docker execution. The implementation preserves Codex's thread, turn, context and agent-loop semantics. It does not implement a replacement agent loop.

Codex receives a random local channel credential, never an OpenAI access or refresh token. The Controller relay alone can add the current OAuth access token to a fixed OpenAI request. Before Codex receives any model output, the relay buffers and validates the entire bounded SSE response. Only the Controller-authored `agentctl_execute` function can reach the SDK dispatcher. Its call ID and exact arguments must match the already-gated model response.

## 2. Alternatives evaluated

| Topology | Decision |
| --- | --- |
| A: trusted app-server with dynamic external tools | Selected and directly measured against the pinned native binary. Model tool dispatch is constrained before the SDK sees the response. |
| B: dedicated isolated app-server runtime | Unnecessary for this measured separation; no new Linux Codex image required. Putting bearer credentials beside generated code remains rejected. |
| C: remote code-mode execution host | Not selected. Its documented experimental connection adds another runtime/protocol without proving compatibility with this Docker runner. |
| Native shell/file tool followed by an approval hook | Rejected: approval does not turn native host execution into Docker delegation. |

## 3. Official contracts relied upon

The app-server provides bidirectional JSONL RPC over stdio, ephemeral threads, turns and experimental dynamic tools delivered as `item/tool/call`. Native command/filesystem methods execute on the server side; they are not our delegation path. Remote code-mode hosting is experimental. [Official app-server documentation](https://developers.openai.com/codex/app-server).

The official SIWC guide describes a Responses provider, app identification and application-owned token refresh/session restart. Our authenticated loopback provider is a framework adaptation of that provider contract, not a claim that Codex supplies this Docker bridge. [Official SIWC app-server guide](https://developers.openai.com/siwc/token-sharing-open-source/codex-app-server).

Requests use streaming Responses, `store=false`, array input and supported function tools. Unsupported provider fields, hosted tools, system items and previous-response HTTP linkage are rejected. [Official preview limitations](https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations).

The private runtime uses ephemeral auth storage and disables native tool features, updates, proxy fallback, apps, plugins, hooks, browser/computer tools and code-mode facilities. [Official configuration reference](https://developers.openai.com/codex/config-reference). Feature flags supplement the mandatory response gate; flags alone are not the boundary proof.

## 4. Trust boundary

```mermaid
flowchart TD
    O[Operator] --> C[Trusted Controller]
    C --> S[Protected OAuth storage]
    C --> R[Bounded model-only relay and response gate]
    R -->|Fixed Responses route; future authorized OAuth| M[OpenAI]
    A[Trusted ephemeral Codex app-server] -->|Authenticated loopback Responses| R
    A -->|Stdio dynamic tool call| C
    C --> B[IsolatedExecutionBridge]
    B --> D[docker_isolated role: network none]
    D --> W[Owned role snapshot: shell, files, tests, Git]
```

The native Codex binary and Controller remain trusted. Generated repository code and model-selected operations execute in Docker. Same-user host administrators are outside this isolation threat model.

## 5. Controller responsibilities

The Controller owns credentials, refresh/disconnect, HMAC approvals, task state, contract selection, admission, snapshot preparation, diff validation/export, evidence hashing and strict result parsing. These deterministic host operations are not model tools.

The opt-in [ChatGPTPlanRunner](agent_system/runners/chatgpt_plan.py) retains the hardened state/history/config/operation identity, contract/architecture/test-design approvals, owned checkout HEAD/cleanliness and context-limit checks. Its operation ID binds one model session to one role execution. An actual factory integration with the existing Controller reached `ACCEPTED`, using a synthetic provider and the existing deterministic fixture for other phases.

## 6. App-server/model transport responsibilities

[CodexToolSession](agent_system/codex_tool_session.py) starts the exact SHA-pinned binary with `app-server --listen stdio://`, private HOME/CODEX_HOME, ephemeral thread, fixed model/reasoning and read-only native sandbox. It checks thread/turn IDs, event types, completion and strict structured results. Built-in execution requests and unknown events fail closed. Informational warnings never grant authority or change routing.

[ResponsesGate](agent_system/model_tool_boundary.py) binds identity, model, reasoning, route, expiry, request/response byte ceilings and count ceilings. Defaults are four model requests, eight tool calls and 1 MiB per model request/response. Unsupported outputs, duplicate keys, invalid UTF-8, partial frames, missing completion, replay and overflow are denied. Buffering prevents a malicious early tool item from executing before later validation fails.

Each execution has fresh paths, channel and session. Shutdown closes stdin, waits, kills if necessary and joins readers. Cancellation shuts down owned tool containers. A changed access-token generation refuses further inference and requires a new execution/session. No cross-role history reuse or silent retry exists.

## 7. Docker-role responsibilities

All model-driven shell, file reads/writes, patches expressed as argv programs, searches, Git exploration, imports, package commands and tests cross [IsolatedExecutionBridge](agent_system/model_tool_boundary.py) into [ToolDockerRunner](agent_system/runners/tool_docker.py). The subclass invokes the existing Docker runner execution mechanism; its historical implementation remains byte-for-byte unchanged.

The role receives an owned snapshot, minimal environment and bounded stdin/stdout/stderr. Read-only roles and architecture/test-design phases cannot request mutation. Only Controller-approved policy export can return validated changes to the owned checkout. No model request supplies a host cwd, mount or inherited environment.

## 8. Tool protocol

The single `agentctl_execute` function has an exact JSON object schema with no additional properties:

| Field | Enforcement |
| --- | --- |
| execution_id, task_id, role, phase, contract_version | Exact Controller identity and types |
| workspace_id | Exact Controller-selected workspace identity |
| tool_type | Only `argv` |
| argv | 1–64 nonempty strings; no NUL; bounded serialized size |
| stdin | String, at most 64 KiB |
| timeout_seconds | Positive integer within policy, at most 60 seconds; execution deadline also applies |
| output_bytes | Positive integer within policy; default 1 MiB |
| read_only | Boolean; cannot escalate a read-only role |

The bridge checks fresh capability admission for every command. Unknown tools, mismatched identity, replay, stale execution or unavailable capabilities deny execution. No host subprocess/filesystem fallback exists. Dynamic-call arguments must equal the canonical arguments authorized by the model response gate.

## 9. Credential boundary

Existing official public-client registration, PKCE/state/nonce, loopback callback, ID-token/JWKS validation, issued-client/account binding, protected storage, refresh rotation and revocation remain unchanged. Runtime storage must be external to all project/role roots. Windows ACL/POSIX protection is provided by the existing OAuth store.

Only the Controller's fixed upstream request receives an access bearer. Refresh and ID tokens stay in trusted storage. Codex receives only an ephemeral relay channel token; Docker roles receive neither that channel nor OAuth tokens. No host HOME, `.codex`, auth-cache import, credentials in argv/prompts/Git or raw provider diagnostics were introduced. Synthetic secret rejection occurs before tool output persistence and evidence export. It detects known literal/canonical escaped values; it is not universal encoded-secret DLP.

## 10. Network boundary

Roles retain `network none`, no generic egress and no local relay socket. Codex-to-Controller uses stdio RPC plus authenticated ephemeral loopback HTTP because the measured official Responses provider requires HTTP. This HTTP service permits only `/v1/responses`, one bounded POST body and its random channel; it is not a generic TCP/HTTP proxy.

Trusted upstream uses only `https://api.openai.com/v1/responses`, disables proxy inheritance and redirects, and has no arbitrary-URL or API-key fallback. Role tool traffic uses Docker attach, not Internet access. No upstream OpenAI HTTP request was made in validation.

## 11. Credits/billing policy

The official account control is **“Allow other apps to use credits after reaching your usage limit”**. App percentage limits are not reserved allowances. No authoritative programmatic per-request no-credit switch or account-setting read was established. [Official Sign in with ChatGPT documentation](https://learn.chatgpt.com/docs/sign-in-with-chatgpt).

Selected resolution is the user's permitted option B: the operator must disable the account setting and maintain it disabled during the smoke. Preflight requires an HMAC-protected `no-credits/<execution_id>` record containing `credits_fallback_disabled=true`, matching execution/client, nonempty operator and an attestation timestamp no older than 24 hours. It also independently requires an exact `live-smoke/<execution_id>` authorization covering identity, model, reasoning and fixed route. Both factory startup and upstream enforce these requirements; missing, false, stale or mismatched attestations deny inference.

This is a mandatory operator-setting guarantee conditional on truthful, current attestation. Software neither controls nor detects later changes to the account setting. There is no paid/API-key fallback. No real attestation or live authorization has been issued by this task. Synthetic test approvals are explicitly offline fixtures.

## 12. Runtime image and binary

Existing Linux role image is preserved:

`sha256:6c07868196d1880d956f4b5ddf50244bc281faab39704a8940b1c1f3159a145e`

Roles run uid/gid 50000, read-only root, dropped capabilities, no-new-privileges, private tmpfs, resource limits and protected read-only overlays. No new image was required. Image provenance/inventory limitations from the historical isolation checkpoint remain; this stage does not claim a newly reproducible image build.

Measured native Codex: **0.159.2**; SHA256:

`fcd5eafefb4ff4a607f244e099e0974f66e17966b6ffda6948de2ef3a7a79530`

Docker: desktop-linux 29.7.2, kernel 6.6.87.2-microsoft-standard-WSL2. Dynamic tools are experimental and pinned to this directly measured binary; this is engineering evidence, not general production compatibility.

## 13. Fresh admission

A new binding includes the old Docker boundary hash, image/engine/config/project, new source bundle hash, native Codex path/hash, fixed model route, role network and new IPC mechanisms. It does not inherit Stage 17 admission for changed transport.

All **13 fresh OS capabilities passed**: fresh context, filesystem read/write, session storage, private HOME/cache, instruction control, denied network, isolated checkout, read-only mounts, environment, hidden tests and Controller storage. Nine transport facts also passed and were HMAC-attested: native dynamic roundtrip, Docker mutation, host execution trap, token invisibility, built-in denial, timeout/cancel/overflow cleanup and secret rejection before export.

New source bundle SHA256:

`312f88f3a8f7e6bfa679f3727fec5dd92195199fba8b6eacf5ac4bf0e2563bff`

Evidence: [fresh summary](docs/stage18c-evidence/real-summary.json), [signed transport record](docs/stage18c-evidence/fresh-admission/stage18c-transport.json), [transport proof](docs/stage18c-evidence/fresh-admission/stage18c-proof.json), [OS validation record](docs/stage18c-evidence/fresh-admission/validation.json). HMAC keys were not exported. These measurements bind the synthetic fixture project; the actual Stage 19 target must obtain its own fresh binding/admission.

## 14. Adversarial tests

The host process trap permits trusted Git/Docker/Codex and the exact deterministic cleanup helper, while rejecting generated host commands. Actual model-selected Python mutation ran inside Docker. A built-in `exec_command` response was denied before Codex received it; its host sentinel remained absent.

Role environment, filesystem and `/proc` probes found no synthetic Controller credentials/channel or host paths. Fresh isolation covered sibling/holdout/Controller reads, writes, network and import provenance. Unit attacks covered endpoint override/metadata routes, wrong channel, identity/role/workspace/version mismatch, tool confusion, malformed JSON/UTF-8, replay and closure. Actual Docker timeout, cancellation, excessive output and a program emitting a known synthetic secret cleaned up without raw-secret export. Upstream guard tests prove missing authorization/credit attestations, changed route, expired/wrong-scope credentials and rotated access token refuse before HTTP.

## 15. Regression results

| Evidence | Passing cases |
| --- | ---: |
| Recent full baseline | 266 |
| Previous Stage 18 focused suite | 102 |
| Final Stage 18c focused suite, including actual local Codex | 150 |
| Fresh actual Codex/Docker/adversarial/factory integration | 1 comprehensive case |
| Opt-in synthetic RSA/JWKS checks | 10 |

Exact node-ID union covers **375/375 currently collected default tests** and **387 unique cases** including opt-in checks; zero failures/errors/skips in these successful evidence runs. This is cumulative coverage, not a single fresh full regression run. The historical Docker boundary hash is unchanged, and the new factory's existing Controller lifecycle integration was freshly exercised.

Evidence: [focused JUnit](docs/stage18c-evidence/focused-complete.xml), [fresh integration JUnit](docs/stage18c-evidence/real-final-2.xml), [exact coverage](docs/stage18c-evidence/coverage.json). Historical assessment hashes verified unchanged. Earlier diagnostic failed attempts are retained and are not counted as passing evidence.

## 16. Remaining limitations

Real OAuth, entitlement, model reasoning, plan quota and billing behavior are untested. Fixture model names and configured aliases do not prove entitlement. Usage/token/cost fields remain unknown. Experimental SDK changes, unsupported future SSE events and schema changes fail closed and require fresh measurement. Buffered SSE limits progress streaming.

Trusted Codex has logical tool confinement; it is not an OS sandbox against a compromised trusted binary. Owned parent shutdown and container cleanup are measured; no complete native descendant-process census is claimed. Controller storage remains protected plaintext under the existing owner permissions. In-session token rotation causes restart rather than automatic continuation.

## 17. Stage 18 completion

**Complete for authorized-live-smoke readiness.** All engineering completion criteria are supported by offline tests, actual native protocol integration and fresh Docker admission. Credits policy is resolved through mandatory operator setting/attestation as expressly allowed in the request. Previous blocked reports remain historical checkpoints; this separate assessment advances the engineering status without claiming live acceptance.

The existing default backends and runner factory selection are unchanged. Trusted application code explicitly opts in by supplying `ChatGPTPlanRunner(config, credential_store, approval_store)` through the existing Orchestrator runner factory. The runner requires the existing hardened task/phase lifecycle and fresh signed admission; it does not bypass these with a standalone tool session.

## 18. Stage 19 admission and exact next step

**NOT ADMITTED.** No smoke, benchmark, OML or role-value experiment was started.

The next separately authorized work is real OAuth setup/connection and preparation of a smoke for one exact operator-selected model/reasoning and task/role execution. Before inference: obtain fresh admission for that target binding; operator disables credit fallback and signs the client/execution-bound attestation; obtain a separate exact live-smoke authorization. Missing prerequisites keep preflight closed. Review this checkpoint before authorizing that work.
