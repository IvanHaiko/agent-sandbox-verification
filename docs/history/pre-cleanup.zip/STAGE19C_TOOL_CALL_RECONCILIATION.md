# Stage 19c — Tool call reconciliation semantics

Date: 2026-10-06. Verdict: **BLOCKED_SEMANTICS_AMBIGUOUS** for the historical captured failure. Stage19 remains **FAIL_LIVE_TRANSPORT**. Stage18c remains the accepted engineering boundary; Stage20 is inadmissible.

The proposed item-ID/call-ID namespace confusion is **not present in the current gate**. Both inventories use `call_id`. However, the current algorithm is substantially weaker than full lifecycle reconciliation. Synthetic tests establish local validation gaps, without establishing the cause of the captured rejection. Production acceptance and MIME handling were not changed.

## 1. Exact old algorithm

Source: `agent_system/model_tool_boundary.py`, `ResponsesGate.response` and `_item` (lines 134–216). The baseline hash inventory preserves the exact inspected source. The gate bounds, UTF-8 decodes, rejects secrets, parses complete SSE frames and permits only its event allowlist. It checks response identity and terminal status.

`calls` is a dictionary **logical call_id → constant allowed tool name**. It contains no item IDs, indices, argument fragments, item status or lifecycle state. Every event carrying an `item` field invokes `_item`, regardless of event type. Normally this includes output-item added/done; an undocumented `item` on another allowed event also populates it. Response created/in-progress/completed snapshots also populate it through `response.output`. Arguments delta/done fields alone do nothing. There is no mapping or conversion from `item_id` to `call_id`.

`final_calls` is another dictionary **logical call_id → allowed tool name**, populated only from `response.completed.response.output`, using the same `_item` implementation with `final=True`. Final arguments are strictly JSON parsed, canonicalized using `json.dumps(..., sort_keys=True)`, and immediately written to the shared `authorized_arguments` dictionary.

```text
calls = {}
for each supported SSE event, before any terminal event:
    if event has item: validate_item_and_record(event.item, calls)
    if created / in_progress / completed:
        verify response.id remains stable
        for item in response.output: validate_item_and_record(item, calls)
        if completed:
            require completed status and output list
            final_calls = {}
            for item in response.output:
                validate_item_and_record(item, final_calls, final=True)
                # final=True publishes canonical arguments immediately
            if keys(calls) - keys(final_calls): raise "Partial tool completion"
            reject previously seen logical call IDs
            seen_calls.update(keys(final_calls))
            mark completed
require completed
return original buffered bytes

validate_item_and_record(item, inventory, final=False):
    permit only message / reasoning / function_call
    validate supported message content
    for function_call:
        require allowed name and namespace
        require nonempty string item.call_id
        inventory[item.call_id] = allowed_name
        if final: authorized_arguments[item.call_id] = canonical_json(item.arguments)
```

The invariant is **subset**, not equality. Because final output was already merged into `calls`, missing streamed calls are detected but extra final calls are automatically included on both sides. Duplicate logical IDs collapse and final arguments can overwrite one another. X and Y are both `call_id`, semantically the same field. The user’s example equality and earlier informal “sets did not equal” phrasing are not the precise implementation.

`Partial tool completion` proves at least one accepted function-item `call_id` from an earlier item or response snapshot was absent from the final snapshot inventory. Plain argument deltas cannot directly cause this exception. A snapshot mutation, omission, or undocumented item-bearing event can reproduce it. Which occurred historically is unknown.

## 2. Official contract, checked on 2026-10-06

General Responses and SIWC guidance are separated below. These are concise paraphrases, not a claim that all general API capabilities apply to SIWC.

| Concept | Streaming representation | Final representation | Required relationship | Evidence |
|---|---|---|---|---|
| Output item | added/done `item.id` | function item `id` | Track output-item identity separately | [Function item schema](https://developers.openai.com/api/reference/typescript/__sdk_schema?declaration=%28resource%29+responses+%3E+%28model%29+response_function_tool_call_item+%3E+%28schema%29&selected=%28resource%29+responses) |
| Logical invocation | function item `call_id` | function item `call_id` | Model-generated invocation identity; do not equate with `id` | [Function call schema](https://developers.openai.com/api/reference/typescript/__sdk_schema?declaration=%28resource%29+responses+%3E+%28model%29+response_function_tool_call+%3E+%28schema%29&selected=%28resource%29+responses) |
| Function and arguments | item `name`; argument fragments | `name`, JSON-string `arguments` | One function with complete arguments | [Function call schema](https://developers.openai.com/api/reference/typescript/__sdk_schema?declaration=%28resource%29+responses+%3E+%28model%29+response_function_tool_call+%3E+%28schema%29&selected=%28resource%29+responses) |
| Argument owner | delta/done `item_id` | item `id` | References output item, not logical call | [Event reference](https://developers.openai.com/api/reference/resources/responses/streaming-events) |
| Output position | `output_index` | position in `response.output` | Output-item position; not invocation identity | [Event reference](https://developers.openai.com/api/reference/resources/responses/streaming-events) |
| Lifecycle | added; arguments delta/done; item done | completed response `output` | Terminal event contains completed Response | [Event reference](https://developers.openai.com/api/reference/resources/responses/streaming-events) |
| Event ordering | `sequence_number` | no analogous item identifier | Track event ordering separately | [Event reference](https://developers.openai.com/api/reference/resources/responses/streaming-events) |
| Item index | no `item_index` in these function events | array position | Do not invent another identity field | [Event reference](https://developers.openai.com/api/reference/resources/responses/streaming-events) |
| Other provider IDs | response `id`, optional `created_by`/`caller` | corresponding schema metadata | No documented substitution for item/call identity | [Function schemas](https://developers.openai.com/api/reference/typescript/resources/responses) |

The [function-calling guide](https://developers.openai.com/api/docs/guides/function-calling) demonstrates distinct `fc_...` and `call_...` identifiers and aggregation by output index. It does not authorize replacing one namespace with another. Its concluding arguments-done description lists `response_id` and `item`, conflicting with the dedicated event reference’s `item_id`, `output_index`, `arguments` schema. The prototype uses the dedicated schema; it does not treat this discrepancy as permission to accept aliases.

SIWC [models and inference](https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference) requires the public Responses endpoint, `store:false`, `stream:true`, and consuming through `response.completed`; interrupted, failed and incomplete inference remain distinct. No model catalog or inference example was executed. The [preview limitations](https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations) requires namespaced function/custom tools or `additional_tools`, prohibits several general API fields and hosted tools, and distinguishes local execution from hosted capabilities. The pre-existing flat request-tool declaration issue remains outside this stage.

The reviewed SIWC pages do **not** specify an alternate function identity lifecycle, permit call-ID transformation, or expressly resolve whether every streamed function item must repeat unchanged in terminal output. The completed Response schema and examples strongly support snapshot reconciliation, but an explicit SIWC cross-event stability guarantee was not located. No positional/name/argument-hash fallback is authorized. This uncertainty plus unavailable captured identities prevents classifying the historical response as a provider violation.

## 3. Safe analysis of retained evidence

Sources: `STAGE19B_FULL_RESPONSE.{md,json}`, `docs/stage19b-full-response-evidence/result.json`, and the unchanged `validation/full_response_observer.py` implementation.

Observed historical facts: HTTP 200, no recognized Content-Type, chunked transfer, EOF, 105,349 decoded bytes, UTF-8 valid, complete final framing, one created/in-progress/completed event each, two output-item added/done events each, 127 argument deltas and one argument-done event. The gate raised `Partial tool completion`. No Codex acceptance, tool, bridge or host execution occurred.

The observer kept response bytes and event payloads only in process memory, never returned them to transport, persisted `raw_body_persisted:false`, cleared buffered chunks and discarded raw bytes. It had no protected raw file output. This stage used its retained safe result only; no raw artifact was recreated or recovery search of credential/runtime directories performed. Python reference deletion is not a claim of cryptographic memory erasure.

| Requested comparison | Retained answer |
|---|---|
| Streamed / final function-item counts | Unknown; total output-item event counts are not typed call inventories |
| Missing streamed logical IDs | At least one dictionary key, derived from the exact failure branch |
| Item-ID equality / call-ID equality | Unknown for the offending calls |
| Stable bijection, output indices, names | Unknown |
| Argument equality or hashes | Unknown; no argument metadata retained |
| Whole body hash | Retained after existing secret rejection; cannot recover identities or arguments |

No IDs, prose, arguments, account data or credentials were invented or exported. No new captured-payload hashes were calculated.

## 4. Identity model assessment

| Model | Assessment |
|---|---|
| A: streamed/final item IDs equal | Appropriate proposed invariant for one item lifecycle; exact historical equality unknown; SIWC stability needs confirmation |
| B: streamed/final call IDs equal | Same logical field; appropriate invocation stability invariant, not equality with item ID; exact historical equality unknown |
| C: track both identities separately | Supported by distinct schema fields and official example; strongest design basis |
| D: map delta output item to invocation | Supported: register item `id` → `call_id` from added item; verify done item. No ID transformation is implied |
| E: index/order participates | Supported by event fields and aggregation example; gate currently ignores it. Array reordering is rejected by the proposal; interleaved arrivals need not be contiguous |

Models C/D/E complement A/B. None establishes the captured root cause.

## 5. Parser-state findings and minimal reproductions

The matrix in `tests/test_stage19c_reconciliation.py` uses synthetic IDs and synthetic bound arguments. It characterizes production separately from the proposed model.

Proven existing gaps: duplicate creation collapses records; duplicate final IDs overwrite authorized arguments; item-ID drift and output-index reuse are ignored; orphan/duplicate argument events and event sequence replay are ignored; argument fragments are not accumulated; final arguments need not match stream or item-done arguments; extra terminal calls are accepted; two item IDs can collapse to one logical call; malformed events carrying `item` can create phantom records. Final argument authorization occurs before inventory/replay validation, so rejected responses can leave entries in `authorized_arguments`.

`output_item.done` is processed, but only for type/name/call-ID validation, not lifecycle completion. Final traversal reads the top-level output list correctly for the supported shape; nested output is denied. Response completion before item-done is not independently checked. Unknown event types are denied, but an allowed delta with an undocumented `item` is processed as an item. Call-ID mutation adds another key instead of changing a record; the missing original ID then reproduces the historical error. Name mutation to a different function is denied by the allowlist. No actual delta item-ID/call-ID alias conversion exists.

The old fixture builder provides complete arguments at item-added and omits argument events, explaining why existing boundary tests did not exercise real streamed argument ownership. These findings are pre-existing gaps, not introduced regressions, and are not evidence that any historical call executed unsafely.

## 6. Proposed correct invariant and security

`validation/stage19c_reconciliation_model.py` is an **offline executable proposal**, never imported by production. Its exposed authorization map is empty on failure. It first validates the entire lifecycle, then runs the unchanged strict gate, then publishes canonical arguments.

```text
created → register response identity
added[index] → require fresh item ID and unique logical call ID; bind name/namespace
delta[index,item_id] → append only to a registered unfinished function item
arguments_done[index,item_id] → compare accumulated string, strictly parse, validate tool schema
item_done[index] → require stable item/call/name/namespace, complete matching arguments
completed → require exactly one terminal response and complete one-to-one final inventory
             compare each final array position with its completed item snapshot
entire buffered SSE + unchanged gate pass → atomically publish canonical calls
```

The proposal replaces the loose subset check with a bijection of **(output position, item ID, call ID, function name/namespace, completed arguments)** and monotonic event-sequence validation. No mapping by names, hashes or order alone can create an invocation. Replay of event sequence, item, response and call identities is rejected. Equal fragment text with distinct sequences is allowed: repeated characters are not intrinsically replay.

Security requirements represented by the proposal: known fragment owner; stable identity/function; complete strict JSON and bound executable schema; exactly one completed call per logical invocation; no missing/extra/ambiguous final item; no unknown/hosted function; no release before complete validation; canonical arguments match the validated output. It inherits secret rejection, buffering ceilings, deadline checks and the allowed output/event subset. The production session’s canonical argument comparison and Docker bridge remain untouched.

Proposal limitations prevent promotion: exact full snapshot equality is deliberately conservative; progress snapshots with nonempty inventories are rejected; text/reasoning fragment completeness is not newly proven; no-delta arguments-done supplies the full arguments when initial arguments are empty; absent sequence numbers are rejected. These are explicit prototype policies, not newly documented universal SIWC guarantees. It is not a production alternative or permission to admit the captured response. No claim is made that production satisfies all new fail-closed requirements: characterization proves it does not.

## 7. Adversarial and regression results

All 30 requested scenarios plus eight additional cases are exercised against both algorithms. Five valid cases pass the proposal; 33 attacks fail. Production accepts 16 of those attacks. Additional tests cover same-text distinct fragments, secret rejection, bounds, failed-publication atomicity, old overwrite/early-publication behavior and preserved file hashes. The final matrix suite has **81 passing tests**. Its original run had a test-fixture error from trapping the wrong runner method; the fixture now traps both the real tool runner and Docker command method.

Executor traps guard downstream acceptance, `CodexToolSession.handle`, `IsolatedExecutionBridge.execute`, `ToolDockerRunner.run_tool`, Docker command invocation, host `run`/`Popen`, and outbound connection creation. Proposed-model rejection occurs before the downstream callback and exposes no calls. Old-gate characterization never forwards accepted attacks. Thus the trap proof applies to the proposal’s failing cases; it cannot truthfully be claimed for attacks production accepts. No real Docker or model executor was run.

The selected boundary/OAuth/plan-transport/agent-transport/diagnostics/Docker-adapter/isolation regression run passed **304 tests**, including the then-current 81 matrix tests. Observer/capture-entrypoint/reconnection verification suites passed **23 tests**, all synthetic. A standalone final matrix rerun also passed 81. Relevant existing tests therefore total 246 passes across the two regression runs, in addition to 81 new tests. No account is needed.

The first regression attempt recorded 218 passes and 86 setup errors because pytest’s default temporary directory was inaccessible. A fresh workspace-local `--basetemp` resolved them; final XML files preserve successful results separately from the failed attempt. The selected tests exercise OAuth verification and fixed routing, forbidden host fallback, isolated runner admission, replay/secret defenses, bounded SSE diagnostics and structured transport parsing. Real-container validation and a live Codex integration were not run in this offline stage.

All 125 baseline production/evidence files remain byte-identical, including the historical 22-file hash inventory and observer sources. No Stage18c/19/19b artifact was rewritten. This preserves implementation and historical authority boundaries; passing regressions does not erase the newly characterized acceptance gaps.

## 8. Implementation, MIME and next evidence

Production changes: **none**. Added only this assessment, structured JSON, an offline proposal, tests and new Stage19c evidence. No corrected production invariant was adopted because captured evidence does not support one and SIWC stability questions remain unresolved.

MIME remains independently blocking. Even a future reviewed policy admitting missing MIME would still encounter the unchanged captured `Partial tool completion` failure.

Minimum next evidence: official clarification (or an authoritative SIWC conformance fixture) of cross-event item/call-ID stability, terminal function inventory completeness and argument-done shape; plus a secret-checked structural comparison of an already authorized captured lifecycle, if such evidence becomes available. Needed metadata: typed call counts, index consistency, item/call-ID equality flags, bijection flags, name stability, and argument equality/hash comparisons after secret rejection. The destroyed response cannot be reconstructed from its whole-body hash. A fixture establishes contract behavior, not the identity of the historical failure.

Another live smoke is **not currently justified as a fix-verification smoke**. No safe production correction has been proven, and MIME still blocks. No request is made or scheduled. If a later correction meets all promotion conditions, exactly one minimal live smoke would require separate authorization. This stage grants none.

Stage19 passed: **false**. Stage20 admissible: **false**. Live inference requests/OAuth refresh/account discovery/tool executions in this stage: **zero**. No OML, model benchmark, model/reasoning switch or multi-agent workflow occurred. Official documentation was fetched read-only.

Evidence: `docs/stage19c-evidence/adversarial-final.xml`, `offline-regression-final.xml`, `observer-regression.xml`, `baseline-hashes.json`, and the JSON assessment’s explicit observed/documented/derived/unknown separation.
