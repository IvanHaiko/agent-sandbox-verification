# Stage19g — Authorized live smoke

**FAIL_PROJECT_INTEGRITY: required tool call absent.** One authorized `stage19g-smoke-1` execution on `gpt-6-astra / low` started one Codex turn and sent one Responses request. HTTP 200 returned a normally completed, bounded SSE response, but it contained zero executable function calls. Mutation, verification and the required final accepted result were not reached. No retry or Stage20 execution occurred.

The initial preflight found expired credentials. After the user requested new credentials, official browser OAuth reconnection succeeded with full signature/identity verification. A fresh account catalog confirmed `gpt-6-astra / low`. Current-source signed transport admission and the Codex/Docker image/engine/config/project binding passed; 38 offline smoke-driver checks passed. A new exclusive latch and fresh execution/client-bound live and no-credit signatures used the actual human confirmation timestamp. Production source matched the accepted Stage19g proposal throughout.

| Observation | Result |
|---|---|
| Live Responses requests / HTTP statuses | 1 / 200 |
| Response bytes / EOF / reader shutdown | 20,627 / confirmed / confirmed |
| Upstream transport validation | Passed |
| Missing Content-Type | Recorded; continued |
| Non-executable stream/final inventory mismatch | Recorded; continued |
| Function calls / executed tools | 0 / 0 |
| Primary and disposable workspace | Unchanged |
| Credentials during smoke | Unchanged; no exposure observed |
| Codex process, disposable home, owned role storage | Cleaned up |
| Stale owned containers / automatic retries | 0 / 0 |

The exact smoke scope check requires a mutation call at the first step; it rejected the response because that call was absent. The executed driver calls this `FAIL_TOOL_BOUNDARY`, but the final assessment classifies the concrete outcome as project integrity / incomplete task. No dangerous executable capability was observed. Harmless protocol differences were tolerated, and strict non-executable lifecycle enforcement was not restored. Raw response, prose, arguments and provider identifiers were not persisted, so the reason the model produced no call is unknown.

- Stage19 passed: **false**.
- Stage20 technically admissible: **false**.
- Stage20 started: **false**.

The exclusive allowance is consumed. The smoke is finished; no further live attempt is scheduled.

Evidence: [execution](docs/stage19g-live-smoke-evidence/execution.json), [assessment](docs/stage19g-live-smoke-evidence/assessment.json), [admission](docs/stage19g-live-smoke-evidence/admission.xml), [driver checks](docs/stage19g-live-smoke-evidence/driver.xml), [catalog](docs/stage19g-live-smoke-evidence/catalog.json), [reconnection](docs/stage19g-live-smoke-evidence/reconnection.json).
