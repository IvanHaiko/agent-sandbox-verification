# Runner isolation capability matrix

`true` means the stated mechanism has evidence; `unknown` is not admission.
Stage 16 adds `docker_isolated`. Its entries below describe the tested Windows
host, Linux Docker engine and pinned image, after independent real probes. An
unvalidated installation or changed evidence binding remains unknown and rejected.
The existing `isolated_session` entries retain their historical limitations.

| Manifest capability | docker_isolated: available / verified | Real evidence |
| --- | --- | --- |
| `fresh_context` | true / true | New process/container; second execution cannot recover first execution's private markers |
| `filesystem_read` | true / true | Sibling, Controller, HOME, history, cache, temp, other-task and Windows bridge path probes find no private canary |
| `filesystem_write` | true / true | Forbidden host writes fail and host files remain unchanged; protected ignored data and private Git writes denied; allowed producer change exported |
| `session_storage` | true / true | Host history inaccessible; execution-local history/state disappears before next execution |
| `private_home` | true / true | HOME and USERPROFILE point to private tmpfs; host-home canary inaccessible |
| `private_cache` | true / true | Private cache path; global cache inaccessible; no cross-execution marker |
| `instruction_control` | true / true, filesystem scope | Parent/sibling/host HOME instruction canaries unavailable; only approved checkout/context exposed |
| `network_denied` | true / true | Loopback positive control succeeds; outbound connect fails with Linux ENETUNREACH; no outbound route |
| `isolated_checkout` | true / true | Private selected-commit ancestry; refs/log/reflog/cat-file/show cannot recover sibling objects or holdout commit |
| `readonly_mounts` (optional) | true / true | Actual read-only inspection and attempted writes to root/checkout/private Git/protected files |
| `environment` | true / true | Approved environment only; image Python imports local project from /workspace; outside origin rejected |
| `hidden_tests` | true / true | Direct path/bridge/search/Git probes and repaired Implementer cannot recover holdout source; phase programs segregated |
| `controller_storage` | true / true | Actual signing key and authoritative state read/write attempts fail; fake role decision creates no authority |

Evidence: [export manifest](stage16-17-evidence/real-probes/manifest.json),
[real-backend results](stage16-17-evidence/stage17-real-final.xml), and
[operation/reproduction](STAGE16_17_RUNBOOK.md). Each of 13 cases independently
bootstrapped real probes; no synthetic capability fixture granted Docker admission.
Twelve capabilities are mandatory; read-only mounts remain optional. The Controller
checks HMAC, evidence hashes, project, settings, implementation, engine and image
identity before admission. Exported signatures are historical evidence; copied
exports without their private Controller key cannot admit a different project.

There are no false/unknown entries in the tested Docker OS/process manifest.
Actual agent conversation behavior, auto-instruction loading, credentials, model
transport/protocol and other engines/images/platforms remain **unknown**. Fresh
process and inaccessible instruction files prove OS prerequisites, not live agent
behavior. No real model call was made. See the separate Stage 16–17 assessment.

| Capability | Built-in isolated_session | Deterministic offline harness |
| --- | --- | --- |
| Fresh role conversation | true: new `exec`, no resume, `--ephemeral` | Separate structured calls; synthetic protocol fixture |
| Git isolation | Controller private checkouts verified locally; this backend admits registered shared worktrees only (isolated checkout unavailable) | Private Implementer/Tester object databases exercised end to end |
| Filesystem read isolation | false: no portable OS read barrier | **Not verified**; simulated admission only |
| Filesystem write isolation | unknown: real CLI sandbox behavior unverified | **Not verified**; fixed scripted actions, mutation detectors tested |
| Session/log isolation | unknown: global session/history exposure unverified | **Not verified** for arbitrary processes |
| Private home | unknown | **Not verified** |
| Private runner cache | unknown | **Not verified** |
| Repository auto-instruction control | unknown | No LLM instruction loader; not real backend evidence |
| Network denied | unknown: CLI flag requests denial, enforcement unverified | No model/network calls made; not a network-sandbox probe |
| Role-local Python environment | Controller `.venv` and import-origin checks tested; backend-level protection unknown | Local environment and integrated-candidate provenance exercised |
| Hidden-test secrecy | false with common filesystem; ordinary Git disclosure separately prevented | Git and feedback separation tested; **not OS secrecy evidence** |
| Controller storage inaccessible to roles | false with common operating-system user | HMAC forgery/replay rejection tested; **not OS key isolation evidence** |
| Read-only mounts | unknown | **Not verified** |
| Admission for hardened workflow | **Rejected before any role/model invocation** | Synthetic verified capability fixtures test controller branches only |

Every runner exposes `IsolationCapabilities.manifest()`: each capability records
`required`, `available` (`true`/`false`/`null`), `verified`, and an evidence reference.
`require()` admits only required entries with `available=true`, `verified=true`,
and a nonempty evidence reference. Read-only mounting is an optional capability;
all other listed capabilities are mandatory for hardened role admission. There
is no fallback or configurable silent downgrade.

The historical offline Pilot 0 deliberately demonstrates that an unmanaged process can read synthetic
sibling/controller/session files. The corresponding required-isolation backend
invocation is rejected. This verifies the fail-closed boundary, not successful
filesystem isolation. Stage 17 separately exercises all ten scenarios through the
real Docker boundary and adds timeout, overflow and stale-lifecycle tests.

The boundary applies to role processes **and** generated test/audit/import
programs through `AgentRunner.run_command`; the base method rejects execution.
Filesystem write verification must include denial of role writes to controller
storage and Git configuration/hooks/metadata outside permitted project files.
Filesystem read verification must exclude sibling checkouts, holdouts, controller
state, home/history/cache and auto-loaded instructions not explicitly approved.
Declarations without real enforcement/probe evidence must remain unverified.
