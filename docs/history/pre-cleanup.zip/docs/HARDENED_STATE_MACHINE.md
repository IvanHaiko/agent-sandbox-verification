# Version-3 workflow

Only implemented states are shown. States v1/v2 keep their existing transition
graphs and repair-cycle semantics.

```mermaid
flowchart TD
  NEW --> CLASSIFY --> CONTRACT_READY
  CONTRACT_READY -->|major_phase| CONTRACT_APPROVAL
  CONTRACT_READY -->|ordinary| INTERFACE_FREEZE
  CONTRACT_APPROVAL -->|signed human approval| INTERFACE_FREEZE
  INTERFACE_FREEZE --> ARCHITECTURE_CHECK
  ARCHITECTURE_CHECK --> WORKTREES_READY
  ARCHITECTURE_CHECK --> ARCHITECTURE_DECISION_REQUIRED
  ARCHITECTURE_DECISION_REQUIRED -->|signed human selection| ARCHITECTURE_APPROVED
  ARCHITECTURE_APPROVED -->|stored resume state| WORKTREES_READY
  WORKTREES_READY --> TEST_DESIGN --> TEST_DESIGN_FROZEN
  TEST_DESIGN_FROZEN -->|execute test_implementation, sign test commit| IMPLEMENTING
  IMPLEMENTING --> IMPLEMENTATION_READY
  IMPLEMENTING -->|architecture_required or ARCH_BLOCKED| ARCHITECTURE_DECISION_REQUIRED
  IMPLEMENTATION_READY -->|actual diff detector| ARCHITECTURE_DECISION_REQUIRED
  ARCHITECTURE_APPROVED -->|approved exact diff| IMPLEMENTATION_READY
  ARCHITECTURE_APPROVED -->|human stop| ESCALATION_REQUIRED
  IMPLEMENTATION_READY -->|no unresolved drift| TESTING
  TESTING -->|merge candidate into frozen tests| INTEGRATING --> INTEGRATED
  INTEGRATED --> EXECUTING_TESTS
  EXECUTING_TESTS --> TESTS_PASSED
  EXECUTING_TESTS --> TESTS_FAILED
  TESTS_FAILED -->|structured contractual evidence| TEST_DISPUTE
  TEST_DISPUTE -->|bounded authorized correction, review, new freeze| TESTING
  TESTS_FAILED -->|implementation failure| REVIEWING
  TESTS_PASSED --> REVIEWING
  REVIEWING -->|passes A and B| REVIEW_PASSED
  REVIEWING --> REVIEW_FAILED
  REVIEWING -->|architecture issue| ARCHITECTURE_DECISION_REQUIRED
  REVIEWING -->|structured contractual inconsistency| TEST_DISPUTE
  REVIEW_PASSED -->|data critical| AUDITING
  REVIEW_FAILED -->|data critical| AUDITING
  REVIEW_PASSED -->|audit not required| GATE_DECISION
  REVIEW_FAILED -->|audit not required| GATE_DECISION
  AUDITING --> AUDIT_PASSED --> GATE_DECISION
  AUDITING --> AUDIT_FAILED --> GATE_DECISION
  AUDITING -->|architecture issue| ARCHITECTURE_DECISION_REQUIRED
  GATE_DECISION -->|all mandatory evidence passed| COMPLETION_CANDIDATE
  GATE_DECISION -->|repair capacity remains| FIX_REQUIRED --> FIXING
  FIXING --> IMPLEMENTATION_READY
  FIXING -->|architecture issue| ARCHITECTURE_DECISION_REQUIRED
  GATE_DECISION -->|two repair cycles exhausted| ESCALATION_REQUIRED
  COMPLETION_CANDIDATE -->|human completion required| USER_COMPLETION_APPROVAL
  COMPLETION_CANDIDATE -->|ordinary task| ACCEPTED
  USER_COMPLETION_APPROVAL -->|signed human approval| ACCEPTED
```

Architecture selections may also resume an interrupted `IMPLEMENTING`, `FIXING`,
`REVIEWING` or `AUDITING` state. Every nonterminal stage can fail to `FAILED` on
missing evidence, integrity errors, policy violations or infrastructure failures.
Capability admission failures cannot consume model quota or trigger a weaker backend.

`TEST_DISPUTE` is a stop point; failing tests alone do not prove a test defect.
Explicit interface equality contradictions and malformed Python tests are detected
mechanically. A controller evidence request can also identify an unapproved assumption.
Disputes are bounded separately (configured maximum one or two); `fix_cycle` does
not increment. Correction review is read-only. The replacement test commit and
mapping are recorded under a new `test_version`, preserving earlier test evidence.

Reviewer may return a structured `test_dispute` with reason, contract clause,
evidence and whether semantics must change. Purely contractual resolution against
the same approved version can proceed without human intervention; the controller
records the Reviewer evidence, checks allowed correction shapes, and requires a
fresh read-only correction review before signing the new tests. Semantic-change
requests remain at the human stop point and require a new versioned task.

Material semantic changes do not modify the existing task: create a new task ID
and increment `contract_version`. Both roles receive the same approved interface
baseline/version. Integration rejects missing or mismatched report versions.
