# Stage19g — Final smoke assessment

**Stage19 passed: false. Stage20 technically admissible: false. Stage20 started: false.** The complete live path through mutation, verification, final structured result and acceptance has not succeeded. Every additional live execution below was explicitly authorized and consumed once, with `gpt-6-astra / low` and zero automatic retries.

| Execution | Observed outcome |
|---|---|
| stage19g-smoke-3 | HTTP 200; 5,122 bytes; incomplete body; zero tools. Specific socket failure was not retained. |
| stage19g-smoke-4 | HTTP 200; 63,851 bytes; transport passed; completed stream function absent from final summary was observed and tolerated; exact smoke argument check rejected the call; zero tools. |
| stage19g-smoke-5 | HTTP 200; 54,234 bytes; transport passed; only argv differed from the exact template; zero tools. Actual argument values were not retained. |
| stage19g-smoke-6 | HTTP 400 for the request containing full-array argv const; zero tools. Error details were unavailable/suppressed, so the particular failed API/schema rule is unknown. |

The real protocol cause is established: the provider sends a completed function in `response.output_item.done` and omits it from `response.completed.output`. Production now accepts that fully validated completed snapshot when the response completes normally. All available executable identities and argument snapshots must agree; incomplete fragments, explicit incomplete status, unknown tools, wrong namespace/identity, resource violations and replay still block. No strict non-executable lifecycle/bijection requirement was restored. This uses completed-item semantics from the [official Responses streaming documentation](https://developers.openai.com/api/reference/resources/responses/streaming-events).

The HTTP reader now allows a 15-second socket idle interval within the unchanged 60-second whole-body deadline and 1 MiB/read limits. Codex allows 65 seconds for the buffered relay. Cancellation and owned-reader shutdown checks remain. A real socket test passed with a 5.2-second pause. Finite failure codes and fixed validator refusal reasons are recorded without payloads. The exact cause of smoke-3's incomplete read cannot be reconstructed from its older compact metadata.

A second, separate failure is now specific: smoke-5's executable argv differed; all other fields matched. Its schema restricted individual strings and length but did not fix the complete argv array. Smoke-6 fixed the entire array as a typed const. That request received HTTP 400. The changed schema is a plausible cause, but the retained error has no type, code or parameter, so unsupported array const is not an established diagnosis. The provider's exact argv behavior and live support for a suitable positional schema remain unresolved. The Controller did not substitute commands or execute mismatched arguments to manufacture success.

199 guards and two real Codex/Docker tests passed with current-source signed transport admission. These included two exact commands, tool results, structured result and acceptance while completed stream calls were omitted from final summaries. Each later prepared schema also passed 42 driver checks plus one real Codex/Docker synthetic roundtrip. Synthetic success did not establish provider compatibility. Schema constraints were checked against the [official Structured Outputs documentation](https://developers.openai.com/api/docs/guides/structured-outputs); specific array-const support remained unproven before smoke-6.

Before each live run, current source/runtime/Codex/Docker bindings, protected valid ChatGPT-plan credentials and model catalog eligibility were checked. Fresh execution/client-bound signed live and no-credit authorizations and exclusive latches were used. The original explicit human billing confirmation timestamp was retained. No alternate model/reasoning, role capability, host execution or role network access was added.

Each run confirmed unchanged primary/framework state and credentials, no credential exposure or unauthorized capability exercised, stopped Codex, removed disposable Codex home/role storage and zero stale owned containers. Raw arguments, provider payloads, IDs and model prose were not persisted. All live authorizations are consumed; no further execution is scheduled.

Evidence: [smoke-3](docs/stage19g-smoke-3-evidence/assessment.json), [smoke-4](docs/stage19g-smoke-4-evidence/assessment.json), [smoke-5](docs/stage19g-smoke-5-evidence/assessment.json), [smoke-6](docs/stage19g-smoke-6-evidence/assessment.json), [current-source admission and real roundtrip](docs/stage19g-smoke-4-evidence/admission-roundtrip.xml), [guards](docs/stage19g-smoke-4-evidence/guards.xml).
