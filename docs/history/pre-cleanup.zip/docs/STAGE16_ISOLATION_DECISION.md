# Stage 16: OS isolation decision

Date: 2026-10-05. State: implemented; real OS validation passed (13/13).
Historical status `HARDENING_OFFLINE_ACCEPTED_WITH_LIMITATIONS` is preserved.
Final regression and completion status are recorded in the separate Stage 16–17
assessment. The exploration below precedes implementation; execution findings
at the end record what was actually tested.

## Operating constraint

The user is working on this computer. Obtain explicit permission before starting
Docker Desktop, containers, WSL distributions, servers, or other execution
environments. Inspection and source editing may continue without starting them.
Permission to choose an architecture is separate from permission to start its runtime.

## Inspected implementation

- `agent_system/runners/base.py`: role execution and generated-command boundary;
  default `run_command` rejects execution without an adapter.
- `runners/isolated_session.py`: fresh CLI calls, shared-worktree admission,
  persisted workflow checks, context construction, policy checks and telemetry.
- `isolation.py` and `schemas/isolation.schema.json`: required/available/verified/
  evidence distinctions; private bundle-based Git checkout; local environments;
  hardened import commands already route through the runner.
- `hardened_workflow.py`: capability admission precedes role calls; Controller
  approvals, frozen interfaces/tests, repair/dispute and architecture gates.
- `git.py` and `integration.py`: ownership manifests and producer integration;
  Implementer/Tester have private object databases, other worktrees still share
  primary Git metadata. The new runner must not mount that shared metadata.
- `config.py`: external runtime v2 separates repository, runs and checkouts.
- `gates.py`, `mechanical_gates.py`: hardened test and Auditor programs call
  `run_command`; `role_command` currently prepares host-specific venv paths and
  inherited environment. A Linux adapter must replace those deliberately.
- `independent_tests.py`: Controller-owned frozen identities, hidden feedback and
  bounded contractual correction. Holdout objects must stay out of Implementer Git.
- `contexts.py`, `storage.py`, `schemas/project.schema.json`, `cli.py`: explicit
  role context, safe relative paths, strict backend configuration and CLI errors.
- `tests/test_pilot0.py`: ten offline scenarios; current filesystem gap is
  deliberately demonstrated. They are not real backend verification.
- Historical assessment records 203 passing unique cases; no new suite was run
  during this inspection. This workspace itself has no Git repository metadata.

## Passive platform findings

`docker.exe` exists at `C:\Program Files\Docker\Docker\resources\bin\docker.exe`.
`wsl.exe` exists. `podman` was not found through command discovery.
The Docker Windows service was stopped; no Docker Desktop/backend process was
found by the process-name inspection. WslService was running; distributions,
engine availability, Linux-container mode and images were not queried or started.
Executable presence is not evidence of a usable engine or an isolation boundary.

## Options

All entries below describe design feasibility, not verified host capabilities.

| Boundary / cost | A: Docker Desktop, Linux containers | B: dedicated WSL2 distribution |
| --- | --- | --- |
| Filesystem reads | Explicit mounts and private container filesystem; test host bridges | Must disable drive automount, interop and other host bridges; ordinary WSL is insufficient |
| Filesystem writes | Read-only root and inputs; explicit writable role areas | Dedicated filesystem plus enforced permissions; stronger setup and auditing needed |
| Git | Private objects/refs only; shared `.git` forbidden | Same private Git requirement; distribution alone does not supply it |
| HOME | Fresh per-execution private directory | Must create and restrict per-role users/homes |
| Session/history | Fresh process and private local storage | Must isolate users/storage and process visibility |
| Cache | Private per-execution directories | Must isolate caches explicitly |
| Network | Select isolated network namespace; probe outbound attempts | Needs separately enforced per-role networking; WSL defaults insufficient |
| Controller secrets | Never mount Controller state or signing keys | Requires verified exclusion of Windows bridges and Controller paths |
| Holdout | Never mount Tester state in Implementer; exclude test Git objects | Requires explicit role filesystem and Git separation |
| Read-only inputs | Read-only mount configuration plus mutation probes | Permissions/mount enforcement must be managed and probed |
| Portability | Linux engine support; Windows requires Docker Desktop with supported backend | Windows specific |
| Cleanup | Exact owned container IDs/labels, bounded removal | Distribution/user lifecycle more invasive; must never unregister unrelated distributions |
| Performance | Startup overhead and Windows file mapping costs must be measured | Warm distribution may reduce startup cost; isolation setup remains |
| Complexity | Mature per-execution primitive and existing installed CLI | Additional OS administration and custom boundary composition |

Choose **A**, backend name `docker_isolated`, subject to permission to inspect and
exercise the engine. Do not install a replacement engine or change global WSL,
Docker or Windows settings automatically if preflight fails. B is not a fallback.

Docker's documented flags describe the intended mechanism, not proof that it is
enforced on this host. Ordinary WSL exposes integration features that require
additional restriction; it is not an isolated runner by itself.
Sources: [Docker run reference](https://docs.docker.com/reference/cli/docker/container/run/),
[Docker security](https://docs.docker.com/engine/security/),
[WSL configuration](https://learn.microsoft.com/en-us/windows/wsl/wsl-config).

## Planned trust and execution boundary

Trust the Controller, operator configuration, pinned reviewed runtime image and
container engine. Do not trust role programs, project tests or generated scripts.
Every role/test/collection/import/audit/package/repair command must use the new
runner. No generated code may fall back to a host subprocess.

The initial offline design uses a non-root process, no extra capabilities, no new
privileges, a read-only image, private process/network namespaces, no published
ports, no devices, no Docker socket, no host networking and bounded CPU/memory/
process/output/time limits. Runtime image acquisition/build is separate from
network-denied role execution and requires permission to start the environment.

Only a role-owned checkout with private Git and explicitly approved inputs is
visible. Immutable inputs and protected data use read-only mounts; scratch, HOME,
cache and temp are private. Never mount the host HOME, runtime parent, Controller,
sibling checkout, primary `.git`, shared caches or global runner history.
Reject symlinks/junctions/reparse points and Git alternates or external metadata
that could defeat the mount allowlist. Handle Windows paths as argv, including
spaces; never translate arbitrary host arguments by substring replacement.

Controller-owned host venvs are not executable Linux environments. Provide the
role toolchain within the reviewed image and resolve commands/import origins in
the container. Forward only approved environment values, not host PATH, secrets,
HOME, Python paths or agent configuration.

No credentials or model calls are needed in Stages 16–17. Live authentication,
agent instruction-loader behavior and model protocol compatibility remain
unverified until a later authorized live validation. Test filesystem prerequisites
for instruction isolation now; do not conflate them with real agent loading.

Create a unique execution identity and persist ownership intent before launch.
Clean up the exact owned container after success, failure and timeout; detect
stale executions without deleting unrelated containers, volumes or images. Keep
bounded Controller evidence, destroy disposable writable state, and fail visibly
when cleanup cannot be confirmed. Never issue global prune or WSL shutdown.

## Validation and evidence requirements

First run independent real probes, retaining enforcement configuration, actual
argv/results, canary identities, engine/image identity and Controller-owned
machine-readable evidence. Admission remains rejected until each mandatory
capability has successful applicable evidence; flags and mocked subprocess tests
cannot set `verified=true`. Bind evidence to the tested backend configuration and
image. Preserve historical assessments and create a new conservative assessment.

Probe forbidden reads/writes, HOME/history/cache/temp, Controller keys/state,
holdouts, parent/sibling traversal, canary instruction discovery, Git refs/reflogs/
objects/unknown commits, protected ignored data, imports, read-only inputs and
outbound connections. A failed outbound connection alone is insufficient when the
destination might be unavailable; include a valid positive control and network
namespace observations. Test timeout/failure/stale cleanup and Windows path cases.

Adapt all ten existing Pilot 0 scenarios so relevant role actions actually cross
the real runner. Retain deterministic gates, dispute repair accounting, Auditor
regeneration and sanitized feedback; add direct isolation probes beyond ten.
Run focused Stage 16/17 checks, existing Pilot 0 and complete regression. Do not
claim success or readiness for live validation before real backend evidence and
regression pass.

## Original permission-dependent first step

With user permission, start Docker Desktop if necessary and perform bounded
engine/image preflight followed by one disposable offline feasibility container.
Target initial probe limit: one container at a time, 1 CPU, 512 MiB memory, no
published ports, no model calls and no global settings/resource cleanup. Docker
Desktop's VM itself may consume resources beyond the container limit. Confirm
whether a suitable local image exists before requesting any image download/build.
Do not launch the full regression workload as part of this feasibility check.

## Execution findings

The user authorized startup/probes, then full regression. Docker Desktop's existing
Linux engine was usable: Engine 29.7.2, WSL2 kernel
6.6.87.2-microsoft-standard-WSL2. The already-local pinned Airflow image supplied
Python 3.12.11 and Git; no image pull/build was performed. All our containers ran
sequentially with 1 CPU and 512 MiB limits. Docker/WSL VM working set was observed
around 6.2 GiB; the user explicitly authorized continuing its current configuration
and identified an older container as theirs. No unrelated container was stopped,
no global VM memory setting changed, and no global cleanup was issued.

The implemented adapter copies each owned role checkout into disposable staging,
creates a private Git object database from selected commit ancestry, mounts only
that staging tree, and destroys writable staging after validated export. Controller
state remains host-side. Read-only command runs protect the entire tree; producer
runs additionally mount Git and existing protected inputs read-only and enforce
scope before export. HOME/cache/history/temp are private tmpfs. Environment is
explicit, root is read-only, network is denied, UID is non-root, capabilities are
dropped, and no host socket/device/port is exposed. The JSON-stdin role-driver
interface has no credential injection or live model transport in this stage.

Real Pilot 0 passed 10/10; direct lifecycle cases passed 3/3. Independent probes
verified all 13 modeled OS/process capabilities, including actual key exclusion,
host bridge paths, holdout objects and real network-denial behavior. Admission
binds signed evidence to engine/image/settings/implementation/project identity.
Implementation changes during exploratory validation correctly invalidated frozen
admission evidence; the final run used unchanged production code throughout.

Windows required per-command Git long-path support, private-pack read-only cleanup,
exact argv path mapping and Linux errno interpretation. No global Git setting was
changed. Cleanup uses exact IDs plus ownership labels, verified bounded directory
targets and timed helper processes. Timeout, failure, output overflow and stopped
owned stale-container disposal have actual evidence.

The engine/kernel, Controller/operator and immutable image remain trusted.
This is no proof against kernel/daemon exploits. A writable Windows staging bind
has no independent disk quota; memory/CPU/PIDs/output/time are bounded. Live CLI
conversation/loading/authentication/protocol remain unverified. Linux-host engines
and other images/configurations need their own probes before admission. See the
[runbook](STAGE16_17_RUNBOOK.md) and [capability matrix](ISOLATION_CAPABILITIES.md).

## Deferred

Live agents/credentials, OML, model benchmarking/routing, remote execution,
distributed orchestration and unrelated framework changes.
