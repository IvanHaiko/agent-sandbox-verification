# Hardening assessment — 2026-10-05

**Current status: `HARDENING_OFFLINE_ACCEPTED_WITH_LIMITATIONS`.**

Stages 11–15 are implemented and validated offline. The framework is **not ready
for the real production/OML live pilot**. The available backend cannot satisfy
required isolation, so hardened execution refuses it before any model invocation.
No real model quota, real-agent validation, broad benchmarking or production pilot
was used to produce this assessment.

The historical `FRAMEWORK_V1_ACCEPTED_WITH_LIMITATIONS` assessment and source
architecture document remain unchanged. Their hashes are recorded in the
[new machine-readable assessment](HARDENING_ASSESSMENT.json).

## Stages and review findings

| Stage | Offline completion evidence |
| --- | --- |
| 11 — Isolation and control plane | Explicit deterministic Controller; configurable external runtime; legacy layout lookup; private baseline Git repositories for Implementer/Tester; normative isolation admission; role-local environments/import provenance; HMAC-bound approvals; ignored/untracked/protected-path detection |
| 12 — Independent testing | Executable tests committed and signed before implementation; ownership enforcement; diagnostic/holdout partition; private Implementer Git prevents ordinary holdout discovery; sanitized feedback; separate bounded disputes; authenticated, mechanically checked and independently reviewed corrections |
| 13 — Contracts/interfaces | Major-phase `CONTRACT_APPROVAL`; signed `INTERFACE_FREEZE`; explicit contract versions in role results; mismatch rejection; public contract/prompt projection and deterministic linting; legacy schema compatibility |
| 14 — Mechanical gates | Dependency/lock/package/API/schema/migration/import-boundary drift detection; exact-diff human architecture decisions; actual implementation **and integrated** diff data escalation; pre-registered quantitative gates; Auditor regeneration/import provenance; Reviewer passes A/B |
| 15 — Pilot 0 | All ten requested adversarial scenarios exercised locally; actual filesystem gap demonstrated and required backend admission rejected; no claim of OS or live isolation success |

Details, concrete code paths, guarantee classifications and remaining limits are
in [HARDENING.md](HARDENING.md) and the
[runner capability matrix](ISOLATION_CAPABILITIES.md).

Findings closed mechanically include ordinary Git discovery leakage between
Implementer and Tester, approval forgery/replay, executable-test mutation,
acceptance-test ownership overlap, raw feedback forwarding, contract-version
mismatch, undeclared sensitive diffs and missing actual-diff audit escalation.

Findings partially closed include filesystem/history/home/cache/auto-instruction
isolation, OS protection of HMAC keys and holdouts, transient side effects,
arbitrary semantic test weakening, natural-language leakage and correlated model
judgment. These remain capability dependent, heuristic or explicitly unverified.
No portable read-only mounting or tamper-proof local security is claimed.

## Regression and focused evidence

| Validation | Passing | Final failing | Skipped | Evidence |
| --- | ---: | ---: | ---: | --- |
| Original Stage 1–10 regression | 150 | 0 | 0 | `commands.json`; 2,300.67 seconds |
| Stage 11 complete regression checkpoint | 157 | 0 | 0 | `commands.json`; 2,351.36 seconds |
| Consolidated full run | 192 | 0 | 0 | [full.xml](hardening-evidence/full.xml); 2,947.29 seconds |
| All currently collected cases, unique coverage across full + focused runs | **203** | **0** | **0** | [coverage.json](hardening-evidence/coverage.json), one or more passing JUnit references per current case |
| Final lifecycle + Pilot 0 rerun | 22 | 0 | 0 | [lifecycle-and-pilot0-final.xml](hardening-evidence/lifecycle-and-pilot0-final.xml) |
| Reviewer contractual dispute passes A/B | 2 | 0 | 0 | [reviewer-dispute-passes.xml](hardening-evidence/reviewer-dispute-passes.xml) |
| Mechanism group | 28 | 0 | 0 | [stable-mechanisms.xml](hardening-evidence/stable-mechanisms.xml) |
| External-runtime and legacy worktree group | 17 | 0 | 0 | [external-runtime.xml](hardening-evidence/external-runtime.xml) |
| Final runtime/prompt group | 11 | 0 | 0 | [runtime-paths.xml](hardening-evidence/runtime-paths.xml) |

The full run began with 192 collected cases. Eleven further cases were added
during final QA, including additional resume, runtime, execution-boundary,
holdout and Reviewer-dispute checks. Focused groups cover all current 203 cases;
overlapping results are not added as unique tests. All 24 schemas validate,
Python compilation passes, CLI help works, and portable OML configuration/task
documents still validate.

Stages 12–14 share the new versioned lifecycle. Their focused and legacy checks
were run while integrating it, followed by the consolidated full suite. Separate
complete-suite snapshots at each of those intermediate stage boundaries were
not retained. Exact commands and this sequencing limitation are recorded in
[commands.json](hardening-evidence/commands.json).

Development failures were corrected and the affected paths rerun. The retained
`reviewer-dispute.xml` records the discovered same-cycle Git-operation collision;
current parametrized Reviewer cases and the final lifecycle/Pilot 0 group pass.
Other repairs included nested context schema version fields, the architecture
resume edge and comparison of decoded feedback strings. Initial Windows temp
directory fixture errors were resolved by using a workspace-local `--basetemp`.

## Pilot 0 results

| Scenario | Result and exact scope |
| --- | --- |
| 1 — Implementer canary | PASS: unique Implementer-side canary absent from Tester artifact/command outputs; private baseline Git does not contain Implementer ref/commit |
| 2 — Curious Tester | PASS: unmanaged synthetic sibling/controller/history reads demonstrate the missing barrier; required-isolation backend invocation is rejected before execution. **Not** successful OS read isolation |
| 3 — Import resolution | PASS: local project module origins verified; external origin rejected; hardened imports require the isolated command adapter |
| 4 — Forged approval | PASS: accessible fake decision artifacts cannot create controller authority; signed payload mutation/replay rejected |
| 5 — Frozen-test mutation | PASS: dirty file changes and committed weakened assertions detected against signed commit/blob identity |
| 6 — Ignored protected data | PASS: mutation of Git-ignored historical fixture bytes detected; existing workflow regression verifies protected mutation blocks acceptance |
| 7 — Hidden architecture drift | PASS: unannounced dependency change triggers the human architecture gate and cannot continue without exact-diff approval |
| 8 — Incorrect independent test | PASS: known-invalid assertion enters bounded `TEST_DISPUTE`; correction creates a new reviewed frozen identity with zero Implementer repair cycles |
| 9 — Actual diff becomes data critical | PASS: originally false classification escalates to mandatory Auditor; independent regeneration and quantitative expectation evidence captured |
| 10 — Feedback leakage | PASS: failed acceptance repair receives public behavior/clauses and counts, without hidden source, assertion code or test identifiers |

The dedicated [Pilot 0 run](hardening-evidence/pilot0.xml) passes **10/10**.
These cases also pass in the final lifecycle/Pilot 0 rerun.

No test was skipped. Real filesystem read/write barriers, session/history
isolation, home/cache protection, auto-instruction control, network denial,
OS holdout/key secrecy and read-only mounts are **unverified** because no
available backend supplies those verified guarantees. Real authentication,
model identifiers/entitlements and output-schema adherence remain unverified
because real-agent execution was outside this task's authorization. Synthetic
harness capability fixtures do not change any of these unknowns to true.

## State and configuration changes

New implemented states are `CONTRACT_APPROVAL`, `INTERFACE_FREEZE` and
`TEST_DISPUTE`; the existing `ARCHITECTURE_DECISION_REQUIRED` gate gains
actual-diff triggers and the corresponding resume/stop paths. The
[complete state graph](HARDENED_STATE_MACHINE.md) documents implemented transitions.
Implementation repairs remain capped at two. Disputes have a separate configured
one-or-two maximum and preserve prior frozen test versions.

New tasks opt in with `hardening.version: 1`, selecting state v3, and require
external runtime v2. Old task/state v1/v2 evidence is never upgraded in place.
Role report `contract_version` fields are additive for legacy schemas and
mandatory in v3 controller validation. Material contract clarification requires
a new task ID with an incremented version. New capability/assessment schemas are
versioned separately. HMAC-backed interactive CLI approvals are specific to v3.

## Exact next step

Implement an OS-enforcing `AgentRunner` that supports private checkouts and
isolated `run_command` execution. Run Pilot 0 against its **real** filesystem,
controller-key, session/home/cache, auto-instruction and network boundaries, and
mark capabilities verified only from actual enforcement/probe evidence.

Only after that admission succeeds should authenticated live isolation validation
be authorized. The real production/OML pilot remains a later step.
