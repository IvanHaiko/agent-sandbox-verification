"""One explicitly authorized existing OAuth refresh, no reconnect or inference."""
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT/'validation'))
sys.path.insert(0, str(ROOT/'.test-tmp/stage18-oauth-deps'))
from agent_system.chatgpt_oauth import (CredentialStore, ChatGPTPlanOAuth, AuthError,
    PLAN_SCOPE, TOKEN, DISCOVERY, JWKS)
from agent_system.errors import AgentSystemError
from stage19_final_smoke_retry import validate_authorization_receipt, sha, load


def main():
    if sys.argv[1:] != ['--execute-one-authorized-refresh']:
        raise AgentSystemError('Explicit one-refresh entry point required')
    with (OUT/'oauth-refresh-latch').open('x', encoding='utf-8') as stream:
        stream.write('One human-authorized OAuth refresh attempt consumed. No retry or reconnect.\n')
        stream.flush(); os.fsync(stream.fileno())
    result = {'refresh_attempts': 0, 'success': False, 'smoke_started': False, 'inference_requests': 0,
              'reconnections': 0, 'automatic_retries': 0, 'oauth_http_counts': {},
              'raw_credentials_exported': False}
    store = None
    try:
        # Import only the already installed crypto runtime, never install anything.
        import jwt
        import cryptography
        receipt = load(OUT/'authorization.json')
        validate_authorization_receipt(receipt, sha(ROOT/'docs/stage19d-evidence/final-smoke-proposal.json'),
            sha(OUT/'prepared-scope.json'), time.time())
        permission = load(OUT/'refresh-authorization.json')
        if permission != {'authorized': True, 'attempts_max': 1, 'reconnect': False,
            'inference': False, 'execution_id': 'stage19-final-conformance-2',
            'human_authorization_at': receipt['human_billing_confirmation_at']}:
            raise AgentSystemError('Exact human refresh authorization required')
        directory = Path('C:/Users/4ivan/.agentctl/stage19-oauth')
        if not directory.is_dir(): raise AgentSystemError('Existing OAuth storage required')
        store = CredentialStore(directory, [ROOT])
        previous = store.read('credentials.json')
        if not previous: raise AgentSystemError('Existing refresh credentials required')
        oauth = ChatGPTPlanOAuth(store)
        request = oauth.http.request
        def observed_request(method, url, form=None):
            category = {(TOKEN, 'POST'): 'token_refresh', (DISCOVERY, 'GET'): 'issuer_discovery',
                        (JWKS, 'GET'): 'signature_keys'}.get((url, method))
            if category is None: raise AgentSystemError('Unexpected OAuth refresh route')
            result['oauth_http_counts'][category] = result['oauth_http_counts'].get(category, 0)+1
            return request(method, url, form)
        oauth.http.request = observed_request
        result['refresh_attempts'] = 1
        (OUT/'oauth-refresh-result.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
        status = oauth.refresh()  # EXACTLY ONE call; original verifier and terminal clearing behavior
        current = store.read('credentials.json')
        result.update(existing_client_match=bool(current and current['client_id'] == previous['client_id']),
            existing_account_match=bool(current and current['subject'] == previous['subject']),
            strict_oidc_verifier_used=True, plan_scope_present=bool(current and PLAN_SCOPE in current['scopes']),
            valid_for_smoke=bool(current and current['expires_at']-time.time() > 180),
            access_token_expired=status['access_token_expired'])
        result['success'] = all(result[k] for k in ('existing_client_match', 'existing_account_match', 'plan_scope_present', 'valid_for_smoke'))
    except AuthError as error:
        result.update(safe_error_code=error.code, oauth_http_status=error.status)
    except AgentSystemError as error:
        allowed = {'ChatGPT ID token verification failed', 'OAuth account identity mismatch',
            'Malformed ChatGPT OAuth token response', 'Exact human refresh authorization required',
            'Existing OAuth storage required', 'Existing refresh credentials required', 'Unexpected OAuth refresh route'}
        result['safe_failure_reason'] = str(error) if str(error) in allowed else 'OAuth refresh or protected storage rejected'
    except BaseException:
        result['safe_failure_reason'] = 'Local refresh preparation failed; arbitrary exception suppressed'
    finally:
        if store:
            try: result['credentials_present_after_attempt'] = store.read('credentials.json') is not None
            except BaseException: result['credential_status_after_attempt_unavailable'] = True
        (OUT/'oauth-refresh-result.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result, indent=2))
    return 0 if result['success'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
