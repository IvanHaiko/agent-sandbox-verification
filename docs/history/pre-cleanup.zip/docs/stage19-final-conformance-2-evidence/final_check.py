"""Independent read-only check of the completed attempt; no grants or inference."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from agent_system.approvals import ApprovalStore
from agent_system.chatgpt_oauth import CredentialStore
from agent_system.config import Configuration
from agent_system.runners.tool_docker import ToolDockerRunner


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


admission = load(ROOT/'docs/stage19d-evidence/fresh-admission.json')
execution = load(OUT/'execution.json')
receipt = load(OUT/'authorization.json')
config = Configuration.load(Path(admission['project']))
runner = ToolDockerRunner(config)
assert runner.preflight() == admission['binding']
runner.require_transport_admission()
workspace = Path(admission['workspace'])
identity = {'execution_id': 'stage19-final-conformance-2', 'task_id': 'STAGE19-SMOKE',
    'role': 'implementer', 'phase': 'implementation', 'contract_version': 1,
    'workspace_id': hashlib.sha256(str(workspace.resolve()).encode()).hexdigest()}
binding = {'transport': admission['binding'], 'source_bundle': admission['source_bundle_sha256'],
    'driver': execution['driver_source_sha256'],
    'proposal': sha(ROOT/'docs/stage19d-evidence/final-smoke-proposal.json'),
    'human_authorization': sha(OUT/'authorization.json'), 'execution': identity,
    'model': 'gpt-6-sol', 'reasoning': 'low'}
approvals = ApprovalStore(config.runtime_root/'stage19-final-conformance-2-approvals', binding)
live = approvals.verify('live-smoke/stage19-final-conformance-2')
assert live == {'authorized': True, **identity, 'model': 'gpt-6-sol', 'reasoning': 'low',
                'route': 'https://api.openai.com/v1/responses'}
credits = approvals.verify('no-credits/stage19-final-conformance-2')
credentials = CredentialStore(Path('C:/Users/4ivan/.agentctl/stage19-oauth'), [ROOT, config.root, config.worktrees_dir]).read('credentials.json')
assert credits['client_id'] == credentials['client_id'] and credits['execution_id'] == identity['execution_id']
assert credits['credits_fallback_disabled'] is True and credits['attested_at'] == receipt['human_billing_confirmation_at']
assert credits['operator'] == 'Human explicitly confirmed OFF and remains OFF for this smoke'
invocation = config.runs_dir/'STAGE19-SMOKE'/'invocations'/'stage19-final-conformance-2'
assert not (invocation/'model-home').exists()
assert not runner.stale_executions()
status = subprocess.run(['git', '--no-optional-locks', '-C', str(workspace), 'status', '--porcelain', '--untracked-files=all'],
    capture_output=True, text=True, timeout=20)
assert status.returncode == 0 and status.stdout == ''
assert (workspace/'src/example.py').read_text(encoding='utf-8') == 'value = 1\n'
assert (config.root/'src/example.py').read_text(encoding='utf-8') == 'value = 1\n'
result = {'read_only_post_execution_check': True, 'additional_inference_requests': 0,
    'current_binding_matches_admission': True, 'signed_transport_proof_reverified': True,
    'signed_live_authorization_reverified': True, 'signed_no_credit_attestation_reverified': True,
    'no_credit_client_execution_binding_verified': True, 'no_credit_timestamp_equals_actual_new_confirmation': True,
    'workspace_git_clean': True, 'workspace_value_remains_baseline_1': True,
    'disposable_primary_value_remains_baseline_1': True, 'ephemeral_codex_home_absent': True,
    'stale_owned_containers': 0, 'credentials_not_exported': True}
(OUT/'post-execution-check.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps(result, indent=2))
