"""Separate assessment of the consumed second attempt, no external actions."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


execution = load(OUT/'execution.json')
refresh = load(OUT/'oauth-refresh-result.json')
postcheck = load(OUT/'post-execution-check.json')
driver = load(OUT/'driver-admission.json')
admission = load(ROOT/'docs/stage19d-evidence/fresh-admission.json')
scope = load(OUT/'prepared-scope.json')
previous = load(OUT/'previous-execution-hashes.json')
baseline = load(OUT/'primary-and-historical-baseline.json')
assert execution['verdict'] == 'FAIL_LIVE_TRANSPORT'
assert execution['responses_dispatch_attempts'] == 1 and execution['responses_http_statuses'] == [400]
assert execution['successful_tools'] == execution['tool_attempts'] == execution['validated_function_count'] == 0
assert refresh['refresh_attempts'] == 1 and refresh['success'] is True
assert execution['signed_live_authorization'] and execution['signed_no_credits']
assert postcheck['signed_live_authorization_reverified'] and postcheck['signed_no_credit_attestation_reverified']
assert postcheck['workspace_git_clean'] and postcheck['workspace_value_remains_baseline_1']
assert execution['codex_process_exited'] and execution['disposable_codex_home_removed']
assert execution['stale_owned_containers'] == 0 and execution['disposable_role_storage_removed']
assert execution['primary_framework_and_historical_evidence_unchanged']
for name, expected in previous.items():
    assert sha(ROOT/name) == expected
for name, expected in admission['source_sha256'].items():
    assert sha(ROOT/name) == expected
assert sha(ROOT/'validation/stage19_final_smoke_retry.py') == driver['entrypoint_sha256']
assert sha(ROOT/'validation/test_stage19_final_smoke_retry.py') == driver['test_source_sha256']
assert sha(OUT/'driver-tests.xml') == driver['offline_xml_sha256']
assert sha(OUT/'prepared-scope.json') == driver['prepared_scope_sha256']
tests = ET.parse(OUT/'driver-tests.xml')
assert len(list(tests.iter('testcase'))) == 37 and not list(tests.iter('failure')) and not list(tests.iter('error'))
historical = {name: value for name, value in baseline.items()
              if name.startswith('docs/') or (name.startswith('STAGE') and '/' not in name)}
framework = {name: value for name, value in baseline.items()
             if name.startswith(('agent_system/', 'tests/', 'validation/', 'examples/', '.agent_system/'))}
for name, expected in {**historical, **framework}.items():
    assert sha(ROOT/name) == expected
artifacts = ['execution.json', 'oauth-refresh-result.json', 'authorization.json', 'refresh-authorization.json',
    'post-execution-check.json', 'driver-admission.json', 'driver-tests.xml', 'prepared-scope.json',
    'one-shot-latch', 'oauth-refresh-latch', 'previous-execution-hashes.json', 'primary-and-historical-baseline.json']
assessment = {
    'date': '2026-10-06', 'verdict': 'FAIL_LIVE_TRANSPORT',
    'execution_id': 'stage19-final-conformance-2', 'task_id': 'STAGE19-SMOKE',
    'model': 'gpt-6-sol', 'reasoning': 'low',
    'authorization': {'explicit_human_assent': True,
        'scope': scope['smoke'], 'single_oauth_refresh_separately_authorized': True,
        'actual_new_confirmation_time_utc': execution['authorization_time_utc'],
        'actual_new_confirmation_time_europe_berlin': '2026-10-06 10:48:50 Europe/Berlin',
        'new_confirmation_timestamp_never_refreshed': True,
        'signed_live_and_client_execution_bound_no_credit_grants_reverified': True,
        'billing_setting_basis': 'Human confirmation OFF and remains OFF; account billing enforcement not independently observable'},
    'counts': {'authorized_oauth_refresh_attempts': 1, 'oauth_token_posts': 1,
        'oauth_issuer_discovery_gets': 1, 'oauth_jwks_gets': 1,
        'responses_dispatch_attempts': 1, 'http_statuses': [400],
        'live_codex_turns_started': 1, 'validated_sse_responses': 0,
        'validated_executable_calls': 0, 'docker_tool_attempts': 0, 'successful_tool_calls': 0,
        'model_catalog_requests': 0, 'reconnects': 0, 'automatic_retries': 0,
        'offline_driver_tests_passed': 37},
    'observed_failure': {'phase': 'First fixed-route Responses request', 'http_status': 400,
        'codex_surface_reason': execution['safe_failure_reason'],
        'sse_body_received_for_semantic_validation': False,
        'before_function_lifecycle_validation': True, 'before_tool_dispatch': True,
        'upstream_error_body_retained': False, 'upstream_machine_error_code': None,
        'exact_http400_cause_established': False,
        'explanation': 'Provider returned HTTP400. The error body was closed without capture. No claim of model entitlement failure, tool-schema failure or lifecycle-reconciliation defect is supported by retained evidence.'},
    'completed_path': ['Strict verified OAuth refresh with unchanged account/client',
        'Current source/Codex/Docker/config/project binding and signed transport proof',
        'CRLF-compatible clean baseline validation', 'Fresh exclusive execution latch',
        'Fresh source/execution/model-bound signed live authorization',
        'Fresh client/execution-bound signed no-credit attestation using actual new human confirmation time',
        'Ephemeral Codex initialization and single turn', 'Controller-authored namespace/schema request',
        'One public Responses POST', 'HTTP400 rejection; stop without retry', 'Cleanup and independent evidence verification'],
    'uncompleted_success_requirements': ['Complete validated SSE', 'Codex dynamic tool request',
        'Controller canonical argument match', 'IsolatedExecutionBridge dispatch', 'Docker mutation',
        'Validated subsequent response', 'Docker verification', 'Final validated model response', 'Strict successful AgentResult'],
    'independent_task_verification': {'owned_workspace_clean': True, 'changed_paths': [],
        'public_value_still_baseline_1': True, 'exact_content_value2_lf': False,
        'mutation_expected_output_observed': False, 'verification_expected_output_observed': False,
        'strict_successful_agent_result_produced': False},
    'security_and_cleanup': {'no_model_selected_host_execution_observed': True,
        'no_credential_escape_observed': True, 'no_unexpected_tool_call': True,
        'codex_process_exited': True, 'disposable_codex_home_removed': True,
        'no_smoke_role_storage_created': True, 'stale_owned_containers': 0,
        'primary_framework_and_historical_evidence_unchanged': True,
        'previous_attempt_files_independently_rehashed': len(previous),
        'historical_files_independently_rehashed': len(historical),
        'framework_test_config_files_independently_rehashed': len(framework),
        'authorized_credential_change': 'Exactly one successful separately authorized refresh in protected Controller storage before smoke',
        'raw_provider_payloads_ids_arguments_prose_retained': False},
    'safe_structural_telemetry': {'transport': execution['transport_structure'], 'gate': execution['gate_structure'],
        'http_statuses': [400], 'function_count': 0,
        'sse_event_counts': {}, 'lifecycle_reconciliation_observed': False,
        'mime_body_eof_usage': 'Unavailable; HTTP error occurred before successful response reader'},
    'source_bundle_sha256': admission['source_bundle_sha256'],
    'codex_sha256': admission['codex_sha256'], 'admission_binding': admission['binding'],
    'executed_driver_sha256': driver['entrypoint_sha256'],
    'new_driver_baseline_correction': 'Same read_text newline semantics as approved mutation argv; LF and CRLF both accepted',
    'post_execution_proof': postcheck, 'execution_record': execution, 'oauth_refresh_record': refresh,
    'artifact_sha256': {name: sha(OUT/name) for name in artifacts},
    'known_limits': ['HTTP400 exact cause unknown because no error body or machine code was retained.',
        'Account-specific availability of gpt-6-sol remains unverified; no catalog lookup or alternate model was attempted.',
        'No live SSE/function lifecycle was exercised; neither a lifecycle pass nor a lifecycle rejection was established.',
        'Cleanup/storage protections rely on the trusted Controller and cannot protect against the local administrator.'],
    'execution_allowance_consumed': True, 'retry_performed': False,
    'stage19_passed': False, 'stage19_status': 'FAIL_LIVE_TRANSPORT',
    'stage20_technically_admissible': False, 'stage20_started': False,
    'stop_state': 'No further refresh, reconnect, inference, alternate model, role workflow, benchmark or Stage20. Consumed latches preserved.'}
(ROOT/'STAGE19_FINAL_CONFORMANCE_SMOKE_2.json').write_text(json.dumps(assessment, indent=2)+'\n', encoding='utf-8')
md = f'''# Финальная попытка Stage19 №2 — stage19-final-conformance-2

**`FAIL_LIVE_TRANSPORT`**. Первый запрос к публичному Responses endpoint получил **HTTP 400**. Выполнен один запрос из разрешённых трёх, tool calls — **0**. Повторных запросов не было. Execution allowance израсходован, latch сохранён.

**Stage19 passed: false. Stage19: `FAIL_LIVE_TRANSPORT`. Stage20 technically admissible: false.** Stage20 не запускался.

## Авторизация и подготовка

Новая явная авторизация пользователя разрешила один OAuth refresh, затем одну попытку `stage19-final-conformance-2` для `STAGE19-SMOKE`, implementer / implementation, строго `gpt-6-sol` / `low`. Остальные границы исходного proposal сохранены: одна execution/turn, максимум три Responses requests, две точные последовательные tool-команды, parallel calls выключены, без автоматических повторов, альтернативного model/reasoning, дополнительных role команд/файлов, role network, package installation, других ролей или Stage20.

Исправленный новый драйвер принимает LF/CRLF через `read_text()` в точности как утверждённая mutation argv. Его 37 офлайн-тестов прошли. Исходный неудачный драйвер, использованный latch первой попытки и её отчёты не изменены.

Однократный отдельно разрешённый `ChatGPTPlanOAuth.refresh()` прошёл: один token POST, один issuer-discovery GET и один JWKS GET. Использован исходный строгий verifier; client/account совпадают, plan scope присутствует, token действителен для smoke. Переподключения, повторного refresh, model catalog lookup и inference на этом этапе не было. Credentials остались в защищённом Controller storage.

Перед live запросом повторно совпали source bundle, Codex executable, Docker image/engine/config/project binding и подписанный transport proof нового runtime. Чистая исходная fixture с CRLF прошла проверку. Созданы новый exclusive execution latch и fresh signed live/no-credit разрешения. Время нового человеческого подтверждения — **6 октября 2026, 10:48:50 Europe/Berlin** (08:48:50 UTC, первое получение ответа); оно не обновлялось. Client/execution binding и подписи independently reverified после попытки. OFF credit fallback — человеческая аттестация; независимого доказательства billing enforcement нет.

## Фактически достигнутый путь и отказ

Ephemeral Codex app-server запущен, начат один turn. Gate подготовил один Controller-owned namespace `agentctl` с единственной strict function `agentctl_execute` и execution-bound schema, фиксированными model/reasoning и выключенными parallel calls. В публичный `https://api.openai.com/v1/responses` отправлен один POST. Провайдер ответил HTTP 400, после чего Codex остановлен с безопасной общей причиной `Codex/model protocol denied`.

Тело HTTP ошибки закрыто без захвата. Точная причина HTTP 400 **не установлена**, machine error code отсутствует в retained evidence. Нельзя приписать отказ недоступности модели, schema или lifecycle reconciliation. Валидация SSE не началась: нет событий, MIME/body/EOF/usage данных или частично авторизованных calls. HTTP статус и нулевые структурные счётчики сохранены. Произвольные IDs, arguments, model prose, credentials и provider payloads не сохранялись.

## Независимые проверки после попытки

- Tool dispatch, `IsolatedExecutionBridge` и Docker mutation/verification не выполнялись; validated executable calls — 0.
- Owned workspace Git-clean, изменённых файлов нет; public value остаётся 1. Требуемые `value = 2\\n`, mutation/verification outputs и успешный strict AgentResult не получены.
- Model-selected host execution, неожиданных tool calls и credential escape не наблюдалось.
- Codex process завершён, ephemeral home удалён, role execution storage для smoke не создавался, stale owned containers — 0.
- Подписанные live/no-credit grants, их client/execution/timestamp bindings и transport proof проверены read-only без новой inference.
- Existing primary/framework и historical baseline совпали в драйвере. Отчёт дополнительно перепроверил **{len(historical)}** historical files, **{len(framework)}** framework/test/config files и **{len(previous)}** files первой попытки. Production код и исторические отчёты/evidence сохранены; изменения credentials ограничены отдельно разрешённым refresh. Новые драйвер/tests/evidence и этот отдельный отчёт — разрешённые добавления.

## Хеши и evidence

Production bundle SHA256: `{admission['source_bundle_sha256']}`.

Codex SHA256: `{admission['codex_sha256']}`.

Executed driver SHA256: `{driver['entrypoint_sha256']}`.

- [Execution record](docs/stage19-final-conformance-2-evidence/execution.json)
- [OAuth refresh result](docs/stage19-final-conformance-2-evidence/oauth-refresh-result.json)
- [Independent post-execution check](docs/stage19-final-conformance-2-evidence/post-execution-check.json)
- [Frozen scope](docs/stage19-final-conformance-2-evidence/prepared-scope.json)
- [New authorization receipt](docs/stage19-final-conformance-2-evidence/authorization.json)
- [Driver admission](docs/stage19-final-conformance-2-evidence/driver-admission.json)
- [37 passing offline tests](docs/stage19-final-conformance-2-evidence/driver-tests.xml)
- [Consumed execution latch](docs/stage19-final-conformance-2-evidence/one-shot-latch)
- [Consumed OAuth refresh latch](docs/stage19-final-conformance-2-evidence/oauth-refresh-latch)
- [Separate JSON assessment](STAGE19_FINAL_CONFORMANCE_SMOKE_2.json)

Live end-to-end успех не достигнут. Реальный function lifecycle не проверен этой попыткой; account availability модели не подтверждена. Повтор, альтернативная модель, переподключение, дальнейший refresh, multi-agent workflow, benchmark и Stage20 не выполнялись. Работа остановлена после этого отчёта.
'''
(ROOT/'STAGE19_FINAL_CONFORMANCE_SMOKE_2.md').write_text(md, encoding='utf-8')
print(json.dumps({'verdict': assessment['verdict'], 'responses_requests': 1, 'http_status': 400,
    'tool_calls': 0, 'historical_files_reverified': len(historical), 'framework_files_reverified': len(framework),
    'previous_attempt_files_preserved': len(previous), 'stage19_passed': False,
    'stage20_technically_admissible': False}, indent=2))
