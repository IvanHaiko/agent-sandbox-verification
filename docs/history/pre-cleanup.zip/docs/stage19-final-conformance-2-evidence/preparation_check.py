"""Read-only preparation; no live entry point, latch, grants or OAuth refresh."""
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from agent_system.chatgpt_oauth import CredentialStore, PLAN_SCOPE
from agent_system.config import Configuration
from agent_system.runners.tool_docker import ToolDockerRunner


out = Path(__file__).resolve().parent
admission = json.loads((ROOT/'docs/stage19d-evidence/fresh-admission.json').read_text())
sources = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
           for p in sorted((ROOT/'agent_system').rglob('*.py'))}
assert sources == admission['source_sha256']
config = Configuration.load(Path(admission['project']))
runner = ToolDockerRunner(config)
assert runner.preflight() == admission['binding']
runner.require_transport_admission()
assert not runner.stale_executions()
path = Path('C:/Users/4ivan/.agentctl/stage19-oauth')
record = {'preparation_only': True, 'live_requests': 0, 'role_commands': 0, 'oauth_refreshes': 0,
    'reconnections': 0, 'new_execution_latch_created': False, 'signed_live_grant_issued': False,
    'source_bundle_match': True, 'runtime_binding_match': True, 'signed_transport_proof_verified': True,
    'stale_owned_containers': 0, 'credential_storage_present': path.is_dir()}
if path.is_dir():
    store = CredentialStore(path, [ROOT, config.root, config.worktrees_dir])
    value = store.read('credentials.json')
    registration = store.read('registration.json')
    record['credential_storage_permissions_verified'] = True
    record['existing_credentials_present'] = isinstance(value, dict)
    record['existing_credentials_unexpired_for_180_seconds'] = bool(value and
        type(value.get('expires_at')) in (int, float) and value['expires_at']-time.time() > 180)
    record['plan_scope_present'] = bool(value and PLAN_SCOPE in value.get('scopes', []))
    record['client_registration_match'] = bool(value and registration and value.get('client_id') == registration.get('client_id'))
    record['existing_credentials_valid_for_smoke'] = all(record[k] for k in
        ('existing_credentials_unexpired_for_180_seconds', 'plan_scope_present', 'client_registration_match'))
(out/'preparation-check.json').write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
print(json.dumps(record, indent=2))
