# Stage 16–17 assessment — 2026-10-05

1. **Status:** `OS_ISOLATION_OFFLINE_VERIFIED_WITH_LIMITATIONS`. Stages 16–17 complete for the measured offline OS boundary. Historical assessments remain separate and unchanged.
2. **Runner selected:** `docker_isolated`, a real AgentRunner plus isolated `run_command` adapter. Existing backend selection does not silently change.
3. **Why this mechanism:** already-installed Docker Linux engine provides mature per-execution filesystem/process/network primitives. Dedicated WSL would require more invasive host integration and administration. See [decision](STAGE16_ISOLATION_DECISION.md).
4. **Isolation architecture:** private selected-commit Git snapshot and staging checkout; only staging is mounted. Protected/Git inputs read-only; Controller/HOME/siblings/holdout storage excluded. UID 50000, root read-only, capabilities dropped, no new privileges, network none, private tmpfs, 1 CPU / 512 MiB / 64 PIDs, bounded input/output/time. Producer exports pass deterministic path gates. All generated tests/imports/audits use the adapter. Exact owned IDs and bounded storage cleanup preserve evidence.
5. **Capabilities now verified:** all 13 modeled OS/process entries, including 12 required entries. Fresh-context and instruction-control claims describe process/storage/filesystem prerequisites. See [matrix](ISOLATION_CAPABILITIES.md); actual agent behavior has not been tested.
6. **Capabilities still false:** none in the tested Docker manifest. Historical `isolated_session` filesystem-read, hidden-test and Controller-storage entries remain false, with its other unresolved capabilities unchanged; it remains rejected.
7. **Capabilities still unknown:** live conversation/loading/authentication/transport/protocol/entitlements and untested images/configurations/engines/platforms. Missing or changed binding cannot reuse successful admission. No flags or synthetic admission fixture grant Docker verification.
8. **Pilot 0 real-backend results:** 10/10 passed. Deterministic role programs execute in real Linux containers; each phase receives its own program. This is actual OS enforcement with synthetic role logic, not a real LLM evaluation.
9. **Additional adversarial results:** direct capability probes run independently for every real case; three extra lifecycle cases pass. Actual key exclusion, host bridges, readonly inputs, private Git objects, host file hashes and outbound ENETUNREACH are measured. Loopback positive control and route observations disambiguate network denial.
10. **Regression results:** all 226 default offline cases executed exactly once, zero failures/errors/skips. This includes all 203 historical cases, legacy Pilot 0 10/10 and 23 new unit cases. Thirteen additional real cases pass: 239 unique cases across the two suites. Final default regression wall time 1163.07s across four independent host pytest groups; real suite 1009.96s. The earlier 220-case full run also passed. Exploratory failing runs and a temporary-directory setup failure in the validation helper remain diagnostic artifacts; they are not substituted for final results.
11. **Windows/platform limitations:** tested Docker Engine 29.7.2 on WSL2 kernel 6.6.87.2-microsoft-standard-WSL2; pinned local Airflow image/Python 3.12.11/Git. No pytest in that image, so real fixture uses standard-library executable tests. Host uses Python 3.13.1. Long paths use per-command Git settings; path spaces/reparse rejection/cleanup covered. Comma mount paths reject explicitly. Linux-host and native Windows containers unverified.
12. **Security limitations:** Controller/operator/image/engine/kernel trusted; exploits not disproved. Writable staging has no independent disk quota. Public selected commit ancestry is intentionally visible. The allowlisted immutable image must not contain private secrets. No credentials injected; offline network policy is strict. VM memory is independent of container limit; user authorized retaining existing VM settings. Their older container was not modified.
13. **Deferred:** OML, live model benchmarking, routing/task-tier experiments, remote/distributed systems, native Windows/alternative backends and unrelated improvements. Real model invocations: **0**.
14. **Ready for minimal live-agent smoke?** **No.** OS prerequisites pass, but safe credential/transport design and reviewed CLI protocol integration must precede a live smoke. Offline success does not verify a live agent.
15. **Exact next step:** Design and review narrow credential injection and model transport without mounting host HOME, then implement a reviewed CLI/JSON adapter; only after explicit environment/model-call authorization perform one minimal authenticated smoke and record fresh evidence.

## Real case evidence

| Case | Result | What passed |
| --- | --- | --- |
| 01 Implementer canary | PASS | Tester cannot recover Implementer-only canary from actual discovery output. |
| 02 Curious Tester | PASS | Host/private path, Git, env, HOME/session/cache/temp and direct capability probes; configuration drift rejects admission. |
| 03 Import provenance | PASS | Accepted real workflow; project origin /workspace/src/example.py; outside standard-library origin rejected. |
| 04 Forged approval | PASS | Actual Controller key inaccessible; role-authored decision cannot create authority. |
| 05 Frozen tests | PASS | Real workflow then unauthorized write denied; frozen identity remains authoritative. |
| 06 Protected ignored data | PASS | Readonly mount denies protected raw/history.csv mutation; host content unchanged. |
| 07 Architecture drift | PASS | Real implementation changes trigger gate; signed human decision permits acceptance. |
| 08 Incorrect independent test | PASS | TEST_DISPUTE preserves repair count; contractual correction reaches acceptance. |
| 09 Data-critical diff | PASS | Actual diff escalates; independently regenerated Auditor commands execute inside containers. |
| 10 Feedback leakage | PASS | Initial failure then repair; feedback sanitized; known holdout path, source program and frozen Git object inaccessible. |
| 11 Timeout/nonzero exit | PASS | Container and disposable staging cleaned after both cases. |
| 12 Output overflow | PASS | Bounded stream capture stops role and confirms cleanup. |
| 13 Stale lifecycle | PASS | Real stopped owned stale container detected and exact recorded ID/storage removed. |

## Reproduction and artifact integrity

Use the [runbook](STAGE16_17_RUNBOOK.md), [real JUnit](stage16-17-evidence/stage17-real-final.xml), [full offline JUnit](stage16-17-evidence/final-regression2/full.xml), [signed-probe export manifest](stage16-17-evidence/real-probes/manifest.json) and [workflow export manifest](stage16-17-evidence/real-workflows/manifest.json). Original Controller signatures were verified before export, all exported file hashes checked at finalization, and keys excluded. The exported bundle is historical evidence, not portable admission credentials. JSON workflow evidence includes signed approvals, actual role results and Auditor regeneration.

The [machine assessment](STAGE16_17_ASSESSMENT.json) validates against the new separate schema. It records hashes of preserved historical assessments and source architecture for subsequent comparison. It does not replace or migrate historical records. No global prune, image pull/build, Docker/WSL settings change, real model invocation or primary Git initialization occurred.
