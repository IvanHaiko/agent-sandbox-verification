# Stage19e — Controlled HTTP 400 diagnostic matrix

**DIAGNOSTIC_MATRIX_INCONCLUSIVE** — stopped before inference because the current ChatGPT-plan OAuth access token is expired.

Zero Responses POSTs, zero account-catalog GETs, zero model tools, zero refresh/reconnect attempts. The five-POST ceiling was not consumed. No production correction is justified. Stage19 remains `FAIL_LIVE_TRANSPORT`; Stage20 is not admissible and was not started.

## Observed preconditions

Fresh admission passed against production source bundle `ccee1417fde05b674122421f7ee6f639ac8363e7e49bd08d95ed21b75d2551fd`. Real Codex dynamic-tool roundtrip, Docker isolation, network denial, secret filtering, adversarial tool rejection and cleanup were validated with a synthetic localhost model. Signed transport proof was verified. These synthetic probes are not Stage19 live smoke.

Current Codex: `C:\Users\4ivan\AppData\Local\OpenAI\Codex\bin\5ea220ae823df3d7\codex.exe`; SHA256 `3b8f6e33caa75f232558a3cf76ff9b87bb5ef6dbcf4996372f24e55c78b1b916`. Docker image `sha256:6c07868196d1880d956f4b5ddf50244bc281faab39704a8940b1c1f3159a145e`. The evidence contains the current engine/config/project binding. The first sandboxed admission attempt failed on Docker context filesystem access; the permitted elevated admission then passed (1 test). Both records are retained.

Credential verification at 2026-10-06T09:53:58.364019+00:00 found protected credentials present, storage permissions verified, and the access token expired. No catalog request was sent with that token. Account-specific availability of `gpt-6-sol / low` and replacement candidates is UNKNOWN; no model was silently substituted.

The human OFF billing confirmation was recorded with the actual local handling timestamp, explicitly not represented as the message send time. No fresh execution/client-bound live or no-credit signatures were issued because credential/catalog preconditions failed. No attestation timestamps were fabricated.

## Comparison table

| Variant | Single changed factor | Catalog model | HTTP status | Error type | Code | Param | Category | SSE reached | Tool call reached | Interpretation |
|---|---|---|---:|---|---|---|---|---|---|---|
| A_BASELINE | None; exact production baseline (planned only) | UNKNOWN | — | — | — | — | — | No | No | Not executed: credential blocker |
| B_TYPED_CONST | Add explicit types to const-only function properties (planned only) | UNKNOWN | — | — | — | — | — | No | No | Not executed: credential blocker |
| C_NO_MESSAGE_IDS | Remove input message IDs (planned only) | UNKNOWN | — | — | — | — | — | No | No | Not executed: credential blocker |
| D_NON_STRICT_CONTROL | Disable explicit function strict mode; admission control only (planned only) | UNKNOWN | — | — | — | — | — | No | No | Not executed: credential blocker |
| E_CATALOG_MODEL_CONTROL | Catalog-justified model/reasoning substitution only (planned only) | UNKNOWN | — | — | — | — | — | No | No | Not executed: credential blocker |

All five variants are blocked, not classified as unnecessary. No request shape fingerprints exist because no diagnostic body was prepared or dispatched. No new provider HTTP error was observed; structured diagnostics and controlled comparisons are empty. The existing centralized bounded error capture remains unchanged.

## Conclusion and next admission

Observed fact: credentials expired. This is a current precondition blocker, **not the confirmed cause of the historical HTTP 400**. There is no A/B, A/C or A/D evidence. Const-only strict-schema and message-ID hypotheses remain unconfirmed. Production strict mode, const values, namespace and input remain unchanged.

Relevant offline regression: **275 passed**, zero failures/errors. No correction was applied, so these are precondition/regression checks rather than post-repair evidence. The fresh admission source manifest still matches production. Previous Stage19d admission remains stale and historical failures/latches were not rewritten.

The stopped-run attempt ledger records zero consumed variants and disables automatic resume. Credential restoration, fresh account-specific catalog confirmation, binding/source revalidation, and fresh execution/client-bound no-credit/live approvals are required before resuming diagnosis. A final Stage19 smoke remains required; no live success was established here.

The non-strict control, if later needed, is admission-only unless independent exact Controller enforcement permits safe execution. The documented distinction between explicit strict and fallback behavior is described in [OpenAI function calling](https://developers.openai.com/api/docs/guides/function-calling); documentation does not establish the cause of this account’s historical 400.

Evidence: [fresh admission](docs/stage19e-evidence/fresh-admission.json), [credential/catalog status](docs/stage19e-evidence/catalog.json), [attempt ledger](docs/stage19e-evidence/consumed-attempts.json), [offline tests](docs/stage19e-evidence/offline.xml), [human confirmation](docs/stage19e-evidence/human-authorization.json).
