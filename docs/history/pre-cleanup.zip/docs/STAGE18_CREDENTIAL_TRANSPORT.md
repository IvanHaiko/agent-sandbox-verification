# Stage 18 credential and transport checkpoint — 2026-10-05

Status: **PARTIAL_BLOCKED**. Highest completed stage remains 17. Current
authoritative status remains `OS_ISOLATION_OFFLINE_VERIFIED_WITH_LIMITATIONS`.
No live model call was made. Stage 19 is not admitted.

The new `agent_system/agent_transport.py` is an offline protocol adapter, not
a live process launcher. Existing Docker enforcement, configuration, signed
admission and historical assessments have not been changed.

## Authentication evidence

The installed Windows CLI reports `codex-cli 0.159.2`. Its local help exposes
stdin API-key and access-token login, `--ephemeral`, `--ignore-user-config`,
`--ignore-rules`, `--json`, and `--output-schema`. Help proves flag availability;
it does not prove Linux compatibility, authentication or model entitlement.

Official [authentication documentation](https://learn.chatgpt.com/docs/auth)
describes a plaintext `auth.json` cache under `CODEX_HOME` or OS credential
storage, automatic ChatGPT token refresh, and an in-memory credential store.
Login can write a diagnostic log. Session refresh can update cached credentials.
These are reusable secrets, not execution-scoped credentials.

A metadata-only inspection of the local authentication file found ChatGPT mode,
no API-key value, and fields named access_token, refresh_token, id_token and
account_id. No values were printed, copied, mounted or exported. The current
process has none of CODEX_API_KEY, OPENAI_API_KEY or CODEX_ACCESS_TOKEN set.
Host HOME state is not necessary in principle for explicit automation auth;
the minimum credential and refresh behavior for this account have not been
verified in Linux. OAuth scope, expiry, entitlement and effective restrictions
remain unknown. No host keyring or browser data was inspected.

Official [non-interactive documentation](https://learn.chatgpt.com/docs/non-interactive-mode)
supports invocation-level CODEX_API_KEY and structured JSON events/results,
but warns against allowing repository-controlled code to read that environment.
Its documented CI approach uses a Responses proxy to reduce API-key exposure.
Copying the local cache is therefore not our chosen boundary design.

## Credential threat model and proposed boundary

The role and its generated programs are untrusted. Controller, daemon, reviewed
image and kernel retain the Stage 17 trust assumptions. A role may inspect its
environment, process state, filesystem, subprocesses, logs and writable files.
Sibling roles, Controller keys, holdouts and unrelated credentials stay excluded.

Direct environment injection into a same-UID coding-agent container is insufficient
to hide a reusable credential from generated programs. Filtering shell environment
inheritance is useful but does not prove that process inspection is prevented.
A temporary auth file or role-private directory also remains readable by that role.
Non-root Docker execution alone does not fix this exposure. Redaction cannot
prevent a malicious program from encoding a secret into source files or network
traffic. These are design conclusions, not measured new isolation capabilities.

Prefer an invocation-scoped credential only if its restrictions are established
and exposure to the role is explicitly acceptable. Otherwise a reviewed narrow
model-transport broker must keep upstream reusable credentials outside the role
and enforce destination, model, usage and lifetime constraints. This decision
changes the live transport boundary and needs operator security approval before
implementation. Do not treat a bool setting as approval or capability evidence.
Neither design is implemented or admitted in this checkpoint.

Never mount HOME, `.codex`, shell/browser state, Controller runtime or keys. Never
put credentials in prompts, argv, Git, command evidence or export bundles. Role
authentication/session files, if later required, must remain in private tmpfs and
die with the container. A Python reference release is not secure memory erasure.

## Implemented protocol

`CodexCliAdapter` prepares a fresh exec command with an explicit model/reasoning,
private schema/final-artifact paths, ephemeral sessions, ignored user config/rules,
and no inherited shell environment. It never calls a host CLI. It never resumes a
conversation or modifies Docker admission. The command is a proposal pending
actual Linux CLI/config-loader validation; repository instruction behavior is
not yet measured.

`BoundedStreams` separately bounds protocol, stderr and tool logs in bytes before
decoding. Capture failures are terminal. The adapter requires a single complete
turn, strict JSONL, zero process exit, a matching final artifact/agent message,
the caller's phase schema, and matching identity fields when included by the role.
Malformed JSON, duplicate keys, nonfinite numbers, partial JSON, unexpected text,
unknown/failure event types, ambiguous completions, invalid UTF-8, missing final
messages, overflow, timeout, cancellation and crashes fail closed. It does not
try to repair arbitrary prose. Unknown future CLI events intentionally block.

The version 1 `transport_result` schema records Controller-bound execution, role,
task, contract, configured model/reasoning, backend, structured result, process
exit, observed tool exit codes, timestamps, exposed usage and errors. Configured
model is distinct from reported model, which remains unavailable. Missing usage
is null; no totals, prices or model identities are inferred. A nonzero tool exit
does not necessarily mean the agent process failed; deterministic workflow gates
still decide acceptance. The existing AgentResult bridge accepts only a validated,
matching envelope and measured runner paths. It grants no workflow authority.

`CredentialLease` binds redaction to an execution and role, avoids secret repr,
redacts literal/standard JSON-escaped values after stream reassembly, normalizes
valid protocol JSON, and rejects known-secret decoded final results. It is a
redaction utility tested with synthetic values,
not an implemented credential injector. Arbitrary secret encodings, same-UID
process reads and safe real credential export are not proven. Raw capture stays
in memory; callers must persist only redacted diagnostics and must separately
enforce isolated cancellation/cleanup. There is no live caller yet.

`require_live_admission` first checks runner capability admission and then always
rejects live use while the credential/egress guarantees remain unverified.
Legacy live-smoke commands are unchanged and cannot supply Stage 19 admission
or substitute for verified isolated transport.

## Environment preflight and next-stage decision

Docker Engine reports 29.7.2. The exact Stage 17 pinned Airflow image
`sha256:6c07868196d1880d956f4b5ddf50244bc281faab39704a8940b1c1f3159a145e`
returned `codex_executable: null` in a disposable container with no host mounts,
network none, non-root UID, readonly root, dropped capabilities, no new privileges,
CPU/memory/PID limits and no Docker logs. It exited successfully and auto-removed.
This inventory check is not a renewed capability attestation. No image was built
or pulled; unrelated containers and daemon settings were untouched.

The measured Docker runner still requires network none. A real remote-model CLI
cannot use that policy. A new Linux CLI image or new transport/network policy
requires a fresh measured admission binding; old evidence cannot admit it.
Current astra/sol/luna routing aliases remain unverified, with no substitution.

Focused and regression evidence is recorded in MASTER_PROGRESS_ASSESSMENT.json.
Focused tests are entirely deterministic. Historical real Docker cases remain
historical and were not rerun because their implementation was not changed.

Next: review the narrow credential/egress boundary with the operator; provision a
reviewed pinned Linux CLI image and role-safe authentication; implement the approved
transport through the existing runner with redacted persistence and secret-safe
file export; remeasure changed admission guarantees. Only then run the three
bounded Stage 19 smokes. Stages 20–24 remain prerequisite-blocked; no pilot,
routing calibration, role-value claim or workflow-tier change is justified.
