# OS-isolated runner: operation and validation

The new backend is `docker_isolated`. The existing `isolated_session` backend and
historical hardening assessments are preserved. Selecting Docker does not admit
execution: independent real probes must pass first.

## Dependencies and explicit launch permission

Windows requires a running Docker Desktop Linux engine and Git/Python on the
Controller host. No automatic installation, engine startup, image pull, global
configuration change or fallback is implemented. Obtain the operator's permission
before starting environments. The validation CLI requires `--allow-containers`.

Select a reviewed local Linux image by its full `sha256:` image ID, containing
`python`, `git`, and the target project's required dependencies. Image tags are
rejected. Never bake credentials, private histories or holdouts into the image.
The image is a trusted immutable toolchain, not a role's shared writable cache.

This host's initial offline image was the already-installed official
`apache/airflow:3.0.4`, ID
`sha256:6c07868196d1880d956f4b5ddf50244bc281faab39704a8940b1c1f3159a145e`.
It has Python/Git but no pytest. The real Pilot 0 fixture deliberately uses
standard-library executable tests. Other projects need an appropriate reviewed
image with their dependencies; missing tools fail the actual executable gate.
No download/build was needed for this validation.

## Project configuration

Keep the project's existing configuration and add the following runner block.
Runtime v2 must point to an absolute directory outside the target repository.
Do not silently migrate frozen runs to a different backend/configuration.

```yaml
runtime:
  version: 2
  root: C:/approved/external/runtime
runner:
  backend: docker_isolated
  executable: python
  timeout_seconds: 60
  max_infrastructure_retries: 0
  container:
    image: sha256:REPLACE_WITH_64_HEX_DIGITS
    context: desktop-linux
    memory_mb: 512
    cpus: 1
    output_limit_bytes: 1048576
    role_args: ["/workspace/approved_role_driver.py"]
```

The role driver receives one JSON request on stdin containing role, configured
model/reasoning identifiers, phase, approved prompt/context inputs, task ID and
contract version. It emits the phase's schema-compatible JSON report on stdout.
It must be present in the reviewed image or approved checkout. The validation
driver in `validation/role_driver.py` is deterministic and makes no model calls.
No Codex authentication or live CLI protocol adapter is claimed here.

Generated test/import/audit/package commands use `run_command`, with read-only
project inputs. Mutating role phases use `run`. There is no unsandboxed generated
command fallback. Host environments and Windows venvs are not forwarded.
Retries are currently explicitly unsupported; Docker configurations require zero.

## Real validation and admission

```powershell
python -m agent_system --project C:/target isolation-validate --allow-containers
python -m agent_system --project C:/target isolation-status
```

Validation creates synthetic private files and the real Controller attestation
key outside the role mount. It probes read/write attempts at known host paths and
common Windows/WSL/Docker host bridges, parent listings, recursive discovery,
Git refs/reflogs/unknown objects, imports, HOME/history/cache reuse, protected
ignored data, immutable mounts and outbound connectivity. A working loopback
connection, kernel `ENETUNREACH`, and absence of routes distinguish enforced
network denial from an unavailable remote service. Linux error names are compared
instead of host-specific Windows errno numbers.

Every probe retains actual command/environment, container inspection, bounded
stdout/stderr and ownership/cleanup results. Only a completely successful report
is HMAC signed in Controller-owned storage. The binding includes engine identity,
version/kernel/security options, immutable image ID, runner settings, project
identity and hashes of the runner/probe/command-boundary code. Referenced evidence
files are hash checked when producing the capability manifest. Unsigned JSON,
missing evidence, changed configuration/code/image/engine and failed probes do
not grant admission. Rerun validation after such changes.

## Visibility and lifecycle

Each command receives a disposable host staging checkout with a private Git
database containing only the selected commit's ancestry. Shared worktree `.git`
files, sibling refs/objects/reflogs, remotes and alternates are never mounted.
The original checkout's actual file state is copied after rejecting links,
junctions, reparse points and special files. Host venv/cache/runtime directories
are excluded. Windows Git calls use per-command long-path support; global Git
settings remain unchanged. Commas in mount paths are rejected rather than
misparsed; spaces are passed as argument-vector values.

The staging checkout is mounted at `/workspace`; Git metadata is always read-only.
Read-only phases have a read-only checkout. Mutating phases have writable staging
project files, with protected files and existing independent-test files for the
Implementer mounted read-only. No Controller directory, host HOME, sibling role,
host agent configuration/history or Docker socket is mounted. Only the reviewed
image, current private checkout and explicitly supplied role context are inputs.

A fresh `/role` tmpfs holds private HOME, session/config/history, cache, stdin and
temporary data. Standard container-private device/shared-memory filesystems are
also isolated from host/other roles. The process runs as UID/GID 50000, with no
added capabilities or new privileges, no network, no published ports/devices and
a read-only root. Container creation is inspected before execution. Limits bound
container memory/swap, CPU, processes, tmpfs, input/output and execution duration.
Docker Desktop/WSL VM overhead is separate from these container limits.

After execution, regular-file changes pass deterministic scope/protection/role
checks before being copied back to the owned role checkout. Git metadata is never
exported. New empty-directory-only mutations fail explicitly. The Controller
continues to commit, integrate, freeze tests, approve contracts and verify gates.

Exact owned container IDs are removed on success, nonzero exit, timeout and
output overflow. Disposal never invokes global prune, volume/image deletion or
WSL shutdown. Windows read-only Git pack attributes are cleared only inside the
verified disposable execution tree. Each storage-removal operation runs in a
trusted Controller helper with a 20-second timeout and a fixed root/name allowlist.
File hashing streams data instead of loading whole project files into host RAM.
Staging checkout/bundle data are destroyed;
bounded command/enforcement/output/ownership records and Controller probe
attestations survive. Synthetic host probe inputs survive for reproducibility.
Mutation path/hash metadata survives rejected exports. Any outstanding owned
container blocks the next execution until its lifecycle is resolved.

Stopped orphan containers can be listed through `stale_executions()` and removed
only by their recorded execution identity:

```powershell
python -m agent_system --project C:/target isolation-cleanup-stale EXECUTION_ID --allow-containers
```

Running or unrelated containers are refused by stale cleanup. An interrupted
Controller cannot safely infer a role result or rerun an ambiguous invocation.
Recorded container IDs must match, even when a name has been reused. Confirmed
container disposal with failed storage cleanup can be retried for the same owned
execution. Inspect failed cleanup evidence before retrying; do not discard task state.

## Reproduce test suites

Choose new, unused `--basetemp` directories: pytest deletes an existing one.
Default offline tests never start Docker. The real suite is deliberately opt-in
and outside default `testpaths`:

```powershell
python -m pytest -q tests/test_docker_runner.py --basetemp=.agent_runs/unit-new
$env:AGENTCTL_ISOLATION_IMAGE='sha256:REPLACE_WITH_64_HEX_DIGITS'
python -m pytest -q validation/test_real_isolation.py --basetemp=.agent_runs/os-new
python -m pytest -q tests/test_pilot0.py --basetemp=.agent_runs/pilot-new
python -m pytest -q tests --basetemp=.agent_runs/regression-new
```

Docker access may require the host's normal user rather than a restricted shell.
Do not treat a permission-denied engine connection as evidence of role isolation.
The validation fixture selects a separate program for each phase on the trusted
Controller. Implementer argv never contains the Tester program or holdout source;
the fixture also attempts retrieval of the exact frozen holdout Git object.

The recorded final default regression uses four independent host pytest groups
(not agents) and verifies that every collected test ID executes exactly once:

```powershell
python -m validation.regression_shards --historical docs/stage16-17-evidence/regression.xml --output docs/new-regression --temporary-root .agent_runs/new-regression --workers 4
```

Real containers remain sequential. To export reproducible synthetic evidence,
replace the source runtime tree with your own completed real-suite `--basetemp`:

```powershell
python -m validation.collect_evidence .agent_runs/os-new docs/new-probes
python -m validation.export_workflows .agent_runs/os-new docs/new-workflows
```

Probe export verifies Controller signatures before copying; both exports exclude
private signing-key files. Exported evidence is historical and cannot grant
admission to a different project. The finalization tool verifies final counts,
all exported hashes and the separate assessment schema before publishing status.

## Limits and deferred work

- The operator, Controller, reviewed image and Docker daemon remain trusted.
  Administrator/daemon compromise and kernel/container escapes are not ruled out
  by these probes. This is an OS boundary backed by a mature container primitive.
- The filesystem prerequisite for instruction/session isolation is tested; actual
  live agent configuration loading, conversation behavior, authentication,
  entitlements, CLI output protocol and measured model usage remain unverified.
- No credentials are injected. Network is denied, with no configurable silent
  exception. Secure authentication/network design precedes any live-agent smoke.
- Bind-backed staging has no independent host disk quota. Large permitted project
  writes can consume host disk before Controller export gates reject them. Memory,
  processes, output, tmpfs and time are bounded; these do not imply a disk quota.
- Image dependencies are supplied in advance. No host site-packages, host editable
  install or mutable shared role environment is admitted.
- Snapshot transfer adds Git/filesystem overhead, especially on Windows. Linux
  images require Linux-compatible commands; arbitrary host paths in argv are
  rejected. Script contents are never automatically rewritten.
- Native Windows containers, standalone WSL isolation, Podman, live models, OML,
  benchmarking/routing and unrelated framework improvements remain deferred.
