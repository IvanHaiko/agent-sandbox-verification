# Observability and evaluation

Telemetry remains local evidence under the existing runtime. No database,
worker, dashboard or additional orchestrator is involved. Ordinary pytest,
planning, schemas, help and inspection consume zero real model quota.

## Invocation records

Each isolated-session attempt stores `context_manifest.json`, `command.json`,
`events.jsonl`, `last_message.txt`, `result.json` and write-once `telemetry_start.json`
and `telemetry.json` envelopes. The normalized schema is explicitly version 1.
The start envelope records task/configuration/context digests, role, phase,
operation/cycle identity, configured model/reasoning, attempt and input commit.
The final envelope binds the result and raw-event digests, UTC timestamps,
measured monotonic duration, exit status, timeout, retry number and failure kind.
Injected AgentRunner implementations without process artifacts receive measured
call duration and unknown usage, plus a record identifying the custom runner.

The parser recognizes one `turn.completed` event per single-prompt exec. Unknown
optional event fields are ignored, absent usage fields remain null, malformed
JSON/required event types or recognized usage counters fail clearly, and duplicate
completion events are rejected. `reasoning_output_tokens` is normalized to
`reasoning_tokens` when exposed. It never infers total tokens by adding fields.
Protocol failures are not automatically retried. Raw events retain the existing
local/ignored process-artifact security boundary.

The installed protocol is checked against CLI help before live validation.
Authoritative documentation: [Codex non-interactive mode](https://learn.chatgpt.com/docs/non-interactive-mode).
Models are passed literally from configuration. CLI availability and successful
login status do not prove model entitlement; only successful inference can do so.
Model unavailability fails explicitly, with no fallback or changed reasoning.

## Task aggregation and resume

Executable tasks newly planned with observability have a small immutable marker.
At every completed drive/gate stop, deterministic snapshots are saved under:

```text
.agent_runs/<task-id>/
  observability.json
  invocations/<execution-id>/telemetry.json
  telemetry/snapshots/<source-digest>.json
  evaluation/snapshots/<source-digest>.json
  telemetry/aggregate.json             # final terminal outcome only
  evaluation/report.json               # final terminal outcome only
  evaluation/pilot_report.json         # consolidated final evidence
```

Aggregates have no separate mutable counter. Each execution ID is counted once,
including failed infrastructure attempts; a retry count is the number of attempts
whose retry number is greater than zero, not the sum of retry numbers. Role/model
summaries and token totals expose unavailable-invocation counts beside measured
partial sums. Monetary cost is always null. Role durations are measured execution
times; elapsed-to-last-transition includes local work and human waits through that
transition. It is not a claim of total inference latency or billing time.

Inspection rebuilds reports without writing and compares any finalized artifact
with its sources. Altered envelopes, execution identities, task/cycle/role/commit
bindings and raw events are rejected. Interrupted results without telemetry are
unavailable, never rerun. Older runs are not silently upgraded with observation
markers or invented historical metrics. Legacy v1 contracts stay preparation-only.
Snapshot fingerprints include state history and evidence, so a resumed unchanged
run reuses exactly the same artifacts without duplicated counters or findings.

## Engineering attribution

Normalized findings bind deterministic IDs to source evidence, cycle, role and
candidate. Executable failing pytest IDs are confirmed failure observations.
Unidentified command failures and model review/audit findings have unknown ground
truth. A later successful command containing the exact test selector can establish
`resolved_by_test`; Windows path separators are normalized only in the path
component, preserving parameter values. A frozen failing case forwarded in repair
feedback establishes that testing contributed to the fix gate. Review disappearance
is only `no_longer_reported`, not a confirmed repair or causal code-quality claim.

Duplicate relationships require an identical normalized test ID or identical
location/problem/evidence. Same locations alone are `possibly_related`. The
reports retain each observation, including repeats across checks/roles, and report
unique confirmed counts separately. Shared findings are not claimed as uniquely
discovered by either source. No LLM is called to infer correctness or deduplicate.

Tester summaries cover frozen cases, selectors actually commanded, additional
regressions, failures and executable resolution. Commanded selectors cannot prove
collection in every testing framework; inspect raw stdout when collection matters.
Reviewer severity counts, final findings, Auditor checks/warnings, architecture
alternatives/selections/actual resume, implementer repair counts and per-cycle
gate triggers are retained. Unknown review/test semantic overlap and causal fixes
remain unknown or zero confirmed, not estimated. No subjective coding score or
composite AI score is generated. One sample cannot justify removing a role.

## Usage ceilings

Optional project configuration:

```yaml
live_limits:
  max_role_invocations: 9
  max_infrastructure_retries: 0
  max_autonomous_fix_cycles: 1
  # max_measured_tokens: 100000   # requires exposed authoritative total_tokens
```

Limits apply whenever configured, including offline fixtures for testing. Count
every persisted process attempt, including unfinished starts. Global retry ceilings
are separate from per-role runner retry limits. The fix ceiling cannot exceed two.
When another required invocation/repair would exceed a ceiling, the workflow stops
in `FAILED`, `failure_kind=usage_limit`, with `LIVE_USAGE_LIMIT_REACHED` evidence.
Acceptance never skips required tests, Reviewer, Auditor or human gates. A new
explicit task is required to change the frozen budget/configuration after failure.
Token ceilings check exposed total-token counters before subsequent calls; if a
previous invocation lacks authoritative totals, the next call fails closed. A
single in-flight exec may exceed a token ceiling: this is a between-call ceiling,
not a hard provider billing limit. CLI-internal request retries are not separate
framework role invocations; authoritative reported usage remains the source.

## Experiments and live validation

`experiment-plan` freezes a distinct task ID/branch/worktree/evidence identity with
the original base commit and a supplied routing file. It refuses an existing ID,
an incomplete source, other incomplete runs and task-bound architecture proposals
that require explicit new contracts. It performs preparation only. Execute through
ordinary `resume`, sequentially. `compare` requires completed executable runs with
equivalent contracts (except task ID/base-ref notation), identical resolved base
and project configuration. It exposes raw telemetry and evaluation dimensions;
redirect JSON output to save a comparison, without mutating source runtimes.

`live-smoke --allow-live` performs preflight and then one disposable read-only
role task. A matching successful runner report is required for `--workflow`.
The latter exercises independent design, implementation, test implementation,
executable checks, review and acceptance with at most four role calls. Both
preserve fixtures and report exact safe argv, CLI version, execution status,
telemetry availability, sandbox observations, deviations and unresolved risks.
They have no framework-level infrastructure retries or repair loops.

`pilot-preflight` checks Git/clean baseline, tracked context, protected historical
paths, contracts/configuration, explicit routing syntax, required command/module
availability, budgets, CLI flags and login. Missing prerequisites stop before any
model call. `pilot --allow-live` executes the ordinary lifecycle and never supplies
human approval. A gate-stopped attempt records failed acceptance validation and
the actual pending workflow outcome; use normal approvals/resume and the final
`pilot-report` for completed evidence. Authentication diagnostics are reduced to
fixed prerequisites; credential files, environment dumps and auth output are not
persisted in validation reports.

Live statuses are `NOT_RUN`, `BLOCKED_BY_ENVIRONMENT`, `FAILED`, `PASSED`, with an
independent factual `executed` flag. Offline fake-process coverage does not imply
successful real inference. Current durable acceptance evidence explicitly records
unverified live behavior and missing OML access. Filesystem hashes detect accidental
corruption, not tampering by an operator controlling all local evidence. Existing
shared-Git and lack of OS-level read confinement remain explicit limitations.
