# Project state

Stage 16–17 update (2026-10-05): `docker_isolated` implements an opt-in enforced
OS boundary and real Pilot 0 validation. See the separate
[current assessment](STAGE16_17_ASSESSMENT.md), [capability matrix](ISOLATION_CAPABILITIES.md)
and [runbook](STAGE16_17_RUNBOOK.md). The earlier framework-v1 state below is
historical; its shared-worktree limits still apply to the old backend. The new
backend uses private staged Git metadata and actual signed probes for admission.
No live model validation, OML or routing experiment was performed.

Source of truth: `Reusable Multi-Agent Engineering System for Codex.md` in the repository root, especially section 40. The current user-approved implementation includes Stage 9 observability/evaluation and Stage 10 pilot machinery; the source architecture document is unchanged.

Stages 1–4 retain strict contracts/configuration, explicit model routing, owned Git worktrees, safe cleanup, isolated-session runner and local persisted state. Version-1 preparation-only runs remain compatible and do not silently gain agent execution.

Stages 5–8 add explicit workflow contracts and version-2 execution state, two-phase independent testing, deterministic local integration, actual command gates, immutable review/audit reports, human architecture decisions and a shared two-cycle repair budget. Ordinary and data-critical fake-backend end-to-end acceptance paths are implemented. Major phases still require explicit completion approval.

Public context is operator-whitelisted and read from the frozen base during independent design. The design is hashed and write-once. Tester phase B receives that exact artifact; independent and additional regression mappings are distinct. Implementer cannot modify reserved independent test files. Reviewer/Auditor are read-only and their mutations reject the candidate. Protected data, including ignored files, is hashed around agent execution.

Persistent state remains local JSON under ignored `.agent_runs/`, with owned checkouts under ignored `.agent_worktrees/`. There is no SQL database, queue, cloud service, dashboard, remote push, force cleanup or automatic architecture approval. Accepted results remain local integration branches; the primary branch is untouched.

Known limits: worktrees share Git metadata and there is no OS-level read-isolation guarantee. Context manifests enforce explicit inputs, not arbitrary-process read confinement. Architecture detection combines rule-based classification, explicit task proposals and agent escalation; it is not a complete semantic detector. Local commands and public context are trusted operator inputs. Unsupported versions, altered identities, policy violations and ambiguous interrupted model executions fail closed. Stale runtime locks require manual owner verification.

Stage 9 is implemented: versioned strict invocation telemetry, measured duration and exposed usage only, immutable reconstructable task/role summaries, deterministic finding normalization and conservative duplicate/resolution attribution, per-task evaluation and consolidated pilot reports, read-only CLI inspection/comparison, explicit sequential routing-experiment preparation, and invocation/retry/fix/measured-token guardrails. Budget failures stop acceptance explicitly without changing routing or raising the two-cycle repair maximum.

Stage 10 machinery is implemented: opt-in runner and multi-agent smoke commands, disposable Git fixtures, safe prerequisite diagnostics, durable JSON/Markdown attempt reports, deterministic project preflight, ordinary-workflow pilot execution, and a portable OML data-hardening contract/configuration/context template. OML-specific identity/temporal/historical rules remain in project-owned artifacts. All placeholder paths must be adapted against the actual repository; no current OML structure is fabricated.

Live status on 2026-10-04: `codex-cli 0.159.2` is installed, but `codex login status` reports not logged in. Both live smoke attempts stopped at authentication preflight and performed zero role invocations. The actual OML Git repository was not supplied or listed among available local projects; its pilot is blocked by missing access/adaptation. Model entitlement and real sandbox/output behavior remain unverified. Offline fixtures successfully exercise the live command paths without real quota.

See `docs/FRAMEWORK_V1_ACCEPTANCE.json` and `.md` for the final assessed offline test status and explicit framework-v1 classification. Framework implementation is not evidence that real-agent behavior or engineering value per usage has been demonstrated. Those questions remain unanswered until authenticated live validation and a real project pilot. Wheel building remains unverified; this folder still has no Git metadata, while executable target projects require a committed repository.

Final validation on 2026-10-04: all 91 original regression cases passed (41 foundation + 50 workflow cases) in 1,575.46 seconds, including independent design, actual command gates, read-only/protected-data enforcement, architecture/completion approval, two bounded repairs, escalation and deterministic recovery. Stage 9–10 adds 59 offline cases, all covered successfully through new groups and corrected-case/targeted reruns. There are 150 collected cases and 22 valid schemas. Windows pytest ID normalization and nested disposable Git path limits were found and fixed, then verified again. The durable classification is `FRAMEWORK_V1_ACCEPTED_WITH_LIMITATIONS`, with real-agent behavior and OML execution explicitly unverified. See the framework acceptance report for commands and remaining operational risks.

The tests demonstrate ordinary/data-critical acceptance, human architecture selection/resume, mid-workflow architecture blocking, two-phase independent design and executable test mapping, read-only violations, ignored protected-data violations, successful first/second repairs, exhausted two-cycle escalation, separate infrastructure retries, major-phase approval, deterministic resume and recovery of completed backend evidence. Real models/authentication and live sandbox behavior remain untested. See README for lifecycle, schemas, CLI, evidence, approval and compatibility details.
