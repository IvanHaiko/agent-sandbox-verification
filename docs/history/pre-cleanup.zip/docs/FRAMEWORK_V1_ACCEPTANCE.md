# Framework v1 acceptance — 2026-10-04

Classification: **FRAMEWORK_V1_ACCEPTED_WITH_LIMITATIONS**. The implementation
and offline checks pass; real-agent behavior remains unverified. The
machine-readable assessment is [FRAMEWORK_V1_ACCEPTANCE.json](FRAMEWORK_V1_ACCEPTANCE.json).

All **150 currently collected offline cases** were covered successfully across
the original regression run and new focused groups: 91 original cases passed
in 1,575.46 seconds, and 59 added cases passed in grouped/targeted runs. Initial
new failures exposed Windows pytest separator normalization and Git's internal
path limit for nested disposable fixtures; both were fixed and the affected
end-to-end cases were rerun successfully. No real model quota was consumed.

Representative executed validation commands (each used its own unused basetemp):

```powershell
python -m pytest -q --basetemp=.agent_runs/stages9-10-regression
python -m pytest -q tests/test_telemetry.py tests/test_live.py --basetemp=.agent_runs/stage9-new-tests
python -m pytest -q tests/test_evaluation_additional.py tests/test_telemetry.py::test_end_to_end_immutable_reporting_and_readonly_cli --basetemp=.agent_runs/stage9-final-report-tests
python -m pytest -q tests/test_live.py::test_offline_live_commands_runner_then_workflow --basetemp=.agent_runs/stage9-path-recovery
python -m pytest -q tests/test_telemetry.py::test_end_to_end_immutable_reporting_and_readonly_cli --basetemp=.agent_runs/s9-final-report
```

Additional focused groups verified timeout/protocol/retry telemetry, duplicate
execution IDs, project-preflight failures, malformed envelope/result integrity,
and rejection of full v1 acceptance based solely on offline tests. Completion
approval and completed-backend recovery were repeated against the final lifecycle
changes. All 22 schemas, portable OML artifacts, Python compilation and CLI help
validate. The source architecture document is unchanged.

Stages 1–8 retain their task/configuration contracts, separate contexts and owned
Git worktrees, two-phase independent testing, executable integration gates,
read-only review/audit, human decisions, bounded two-cycle repairs and immutable
deterministic resume. Stage 9 adds measured invocation/role/task telemetry,
deterministic findings/evaluation, usage ceilings and controlled routing comparisons.
Stage 10 adds opt-in disposable live validation, project preflight and ordinary
workflow pilot execution, plus the portable OML hardening contract/configuration.

The actual live validation result is **BLOCKED_BY_ENVIRONMENT**, not passed.
`codex-cli 0.159.2` is installed and required exec flags are present, but
`codex login status` reports not logged in. Both smoke attempts stopped before
any role invocation. Their raw attempt reports are linked in the JSON assessment.
The OML repository was not supplied or available among accessible local projects;
its report separately records that blocker. Model identifiers/entitlements, real
output-schema adherence and real sandbox behavior have not been verified.

Offline tests execute fake processes and real local Git/test commands. They
exercise runner smoke and the four-role workflow smoke paths without real quota.
This is implementation evidence, not a live-agent or OML pilot success. The real
questions of engineering value versus model usage and routing superiority remain
unanswered until authenticated execution against a real representative project.

Telemetry records only backend-exposed counters, exact configured routing,
timestamps, measured durations, retries, results, candidates and provenance
digests. Missing historical metrics remain unavailable. No monetary cost is
inferred. Final aggregates and evaluation reports can be rebuilt from lower-level
write-once evidence and reject mismatched identities or altered source artifacts.

Evaluation deliberately limits attribution. Identical test identifiers and exact
location/problem/evidence support duplicate relationships; location-only overlap
is merely possible. Failing executable cases can be confirmed and resolved by
later exact-selector passing runs. Review/audit allegations retain unknown ground
truth, and absence in a later report is not a confirmed fix. One sample cannot
justify removing a role or recommending a stronger model.

Limits remain explicit: no OS-level read isolation, shared Git metadata, trusted
operator context/commands, local corruption detection rather than tamper-proof
security, stale-lock handling, sequential routing experiments, unverified wheel
building and Windows Git path constraints. A measured-token ceiling checks between
invocations and cannot bound a single in-flight exec. Usage ceilings fail closed
without bypassing mandatory review/audit/tests or approval.

To complete live acceptance, authenticate the CLI, configure literal accepted
model identifiers explicitly, run one runner smoke, then one matching workflow
smoke, then adapt and execute the bounded OML reconciliation pilot with its human
completion gate. No broad model matrix is authorized or automatically scheduled.
