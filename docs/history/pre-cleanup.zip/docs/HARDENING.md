# Post-v1 hardening (Stages 11–15)

This is an additive revision. The source architecture document, v1 acceptance
assessment, existing project history, and previous task evidence are unchanged.
The prior `FRAMEWORK_V1_ACCEPTED_WITH_LIMITATIONS` remains historical evidence.
See [implementation map](HARDENING_PLAN.md), [capability matrix](ISOLATION_CAPABILITIES.md),
[state machine](HARDENED_STATE_MACHINE.md), and [new assessment](HARDENING_ASSESSMENT.md).

## Guarantees and their limits

| Previous limitation / finding | Mechanism and concrete implementation | Guarantee | Remaining limit |
| --- | --- | --- | --- |
| Ambiguous orchestrator authority | `controller.Controller` names the existing deterministic authority; `workflow.Workflow`, `gates.acceptance`, `state_machine.transition` retain transitions, gates, integration, counters, evidence, and final outcomes | Deterministic enforcement | LLM orchestrator is still a proposal-producing role; operator configuration and commands are trusted |
| Repository-local runtime required | `Configuration` runtime v2 accepts an absolute external root, namespaces projects by ID plus repository-path digest, and separates runs/workspaces | Prevented by path validation for v3 | External storage is not itself an OS read boundary; changing repository location needs explicit runtime migration |
| Shared Git objects leak other roles' information | `isolation.IsolatedCheckout` bundles only a selected baseline ref and its reachable history into a fresh repository without remotes, object alternates, or shared metadata. Hardened Implementer **and** Tester use independent object databases | Prevented for ordinary Git discovery | Baseline history is visible. Direct filesystem access to siblings needs runner enforcement. Reviewer/integration/Auditor still use ordinary owned worktrees |
| Sandbox flags treated as evidence | `IsolationCapabilities.require` requires availability, verification, and evidence for every mandatory capability before any hardened role invocation | Prevented admission of unavailable/unknown backends | Backend implementations and their verification evidence are trusted controller components. The current runner fails admission; no weaker fallback exists |
| Shared editable Python environment | Role-local `.venv`, sanitized Python environment, `uv run --offline --no-sync`, pre-invocation and integrated-candidate import-origin evidence; actual test argv records use local Python | Detected import escape; role-local execution | Dependencies must already be provisioned locally. No automatic network install. Arbitrary non-Python operator commands remain trusted; there is no general interpreter discovery |
| Accessible approval JSON can unblock a gate | `approvals.ApprovalStore` binds HMAC records to task, baseline, configuration, approval name, and exact package/candidate. CLI v3 approvals require interactive confirmation. Resumes verify signatures | Integrity protected | Key storage is private only when the admitted runner enforces `controller_storage`; no protection from the local user/admin, compromised controller, or a dishonest adapter. Trusted Python controller API is the test seam, not an agent approval channel |
| Ignored historical-data mutations escape Git diff | Existing `policies.protected_snapshot` already covered file bytes. V3 adds `path_manifest` (directories/symlinks) plus ignored-file inspection and read-only whole-workspace manifests before/after roles | Detected and acceptance blocked | Persistent changes are detected; write-and-restore side effects need prevention by a verified backend. No portable read-only mounting is claimed |
| Only a Markdown test plan is frozen | Controller signs the actual independent test commit and blob manifest before implementation. Candidate commits and dirty test files are compared with the frozen identity | Integrity protected identity; detected mutation | Semantic classification is conservative. Hash identity detects every source change; AST flags explain common weakening rather than prove arbitrary semantic equivalence |
| Implementer edits acceptance tests | Existing `contexts.check_role_paths`/`GitWorkflow.commit_result` ownership checks retained. Controller never synchronizes acceptance/holdout objects into hardened Implementer's private Git database | Prevented ordinary test ownership overlap; Git disclosure prevented | Default independent paths come from `workflow.test_paths`; `tests/unit/**` can remain Implementer-owned if explicitly allowed and outside independent paths |
| Hidden tests leak via feedback | `hardening.holdout_paths` partitions independent selectors into visible and holdout commands. Controller executes both. Repair bundles contain public clauses and blocking counts, never raw stdout/stderr/test selectors/reviewer prose. `check_feedback` detects obvious assertion/source leakage | Prevented raw forwarding; detected obvious leakage | Hidden-test filesystem secrecy remains capability dependent. Public clauses can legitimately disclose expected behavior. General natural-language information-flow checking is not claimed |
| Invalid tests burn implementation repair cycles | Explicit approved interface assertions enable deterministic equality contradiction detection; syntax errors or a structured Reviewer dispute also trigger `TEST_DISPUTE`. Separate max-two dispute counter; authenticated resolution; mechanically checked and read-only reviewed correction; new signed frozen test version. Reviewer may resolve purely contractual assumptions against the same version | Deterministic state/counter enforcement | Natural-language consistency is a Reviewer judgment, never inferred from test failure. Semantic changes, coverage removal or arbitrary assertion replacement require human reconciliation/new approved task |
| Major work branches before contract approval | `major_phase` controls `CONTRACT_APPROVAL`; package includes acceptance criteria and public interface. Existing completion approval remains `major_phase OR completion.requires_user_approval` | Prevented pre-approval role execution in v3 | Legacy v2 tasks preserve their original behavior; no silent migration |
| Interface/contract drift | `INTERFACE_FREEZE` signs the public package and baseline interface blob IDs. Every v3 role result must name the frozen contract version; gate evidence rejects mismatches | Integrity protected baseline; detected mismatch | Material clarifications use a new task ID with an incremented contract version, not in-place evidence edits. Interface file changes are architecture-gated |
| Tester contract contains private instructions | `contracts.lint_contract` emits structured warnings for private names, internal paths, prescriptive steps, private runtime and implementation hints. V3 fails closed on warnings. Public package excludes Implementer scope/context; hardened prompt preparation uses it | Detected heuristic leakage | Ambiguous warnings need a clarified task. Public contracts may still be jointly wrong; model diversity is not mechanically guaranteed |
| Undeclared architectural changes | `mechanical_gates.architecture_drift` checks dependency/lock/schema/migration paths, new top-level modules, configured public signatures, interface files, and configured import boundaries from the actual candidate diff | Detected; architecture gate enforced | Path/AST heuristics are configurable, not a semantic architecture proof. Exact detected diff approval never authorizes future drift |
| Initially non-data task bypasses audit | V3 retains declared classification initially and then matches actual changed paths against `data_critical_patterns`; records reasons and provisions Auditor automatically | Mandatory actual-diff escalation | Repository-specific patterns must be configured correctly |
| Auditor trusts Implementer-generated validation | Controller runs frozen audit commands in Auditor's environment against the integrated commit; captures metrics, command output, environment and input hashes. Quantitative expectations have explicit bounds or explicit unavailability | Independently regenerated deterministic evidence; gate enforced | Without supplied commands/thresholds, unavailability is recorded rather than invented. Auditor commands are trusted configuration; OS input write prevention remains capability dependent |
| Reviewer is primed by green-test framing | Separate read-only `review_blind` pass gets contract/interface and raw implementation diff without outcomes/commit messages; pass B receives structured validation. Blocking findings from either pass block acceptance | Context separation in supplied bundle | Full test artifacts may still be inspectable in Reviewer's workspace; conceptual passes are not a claim of OS read isolation for Reviewer. Comments/docstrings are untrusted claims |

## Opt-in configuration and migration

Old runtime layouts and state v1/v2 remain supported. Existing runs use their
frozen configuration. When current configuration switches to runtime v2,
`Controller.run_dir` can locate a historical `.agent_runs/<task-id>` run without
rewriting it. Duplicate IDs in both layouts fail closed. Cleanup uses the frozen
run configuration. Hardened isolated repositories are conservatively retained:
ordinary worktree cleanup must not delete their only independent Git history.

For a **new** hardened task, configure:

```yaml
runtime:
  version: 2
  root: C:/agentctl-runtime  # absolute, separate from the project; use a writable location
```

Add this to a normal workflow task (paths/modules are task-specific):

```yaml
hardening:
  version: 1
  contract_version: 1
  interface:
    description: Approved public behavior and signatures
    files: []  # baseline files also explicitly listed in workflow.public_context
    assertions: []  # optional expression/expected/criterion records for comparable disputes
  holdout_paths: [tests/acceptance/TASK-ID/holdout/**]
  python_modules: [project_package]
  max_disputes: 2
  data_expectations: []  # operator-supplied registered bounds or explicit unavailable records
  audit_commands: []     # argv arrays returning distinct named JSON metrics
```

`hardening.version: 1` selects state v3. Runtime v2 alone does not silently harden
old tasks. Additive report `contract_version` fields remain optional in legacy
schemas but are mandatory in v3 controller validation. New phase names are
`review_blind`, `test_correction`, and `test_correction_review`. `ARCH_BLOCKED`
is an explicit architecture-stop outcome; it requires a decision package.

Architecture detector configuration is under `architecture.drift`:
`sensitive_paths`, `package_roots`, `public_api_paths`, and `import_boundaries`
(`from` path glob plus `deny` import globs). Defaults also inspect common Python
dependencies, lock files, schemas and migrations.

The contract approval package and digest are available from `agentctl inspect`.
`approve-contract --package-sha256 ... --approved-by ...` requires a matching
package and an interactive CLI confirmation. Architecture and completion CLI
approvals use the same interactive rule for v3. `resolve-test-dispute` authorizes
a correction against the current contract; semantic changes require a new task.

Generated test and audit programs also require the backend's isolated
`AgentRunner.run_command` adapter. The controller does not execute that untrusted
code via an unsandboxed subprocess in hardened mode. The base adapter fails
closed; an admitted future backend must enforce its verified boundary for both
role invocations and generated-program execution. Offline harness programs are
fixed fixtures and deliberately do not constitute a production sandbox.

Do **not** enable hardened production runs with the built-in runner expecting
them to proceed: its missing verified capabilities deliberately block execution.
No OML-specific logic, model benchmarking, model quota use, or production-data
modification was introduced.
