"""Read measured failed one-shot evidence; write separate final assessment only."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


execution = load(OUT/'execution.json')
diagnosis = load(OUT/'baseline-diagnosis.json')
admission = load(ROOT/'docs/stage19d-evidence/fresh-admission.json')
driver = load(OUT/'driver-admission.json')
baseline = load(OUT/'primary-and-historical-baseline.json')
assert execution['verdict'] == 'BLOCKED_BEFORE_INFERENCE'
assert execution['responses_dispatch_attempts'] == execution['tool_attempts'] == execution['successful_tools'] == 0
assert diagnosis['fixture_content_crlf_baseline'] and not diagnosis['fixture_content_exact_lf']
assert diagnosis['git_status_returncode'] == 0 and diagnosis['git_status_entries'] == []
assert not execution['signed_live_authorization'] and not execution['signed_no_credits']
assert execution['primary_framework_and_historical_evidence_unchanged']
assert sha(ROOT/'validation/stage19_final_smoke.py') == driver['entrypoint_sha256']
assert sha(ROOT/'validation/test_stage19_final_smoke_driver.py') == driver['test_source_sha256']
assert sha(OUT/'driver-tests.xml') == driver['offline_xml_sha256']
assert sha(OUT/'authorization.json') == driver['authorization_receipt_sha256']
tests = ET.parse(OUT/'driver-tests.xml')
assert len(list(tests.iter('testcase'))) == 23 and not list(tests.iter('failure')) and not list(tests.iter('error'))
for name, expected in admission['source_sha256'].items():
    assert sha(ROOT/name) == expected
historical = {name: value for name, value in baseline.items()
              if name.startswith('docs/') or (name.startswith('STAGE') and '/' not in name)}
for name, expected in historical.items():
    assert sha(ROOT/name) == expected
framework = {name: value for name, value in baseline.items()
             if name.startswith(('agent_system/', 'tests/', 'validation/', 'examples/', '.agent_system/'))}
for name, expected in framework.items():
    assert sha(ROOT/name) == expected
artifact_hashes = {name: sha(OUT/name) for name in ('execution.json', 'baseline-diagnosis.json',
    'driver-admission.json', 'driver-tests.xml', 'authorization.json', 'one-shot-latch', 'primary-and-historical-baseline.json')}
assessment = {
    'date': '2026-10-06', 'verdict': 'BLOCKED_BEFORE_INFERENCE', 'execution': execution,
    'exact_authorized_scope': {**load(ROOT/'docs/stage19d-evidence/final-smoke-proposal.json'),
        'proposal_only': False, 'authorized': True, 'executed': False, 'model': 'gpt-6-sol',
        'model_amendment': 'Explicit subsequent human confirmation: Use gpt-6-sol only'},
    'allowance_consumed': True, 'retry_performed': False, 'fixture_repaired': False,
    'root_cause': {
        'category': 'DRIVER_PREFLIGHT_NEWLINE_REQUIREMENT',
        'executed_check': "read_bytes() == b'value = 1\\n' and clean git status",
        'observed': 'Clean owned checkout; baseline src/example.py is 11 bytes with CRLF',
        'proposal_check': "Path('src/example.py').read_text() == 'value = 1\\n'",
        'proposal_would_accept_baseline': True,
        'explanation': 'The new driver byte check was stricter than the accepted mutation template, whose text read normalizes CRLF. This local driver requirement caused the block; dirty workspace, provider transport and tool execution were not established failure causes.',
        'driver_mistake_acknowledged': True,
        'not_a_live_transport_observation': True},
    'pre_inference_requirements': {
        'source_bundle': 'PASS', 'codex_executable': 'PASS',
        'docker_image_engine_config_project_binding': 'PASS', 'signed_stage18c_transport_proof': 'PASS',
        'exclusive_one_shot_latch': 'CREATED; allowance consumed even on preflight failure',
        'existing_oauth_validity': 'NOT_REACHED; credential store was not opened',
        'fresh_signed_live_smoke_grant': 'NOT_ISSUED', 'execution_client_bound_signed_no_credit_attestation': 'NOT_ISSUED',
        'human_confirmation_time': '2026-10-06 08:29:30 UTC; captured at first handling, never refreshed',
        'human_confirmation_receipt_preserved': True},
    'counts': {'live_responses_requests': 0, 'live_codex_turns': 0, 'docker_tool_calls': 0,
        'successful_tools': 0, 'refreshes': 0, 'reconnections': 0, 'model_discovery_requests': 0,
        'automatic_retries': 0, 'offline_driver_tests_passed': 23},
    'end_to_end_success_requirements': {
        'openai_responses': 'NOT_ATTEMPTED', 'validated_live_response': 'NOT_OBSERVED',
        'codex_dynamic_tool_request': 'NOT_ATTEMPTED', 'controller_canonical_match': 'NOT_ATTEMPTED',
        'isolated_execution_bridge': 'NOT_ATTEMPTED', 'docker_mutation': 'NOT_ATTEMPTED',
        'docker_verification': 'NOT_ATTEMPTED', 'final_validated_model_response': 'NOT_ATTEMPTED',
        'strict_agent_result': 'NOT_PRODUCED', 'exact_value_2_content': False,
        'only_expected_file_changed': 'No smoke mutation occurred; owned checkout remains clean',
        'expected_mutation_output': 'NOT_PRODUCED', 'expected_verification_output': 'NOT_PRODUCED'},
    'cleanup_and_security': {
        'model_selected_host_execution': False, 'unexpected_tool_dispatch': False, 'credentials_loaded': False,
        'credential_escape_observed': False, 'stale_owned_containers': 0,
        'disposable_codex_home': 'Never created; absence verified',
        'disposable_role_storage': 'No smoke role storage created',
        'primary_framework_unchanged_during_execution': True,
        'historical_evidence_unchanged_during_execution': True,
        'independent_historical_files_rehashed': len(historical),
        'independent_framework_files_rehashed': len(framework),
        'framework_exception': 'New authorized driver/tests and separate final assessment/evidence artifacts only; no prior framework file edited',
        'raw_provider_payloads_retained': False, 'structural_telemetry': 'No provider events occurred; safe preflight and count metadata only'},
    'source_bundle_sha256': admission['source_bundle_sha256'],
    'codex_sha256': admission['codex_sha256'], 'admission_binding': admission['binding'],
    'executed_driver_sha256': driver['entrypoint_sha256'], 'offline_driver_validation': driver,
    'artifact_sha256': artifact_hashes,
    'remaining_uncertainties': ['Existing OAuth validity was not checked because the ordered preflight stopped earlier.',
        'Current account availability of gpt-6-sol is unverified; historical saved catalog does not list it.',
        'No repaired SIWC live path was exercised; Stage19d offline readiness does not establish live success.'],
    'stage19_passed': False, 'stage19_status': 'FAIL_LIVE_TRANSPORT',
    'stage20_technically_admissible': False, 'stage20_started': False,
    'stop_state': 'Consumed execution preserved; no retry, fixture correction, credential refresh/reconnect or Stage20 performed.'}
(ROOT/'STAGE19_FINAL_CONFORMANCE_SMOKE.json').write_text(json.dumps(assessment, indent=2)+'\n', encoding='utf-8')
md = f'''# Final Stage19 conformance smoke — stage19-final-conformance-1

**`BLOCKED_BEFORE_INFERENCE`**. The one-shot entry point was invoked once and the exclusive latch consumed the execution allowance. Zero Responses requests, zero Codex turns and zero Docker tool calls occurred. No automatic retry, fixture repair, OAuth refresh/reconnection or Stage20 execution followed.

Stage19 passed: **false**. Stage19 remains **`FAIL_LIVE_TRANSPORT`**. Stage20 technically admissible: **false**.

## Exact block and responsibility

The new driver rejected the initial workspace because it required `src/example.py` to equal `b'value = 1\\n'` as bytes. The read-only post-failure check established that the owned checkout is Git-clean and the file is `value = 1\\r\\n` (11 bytes).

This was a driver preflight mistake: its LF-byte requirement was stricter than the accepted mutation argv, which uses `read_text()` and would normalize this CRLF baseline to the expected `value = 1\\n`. No dirty-workspace failure, provider rejection, tool-boundary failure or task-execution failure was demonstrated. The stricter check prevented inference. The executed driver and one-shot latch are preserved; neither was modified or rerun after the failure.

## Authorization and preflight

The accepted proposal remains byte-preserved. The user explicitly amended its sole model to `gpt-6-sol`; reasoning remains `low`. Every other bound remains the proposal's exact scope: task `STAGE19-SMOKE`, execution `stage19-final-conformance-1`, one implementer/implementation turn, at most three Responses requests, exactly two sequential successful tool calls, exact mutation/verification argv, no retries, alternate model/reasoning, additional role command/file or role network.

The new driver's 23 offline guard tests passed before invocation. They cover exact argument/order/output restrictions, atomic scope rejection, final tool-free response, strict fixed result, disabled parallel calls and exclusive latch behavior. They did not cover CRLF preflight input, which explains why this unnecessary rejection survived driver validation.

| Requirement | Measured state |
|---|---|
| Current production bundle | Passed; `{admission['source_bundle_sha256']}` |
| Pinned Codex executable | Passed; `{admission['codex_sha256']}` |
| Docker image/engine/settings/project binding | Matched fresh Stage19d admission |
| Signed Stage18c transport proof for new runtime | Verified |
| Exclusive execution latch | Created, allowance consumed |
| Existing ChatGPT-plan OAuth validity | Not reached; protected credential store was not opened |
| Fresh signed live-smoke authorization | Not issued |
| Execution/client-bound signed no-credit attestation | Not issued |

The human OFF billing confirmation was recorded at first handling of the authorization, **2026-10-06 08:29:30 UTC**, and was never given a newer timestamp. Its original receipt and explicit model amendment are retained. No attestation was fabricated for a client, since credential validation was never reached. Current official docs support the [gpt-6-sol request identifier and low reasoning](https://developers.openai.com/api/docs/models/gpt-6-sol); account availability remains unverified, and the historical saved catalog does not list this model.

## Independent result and cleanup checks

The disposable workspace remains clean with baseline value 1; it was not changed to the required `value = 2\\n`. Neither expected tool output nor a strict AgentResult was produced. The complete end-to-end path was not exercised, so no live success is claimed.

The driver verified zero stale owned containers. It never created a disposable Codex home or smoke role storage. No model-selected host execution, unexpected tool call or credential escape occurred; credentials were not loaded. No raw provider IDs, arguments, model prose or response body exists from this execution. Safe metadata records only preflight checks, failure and zero counts.

The driver compared the existing primary/framework and historical file baseline after failure and found it unchanged. The final assessment independently rehashed **{len(historical)}** historical report/documentation/evidence files and **{len(framework)}** framework/test/example/configuration files against that baseline. Production source hashes and executed driver/test/XML/authorization hashes were also reverified. New driver/tests, separate final reports and execution evidence are the authorized artifact additions; no prior framework source or historical report/evidence was edited.

## Evidence and stop state

Executed driver SHA256: `{driver['entrypoint_sha256']}`.

- [Execution record](docs/stage19-final-conformance-evidence/execution.json)
- [Read-only baseline diagnosis](docs/stage19-final-conformance-evidence/baseline-diagnosis.json)
- [Human authorization receipt](docs/stage19-final-conformance-evidence/authorization.json)
- [Driver admission](docs/stage19-final-conformance-evidence/driver-admission.json)
- [23 passing offline driver tests](docs/stage19-final-conformance-evidence/driver-tests.xml)
- [Consumed one-shot latch](docs/stage19-final-conformance-evidence/one-shot-latch)
- [Primary/historical integrity baseline](docs/stage19-final-conformance-evidence/primary-and-historical-baseline.json)
- [Machine-readable final assessment](STAGE19_FINAL_CONFORMANCE_SMOKE.json)

The original authorization does not permit another attempt. The fixture, production code, executed driver and credentials were left unchanged after the failure. Work stops at this assessment. Stage20 was not started and remains technically inadmissible.
'''
(ROOT/'STAGE19_FINAL_CONFORMANCE_SMOKE.md').write_text(md, encoding='utf-8')
print(json.dumps({'verdict': assessment['verdict'], 'historical_files_reverified': len(historical),
    'framework_files_reverified': len(framework), 'stage19_passed': False, 'stage20_technically_admissible': False}, indent=2))
