# Post-v1 hardening implementation map

Historical Stages 1–10 and their acceptance artifacts remain unchanged.

| Stage | Existing mechanism | Missing work |
| --- | --- | --- |
| 11 | `workflow.Workflow`, `gates.acceptance`, `state_machine.transition` already make deterministic decisions; `protected_snapshot` already hashes ignored data | Name Controller explicitly; external runtime v2; independent Git checkout; normative verified-capability admission; controller HMAC records; role-local Python/import evidence; whole-workspace ignored-file checks |
| 12 | `contexts.check_role_paths`, `integration.commit_result` already separate test ownership; immutable design/mapping evidence | Freeze executable test commit before implementation; holdout ownership; contract-level repair feedback; separate bounded dispute state |
| 13 | Frozen task/configuration digests and major-phase completion gate | Version-3 lifecycle, contract approval before branching, frozen public interface, result contract versions, contract linter |
| 14 | Initial architecture classification, role architecture packages, initial data classification | Actual-diff detectors; mandatory auditor escalation; quantitative expectation evaluation; controller-regenerated audit evidence; Reviewer passes A/B |
| 15 | 150 offline regression cases; disposable fake CLI fixtures | Adversarial Pilot 0 cases, capability matrix and separate conservative assessment |

Compatibility: old project/task configuration creates state v1/v2 and follows its original graph. New task `hardening.version: 1` opts into state v3 and requires runtime v2 outside the repository. Existing evidence is never upgraded in place. Unsupported isolation must stop before role invocation; no backend fallback. No model calls or production pilot are authorized by this phase.
