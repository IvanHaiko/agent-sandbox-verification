"""Bounded, non-executing Responses lifecycle validation and safe structural metadata."""
import json

from .agent_transport import strict_json
from .errors import AgentSystemError


def canonical_arguments(value):
    if not isinstance(value, str): raise AgentSystemError('Malformed function arguments')
    parsed = strict_json(value)
    if not isinstance(parsed, dict): raise AgentSystemError('Function arguments must be an object')
    return json.dumps(parsed, sort_keys=True)


def validate_response(gate, raw, metadata):
    """Return private candidates. Never modify authorization or replay state."""
    gate.alive()
    if len(raw) > gate.policy.max_response_bytes: raise AgentSystemError('Model output overflow')
    try: text = raw.decode('utf-8').replace('\r\n', '\n')
    except UnicodeDecodeError: raise AgentSystemError('Invalid model output encoding') from None
    gate.secrets.reject(text)
    if not text.endswith('\n\n'): raise AgentSystemError('Partial model SSE frame')
    items, ids, calls, candidates = {}, set(), set(), {}
    response_id, completed, previous_sequence = None, False, -1
    metadata.update(secret_checked=True, item_ids_stable=True, call_ids_stable=True,
                    output_indices_stable=True, arguments_equal=True)

    def deny(reason, flag=None):
        if flag: metadata[flag] = False
        raise AgentSystemError(reason)

    def identity(original, item):
        if item.get('id') != original['id']: deny('Model item identity mutation', 'item_ids_stable')
        if item.get('type') != original['type']: deny('Model item type mutation')
        if original['type'] == 'function_call':
            if item.get('call_id') != original['call_id']: deny('Model call identity mutation', 'call_ids_stable')
            if any(item.get(k) != original.get(k) for k in ('name', 'namespace')):
                deny('Model function identity mutation')

    for frame in text.split('\n\n')[:-1]:
        if not frame: continue
        gate.alive()
        data, event = [], None
        for line in frame.split('\n'):
            if line.startswith('data: '): data.append(line[6:])
            elif line.startswith('event: ') and event is None: event = line[7:]
            else: deny('Unsupported SSE framing')
        value = strict_json('\n'.join(data))
        gate.secrets.reject(json.dumps(value))
        if not isinstance(value, dict): deny('Invalid model event')
        kind = value.get('type')
        if completed or kind not in gate.EVENTS or event not in (None, kind):
            deny('Unknown or out-of-order model event')
        metadata['event_counts'][kind] = metadata['event_counts'].get(kind, 0) + 1
        if 'sequence_number' in value:
            seq = value['sequence_number']
            if type(seq) is not int or seq < 0 or seq <= previous_sequence:
                deny('Replayed or decreasing model event sequence')
            previous_sequence = seq
        if 'item' in value and kind not in ('response.output_item.added', 'response.output_item.done'):
            deny('Unexpected item on model event')
        if kind in ('response.created', 'response.in_progress', 'response.completed'):
            response = value.get('response')
            if not isinstance(response, dict) or not isinstance(response.get('id'), str) or not response['id']:
                deny('Missing model response identity')
            if response_id is None:
                if kind != 'response.created' or response['id'] in gate.seen_responses:
                    deny('Missing creation or replayed model response')
                response_id = response['id']
            elif response['id'] != response_id or kind == 'response.created':
                deny('Model response identity mismatch')
            output = response.get('output')
            if not isinstance(output, list): deny('Malformed model response output')
            if kind != 'response.completed':
                if response.get('status') != 'in_progress': deny('Invalid model progress status')
                for index, item in enumerate(output):
                    gate._item(item)
                    if index not in items: deny('Unregistered progress output')
                    identity(items[index]['item'], item)
                continue
            metadata['terminal_status'] = 'completed' if response.get('status') == 'completed' else 'invalid'
            if response.get('status') != 'completed': deny('Unsuccessful model completion')
            if len(output) != len(items): deny('Conflicting final output inventory', 'stream_final_bijection')
            final_calls = set()
            for index, item in enumerate(output):
                record = items.get(index)
                if record is None or not record['done']: deny('Missing completed model item', 'stream_final_bijection')
                gate._item(item)
                identity(record['item'], item)
                if item['type'] == 'function_call':
                    if item.get('status') != 'completed': deny('Incomplete final function')
                    canonical = canonical_arguments(item.get('arguments'))
                    if canonical != record['canonical']: deny('Conflicting final function arguments', 'arguments_equal')
                    final_calls.add(item['call_id'])
                    candidates[item['call_id']] = canonical
                elif item != record['snapshot']:
                    deny('Conflicting final non-function snapshot')
            if final_calls != calls: deny('Conflicting final function inventory', 'stream_final_bijection')
            usage = response.get('usage')
            if isinstance(usage, dict):
                # Only recognized numeric usage; arbitrary nested provider fields never exported.
                metadata['usage'] = {k: usage[k] for k in ('input_tokens', 'output_tokens', 'total_tokens')
                                     if type(usage.get(k)) is int and usage[k] >= 0}
            metadata['stream_final_bijection'] = True
            completed = True
            continue
        if response_id is None: deny('Model event before creation')
        if 'response_id' in value and value['response_id'] != response_id: deny('Model response identity mismatch')
        index = value.get('output_index')
        if type(index) is not int or index < 0: deny('Invalid model output index', 'output_indices_stable')
        if kind == 'response.output_item.added':
            item = value.get('item')
            gate._item(item)
            iid = item.get('id')
            if not isinstance(iid, str) or not iid or iid in ids or iid in gate.seen_items:
                deny('Duplicate or replayed model item', 'item_ids_stable')
            if index in items: deny('Duplicate model output index', 'output_indices_stable')
            record = {'item': item, 'done': False, 'arguments_done': False,
                      'arguments': item.get('arguments', ''), 'deltas': 0}
            if item['type'] == 'function_call':
                if item.get('status') != 'in_progress' or not isinstance(record['arguments'], str):
                    deny('Invalid function creation')
                cid = item['call_id']
                if cid in calls or cid in gate.seen_calls: deny('Duplicate or replayed model tool call', 'call_ids_stable')
                calls.add(cid)
                if len(calls) > gate.policy.max_tool_calls: deny('Model tool count exceeded')
                metadata['function_call_count'] += 1
            ids.add(iid)
            items[index] = record
            metadata['transitions']['item_added'] += 1
            continue
        record = items.get(index)
        if record is None or record['done']: deny('Orphan or terminal model item event', 'output_indices_stable')
        original = record['item']
        if kind == 'response.output_item.done':
            item = value.get('item')
            gate._item(item)
            identity(original, item)
            if item['type'] == 'message' and item.get('status') != 'completed': deny('Incomplete model message')
            if item['type'] == 'reasoning' and item.get('status') not in (None, 'completed'): deny('Incomplete model reasoning')
            if item['type'] == 'function_call':
                if not record['arguments_done'] or item.get('status') != 'completed': deny('Incomplete function lifecycle')
                if canonical_arguments(item.get('arguments')) != record['canonical']:
                    deny('Conflicting completed function arguments', 'arguments_equal')
            record.update(done=True, snapshot=item)
            metadata['transitions']['item_done'] += 1
            continue
        if value.get('item_id') != original['id']: deny('Model argument/item identity mismatch', 'item_ids_stable')
        if kind.startswith('response.function_call_arguments.'):
            if original['type'] != 'function_call' or record['arguments_done']: deny('Orphan or duplicate model arguments')
            # Undocumented alternate identities cannot override registered authority.
            if any(k in value for k in ('call_id', 'name', 'namespace')): deny('Unexpected argument identity fields')
            if kind.endswith('.delta'):
                if not isinstance(value.get('delta'), str): deny('Malformed argument delta')
                record['arguments'] += value['delta']
                record['deltas'] += 1
                metadata['transitions']['arguments_delta'] += 1
            else:
                arguments = value.get('arguments')
                canonical = canonical_arguments(arguments)
                if (record['deltas'] or original.get('arguments')) and arguments != record['arguments']:
                    deny('Arguments differ from streamed fragments', 'arguments_equal')
                gate.validate_arguments(canonical)
                record.update(arguments_done=True, arguments=arguments, canonical=canonical)
                metadata['transitions']['arguments_done'] += 1
        elif original['type'] == 'function_call':
            deny('Non-function event on function item')
        else:
            message_event = kind.startswith(('response.content_part.', 'response.output_text.'))
            if message_event != (original['type'] == 'message'): deny('Model content event type mismatch')
            if kind.endswith('.delta') and not isinstance(value.get('delta'), str): deny('Malformed model content delta')
    if not completed: deny('Missing model completion')
    gate.alive()
    return candidates, ids, response_id


def structural_metadata(size):
    return {'response_bytes': size, 'secret_checked': False, 'event_counts': {},
            'function_call_count': 0, 'item_ids_stable': None, 'call_ids_stable': None,
            'output_indices_stable': None, 'arguments_equal': None, 'stream_final_bijection': None,
            'terminal_status': 'missing', 'validation_passed': False,
            'transitions': {'item_added': 0, 'arguments_delta': 0, 'arguments_done': 0, 'item_done': 0}}
