"""Production protocol/MIME matrix with synthetic HTTP peers and executor traps."""
import builtins
import copy
from dataclasses import replace
from email.message import Message
import json
import os
from pathlib import Path
import socket
import subprocess
import threading
import time

import pytest
from jsonschema import Draft202012Validator

import agent_system.model_tool_boundary as boundary
from agent_system.codex_tool_session import CodexToolSession
from agent_system.errors import AgentSystemError
from agent_system.responses_lifecycle import canonical_arguments
from agent_system.responses_http import mime_category
from agent_system.runners.docker_isolated import DockerIsolatedRunner
from agent_system.runners.tool_docker import ToolDockerRunner
from test_model_tool_boundary import body, function, message, sse, tool_request
from test_stage19c_reconciliation import policy, stream, encode, case, CASES, replay_with_new_response_and_item
from test_transport_diagnostics import response


def namespaced(raw):
    events = [json.loads(frame.split('\ndata: ', 1)[1]) for frame in raw.decode().strip().split('\n\n')]
    for event in events:
        if isinstance(event.get('item'), dict) and event['item'].get('type') == 'function_call':
            event['item']['namespace'] = boundary.NAMESPACE
        if isinstance(event.get('response', {}).get('output'), list):
            for item in event['response']['output']:
                if isinstance(item, dict) and item.get('type') == 'function_call': item['namespace'] = boundary.NAMESPACE
    return events


@pytest.fixture
def traps(monkeypatch):
    reached = []
    def deny(label):
        def trap(*a, **kw):
            reached.append(label)
            pytest.fail('Rejected response reached ' + label)
        return trap
    for obj, key in [(CodexToolSession, 'handle'), (boundary.IsolatedExecutionBridge, 'execute'),
                     (ToolDockerRunner, 'run_tool'), (DockerIsolatedRunner, '_docker'),
                     (subprocess, 'run'), (subprocess, 'Popen'), (socket, 'create_connection'),
                     (Path, 'write_text'), (Path, 'write_bytes'), (Path, 'touch'),
                     (os, 'remove'), (os, 'unlink'), (os, 'rename'), (os, 'replace')]:
        monkeypatch.setattr(obj, key, deny(key))
    original_open = builtins.open
    def checked_open(file, mode='r', *args, **kwargs):
        if isinstance(mode, str) and any(flag in mode for flag in ('w', 'a', '+', 'x')): deny('host_file_write')()
        return original_open(file, mode, *args, **kwargs)
    monkeypatch.setattr(builtins, 'open', checked_open)
    return reached, deny('codex_downstream_acceptance')


@pytest.mark.parametrize('name,valid,old_valid', CASES, ids=[c[0] for c in CASES])
def test_stage19c_attacks_now_fail_closed(name, valid, old_valid, traps):
    p = policy()
    gate = boundary.ResponsesGate(p)
    raw = case(p, name)
    if name not in ('partial_stream', 'nested_output_schema'):
        raw = encode(namespaced(raw))
    if name == 'replayed_event':
        events = namespaced(case(p, name))
        raw = encode(events, number=False)
    if name == 'replayed_call':
        gate.response(raw)
        raw = replay_with_new_response_and_item(raw)
    before = dict(gate.authorized_arguments)
    if valid:
        assert gate.response(raw) == raw
    else:
        with pytest.raises(AgentSystemError): traps[1](gate.response(raw))
        assert gate.authorized_arguments == before
    assert traps[0] == []


MORE = ['delta_before_added', 'done_before_added', 'item_done_before_added', 'duplicate_added',
        'duplicate_item_done', 'event_after_terminal', 'missing_item_done', 'response_id_mutation',
        'output_index_mutation', 'namespace_mutation', 'decreasing_sequence', 'duplicate_sequence',
        'wrong_namespace', 'malformed_stream_arguments', 'schema_identity', 'workspace_mismatch',
        'role_mismatch', 'secret_response', 'post_done_delta', 'bad_argument_event_fields']


def altered(p, name):
    events = namespaced(encode(stream(p)))
    if name in ('delta_before_added', 'done_before_added', 'item_done_before_added'):
        target = {'delta_before_added': 2, 'done_before_added': 4, 'item_done_before_added': 5}[name]
        events.insert(1, events.pop(target))
    elif name == 'duplicate_added': events.insert(2, copy.deepcopy(events[1]))
    elif name == 'duplicate_item_done': events.insert(6, copy.deepcopy(events[5]))
    elif name == 'event_after_terminal': events.insert(6, copy.deepcopy(events[2]))
    elif name == 'post_done_delta': events.insert(5, copy.deepcopy(events[2]))
    elif name == 'missing_item_done': events.pop(5)
    elif name == 'response_id_mutation': events[-1]['response']['id'] = 'mutated'
    elif name == 'output_index_mutation': events[2]['output_index'] = 1
    elif name == 'namespace_mutation': events[5]['item']['namespace'] = 'other'
    elif name == 'wrong_namespace':
        for event in events:
            if 'item' in event: event['item']['namespace'] = 'functions'
        events[-1]['response']['output'][0]['namespace'] = 'functions'
    elif name == 'malformed_stream_arguments': events[4]['arguments'] = '{'
    elif name == 'secret_response': events[2]['delta'] = 'synthetic-private-response'
    elif name == 'bad_argument_event_fields': events[4]['call_id'] = 'alternate'
    elif name in ('schema_identity', 'workspace_mismatch', 'role_mismatch'):
        args = tool_request(p)
        args[{'schema_identity': 'execution_id', 'workspace_mismatch': 'workspace_id', 'role_mismatch': 'role'}[name]] = 'other'
        item = function(p)
        item['arguments'] = json.dumps(args)
        return sse([item])
    raw = encode(events)
    if name in ('decreasing_sequence', 'duplicate_sequence'):
        for seq, event in enumerate(events): event['sequence_number'] = seq
        events[3]['sequence_number'] = 0 if name == 'decreasing_sequence' else 2
        raw = encode(events, number=False)
    return raw


@pytest.mark.parametrize('name', MORE)
def test_additional_invalid_lifecycle_and_security(name, traps):
    p = policy()
    gate = boundary.ResponsesGate(p, boundary.SecretFilter(['synthetic-private-response']))
    before = (dict(gate.authorized_arguments), set(gate.seen_calls), set(gate.seen_items), set(gate.seen_responses))
    with pytest.raises(AgentSystemError): traps[1](gate.response(altered(p, name)))
    assert (gate.authorized_arguments, gate.seen_calls, gate.seen_items, gate.seen_responses) == before
    assert traps[0] == []
    if name == 'secret_response': assert gate.last_response_metadata == {'secret_checked': False, 'validation_passed': False}


def test_valid_message_reasoning_interleaving_optional_sequences_and_canonical_arguments(traps):
    p = policy()
    assert boundary.ResponsesGate(p).response(sse([message()]))
    reasoning = {'type': 'reasoning', 'id': 'reasoning-1', 'summary': [], 'status': 'completed'}
    assert boundary.ResponsesGate(p).response(sse([reasoning, message()]))
    events = namespaced(encode(stream(p, count=2)))
    # Register both calls, then interleave their independent lifecycles.
    interleaved = [events[0], events[1], events[6], events[2], events[7], events[3], events[8],
                   events[4], events[9], events[5], events[10], events[11]]
    gate = boundary.ResponsesGate(p)
    gate.response(encode(interleaved))
    assert len(gate.authorized_arguments) == 2 and gate.last_response_metadata['stream_final_bijection']
    for event in events: event.pop('sequence_number', None)
    assert boundary.ResponsesGate(p).response(encode(events, number=False))
    events = namespaced(encode(stream(p)))
    events[-1]['response']['output'][0]['arguments'] = json.dumps(tool_request(p), indent=2)
    assert boundary.ResponsesGate(p).response(encode(events))
    assert canonical_arguments('{}') == '{}'
    item = function(p); item['arguments'] = '{}'
    # Empty JSON object is protocol-valid but cannot satisfy this bound executable schema.
    with pytest.raises(AgentSystemError): traps[1](boundary.ResponsesGate(p).response(sse([item])))


def test_atomic_authority_preserved_after_success_then_every_failure(traps):
    p = policy(); gate = boundary.ResponsesGate(p)
    gate.response(sse([function(p)]))
    original = gate.authorized_arguments
    state = (set(gate.seen_calls), set(gate.seen_items), set(gate.seen_responses))
    for name in MORE:
        raw = altered(p, name).replace(b'response-1', b'response-fresh').replace(b'fc-0', b'fc-fresh').replace(b'call-0', b'call-fresh')
        with pytest.raises(AgentSystemError): traps[1](gate.response(raw))
        assert gate.authorized_arguments is original
        assert (gate.seen_calls, gate.seen_items, gate.seen_responses) == state


def test_request_has_exact_namespaced_strict_schema_and_no_injected_inventory(traps):
    p = policy(); gate = boundary.ResponsesGate(p)
    value = body(p)
    value['tools'] = [{'type': 'web_search'}, {'type': 'namespace', 'name': 'evil', 'tools': []}]
    value['client_metadata'] = {'tools': [{'type': 'file_search'}]}
    out = gate.request(json.dumps(value).encode())
    ns = out['tools'][0]; tool = ns['tools'][0]
    assert len(out['tools']) == len(ns['tools']) == 1
    assert ns['type'] == 'namespace' and ns['name'] == boundary.NAMESPACE
    assert tool['name'] == boundary.TOOL and tool['strict'] is True
    assert tool['parameters'] == boundary.tool_spec(p)['inputSchema']
    assert tool['parameters']['additionalProperties'] is False
    assert 'client_metadata' not in out
    removed = gate.request(json.dumps({**body(p), 'input': [{'type': 'additional_tools', 'role': 'developer', 'tools': [{'type': 'web_search'}]}]}).encode())
    assert removed['input'] == [] and removed['tools'] == out['tools']
    for kind in ('tool_search_output', 'tool_search_call'):
        with pytest.raises(AgentSystemError): gate.request(json.dumps({**body(p), 'input': [{'type': kind, 'tools': []}]}).encode())
    schema = json.loads((Path(__file__).resolve().parents[1]/'docs/stage19d-evidence/codex-schema/v2/ThreadStartParams.json').read_text())
    dynamic = {'type': 'namespace', 'name': boundary.NAMESPACE, 'description': ns['description'], 'tools': [boundary.tool_spec(p)]}
    Draft202012Validator({'$ref': '#/definitions/DynamicToolSpec', 'definitions': schema['definitions']}).validate(dynamic)


def synthetic_upstream(p, monkeypatch, value, cancel=None):
    credentials = {'access_token': 'synthetic-access-token-123456', 'refresh_token': 'synthetic-refresh-token-123456', 'id_token': 'synthetic-id-token-123456',
                   'client_id': 'oaiapp_fixture', 'scopes': [boundary.PLAN_SCOPE], 'expires_at': time.time()+300}
    class Store:
        def read(self, name): return credentials
    class Approvals:
        def verify(self, name):
            if name.startswith('no-credits/'):
                return {'credits_fallback_disabled': True, 'execution_id': p.binding.execution_id,
                        'client_id': credentials['client_id'], 'operator': 'synthetic', 'attested_at': time.time()}
            return {'authorized': True, **p.identity(), 'model': p.binding.model, 'reasoning': p.binding.reasoning, 'route': boundary.UPSTREAM}
    class Opener:
        def open(self, request, **kwargs):
            assert request.full_url == boundary.UPSTREAM and request.method == 'POST'
            return value
    monkeypatch.setattr(boundary, 'build_opener', lambda *handlers: Opener())
    return boundary.PlanUpstream(Store(), p, Approvals(), lambda: None, cancel)


TRANSPORT = [
    ('missing_valid', None, 'valid', True), ('expected_valid', 'text/event-stream', 'valid', True),
    ('unrecognized_valid', 'unknown', 'valid', True), ('malformed_valid', ';', 'valid', True),
    ('explicit_plain', 'text/plain', 'valid', False), ('json_sse', 'application/json', 'valid', False),
    ('missing_bad', None, 'bad', False), ('expected_bad', 'text/event-stream', 'bad', False),
    ('utf8', None, 'utf8', False), ('overflow', None, 'overflow', False),
    ('timeout', None, 'timeout', False), ('cancellation', None, 'cancellation', False),
    ('truncated', None, 'truncated', False), ('no_completion', None, 'no_completion', False),
    ('unsupported', None, 'unsupported', False), ('chunked', None, 'chunked', True),
    ('secret_escaped', None, 'secret_escaped', False), ('wrong_status', None, 'wrong_status', False),
    ('duplicate_mime', 'text/event-stream', 'duplicate_mime', False),
    ('plain_parameter', 'text/plain; type=text/event-stream', 'valid', False),
]


@pytest.mark.parametrize('name,mime,kind,valid', TRANSPORT, ids=[c[0] for c in TRANSPORT])
def test_complete_transport_validation(name, mime, kind, valid, monkeypatch, traps):
    p = policy(); raw = sse([function(p)])
    cancel = threading.Event(); extra = ()
    if kind == 'bad': raw = b'event: response.created\ndata: {}\n\n'
    elif kind == 'utf8': raw = b'\xff'
    elif kind == 'overflow': p = replace(p, max_response_bytes=100)
    elif kind == 'timeout': p = replace(p, deadline=time.monotonic()+.08)
    elif kind == 'truncated': raw = raw[:-1]
    elif kind == 'no_completion': raw = raw[:raw.rfind(b'event: response.completed')]
    elif kind == 'unsupported': raw = b'event: arbitrary\ndata: {"type":"arbitrary"}\n\n'
    elif kind == 'chunked':
        raw = (hex(len(raw))[2:]+'\r\n').encode()+raw+b'\r\n0\r\n\r\n'
        extra = ('Transfer-Encoding: chunked',)
    elif kind == 'secret_escaped': raw = sse([message('synthetic-access-token-123456')]).replace(b'synthetic-access-token-123456', b'\\u0073ynthetic-access-token-123456')
    elif kind == 'duplicate_mime': extra = ('Content-Type: text/plain',)
    with response(raw, mime, extra=extra, stuck=kind in ('timeout', 'cancellation')) as peer:
        if kind == 'wrong_status': peer.status = 201
        if kind == 'cancellation':
            timer = threading.Timer(.03, cancel.set); timer.start()
        upstream = synthetic_upstream(p, monkeypatch, peer, cancel)
        gate = boundary.ResponsesGate(p)
        if valid:
            accepted = gate.response(upstream(body(p)))
            assert accepted and upstream.last_response_metadata['validation_passed']
            assert upstream.last_response_metadata['missing_mime_tolerated'] == (mime != 'text/event-stream')
        else:
            with pytest.raises(AgentSystemError): traps[1](gate.response(upstream(body(p))))
            assert not gate.authorized_arguments and not gate.seen_calls
        if kind == 'cancellation': timer.join()
        assert traps[0] == []


def test_readonly_policy_and_codex_namespace_are_independent(traps):
    p = replace(policy(), binding=boundary.InvocationBinding('readonly', 'reviewer', 'TASK', 1, 'offline', 'low'), phase='review')
    item = function(p); args = tool_request(p); args['read_only'] = False; item['arguments'] = json.dumps(args)
    with pytest.raises(AgentSystemError): traps[1](boundary.ResponsesGate(p).response(sse([item])))
    p = policy(); gate = boundary.ResponsesGate(p); gate.response(sse([function(p)]))
    class Bridge: pass
    bridge = Bridge(); bridge.runner = None
    session = CodexToolSession('unused', 'unused', 'unused', type('Relay', (), {'gate': gate})(), bridge, p)
    session.thread_id, session.turn_id = 'thread', 'turn'
    for ns in (None, 'functions', 'other'):
        with pytest.raises(AgentSystemError):
            # Call original method because the executor trap replaces handle.
            ORIGINAL_HANDLE(session, {'id': str(ns), 'method': 'item/tool/call', 'params': {
                'threadId': 'thread', 'turnId': 'turn', 'tool': boundary.TOOL, 'namespace': ns,
                'callId': 'call-1', 'arguments': tool_request(p)}})


def test_metadata_history_has_only_safe_structure_and_secret_suppression(traps):
    p = policy(); gate = boundary.ResponsesGate(p, boundary.SecretFilter(['synthetic-private-response']))
    events = namespaced(encode(stream(p)))
    events[-1]['response']['usage'] = {'input_tokens': 1, 'output_tokens': 2, 'total_tokens': 3,
                                     'account_id': 'synthetic-account-not-exportable'}
    gate.response(encode(events))
    metadata = json.dumps(gate.response_metadata_history)
    for text in ('synthetic-account', 'exec-1', 'call-0', 'fc-0', 'print(1)', 'argv'):
        assert text not in metadata
    assert gate.last_response_metadata['usage'] == {'input_tokens': 1, 'output_tokens': 2, 'total_tokens': 3}
    original = gate.authorized_arguments
    with pytest.raises(AgentSystemError): gate.response(altered(p, 'secret_response'))
    assert gate.authorized_arguments is original
    assert gate.response_metadata_history[-1] == {'secret_checked': False, 'validation_passed': False}


def test_private_inspection_never_publishes_and_gate_serializes_atomic_commit(traps):
    p = policy(); gate = boundary.ResponsesGate(p)
    raw = sse([function(p)])
    gate.inspect_response(raw)
    assert not gate.authorized_arguments and not gate.seen_calls
    results = []
    def run():
        try: gate.response(raw); results.append('accepted')
        except AgentSystemError: results.append('rejected')
    workers = [threading.Thread(target=run) for _ in range(2)]
    for worker in workers: worker.start()
    for worker in workers: worker.join(2)
    assert sorted(results) == ['accepted', 'rejected']
    assert len(gate.authorized_arguments) == 1


ORIGINAL_HANDLE = CodexToolSession.handle
