# Stage 19 — Authorized minimal live smoke

Date: 2026-10-05, Europe/Berlin. Verdict: **BLOCKED_BEFORE_INFERENCE**.

One real official OAuth connection was attempted. It did not establish a validated connection. Preflight stopped closed; no inference, model catalog request, dynamic live tool, full role workflow, automatic fix cycle or Stage 20 execution occurred. Stage 18c production sources and previous assessments remain unchanged.

[Machine-readable assessment](STAGE19_AUTHORIZED_LIVE_SMOKE.json) · [Protected-store inspection](docs/stage19-evidence/auth-inspection.json) · [Offline security regression](docs/stage19-evidence/offline-focused.xml).

## 1. OAuth connection

The explicitly opt-in operator wrapper launched the existing official Sign in with ChatGPT flow in the system browser, using the existing loopback listener, PKCE/state/nonce and Controller credential store. Browser consent returned an issued registration, which was saved. The connection then failed with a locally suppressed `AgentSystemError`; the process exited with code 1.

Inspection found only `host.json` and `registration.json`. `credentials.json` is absent; connection and plan permission are false. Protected-store ACL verification passed. The issued client is represented in exported evidence only by SHA256. Account identity was not successfully established.

The initial wrapper did not retain the precise static error, so the failed step cannot be narrowed reliably to exchange, token validation or credential persistence. Whether a token response was received transiently is unknown. No successful token acquisition is claimed. No automatic second OAuth attempt or model execution was made. The wrapper now permits only exact static OAuth error literals in future diagnostics; this change was not exercised by another login.

The flow uses the official dynamic public-client contract, without a client secret or API key. [Official registration/sign-in documentation](https://developers.openai.com/siwc/token-sharing-open-source/sign-in).

## 2. Real inference

**Did not occur.** Real model executions: **0**. Real Responses requests: **0**. The connection helper has no inference path. No host Codex auth cache was read or imported.

## 3. Execution count

One OAuth connection attempt, zero real model executions, zero automatic retries. The separately authorized minimal execution was never admitted. The existing request's authorization was not converted into a signed exact live-smoke record because its prerequisites failed.

## 4. Model and reasoning

No model or reasoning was actually used. Selection did not proceed after the failed prerequisite. No configured alias, fixture model or model from the host's Codex session is treated as a selected live target.

## 5. Entitlement

**Not proven.** No account model catalog was requested. A future continuation must obtain the account-specific catalog rather than infer availability from Codex's bundled list. [Official model discovery and inference contract](https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference).

## 6. Dynamic Docker tool execution

**Not run live.** No dynamic model call, response-gate release, canonical call-ID/argument check or role container was started for the Stage 19 live path. Stage 18c's synthetic measurements remain valid engineering history but are not presented as live observations.

## 7. Host execution

No model-selected host operation occurred; there was no model response. Trusted Python/ACL utilities and the interactive system browser handled OAuth. The existing native Codex/model/tool topology was not redesigned. The independent offline regression did start a synthetic local Codex protocol session, which is not a real model execution.

## 8. Credentials

No raw access, refresh or ID token was printed or exported by the wrapper. No credential record was persisted. Controller storage is outside the framework and role roots, with its existing owner/SYSTEM ACL. Registration metadata remains there to preserve the official host/client identity.

No credential escape was observed. A live token-visibility/exfiltration probe was not reached, so this stopped attempt does not prove the live credential boundary. Token exchange/validation internals were not captured or dumped for diagnosis.

## 9. Disposable task

**Not started.** No live repository/task was created because OAuth failed first. No framework project files were edited on behalf of a model. Changes in this task are the opt-in operator wrapper, assessment builder, reports and offline test evidence.

## 10. Cleanup

The OAuth process exited. The existing listener context closed its socket; its lock context left no lock file in the inspected store. No live Codex session or tool containers existed to clean up. No temporary token record is present. Protected `host.json` and `registration.json` are intentionally retained, not leaked session artifacts.

No live workspace mutation or live cleanup probe occurred. This is cleanup of the failed authentication attempt, not a claim that the full live execution cleanup passed.

## 11. Usage

No provider inference usage fields were returned. Input/output/total tokens, remaining plan usage and monetary cost are **unavailable**, not estimated. Observed execution/request counters are zero because no inference code was invoked.

## 12. Credits/billing

The operator reported balance **0** and automatic top-up disabled, then explicitly confirmed that **“Allow other apps to use credits after reaching your usage limit”** is disabled. The account setting is operator-confirmed, not programmatically verified. No signed execution-bound no-credit attestation was issued because OAuth preflight failed. There was no paid/API-key fallback and no observed inference billing behavior.

The documented setting is in ChatGPT **Settings → Usage**, below **App limits**. It must be disabled and remain disabled during the smoke before a current client/execution-bound attestation can be signed. Software does not control this account setting. [Official settings documentation](https://learn.chatgpt.com/docs/sign-in-with-chatgpt).

## 13. Security regression

After stopping, **150 focused offline cases passed**, with no failures/errors/skips. They cover OAuth/credential policies, fixed endpoints, model/tool identity, dispatch, host fallback denial, replay, byte/time limits, secret rejection, live-authorization refusal before HTTP and a synthetic native Codex dynamic-tool roundtrip. No live account was used by tests.

Fresh Stage 19 Docker network/timeout/cancellation probes were not run because no live binding was admitted. Stage 18c's real Docker evidence is preserved but not relabeled as this stage's fresh evidence. The assessment verifies the Stage 18c production source hashes and earlier checkpoint hashes unchanged.

## 14. Deviations from assumptions

- Real OAuth failed to establish a validated connection despite receiving an issued client registration. Its precise cause was suppressed by the initial operator wrapper and is unknown.
- The required credit-fallback setting was subsequently confirmed disabled by the operator. Its execution-bound signed record remains unissued because OAuth failed first.
- Consequently model selection/entitlement, fresh live-target admission and exact signed approvals were not reached. No preflight was weakened to proceed.

## 15. Final verdict and next step

**BLOCKED_BEFORE_INFERENCE**. Stage 20 is **not technically admissible on Stage 19 evidence** and was not started.

The required account setting is now confirmed disabled. The next step is explicit operator instruction to continue OAuth diagnostics with the allowlisted error reporting. A successful connection must still be followed by entitlement/model selection, fresh exact-target admission, current signed no-credit attestation and exact live authorization before the single model execution. No second attempt is scheduled automatically.
