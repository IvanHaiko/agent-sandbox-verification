# Stage 19 — Authorized minimal live smoke

Date: 2026-10-05, Europe/Berlin. Verdict: **BLOCKED_BEFORE_INFERENCE**.

OAuth reconnection is now **successful**. Across the original attempt and the operator-authorized reconnection, three OAuth attempts occurred; the last passed strict ID-token verification and obtained plan permission. Stage 19 inference preflight remains closed: no model catalog request, dynamic live tool, full role workflow, automatic fix cycle or Stage 20 execution occurred. Stage 18c production sources and previous assessments remain unchanged.

[Machine-readable assessment](STAGE19_AUTHORIZED_LIVE_SMOKE.json) · [Protected-store inspection](docs/stage19-evidence/auth-inspection.json) · [Offline security regression](docs/stage19-evidence/offline-focused.xml).

## 1. OAuth connection

The explicitly opt-in operator wrapper launched the existing official Sign in with ChatGPT flow in the system browser, using the existing loopback listener, PKCE/state/nonce and Controller credential store. The original attempt failed with suppressed diagnostics. On the operator-authorized reconnection, the first attempt reported `ChatGPT ID token verification failed`. A subsequent diagnostic attempt passed the unchanged verifier and exited successfully.

Latest inspection found `host.json`, `registration.json` and protected `credentials.json`. Connection and plan permission are true; ACL verification passed. Evidence records account/client identity hashes, not token values. Signature/standard claims, subject, nonce and authorized-party checks all passed. [Safe reconnection evidence](docs/stage19-evidence/oauth-reconnection.json).

The earlier failure's root cause remains unestablished. Public discovery/JWKS matched the pinned issuer and RS256 configuration. Boolean-only diagnostic instrumentation observes the original verifier and does not bypass validation or change acceptance criteria. Tokens were successfully acquired on the last attempt and stored only in Controller storage. No model execution occurred. The preceding stopped checkpoint is retained in [the pre-reconnection report](docs/stage19-evidence/before-reconnection-report.md) and [assessment](docs/stage19-evidence/before-reconnection-assessment.json).

The flow uses the official dynamic public-client contract, without a client secret or API key. [Official registration/sign-in documentation](https://developers.openai.com/siwc/token-sharing-open-source/sign-in).

## 2. Real inference

**Did not occur.** Real model executions: **0**. Real Responses requests: **0**. The connection helper has no inference path. No host Codex auth cache was read or imported.

## 3. Execution count

Three OAuth connection attempts total, zero real model executions. The additional attempts followed the operator's explicit reconnection request. The minimal live execution remains unadmitted; no exact execution/model-bound live-smoke record has been created.

## 4. Model and reasoning

No model or reasoning was actually used. This continuation completed OAuth reconnection only. No configured alias, fixture model or model from the host's Codex session is treated as a selected live target.

## 5. Entitlement

**Not proven.** No account model catalog was requested. A future continuation must obtain the account-specific catalog rather than infer availability from Codex's bundled list. [Official model discovery and inference contract](https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference).

## 6. Dynamic Docker tool execution

**Not run live.** No dynamic model call, response-gate release, canonical call-ID/argument check or role container was started for the Stage 19 live path. Stage 18c's synthetic measurements remain valid engineering history but are not presented as live observations.

## 7. Host execution

No model-selected host operation occurred; there was no model response. Trusted Python/ACL utilities and the interactive system browser handled OAuth. The existing native Codex/model/tool topology was not redesigned. The independent offline regression did start a synthetic local Codex protocol session, which is not a real model execution.

## 8. Credentials

No raw access, refresh or ID token was printed or exported by the wrapper. The credential record is persisted only in protected Controller storage outside the framework and role roots, with its existing owner/SYSTEM ACL. Registration metadata preserves the official host/client identity.

No credential escape was observed. A live token-visibility/exfiltration probe was not reached, so this stopped attempt does not prove the live credential boundary. Token exchange/validation internals were not captured or dumped for diagnosis.

## 9. Disposable task

**Not started.** This continuation completed OAuth reconnection; the exact disposable live target has not yet been prepared. No framework project files were edited on behalf of a model. Changes are the opt-in operator wrapper, assessment builder, reports and offline evidence.

## 10. Cleanup

The OAuth process exited. The existing listener context closed its socket; its lock context left no lock file in the inspected store. No live Codex session or tool containers existed to clean up. No temporary token record is present. Protected host, registration and credential records are intentionally retained for the connected account, not leaked session artifacts.

No live workspace mutation or live cleanup probe occurred. This is OAuth lifecycle cleanup, not a claim that the full live execution cleanup passed.

## 11. Usage

No provider inference usage fields were returned. Input/output/total tokens, remaining plan usage and monetary cost are **unavailable**, not estimated. Observed execution/request counters are zero because no inference code was invoked.

## 12. Credits/billing

The operator reported balance **0** and automatic top-up disabled, then explicitly confirmed that **“Allow other apps to use credits after reaching your usage limit”** is disabled. The account setting is operator-confirmed, not programmatically verified. A signed no-credit attestation remains to be bound to an exact prepared smoke execution. There was no paid/API-key fallback and no observed inference billing behavior.

The documented setting is in ChatGPT **Settings → Usage**, below **App limits**. It must be disabled and remain disabled during the smoke before a current client/execution-bound attestation can be signed. Software does not control this account setting. [Official settings documentation](https://learn.chatgpt.com/docs/sign-in-with-chatgpt).

## 13. Security regression

After stopping, **150 focused offline cases passed**, with no failures/errors/skips. They cover OAuth/credential policies, fixed endpoints, model/tool identity, dispatch, host fallback denial, replay, byte/time limits, secret rejection, live-authorization refusal before HTTP and a synthetic native Codex dynamic-tool roundtrip. No live account was used by tests.

Fresh Stage 19 Docker network/timeout/cancellation probes were not run because no live binding was admitted. Stage 18c's real Docker evidence is preserved but not relabeled as this stage's fresh evidence. The assessment verifies the Stage 18c production source hashes and earlier checkpoint hashes unchanged.

## 14. Deviations from assumptions

- Two initial OAuth failures preceded successful strict verification. Their root cause remains unestablished; the verifier was not changed.
- Credit fallback is operator-confirmed disabled. Model selection/entitlement, fresh live-target admission and exact signed approvals remain to be prepared. No preflight was weakened.

## 15. Final verdict and next step

**BLOCKED_BEFORE_INFERENCE**. Stage 20 is **not technically admissible on Stage 19 evidence** and was not started.

OAuth reconnection is complete and the required account setting is operator-confirmed disabled. The next step is entitlement/model selection and preparation of the disposable minimal-smoke target, fresh admission and exact signed approvals. No inference occurs before all those gates pass.
