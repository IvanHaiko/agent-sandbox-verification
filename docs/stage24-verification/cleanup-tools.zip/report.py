"""Write the requested final cleanup assessment from measured files and receipts."""
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'docs/stage24-verification'
before = json.loads((OUT / 'inventory-before.json').read_text())
after = json.loads((OUT / 'inventory-after.json').read_text())
audit = json.loads((OUT / 'integrity-audit.json').read_text())
archive = json.loads((OUT / 'archive-receipt.json').read_text())
dispositions = json.loads((OUT / 'file-dispositions.json').read_text())
assert audit['gate'] == 'passed'
old = before['counts']
new = after['counts']
removed_modules = [r['path'] for r in dispositions if r['path'].startswith('agent_system/')
                   and r['path'].endswith('.py') and r['disposition'].startswith('removed')]
role_rows = []
workflow_rows = []
for workflow in audit['workflows']:
    workflow_rows.append(f"| {workflow['workflow']} | {workflow['case_count']}/{workflow['case_count']} | PASS | Verified absent |")
    for role in workflow['roles']:
        role_rows.append(f"| {workflow['workflow']} | {role['role']} | `{role['session']}` | {role['seconds']:.3f} |")
test_rows = []
for name in ['focused-wsl.xml', 'focused-windows.xml']:
    suite = next(iter(ET.parse(OUT / name).getroot()))
    tests, skipped, failures, errors = (int(suite.attrib[k]) for k in ['tests', 'skipped', 'failures', 'errors'])
    assert not failures and not errors
    test_rows.append(f"| {name} | {tests-skipped} | {skipped} | 0 |")
module_list = '\n'.join('- `' + name + '`' for name in removed_modules)
report = f'''# Stage24 — Architecture Cleanup and Consolidation

**Verdict: STAGE24_PASS_ARCHITECTURE_CLEANUP.** Completed 7 October 2026.
No new features, model-routing experiments, OML work or subsequent hardening stage were started.

## A. Before

The repository contained {old['production']['files']} production Python files ({old['production']['lines']:,} physical lines),
{old['validation_scripts']['files']} non-test validation Python modules, and {old['test_files']} test files
(28 in `tests/`, 42 in `validation/`). Its README and CLI described older worktree/Docker/custom-transport
architectures. The validated native WSL path lived in the native Linux runner and three validation modules;
the Windows native runner remained experimental. Stage drivers, retry probes, protocol diagnostics,
OAuth/Responses machinery, older orchestration frameworks and generated evidence obscured that boundary.

Inventory and import/reference analysis were recorded before deletion:
[readable inventory](docs/stage24-verification/INVENTORY_BEFORE.md) and
[complete inventory with hashes/import edges](docs/stage24-verification/inventory-before.json).
Every relevant source/test/validation module is classified KEEP, CONSOLIDATE, LEGACY FALLBACK or
HISTORICAL VALIDATION. No original source was irretrievably discarded under DELETE: this checkout
has no Git metadata, so the complete original dependency closure was archived before active-path removal.

The native closure had no dependency on the custom backend. NativeLinuxCodexRunner used standard-library
process/filesystem code; the WSL Controller used that runner and the labels contract; optional roles used
jsonschema and the same Controller helpers. The old package's relative imports were retained together
inside the archive, rather than leaving a partial rollback backend in production.

Before mutation, nine focused guards passed on Windows and WSL. A fresh native baseline used
gpt-6.1-sol / medium, passed 23 frozen cases and removed all three repositories. See
[baseline test record](docs/stage24-verification/baseline-tests.json) and
[live baseline assessment](docs/stage24-verification/before/native-baseline/assessment.json).

## B. Removed

**Removed from active paths; original bytes remain recoverable in the verified archive.**
{len(removed_modules)} former production Python paths were removed outright. The former `controller.py`,
`roles.py`, `native_codex_linux.py` and package initializer were replaced with the consolidated native
implementation. The active package no longer contains the Windows native experiment, custom transport,
OAuth/Responses/tool relay, Docker runners, old orchestration/approval/persistence frameworks,
telemetry/routing experiments, admission probes or model protocol reconciliation.

Exact removed production Python paths:

{module_list}

All original validation drivers and validation tests were removed from the active tree. Only the validated
contract/harness and nine relevant guards were promoted, under ordinary names. The old 28 permanent test
files and 42 validation test files were archived; four current test files contain 37 focused test cases.
The obsolete 26 JSON schemas, `.agent_system/models.yaml`, `.agent_system/project.yaml`, old examples,
old `agentctl` entry point, PyYAML dependency and OAuth optional dependency were also removed from active use.

[Exact source/test/validation dispositions](docs/stage24-verification/REMOVED_FILES.md) list every original
module and why it left active source. [Every original file disposition](docs/stage24-verification/file-dispositions.json)
also covers the generated evidence and documents. In total, 2,352 original paths left the active tree;
four production files and the README/build metadata were replaced; `.gitignore` stayed unchanged.

## C. Consolidated

- `artifacts.py` is the single active implementation of candidate/artifact hashing, complete repository
  snapshots, mutation comparison, diffs, owned workspace creation/removal and frozen design/harness/task hashes.
- `native_codex_linux.py` builds native commands once for writable and read-only roles and extracts native
  model/session/provider/error metadata once. Role-specific receipt fields remain explicit.
- `controller.py` contains one handoff → blind design → freeze → deterministic acceptance → cleanup decision
  sequence. It replaces the Stage23 trial driver, removing global output roots, counters and historical gate logic.
- `roles.py` retains the supported structured-output schemas, read-only semantic role execution, review gate
  and Controller canonical-contract verification. Architect and Reviewer reuse the same native runner.
- `validation/labels_contract.py` holds the existing bounded task, Tester-specific instructions, validators
  and harness. The historical task identity was renamed from STAGE20-LABELS to LABEL-NORMALIZATION.
  Criteria, constraints, interface, harness, design/interface validation and failure interpretation are unchanged.
- `validation/native_workflow.py` is one integration driver, with a minimal path and optional full-chain
  preparation/execution. Retry drivers, catalogs, assessment generators and historical prerequisite chains are gone.

Legacy duplicates were removed from active use rather than merged into new generic abstractions. The audit
compares the original and current contract fields and validator/harness ASTs. No production module contains
Stage19–23 naming, experiment task IDs or retry counters. Native permission and workspace ownership names
are now `role_workspace` and `codex-role-*`; their permission/ownership semantics are preserved.

## D. Legacy

There is **no executable legacy package or automatic fallback**. The complete former package, including
74 package files (48 Python modules and 26 schemas), original configuration, tests, examples, drivers and
history is retained only as `docs/history/pre-cleanup.zip`. Manual rollback means extracting into a separate
checkout and explicitly using the former framework. No active import or package-discovery path enters it.

The snapshot contains {archive['entries']:,} original files. Every entry hash was verified before deletion;
the final archive SHA-256 was verified again. Its size is {archive['bytes']:,} bytes, compared with
{old['historical_source_bytes']:,} bytes of original inventoried content. See the
[archive receipt](docs/stage24-verification/archive-receipt.json).

641 final-assessment/evidence files are also expanded under `docs/history/`, preserving the original
relative layout for important Stage20, Stage21/21A, Stage22 and Stage23 records. Earlier/redundant evidence
and source remain compressed. [History index](docs/history/README.md) labels everything historical.
Historical references to early evidence require the full snapshot; they are not current operational instructions.

## E. Current architecture

Controller → fresh native WSL execution → validated workspace artifact → Controller-generated handoff
→ fresh role execution. The default small workflow is Implementer → Independent Tester → Controller
acceptance. Architect and Reviewer are optional. No native Data Auditor is added without a justified task.

Tester sees no candidate, source stub, diff, handoff or conversation history. Its design and Controller
harness are frozen before candidate exposure. Acceptance runs deterministically in a separate read-only
native sandbox, with no additional model/Tester request. Scope, full repository equality, interface,
candidate/design/harness/task hashes, fresh context, native model identity, process shutdown and cleanup
are acceptance requirements. Architect/Reviewer use read-only structured output. Controller alone owns
canonical state and normalization. Native failures remain explicit; they never substitute the old backend.

[README](README.md) is the single current architecture and operation document. The current API is
`agent_system.controller.run_workflow`; the old CLI/configuration/task formats belong to history.

## F. Verification

Final focused results:

| Evidence | Passed | Skipped | Failed/errors |
|---|---:|---:|---:|
{chr(10).join(test_rows)}

Commands: `python3 -m pytest -q -p no:cacheprovider --basetemp=/tmp/stage24-focused-linux-final
--junitxml=docs/stage24-verification/focused-wsl.xml` in WSL; the corresponding Windows Python command
used `.test-tmp/stage24-focused-windows-final`. Windows initially exercised unsupported Linux Git cleanup
and Linux absolute-path assumptions; fixture scope was corrected, and those eight Linux lifecycle cases
are explicitly skipped on Windows and pass in WSL. No Windows production backend was repaired or reintroduced.

The tests cover handoff authority, Tester blindness, freeze ordering, all three freeze hashes, deterministic
acceptance, acceptance mutation rejection, native identity/failure/scope predicates, read-only structured
output, schema compatibility, exact Architect scope/criterion validation, review rejection, linked artifact
rejection, cleanup on success/failure, environment filtering and owned Linux process-group timeout handling.

Live native results, all gpt-6.1-sol / medium:

| Workflow | Frozen cases | Controller | Owned workspaces |
|---|---:|---|---|
{chr(10).join(workflow_rows)}

The post-cleanup small workflow used two fresh role contexts. The full chain used Architect → Controller
normalization → Implementer → blind Independent Tester → frozen acceptance → Reviewer → final decision.
The Controller reviewed all four Architect clarifications and four risks as interpretations of existing
rules, preserving every original task field. Reviewer returned accept with zero blockers/findings.
Both post-cleanup workflows passed 24/24 frozen cases and cleanup. No failed native attempt or retry
was needed. No historical stage experiment was rerun.

| Workflow | Role | Native context | Seconds |
|---|---|---|---:|
{chr(10).join(role_rows)}

Evidence: [small assessment](docs/stage24-verification/after/minimal/assessment.json),
[full assessment](docs/stage24-verification/after/full/assessment.json),
[Controller normalization](docs/stage24-verification/after/full/contract-normalization.json),
[Reviewer](docs/stage24-verification/after/full/reviewer-result.json), and
[final integrity audit](docs/stage24-verification/integrity-audit.json).

The final read-only WSL audit verified eight distinct contexts, all 11 owned repositories absent,
freeze-before-exposure, immutable candidate/task/design/harness hashes, exact routing, read-only semantic
roles, deterministic acceptance, source hashes matching the execution snapshots and the rollback archive.
It performed no new model or acceptance calls. [Executed source](docs/stage24-verification/executed-source.json)
records the exact current source hashes; original source hashes are in the pre-deletion inventory.

## G. Size reduction

| Measure | Before | After |
|---|---:|---:|
| Production Python files, including initializer | {old['production']['files']} | {new['production_files']} |
| Non-test validation Python modules, including initializer | {old['validation_scripts']['files']} | {new['validation_scripts']} |
| Test files, tests + validation | {old['test_files']} | {new['test_files']} |
| Physical active production lines, including blanks/docstrings | {old['production']['lines']:,} | {new['production_lines']:,} |

Active production lines fell by {100*(1-new['production_lines']/old['production']['lines']):.1f}%. After cleanup there
are four substantive production modules plus an initializer, one integration driver plus a contract fixture
and initializer, and four test files. Historical snapshots are excluded from active counts; no surviving
runtime code is concealed in the history count. Counts are reproducible from
[before](docs/stage24-verification/inventory-before.json) and
[after](docs/stage24-verification/inventory-after.json) inventories.

The original inventoried source/docs content was 48.66 MB. The compressed history, expanded important
assessments/evidence and new audit artifacts occupy materially less space (the source/docs tree is about
14.5 MB before this final report). Existing ignored runtime/test caches are excluded from these comparisons.

## H. Remaining debt

- Validation still covers the existing bounded label-normalization contract, not arbitrary repositories,
  dependency-heavy projects or general abnormal-native-error recovery. This cleanup adds no such claims.
- Native execution requires an installed/authenticated Linux Codex CLI and supported permission/schema
  behavior. Future native releases may require compatibility verification; failures currently stop explicitly.
- This checkout has no Git metadata. Manual rollback therefore depends on preserving the verified archive;
  obsolete persisted workflows/CLI formats are historical, not migrated to the native API.

All twelve requested cleanup success criteria are met within the validated bounded workflow.
Stage24 ends here.
'''
(ROOT / 'STAGE24_ARCHITECTURE_CLEANUP.md').write_text(report, encoding='utf-8')
summary = {'verdict': 'STAGE24_PASS_ARCHITECTURE_CLEANUP', 'before': old, 'after': new,
    'focused_wsl_passed': 37, 'focused_windows_passed': 29, 'focused_windows_skipped': 8,
    'post_cleanup_live_workflows_passed': 2, 'post_cleanup_frozen_cases_passed': 48,
    'historical_archive_entries': archive['entries'], 'expanded_historical_files': 641,
    'removed_production_python_paths': len(removed_modules),
    'integrity_gate': audit['gate'], 'automatic_legacy_fallback': False}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary, indent=2))
