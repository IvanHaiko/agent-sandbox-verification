$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path -LiteralPath 'C:\Users\4ivan\codex-multi-agent').Path
$inventoryPath = Join-Path $taskRoot 'docs\stage24-verification\inventory-before.json'
$archiveReceipt = Get-Content -LiteralPath (Join-Path $taskRoot 'docs\stage24-verification\archive-receipt.json') -Raw | ConvertFrom-Json
$archivePath = Join-Path $taskRoot $archiveReceipt.archive
if ((Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $archiveReceipt.sha256) { throw 'Archive changed' }
$inventory = Get-Content -LiteralPath $inventoryPath -Raw | ConvertFrom-Json
# Verify every original before deletion. Newly generated verification/history stays outside this list.
foreach ($entry in $inventory.files) {
    $target = [System.IO.Path]::GetFullPath((Join-Path $taskRoot $entry.path))
    if (-not $target.StartsWith($taskRoot + '\', [System.StringComparison]::OrdinalIgnoreCase)) { throw 'Path escapes workspace' }
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Original changed: $($entry.path)" }
}
foreach ($directory in @('agent_system', 'tests', 'validation', 'examples')) {
    $target = (Resolve-Path -LiteralPath (Join-Path $taskRoot $directory)).Path
    if (-not $target.StartsWith($taskRoot + '\', [System.StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe removal target' }
    if ((Get-Item -LiteralPath $target).Attributes -band [System.IO.FileAttributes]::ReparsePoint) { throw 'Linked removal target' }
    if (Get-ChildItem -LiteralPath $target -Recurse -Force | Where-Object { $_.Attributes -band [System.IO.FileAttributes]::ReparsePoint }) { throw 'Linked descendant' }
    Remove-Item -LiteralPath $target -Recurse -Force
}
foreach ($entry in $inventory.files) {
    if ($entry.path.StartsWith('docs/') -or ($entry.path -notmatch '/' -and $entry.path -notin @('README.md', 'pyproject.toml', '.gitignore'))) {
        $target = [System.IO.Path]::GetFullPath((Join-Path $taskRoot $entry.path))
        if (-not $target.StartsWith($taskRoot + '\', [System.StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe file removal target' }
        Remove-Item -LiteralPath $target -Force
    }
}
# Remove only empty historical directories, deepest first, bounded to the original docs tree.
Get-ChildItem -LiteralPath (Join-Path $taskRoot 'docs') -Directory -Recurse | Sort-Object { $_.FullName.Length } -Descending | ForEach-Object {
    $target = $_.FullName
    if (-not $target.StartsWith((Join-Path $taskRoot 'docs') + '\', [System.StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe empty directory target' }
    if (-not (Get-ChildItem -LiteralPath $target -Force)) { Remove-Item -LiteralPath $target }
}
Get-ChildItem -LiteralPath (Join-Path $taskRoot '.test-tmp\stage24-prepared') -Directory | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $taskRoot -Recurse
}
Write-Output 'Verified archive preserved; active source installed.'
