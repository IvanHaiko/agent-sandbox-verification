"""One-time inventory and preparation; original files are never deleted here."""
import ast
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'docs/stage24-verification'
PREP = ROOT / '.test-tmp/stage24-prepared'
OUT.mkdir(exist_ok=True)
PREP.mkdir(exist_ok=True)


def write(name, data):
    path = PREP / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(data, encoding='utf-8')


def source(name):
    return (ROOT / name).read_text(encoding='utf-8-sig')


def category(path):
    name = path.as_posix()
    if name == 'agent_system/native_codex_linux.py':
        return 'KEEP', 'Validated native Linux launcher; rename permission profile and consolidate artifact/receipt helpers.'
    if name in {'validation/stage23_wsl_workflow.py', 'validation/stage23_wsl_continuation.py',
                'validation/stage23_labels_contract.py', 'validation/test_stage23_wsl_workflow.py',
                'validation/test_stage23_continuation.py'}:
        return 'CONSOLIDATE', 'Promote verified behavior; discard historical gate/counter/driver scaffolding.'
    if name == 'agent_system/native_codex.py':
        return 'HISTORICAL VALIDATION', 'Failed Windows native experiment; no active WSL dependency.'
    if name.startswith('agent_system/'):
        return 'LEGACY FALLBACK', 'Complete old package dependency closure archived for manual rollback; no active imports.'
    return 'HISTORICAL VALIDATION', 'Old stage driver, test, example, configuration or assessment; snapshot preserved.'


files = []
for prefix in ['agent_system', 'tests', 'validation', 'examples', '.agent_system', 'docs']:
    for path in sorted((ROOT / prefix).rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or 'stage24-verification' in path.parts:
            continue
        files.append(path.relative_to(ROOT))
files += [p.relative_to(ROOT) for p in ROOT.iterdir() if p.is_file()]
inventory = []
for relative in files:
    path = ROOT / relative
    data = path.read_bytes()
    kind, reason = category(relative)
    imports = []
    if path.suffix == '.py':
        try:
            tree = ast.parse(data.decode('utf-8-sig'))
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    imports.extend(a.name for a in node.names)
                elif isinstance(node, ast.ImportFrom):
                    imports.append('.' * node.level + (node.module or ''))
        except (ValueError, SyntaxError, UnicodeError):
            pass  # raw evidence snapshots can be partial source
    inventory.append({'path': relative.as_posix(), 'classification': kind, 'reason': reason,
                      'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                      'lines': len(data.splitlines()) if path.suffix == '.py' else None,
                      'imports': sorted(set(imports))})


def metrics(prefix, test=False):
    entries = [r for r in inventory if r['path'].startswith(prefix + '/') and r['path'].endswith('.py')]
    if prefix == 'validation' and not test:
        entries = [r for r in entries if not Path(r['path']).name.startswith('test_')]
    return {'files': len(entries), 'lines': sum(r['lines'] for r in entries)}


before = {'production': metrics('agent_system'), 'validation_scripts': metrics('validation'),
          'test_files': len([r for r in inventory if r['path'].startswith(('tests/', 'validation/'))
                             and Path(r['path']).name.startswith('test_') and r['path'].endswith('.py')]),
          'historical_source_bytes': sum(r['bytes'] for r in inventory),
          'inventory_files': len(inventory)}
(OUT / 'inventory-before.json').write_text(json.dumps({'counts': before, 'files': inventory}, indent=2), encoding='utf-8')
lines = ['# Before-cleanup inventory', '', 'Recorded before deletion. JSON includes hashes and import edges for every file.', '',
         'The native closure is native_codex_linux + WSL workflow + labels contract + optional WSL continuation roles.',
         'All other old package imports form the manual rollback closure. No active native-to-legacy edge exists.', '',
         '| Module | Class | Disposition |', '|---|---|---|']
for r in inventory:
    if r['path'].startswith(('agent_system/', 'tests/', 'validation/')) and r['path'].endswith('.py'):
        lines.append(f"| `{r['path']}` | {r['classification']} | {r['reason']} |")
(OUT / 'INVENTORY_BEFORE.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')

# Preserve source and history with original relative paths: this checkout has no Git history.
history = ROOT / 'docs/history'
history.mkdir(exist_ok=True)
archive = history / 'pre-cleanup.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for relative in files:
        zipped.write(ROOT / relative, relative.as_posix())
with zipfile.ZipFile(archive) as zipped:
    assert zipped.testzip() is None
    for r in inventory:
        assert hashlib.sha256(zipped.read(r['path'])).hexdigest() == r['sha256']
(OUT / 'archive-receipt.json').write_text(json.dumps({'archive': 'docs/history/pre-cleanup.zip',
    'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'entries': len(files),
    'bytes': archive.stat().st_size, 'all_entry_hashes_verified': True}, indent=2), encoding='utf-8')

# Copy final assessments and their evidence with original relative layout, preserving links.
for relative in files:
    name = relative.as_posix()
    if (relative.parent == Path('.') and name.startswith(('STAGE20', 'STAGE21', 'STAGE22', 'STAGE23'))
        or name.startswith(('docs/stage20-', 'docs/stage21-', 'docs/stage21a-', 'docs/stage22-',
                               'docs/stage23-', 'docs/stage23a-', 'docs/stage23b-'))):
        destination = history / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes((ROOT / relative).read_bytes())

write('agent_system/__init__.py', '"""Controller-owned artifact workflows using fresh native WSL Codex contexts."""\n')

# Artifact integrity, snapshots, hashing and diffing have one active implementation.
native = source('agent_system/native_codex_linux.py')
start = native.index('def snapshot(')
end = native.index('def native_errors(')
artifact_functions = native[start:end]
flow = source('validation/stage23_wsl_workflow.py')
helper_start = flow.index('def save(')
helper_end = flow.index('def run_trial(')
helpers = flow[helper_start:helper_end]
helpers = helpers.replace("prefix='stage23-flow-'", "prefix='codex-role-'")
helpers = helpers.replace("startswith('stage23-flow-')", "startswith('codex-role-')")
helpers = helpers.replace('Stage23 Controller', 'Codex Controller').replace('stage23@example.invalid', 'controller@example.invalid')
helpers = helpers.replace('def freeze_design(directory, design_bytes):', 'def freeze_design(directory, design_bytes, contract):')
write('agent_system/artifacts.py', '"""Controller artifact integrity and owned-workspace lifecycle."""\n'
      'import ast\nimport difflib\nimport hashlib\nimport json\nfrom pathlib import Path\n'
      'import shutil\nimport subprocess\nimport tempfile\nimport time\n\n' + artifact_functions + helpers +
      '\ndef changed_files(before, after):\n'
      '    return sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))\n\n'
      'def artifact_diff(before, after, target):\n'
      "    return ''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True),\n"
      "        fromfile='a/' + target, tofile='b/' + target))\n")
native = native[:start] + native[end:]
native = native.replace('import difflib\n', '').replace('import hashlib\n', '')
native = native.replace('import time\n', 'import time\n\nfrom .artifacts import snapshot, digest, changed_files, artifact_diff\n')
native = native.replace('Opt-in native Linux', 'Native Linux').replace('stage23', 'role_workspace')
native = native.replace("sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))", 'changed_files(before, after)')
native = native.replace("sorted(k for k in before.keys() | after.keys() if before.get(k) != after.get(k))", 'changed_files(before, after)')
native = native.replace("''.join(difflib.unified_diff(before[target].decode().splitlines(True),\n                after[target].decode().splitlines(True), fromfile='a/' + target, tofile='b/' + target))", 'artifact_diff(before[target], after[target], target)')
# Shared command and metadata extraction, preserving exact settings and receipt fields.
cmd_start = native.index('        argv = [self.executable, \'--no-daemon\'')
cmd_end = native.index("        record['command'] = argv", cmd_start)
command = native[cmd_start:cmd_end].replace('        argv = ', '        return ')
command = command.replace('*self.permissions(writable),', '*self.permissions(writable),')
metadata_start = native.index("        for name, key in (('model', 'resolved_model')")
metadata_end = native.index('        # Never persist', metadata_start)
metadata = native[metadata_start:metadata_end]
native = native[:cmd_start] + '        argv = self.command(workspace, model, effort, writable)\n' + native[cmd_end:]
native = native.replace(metadata, '        self.metadata(record, outcome)\n')
second_start = native.index('        argv = [self.executable, \'--no-daemon\'')
second_end = native.index("        record['command'] = argv", second_start)
native = native[:second_start] + "        argv = self.command(workspace, 'gpt-6.1-sol', 'medium')[:-1] + [\n            '--output-schema', str(workspace / 'schema.json'), '--output-last-message', str(output), '-']\n" + native[second_end:]
second_meta_start = native.index("        for name, key in (('model', 'resolved_model')")
second_meta_end = native.index('        after = snapshot', second_meta_start)
native = native[:second_meta_start] + '        self.metadata(record, outcome)\n' + native[second_meta_end:]
# Error extraction was duplicated beside metadata as well.
native = native.replace("        if outcome['exit_code'] != 0:\n            record['native_error_diagnostics'] = native_errors(outcome['stderr'])\n", '')
methods = '\n    def command(self, workspace, model, effort, writable=None):\n' + command
methods += '\n    @staticmethod\n    def metadata(record, outcome):\n'
methods += "        if outcome['exit_code'] != 0:\n            record['native_error_diagnostics'] = native_errors(outcome['stderr'])\n" + metadata
native += methods
write('agent_system/native_codex_linux.py', native)

# Keep the validated sequence, removing gate-specific global output roots and counters.
body = flow[flow.index('def run_trial('):flow.index('def main():')]
body = body.replace('def run_trial(runner, number, *, trial_id=None, canonical_contract=None, initial_roles=(), review_hook=None):\n    trial_id = trial_id or \'minimal-\' + str(number)\n    directory = OUT / trial_id',
    'def run_workflow(runner, directory, contract, *, canonical_contract=None, initial_roles=(), review_hook=None):\n    directory = Path(directory).resolve()\n    trial_id = directory.name\n    TARGET = contract.TASK[\'file\']\n    BASELINE = contract.BASELINE')
body = body.replace('freeze_design(directory, (tester_workspace / DESIGN_TARGET).read_bytes())',
                    'freeze_design(directory, (tester_workspace / DESIGN_TARGET).read_bytes(), contract)')
body = body.replace('canonical_contract or contract.TASK)', 'canonical_contract or contract.TASK, contract)')
body = body.replace('Read role-input.md, TASK.json and src/normalize_labels.py.\\n', 'Read role-input.md, TASK.json and {TARGET}.\\n')
body = body.replace('Only src/normalize_labels.py may change.', 'Only {TARGET} may change.')
body = body.replace("        implementation_workspace = owned_workspace", "        implementer_input = implementer_input.replace('{TARGET}', TARGET)\n        implementation_workspace = owned_workspace")
write('agent_system/controller.py', '"""Validated native artifact workflow; Controller owns handoff, freeze and acceptance."""\n'
      'import json\nfrom pathlib import Path\nimport time\n\n'
      'from .artifacts import (archive, cleanup, digest, freeze_design, owned_workspace,\n'
      '                        require, require_frozen, save, snapshot)\n\n'
      "DESIGN_TARGET = 'tests/test-design.json'\n\n\n" + body)

roles = source('validation/stage23_wsl_continuation.py')
roles = roles[roles.index('TEXT ='):roles.index('def prerequisite(')]
arch_start = roles.index('ARCHITECT_SCHEMA =')
arch_end = roles.index('def validate_semantic(')
arch = roles[arch_start:arch_end].replace('ARCHITECT_SCHEMA =', 'return').replace('flow.contract.', 'contract.').replace('flow.TARGET', "contract.TASK['file']")
roles = roles[:arch_start] + 'def architect_schema(contract):\n' + '\n'.join('    ' + line if line else '' for line in arch.splitlines()) + '\n\n' + roles[arch_end:]
roles = roles.replace('def validate_semantic(data, schema):', 'def validate_semantic(data, schema, contract):')
roles = roles.replace('if schema is ARCHITECT_SCHEMA:', "if 'allowed_mutation_scope' in schema['properties']:")
roles = roles.replace('def semantic_role(runner, directory, trial_id, role, bundle, schema, instruction, owned):',
                      'def semantic_role(runner, directory, trial_id, role, bundle, schema, instruction, owned, contract):')
roles = roles.replace('def review(runner, directory, assessment, owned, canonical):',
                      'def review(runner, directory, assessment, owned, canonical, contract):')
roles = roles.replace('flow.contract.', 'contract.').replace('flow.TARGET', "contract.TASK['file']")
roles = roles.replace('validate_semantic(data, schema)', 'validate_semantic(data, schema, contract)')
roles = roles.replace('No implementation changes.\', owned)', 'No implementation changes.\', owned, contract)')
# The old marginal-value assessment belongs to history, not production.
marginal_start = roles.index("    flow.save(directory, 'reviewer-marginal-value'")
marginal_end = roles.index('    return result', marginal_start)
roles = roles[:marginal_start] + roles[marginal_end:]
write('agent_system/roles.py', '"""Optional read-only role instructions and structured artifact contracts."""\n'
      'import json\nimport jsonschema\nfrom . import artifacts as flow\nfrom .artifacts import digest\n\n' + roles)

contract = source('validation/stage23_labels_contract.py').replace("TASK_ID = 'STAGE20-LABELS'", "TASK_ID = 'LABEL-NORMALIZATION'")
contract += "\nBASELINE = 'def normalize_labels(value: str) -> list[str]:\\n    raise NotImplementedError\\n'\n"
write('validation/labels_contract.py', contract)
write('validation/__init__.py', '"""Small native WSL integration fixture; historical stages are archived."""\n')

freeze_tests = source('validation/test_stage23_wsl_workflow.py')
freeze_tests = freeze_tests.replace('import stage23_labels_contract as contract', 'from validation import labels_contract as contract')
freeze_tests = freeze_tests.replace('from stage23_wsl_workflow import freeze_design, require_frozen, save', 'from agent_system.artifacts import freeze_design, require_frozen, save')
freeze_tests = freeze_tests.replace("prefix='stage23-offline-'", "prefix='native-offline-'")
freeze_tests = freeze_tests.replace('freeze_design(directory, json.dumps(design()).encode())', 'freeze_design(directory, json.dumps(design()).encode(), contract)')
write('tests/test_acceptance.py', freeze_tests)
semantic_tests = source('validation/test_stage23_continuation.py')
semantic_tests = semantic_tests.replace('import stage23_wsl_continuation as continuation', 'from agent_system import roles as continuation\nfrom validation import labels_contract as contract')
semantic_tests = semantic_tests.replace('continuation.flow.contract.TASK', 'contract.TASK').replace('continuation.ARCHITECT_SCHEMA', 'continuation.architect_schema(contract)')
semantic_tests = semantic_tests.replace('continuation.REVIEW_SCHEMA)', 'continuation.REVIEW_SCHEMA, contract)')
semantic_tests = semantic_tests.replace('continuation.architect_schema(contract))', 'continuation.architect_schema(contract), contract)')
write('tests/test_roles.py', semantic_tests)

print(json.dumps(before, indent=2))
print('Archive verified; prepared active files:', len(list(PREP.rglob('*.py'))))
