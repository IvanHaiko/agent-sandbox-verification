"""Read-only final artifact/semantic audit inside WSL; no native model or test calls."""
import ast
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from agent_system.artifacts import digest, require_frozen, snapshot
from agent_system.roles import load_canonical
from validation import labels_contract as contract

OUT = ROOT / 'docs/stage24-verification'
paths = ['before/native-baseline', 'after/minimal', 'after/full']
records, repositories, sessions = [], [], []
for name in paths:
    directory = OUT / name
    trial = json.loads((directory / 'assessment.json').read_text())
    assert trial['accepted'] and trial['cleanup_passed'] and not trial['cleanup_failures']
    freeze = json.loads((directory / 'test-freeze.json').read_text())
    require_frozen(directory, freeze)
    exposure = json.loads((directory / 'candidate-exposure.json').read_text())
    assert exposure['sequence'] > freeze['sequence'] and exposure['exposed_at'] >= freeze['frozen_at']
    assert not exposure['tester_session_running'] and freeze['tester_execution_ended']
    assert not freeze['candidate_visible_during_design']
    candidate = digest((directory / 'candidate.py').read_bytes())
    assert candidate == trial['candidate_sha256'] == trial['acceptance']['candidate_sha256_before']
    assert candidate == trial['acceptance']['candidate_sha256_after']
    assert trial['acceptance']['model_requests'] == trial['acceptance']['tester_sessions'] == 0
    assert trial['acceptance']['returncode'] == 0
    assert all(c['passed'] for c in trial['acceptance']['result']['cases'])
    assert trial['acceptance']['result']['interface']
    assert all(c['passed'] for c in trial['acceptance']['result']['properties'])
    for role in trial['roles']:
        assert role['execution_status'] == 'completed'
        assert role['model'] == role['resolved_model'] == 'gpt-6.1-sol' and role['reasoning'] == 'medium'
        assert role['fresh_context'] and role['ephemeral'] and not role['conversation_history_inherited']
        assert role['sandbox_preflight_passed'] and role['mutation_scope_valid']
        assert role['shutdown_confirmed'] and role['cleanup_passed']
        sessions.append(role['thread_id'])
    for workspace in trial['owned_workspaces']:
        target = Path(workspace)
        assert target.parent == Path.home() and target.name.startswith(('stage23-flow-', 'codex-role-'))
        assert not target.exists()
        repositories.append(workspace)
    records.append({'workflow': name, 'accepted': True, 'case_count': trial['case_count'],
        'roles': [{'role': r['role'], 'session': r['thread_id'], 'seconds': r['elapsed_seconds']}
                  for r in trial['roles']], 'candidate_sha256': candidate,
        'frozen_design_sha256': freeze['design_sha256'], 'cleanup_verified': True})
assert all(sessions) and len(sessions) == len(set(sessions))
assert len(repositories) == len(set(repositories))
load_canonical(OUT / 'after/full', contract)
assert json.loads((OUT / 'after/full/reviewer-result.json').read_text())['recommendation'] == 'accept'
for item in json.loads((OUT / 'executed-source.json').read_text()):
    assert digest((ROOT / item['path']).read_bytes()) == item['sha256']

receipt = json.loads((OUT / 'archive-receipt.json').read_text())
assert digest((ROOT / receipt['archive']).read_bytes()) == receipt['sha256']
with zipfile.ZipFile(ROOT / receipt['archive']) as history:
    old = ast.parse(history.read('validation/stage23_labels_contract.py').decode())
    # Evaluate only the three recorded literal contract assignments, never archived runtime code.
    assignments = [n for n in old.body if isinstance(n, ast.Assign) and
                   any(isinstance(t, ast.Name) and t.id in {'TASK_ID', 'CRITERIA', 'TASK'} for t in n.targets)]
    namespace = {}
    exec(compile(ast.Module(body=assignments, type_ignores=[]), '<historical-contract>', 'exec'), namespace)
    assert {k: v for k, v in namespace['TASK'].items() if k != 'task_id'} == {
        k: v for k, v in contract.TASK.items() if k != 'task_id'}
    current = ast.parse(Path(contract.__file__).read_text())
    for function in ['acceptance_source', 'validate_candidate', 'validate_design', 'contract_interpret']:
        original = next(n for n in old.body if isinstance(n, ast.FunctionDef) and n.name == function)
        present = next(n for n in current.body if isinstance(n, ast.FunctionDef) and n.name == function)
        assert ast.dump(original) == ast.dump(present)

result = {'gate': 'passed', 'workflows': records, 'distinct_contexts': len(sessions),
    'owned_repositories_verified_absent': len(repositories), 'source_hashes_match_execution_snapshot': True,
    'archive_hash_verified': True, 'original_contract_semantics_unchanged': True,
    'fixture_identity_rename': {'before': namespace['TASK']['task_id'], 'after': contract.TASK_ID},
    'original_harness_interface_design_validation_and_failure_interpreter_unchanged': True,
    'no_model_or_acceptance_calls_in_this_audit': True}
(OUT / 'integrity-audit.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({k: v for k, v in result.items() if k != 'workflows'}, indent=2))
